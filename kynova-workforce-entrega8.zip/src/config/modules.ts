import { EXEC, STAFF, type Role } from "./roles";

export type AppModule = { slug: string; name: string; roles: Role[]; nav: boolean };

/** Single source of truth for everything under /app/*. */
export const MODULES: AppModule[] = [
  { slug: "dashboard", name: "Dashboard", roles: STAFF, nav: true },
  { slug: "crm", name: "CRM", roles: [...EXEC, "sales", "marketing", "support"], nav: true },
  { slug: "communications", name: "Communications", roles: [...EXEC, "sales", "marketing", "support"], nav: true },
  { slug: "billing", name: "Billing", roles: ["super_admin", "owner", "ceo", "administrator", "finance"], nav: true },
  { slug: "security", name: "Security", roles: ["super_admin", "owner", "ceo", "administrator"], nav: true },
  { slug: "mission-control", name: "Mission Control", roles: STAFF, nav: true },
  { slug: "analytics-bi", name: "Analytics BI", roles: STAFF, nav: true },
  { slug: "integrations", name: "Integrations", roles: [...EXEC, "finance", "marketing"], nav: true },
  { slug: "analytics", name: "Analytics", roles: ["super_admin", "owner", "ceo", "administrator", "manager", "finance", "marketing", "sales", "support", "employee"], nav: true },
  { slug: "growth", name: "GrowthOS", roles: [...EXEC, "marketing", "sales"], nav: true },
  { slug: "seo", name: "SEO Engine", roles: [...EXEC, "marketing"], nav: true },
  { slug: "social-media", name: "Social Media", roles: [...EXEC, "marketing"], nav: true },
  { slug: "google-business", name: "Google Business", roles: [...EXEC, "marketing"], nav: true },
  { slug: "finance", name: "Finance", roles: ["super_admin", "owner", "ceo", "administrator", "finance"], nav: true },
  { slug: "team", name: "Mi equipo", roles: STAFF, nav: true },
  { slug: "workforce", name: "Equipo IA", roles: STAFF, nav: false },
  { slug: "marketplace", name: "Marketplace", roles: STAFF, nav: true },
  { slug: "partners", name: "Partners", roles: [...EXEC, "sales", "marketing", "finance"], nav: true },
  { slug: "referrals", name: "Referrals", roles: [...EXEC, "sales", "marketing", "finance"], nav: true },
  { slug: "portal", name: "Portal", roles: [...EXEC, "sales", "marketing", "finance"], nav: true },
  { slug: "activation", name: "Activation", roles: [...EXEC, "sales", "marketing", "finance"], nav: true },
  { slug: "academy", name: "Academy", roles: STAFF, nav: true },
  { slug: "ai-studio", name: "AI Studio", roles: [...EXEC, "marketing", "sales"], nav: true },
  { slug: "projects", name: "Projects", roles: STAFF, nav: true },
  { slug: "automation", name: "Automation", roles: EXEC, nav: true },
  { slug: "settings", name: "Settings", roles: ["super_admin", "owner", "ceo", "administrator"], nav: true },
  { slug: "profile", name: "Profile", roles: STAFF, nav: true },
  { slug: "notifications", name: "Notifications", roles: STAFF, nav: true },
  { slug: "admin", name: "Admin", roles: ["super_admin", "owner", "administrator"], nav: true },
  { slug: "onboarding", name: "Onboarding", roles: [...STAFF, "guest"], nav: false },
];

export const canAccess = (role: Role, slug: string) =>
  MODULES.find((m) => m.slug === slug)?.roles.includes(role) ?? false;
