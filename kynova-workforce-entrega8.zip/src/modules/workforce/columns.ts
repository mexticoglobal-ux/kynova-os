import type { Kind } from "./store";

export const TABLE: Record<Kind, string> = { package: "wf_packages", skillInstall: "wf_skill_installs", thread: "wf_threads", message: "wf_messages", objective: "wf_objectives", agenda: "wf_agenda", run: "wf_runs", memory: "wf_memory", budget: "wf_budgets", usage: "wf_usage", budgetRequest: "wf_budget_requests" };
export const KIND_LIST = Object.keys(TABLE) as Kind[];
/** Nothing is deleted anywhere: things are archived, paused, superseded or deactivated. */
export const SOFT_DELETE: ReadonlySet<Kind> = new Set<Kind>();
export const REMOVABLE: ReadonlySet<Kind> = new Set<Kind>();
/** Append-only: a message and a usage row are evidence and never change. */
export const IMMUTABLE_KINDS: ReadonlySet<Kind> = new Set<Kind>(["message", "usage"]);
export const FROZEN_COLS: Partial<Record<Kind, readonly string[]>> = { package: ["packageKey", "version", "kind"], skillInstall: ["employeeKey", "skillKey"], thread: ["employeeKey", "userId"], objective: ["employeeKey"], agenda: ["employeeKey"], run: ["agendaId", "employeeKey"], memory: ["employeeKey"], budget: ["scope"], budgetRequest: ["employeeKey", "period", "amountMicros"] };
export const BOOLEAN_COLS: ReadonlySet<string> = new Set(["requiresApproval", "active"]);
export const JSON_COLS: ReadonlySet<string> = new Set(["manifest", "links", "attachments", "dependsOn"]);
export const COLUMNS: Record<Kind, readonly string[]> = {
  package: ["id", "tenantId", "packageKey", "kind", "version", "name", "manifest", "status", "source", "installedBy", "createdAt", "updatedAt"],
  skillInstall: ["id", "tenantId", "employeeKey", "skillKey", "version", "status", "installedBy", "createdAt", "updatedAt"],
  thread: ["id", "tenantId", "employeeKey", "userId", "title", "status", "messageCount", "lastMessageAt", "createdAt", "updatedAt"],
  message: ["id", "tenantId", "threadId", "role", "body", "mode", "provider", "links", "attachments", "createdBy", "createdAt"],
  objective: ["id", "tenantId", "employeeKey", "title", "description", "priority", "status", "dependsOn", "metric", "dueAt", "createdBy", "createdAt", "updatedAt"],
  agenda: ["id", "tenantId", "employeeKey", "objectiveId", "title", "instruction", "triggerKind", "eventAction", "everyMinutes", "priority", "status", "requiresApproval", "dependsOn", "nextRunAt", "lastRunAt", "runCount", "createdBy", "createdAt", "updatedAt"],
  run: ["id", "tenantId", "agendaId", "employeeKey", "firedBy", "status", "reason", "threadId", "costMicros", "tokens", "mode", "decidedBy", "createdAt", "updatedAt", "finishedAt"],
  memory: ["id", "tenantId", "employeeKey", "kind", "title", "body", "source", "active", "createdBy", "createdAt", "updatedAt"],
  budget: ["id", "tenantId", "scope", "monthlyMicros", "currency", "updatedBy", "createdAt", "updatedAt"],
  usage: ["id", "tenantId", "employeeKey", "period", "costMicros", "tokens", "provider", "mode", "refKind", "refId", "createdAt"],
  budgetRequest: ["id", "tenantId", "employeeKey", "period", "amountMicros", "reason", "status", "requestedBy", "decidedBy", "decidedAt", "createdAt", "updatedAt"],
};
export const UNIQUE: Partial<Record<Kind, readonly (readonly string[])[]>> = { package: [["packageKey", "version"]], skillInstall: [["employeeKey", "skillKey"]], budget: [["scope"]] };
/** Only one ACTIVE version of a package at a time. */
export const UNIQUE_WHEN: Partial<Record<Kind, readonly { cols: readonly string[]; col: string; in: readonly string[] }[]>> = { package: [{ cols: ["packageKey"], col: "status", in: ["active"] }] };
export const snake = (k: string) => k.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
export const camel = (k: string) => k.replace(/_([a-z0-9])/g, (_m, c: string) => c.toUpperCase());
