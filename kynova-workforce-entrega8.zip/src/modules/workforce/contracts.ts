/** What is and is not implemented in Workforce (the AI Employee Framework). Shown as-is in the UI so nothing is presented as more than it is. */
export const ARCHITECTURE_STATUS = {
  employee_registry: "built",
  skills: "built_reasoning_only",
  installable_packages: "built_declarative",
  conversations: "built_private_per_user",
  objectives: "built",
  agenda: "built_manual_and_on_demand",
  continuous_scheduler_worker: "not_built",
  memory: "built_manual_entries",
  budget: "built_provider_independent",
  evidence: "built_activity_engine",
  ai_provider_interface: "built",
  real_ai_provider: "not_connected",
  employee_tools: "partial_read_only",
  skill_marketplace_sales: "not_built",
  cross_company_learning: "not_built",
} as const;
