import { createMemoryWorkforceStore } from "./store-memory";
import type { WorkforceStore } from "./store";

let override: WorkforceStore | null = null;
/** Tests and tooling can inject a store. */
export const setWorkforceStore = (s: WorkforceStore | null): void => { override = s; };
const g = globalThis as unknown as { __kynovaWorkforceDevStore?: WorkforceStore };
const isDevLike = (): boolean => process.env.APP_ENV === "local" || process.env.NODE_ENV === "test" || process.env.NODE_ENV === "development";

/**
 * Resolves the store for the current request. In the Worker the D1 binding is only known per request, so it is read lazily.
 * Without a binding (a laptop running `next dev`) an in-memory store keeps the module usable; elsewhere a missing binding fails closed.
 */
export async function getWorkforceStore(): Promise<WorkforceStore> {
  if (override) return override;
  try {
    const { getCloudflareContext } = await import("@opennextjs/cloudflare");
    const d1 = getCloudflareContext().env.DB;
    if (d1) { const { createD1WorkforceStore } = await import("./store-d1"); return createD1WorkforceStore(d1); }
  } catch { /* no Cloudflare context */ }
  if (!isDevLike()) {
    const { WorkforceError } = await import("./errors");
    throw new WorkforceError("unavailable", "The Workforce database is not available. Check the D1 binding.");
  }
  return (g.__kynovaWorkforceDevStore ??= createMemoryWorkforceStore());
}
