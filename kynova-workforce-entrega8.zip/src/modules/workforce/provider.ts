import { WorkforceError } from "./errors";
import type { Mode } from "./domain";

/**
 * AI Provider Interface (adapter). The Framework NEVER imports a vendor SDK or the AI Kernel's provider code: it talks to this port. Claude, OpenAI,
 * Gemini, Mistral, DeepSeek or a future model are adapters registered behind it, so changing or adding a provider never touches the Framework.
 * Entrega 8 connects NO real provider: the only connected adapter is `simulated`, and everything it produces is labelled Simulation.
 */
export interface ProviderRequest { tenantId: string; employeeKey: string; employeeName: string; system: string; messages: { role: "user" | "employee"; content: string }[]; maxOutputTokens: number; locale: "es" | "en"; facts: ProviderFacts }
/** What the framework knows, so a provider that cannot reason can still say truthfully what is on record. */
export interface ProviderFacts { objectives: number; memories: number; skills: string[]; lastUserMessage: string }
export interface ProviderResult { text: string; inputTokens: number; outputTokens: number; costMicros: number; model: string; mode: Mode }
export interface AiProvider { id: string; label: string; /** False for adapters that are declared but not wired yet. */ connected: boolean; complete(req: ProviderRequest): Promise<ProviderResult> }

export const estimateTokens = (s: string): number => Math.ceil(s.length / 4);
/** Simulated price (USD micros per 1,000 tokens). Not a real charge; it lets budgets and approvals be exercised honestly before a provider is connected. */
export const SIMULATED_MICROS_PER_1K_TOKENS = 2000;

export function createSimulatedProvider(): AiProvider {
  return {
    id: "simulated", label: "Simulation", connected: true,
    async complete(r) {
      const f = r.facts, es = r.locale === "es";
      const skills = f.skills.length ? f.skills.join(", ") : es ? "ninguna" : "none";
      const text = es
        ? `[Simulación] Soy ${r.employeeName}. Todavía no hay un proveedor de IA conectado, así que no puedo razonar sobre tu mensaje ni dar una recomendación real. Esto es lo que tengo registrado: ${f.objectives} objetivo(s) activo(s), ${f.memories} dato(s) en memoria y estas skills: ${skills}. Recibí: «${f.lastUserMessage.slice(0, 160)}».`
        : `[Simulation] I am ${r.employeeName}. No AI provider is connected yet, so I cannot reason about your message or give a real recommendation. This is what I have on record: ${f.objectives} active objective(s), ${f.memories} memory item(s) and these skills: ${skills}. I received: "${f.lastUserMessage.slice(0, 160)}".`;
      const inputTokens = estimateTokens(r.system) + r.messages.reduce((n, m) => n + estimateTokens(m.content), 0), outputTokens = estimateTokens(text);
      return { text, inputTokens, outputTokens, costMicros: Math.ceil(((inputTokens + outputTokens) / 1000) * SIMULATED_MICROS_PER_1K_TOKENS), model: "simulated-1", mode: "simulation" };
    },
  };
}
/** Declared, not wired: calling one fails closed with a clear error instead of pretending. */
const notConnected = (id: string, label: string): AiProvider => ({ id, label, connected: false, async complete() { throw new WorkforceError("provider_not_connected", `The ${label} provider is not connected yet.`); } });

const g = globalThis as unknown as { __kynovaWfProviders?: Map<string, AiProvider> };
const reg = (): Map<string, AiProvider> => (g.__kynovaWfProviders ??= new Map([createSimulatedProvider(), notConnected("claude", "Claude"), notConnected("openai", "OpenAI"), notConnected("gemini", "Gemini"), notConnected("mistral", "Mistral"), notConnected("deepseek", "DeepSeek")].map((p) => [p.id, p])));
/** The place a real adapter plugs in later (it replaces the declared stub with the same id). */
export function registerProvider(p: AiProvider): void { reg().set(p.id, p); }
export const listProviders = (): AiProvider[] => [...reg().values()];
/** Provider for a company. Per-company choice is a later setting; today it follows WORKFORCE_PROVIDER and defaults to the simulation. */
export function resolveProvider(_tenantId: string, id: string | undefined = process.env.WORKFORCE_PROVIDER): AiProvider {
  const p = reg().get(id && id.length ? id : "simulated");
  if (!p) throw new WorkforceError("provider_not_connected", "That AI provider does not exist.");
  return p;
}
