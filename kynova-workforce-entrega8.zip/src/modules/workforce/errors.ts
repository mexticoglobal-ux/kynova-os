export type WorkforceErrorCode = "forbidden" | "not_found" | "validation_failed" | "conflict" | "duplicate" | "invalid_state" | "limit_exceeded" | "unavailable" | "ai_unavailable" | "budget_exceeded" | "provider_not_connected" | "plan_required";
const STATUS: Record<WorkforceErrorCode, number> = { forbidden: 403, not_found: 404, validation_failed: 422, conflict: 409, duplicate: 409, invalid_state: 409, limit_exceeded: 403, unavailable: 503, ai_unavailable: 503, budget_exceeded: 402, provider_not_connected: 503, plan_required: 403 };
export class WorkforceError extends Error {
  readonly status: number;
  constructor(readonly code: WorkforceErrorCode, message: string, readonly details?: Record<string, unknown>) { super(message); this.name = "WorkforceError"; this.status = STATUS[code]; }
}
export const isWorkforceError = (e: unknown): e is WorkforceError => e instanceof WorkforceError || (typeof e === "object" && e !== null && (e as { name?: string }).name === "WorkforceError");
