import { NextResponse, type NextRequest } from "next/server";
import { canAccess } from "@/config/modules";
import { isConfigError } from "@/platform/auth/errors";
import { assertSameOrigin, getAuthConfig, ok, problem, route } from "@/platform/auth/http";
import { requireApiSession } from "@/platform/auth/session";
import { WorkforceError, isWorkforceError } from "./errors";
import { getWorkforceService } from "./server";
import type { Actor, WorkforceService } from "./service";
import { fromWire, queryObject, toWire } from "./wire";

/** Workforce has its own module slug in src/config/modules.ts. */
export const WORKFORCE_SLUG = "workforce";
export interface WorkforceRouteContext { actor: Actor; rid: string; svc: WorkforceService }

/** Verified session, module access for the role, an active company, CSRF checks on mutations, and Workforce/AI errors as problem+json. */
export function workforceRoute<C = unknown>(fn: (req: NextRequest, ctx: C, a: WorkforceRouteContext) => Promise<NextResponse>, opts: { mutating?: boolean } = {}) {
  return route<C>(async (req, ctx, rid) => {
    try {
      if (opts.mutating) assertSameOrigin(req, getAuthConfig());
      const s = await requireApiSession();
      if (!s.tenantId) throw new WorkforceError("forbidden", "Select or create a company first.");
      if (!canAccess(s.role, WORKFORCE_SLUG)) throw new WorkforceError("forbidden", "Your role cannot use Workforce.");
      const actor: Actor = { tenantId: s.tenantId, userId: s.user.id, role: s.role, requestId: rid };
      return await fn(req, ctx, { actor, rid, svc: await getWorkforceService() });
    } catch (e) {
      if (isWorkforceError(e)) return problem(e.code, e.status, e.message, rid, { ...(e.details?.fields ? { errors: e.details.fields } : {}), ...(e.details && !e.details.fields ? { details: e.details } : {}) });
      if (isConfigError(e) && !(e as { name?: string }).name?.startsWith("Missing")) return problem("ai_unavailable", 503, "This service is temporarily unavailable.", rid);
      throw e;
    }
  });
}
export async function readBody(req: NextRequest): Promise<unknown> {
  if (!req.headers.get("content-type")?.toLowerCase().startsWith("application/json")) throw new WorkforceError("validation_failed", "Content-Type must be application/json.");
  const text = await req.text();
  if (!text.trim()) return {};
  try { const b = JSON.parse(text) as unknown; if (b === null || typeof b !== "object" || Array.isArray(b)) throw 0; return fromWire(b); }
  catch { throw new WorkforceError("validation_failed", "The body must be a JSON object."); }
}
export const respond = (data: unknown, rid: string, status = 200) => ok(toWire(data), rid, status);
export const noContent = (rid: string) => new NextResponse(null, { status: 204, headers: { "X-Request-Id": rid, "Cache-Control": "no-store" } });

