import { z } from "zod";
import type { ActivitySink, SinkEvent } from "@/platform/activity";
import type { Role } from "@/config/roles";
import { allows } from "./access";
import {
  type AgendaRecord, type BudgetRecord, type BudgetRequestRecord, type Capability, type Link, type MemoryRecord, type MessageRecord, type Mode, type ObjectiveRecord, type PackageRecord, type RunRecord, type SkillInstallRecord, type ThreadRecord,
  agendaInput, agendaPatch, budgetInput, decisionInput, fireInput, installInput, memoryInput, memoryPatch, monthOf, objectiveInput, objectivePatch, sendInput, skillToggleInput, startThreadInput, employeeManifest,
} from "./domain";
import { WorkforceError } from "./errors";
import { estimateTokens, listProviders, resolveProvider, SIMULATED_MICROS_PER_1K_TOKENS, type AiProvider } from "./provider";
import { DEFAULT_SKILLS, builtinSkill, builtinSkills, skillFromManifest, type SkillDef } from "./skills";
import type { Kind, KindMap, WorkforceStore } from "./store";

export interface Actor { tenantId: string; userId: string; role: Role; requestId?: string }
/** Everything the Framework needs to know about WHO an employee is. Roster employees come from the Team module; package employees from the store. */
export interface EmployeeInfo { key: string; name: string; department: string; goal: string; instructions: string; /** The key evidence is filed under. */ activityKey: string; active: boolean; entitled: boolean; origin: "roster" | "package" }
export interface WorkforcePorts {
  employee(a: Actor, key: string): Promise<EmployeeInfo | null>;
  /** Every official roster member with its state for this company (one read), so screens can offer who can be given work. */
  roster(a: Actor): Promise<EmployeeInfo[]>;
  /** Code of the company's plan, or null when unknown. */
  plan(a: Actor): Promise<string | null>;
  /** Capability keys the Core can execute. A package may only require these. */
  capabilities(): ReadonlySet<string>;
}
export interface WorkforceDeps { store: WorkforceStore; ports: WorkforcePorts; newId: () => string; now?: () => number; activity?: ActivitySink; provider?: (tenantId: string) => AiProvider; locale?: "es" | "en" }
export type WorkforceService = ReturnType<typeof createWorkforceService>;

const PACKAGE_PLANS = new Set(["business", "enterprise"]);
const SYSTEM_THREAD_USER = "system:agenda";
const MAX_OUTPUT_TOKENS = 600;
const MIN_REQUEST_MICROS = 1_000_000;
const TICK_LIMIT = 20;
const HISTORY_MESSAGES = 12;

function parse<T extends z.ZodType>(schema: T, input: unknown): z.output<T> {
  const r = schema.safeParse(input);
  if (!r.success) throw new WorkforceError("validation_failed", "The request is not valid.", { fields: r.error.issues.map((i) => ({ field: i.path.join("."), message: i.message })) });
  return r.data;
}
const num = (n: number | null | undefined): number => n ?? 0;

type LooseCond = { col: string; op: "eq" | "ne"; value: string | number | boolean } | { col: string; op: "in"; value: readonly string[] } | { col: string; op: "gte" | "lte"; value: number };
interface LooseSpec { where?: readonly LooseCond[]; orderBy?: { col: string; dir: "asc" | "desc" }; limit: number; after?: { value: string | number; id: string } }
/** The store's typed columns, loosened for the service: the whitelist in columns.ts is what actually guards every column name. */
interface LooseStore { query<K extends Kind>(kind: K, tenantId: string, spec: LooseSpec): Promise<KindMap[K][]>; count(kind: Kind, tenantId: string, where?: readonly LooseCond[]): Promise<number>; sum(kind: Kind, tenantId: string, col: string, where?: readonly LooseCond[]): Promise<number> }

export function createWorkforceService(deps: WorkforceDeps) {
  const { store, ports } = deps, st = store as unknown as LooseStore, now = deps.now ?? Date.now, locale = deps.locale ?? "es";
  const need = (a: Actor, c: Capability): void => { if (!allows(a.role, c)) throw new WorkforceError("forbidden", "Your role cannot do this."); };
  const rec = async (a: Actor, e: SinkEvent): Promise<void> => {
    if (!deps.activity) return;
    await deps.activity.record({ tenantId: a.tenantId, ...(a.requestId ? { requestId: a.requestId } : {}) }, { module: "workforce", source: "workforce", actorKind: "user", actorId: a.userId, mode: "simulation", ...e });
  };
  const provider = (a: Actor): AiProvider => (deps.provider ?? ((t) => resolveProvider(t)))(a.tenantId);
  const modeOf = (p: AiProvider): Mode => (p.id === "simulated" ? "simulation" : "production");

  async function all<K extends Kind>(kind: K, a: Actor, spec: Partial<LooseSpec> = {}): Promise<KindMap[K][]> {
    const out: KindMap[K][] = []; let after: { value: string | number; id: string } | undefined;
    for (let i = 0; i < 20; i++) {
      const page = await st.query(kind, a.tenantId, { ...spec, limit: 500, ...(after ? { after } : {}) });
      out.push(...page);
      if (page.length < 500) break;
      const last = page[page.length - 1] as unknown as Record<string, string | number>, col = (spec.orderBy?.col ?? "createdAt");
      after = { value: last[col] as string | number, id: String(last.id) };
    }
    return out;
  }
  const getOr = async <K extends Kind>(kind: K, a: Actor, id: string, what: string): Promise<KindMap[K]> => {
    const r = await store.get(kind, a.tenantId, id);
    if (!r) throw new WorkforceError("not_found", `${what} not found.`);
    return r;
  };

  /* ───────────── Employees and skills ───────────── */

  async function packages(a: Actor): Promise<PackageRecord[]> { return all("package", a, { orderBy: { col: "createdAt", dir: "desc" } }); }
  async function resolveEmployee(a: Actor, key: string): Promise<EmployeeInfo> {
    const fromRoster = await ports.employee(a, key);
    if (fromRoster) return fromRoster;
    const pk = (await packages(a)).find((p) => p.kind === "employee" && p.packageKey === key && p.status === "active");
    if (pk) {
      const m = employeeManifest.parse(pk.manifest);
      return { key, name: m.name, department: m.department, goal: m.goal, instructions: m.instructions, activityKey: `pkg_${key}`.slice(0, 63), active: true, entitled: true, origin: "package" };
    }
    throw new WorkforceError("not_found", "AI employee not found.");
  }
  async function skillCatalog(a: Actor): Promise<SkillDef[]> {
    const fromPackages = (await packages(a)).filter((p) => p.kind === "skill" && p.status === "active").map((p) => skillFromManifest(p.manifest as never, p.source));
    const byKey = new Map(builtinSkills().map((s) => [s.key, s]));
    for (const s of fromPackages) byKey.set(s.key, s); // an installed package replaces the built-in skill of the same key
    return [...byKey.values()];
  }
  async function effectiveSkills(a: Actor, e: EmployeeInfo): Promise<{ skill: SkillDef; enabled: boolean; fromDefault: boolean }[]> {
    const cat = await skillCatalog(a), rows = await all("skillInstall", a, { where: [{ col: "employeeKey", op: "eq", value: e.key }] });
    const manifestSkills = e.origin === "package" ? employeeManifest.parse((await packages(a)).find((p) => p.packageKey === e.key && p.status === "active")?.manifest).skills : [];
    const defaults = new Set([...(DEFAULT_SKILLS[e.key] ?? []), ...manifestSkills]), by = new Map(rows.map((r) => [r.skillKey, r]));
    return cat.filter((s) => defaults.has(s.key) || by.has(s.key)).map((skill) => { const r = by.get(skill.key); return { skill, enabled: r ? r.status === "enabled" : true, fromDefault: defaults.has(skill.key) }; });
  }
  async function skills(a: Actor, employeeKey?: string) {
    need(a, "view");
    const catalog = await skillCatalog(a);
    if (!employeeKey) return { catalog: catalog.map(skillDto), employee: null };
    const e = await resolveEmployee(a, employeeKey);
    return { catalog: catalog.map(skillDto), employee: (await effectiveSkills(a, e)).map((x) => ({ ...skillDto(x.skill), enabled: x.enabled, fromDefault: x.fromDefault })) };
  }
  const skillDto = (s: SkillDef) => ({ key: s.key, name: s.name, description: s.description, category: s.category, version: s.version, stage: s.stage, source: s.source, requires: [...s.requires] });
  async function setSkill(a: Actor, employeeKey: string, skillKey: string, input: unknown): Promise<SkillInstallRecord> {
    need(a, "manage");
    const { enabled } = parse(skillToggleInput, input), e = await resolveEmployee(a, employeeKey), s = (await skillCatalog(a)).find((x) => x.key === skillKey);
    if (!s) throw new WorkforceError("not_found", "Skill not found.");
    const t = now(), cur = (await st.query("skillInstall", a.tenantId, { where: [{ col: "employeeKey", op: "eq", value: employeeKey }, { col: "skillKey", op: "eq", value: skillKey }], limit: 1 }))[0];
    const row = cur ? (await store.update("skillInstall", a.tenantId, cur.id, { status: enabled ? "enabled" : "disabled", version: s.version, updatedAt: t })) as SkillInstallRecord
      : await (async () => { const r: SkillInstallRecord = { id: deps.newId(), tenantId: a.tenantId, employeeKey, skillKey, version: s.version, status: enabled ? "enabled" : "disabled", installedBy: a.userId, createdAt: t, updatedAt: t }; await store.insert("skillInstall", r); return r; })();
    await rec(a, { action: enabled ? "workforce.skill.enabled" : "workforce.skill.disabled", summary: `${e.name}: skill ${s.name} ${enabled ? "enabled" : "disabled"}`, subjectKind: "skill", subjectId: skillKey, reversible: true, revertHint: { employeeKey, skillKey, enabled: !enabled } });
    return row;
  }

  /* ───────────── Packages (marketplace-ready) ───────────── */

  async function installPackage(a: Actor, input: unknown): Promise<PackageRecord> {
    need(a, "manage");
    const plan = await ports.plan(a);
    if (!plan || !PACKAGE_PLANS.has(plan)) throw new WorkforceError("plan_required", "Installing packages is available on the Business and Enterprise plans.");
    const { manifest, source } = parse(installInput, input);
    if (manifest.kind === "skill") for (const c of manifest.requires) if (!ports.capabilities().has(c)) throw new WorkforceError("validation_failed", `The package needs the capability "${c}", which this platform does not provide.`);
    if (manifest.kind === "employee" && (await ports.employee(a, manifest.key))) throw new WorkforceError("conflict", "That key belongs to a built-in AI employee.");
    const existing = (await packages(a)).filter((p) => p.packageKey === manifest.key);
    if (existing.some((p) => p.version === manifest.version)) throw new WorkforceError("duplicate", "That version is already installed.");
    const cmp = (x: string, y: string) => { const [p, q] = [x.split(".").map(Number), y.split(".").map(Number)]; for (let i = 0; i < 3; i++) if ((p[i] ?? 0) !== (q[i] ?? 0)) return (p[i] ?? 0) - (q[i] ?? 0); return 0; };
    const active = existing.find((p) => p.status === "active");
    if (active && cmp(manifest.version, active.version) < 0) throw new WorkforceError("invalid_state", "A newer version is already installed.");
    const t = now(), row: PackageRecord = { id: deps.newId(), tenantId: a.tenantId, packageKey: manifest.key, kind: manifest.kind, version: manifest.version, name: manifest.name, manifest: manifest as unknown as Record<string, unknown>, status: "active", source, installedBy: a.userId, createdAt: t, updatedAt: t };
    await store.batch([...(active ? [{ op: "update" as const, kind: "package" as const, tenantId: a.tenantId, id: active.id, patch: { status: "superseded" as const, updatedAt: t } }] : []), { op: "insert", kind: "package", row }]);
    await rec(a, { action: active ? "workforce.package.upgraded" : "workforce.package.installed", summary: `Package ${manifest.name} ${manifest.version} ${active ? `upgraded from ${active.version}` : "installed"}`, subjectKind: "package", subjectId: row.id, reversible: false });
    return row;
  }
  async function listPackages(a: Actor): Promise<PackageRecord[]> { need(a, "view"); return packages(a); }
  async function disablePackage(a: Actor, id: string): Promise<PackageRecord> {
    need(a, "manage");
    const p = await getOr("package", a, id, "Package");
    if (p.status !== "active") throw new WorkforceError("invalid_state", "Only the active version can be disabled.");
    const r = (await store.update("package", a.tenantId, id, { status: "disabled", updatedAt: now() })) as PackageRecord;
    await rec(a, { action: "workforce.package.disabled", summary: `Package ${p.name} ${p.version} disabled`, subjectKind: "package", subjectId: id });
    return r;
  }

  /* ───────────── Memory ───────────── */

  async function addMemory(a: Actor, input: unknown): Promise<MemoryRecord> {
    need(a, "manage");
    const i = parse(memoryInput, input), e = await resolveEmployee(a, i.employeeKey), t = now();
    const row: MemoryRecord = { id: deps.newId(), tenantId: a.tenantId, employeeKey: i.employeeKey, kind: i.kind, title: i.title, body: i.body, source: "user", active: true, createdBy: a.userId, createdAt: t, updatedAt: t };
    await store.insert("memory", row);
    await rec(a, { action: "workforce.memory.saved", summary: `${e.name} will remember (${i.kind}): ${i.title}`, subjectKind: "memory", subjectId: row.id, employeeKey: e.activityKey, reversible: true, revertHint: { memoryId: row.id, active: false } });
    return row;
  }
  async function listMemory(a: Actor, q: { employeeKey: string; includeInactive?: boolean }): Promise<MemoryRecord[]> {
    need(a, "view"); await resolveEmployee(a, q.employeeKey);
    return all("memory", a, { where: [{ col: "employeeKey", op: "eq", value: q.employeeKey }, ...(q.includeInactive ? [] : [{ col: "active" as const, op: "eq" as const, value: true }])], orderBy: { col: "createdAt", dir: "desc" } });
  }
  async function patchMemory(a: Actor, id: string, input: unknown): Promise<MemoryRecord> {
    need(a, "manage");
    const patch = parse(memoryPatch, input), m = await getOr("memory", a, id, "Memory");
    const r = (await store.update("memory", a.tenantId, id, { ...patch, updatedAt: now() })) as MemoryRecord;
    await rec(a, { action: patch.active === false ? "workforce.memory.forgotten" : "workforce.memory.updated", summary: `Memory ${patch.active === false ? "forgotten" : "updated"}: ${m.title}`, subjectKind: "memory", subjectId: id });
    return r;
  }

  /* ───────────── Objectives ───────────── */

  async function checkDeps(a: Actor, selfId: string | null, dependsOn: readonly string[]): Promise<void> {
    if (selfId && dependsOn.includes(selfId)) throw new WorkforceError("validation_failed", "An objective cannot depend on itself.");
    const all_ = await all("objective", a, {}), byId = new Map(all_.map((o) => [o.id, o]));
    for (const d of dependsOn) if (!byId.has(d)) throw new WorkforceError("validation_failed", "A dependency does not exist.");
    if (selfId) { // no cycles: walking the dependencies of the new set must never come back to this objective
      const seen = new Set<string>(), stack = [...dependsOn];
      while (stack.length) { const x = stack.pop() as string; if (x === selfId) throw new WorkforceError("validation_failed", "Those dependencies form a cycle."); if (seen.has(x)) continue; seen.add(x); stack.push(...(byId.get(x)?.dependsOn ?? [])); }
    }
  }
  async function createObjective(a: Actor, input: unknown): Promise<ObjectiveRecord> {
    need(a, "manage");
    const i = parse(objectiveInput, input), e = await resolveEmployee(a, i.employeeKey);
    await checkDeps(a, null, i.dependsOn);
    const t = now(), row: ObjectiveRecord = { id: deps.newId(), tenantId: a.tenantId, employeeKey: i.employeeKey, title: i.title, description: i.description, priority: i.priority, status: "active", dependsOn: [...new Set(i.dependsOn)], metric: i.metric, dueAt: i.dueAt, createdBy: a.userId, createdAt: t, updatedAt: t };
    await store.insert("objective", row);
    await rec(a, { action: "workforce.objective.created", summary: `Objective for ${e.name}: ${i.title}`, subjectKind: "objective", subjectId: row.id, employeeKey: e.activityKey });
    return row;
  }
  async function listObjectives(a: Actor, q: { employeeKey?: string; status?: string } = {}): Promise<(ObjectiveRecord & { blockedBy: string[] })[]> {
    need(a, "view");
    const rows = await all("objective", a, { where: [...(q.employeeKey ? [{ col: "employeeKey" as const, op: "eq" as const, value: q.employeeKey }] : []), ...(q.status ? [{ col: "status" as const, op: "eq" as const, value: q.status }] : [])], orderBy: { col: "createdAt", dir: "asc" } });
    const every = await all("objective", a, {}), done = new Set(every.filter((o) => o.status === "achieved").map((o) => o.id));
    return rows.sort((x, y) => x.priority - y.priority || x.createdAt - y.createdAt).map((o) => ({ ...o, blockedBy: o.dependsOn.filter((d) => !done.has(d)) }));
  }
  async function patchObjective(a: Actor, id: string, input: unknown): Promise<ObjectiveRecord> {
    need(a, "manage");
    const patch = parse(objectivePatch, input), o = await getOr("objective", a, id, "Objective");
    if (patch.dependsOn) await checkDeps(a, id, patch.dependsOn);
    if (patch.status === "achieved") { const open = (await all("objective", a, {})).filter((x) => o.dependsOn.includes(x.id) && x.status !== "achieved"); if (open.length) throw new WorkforceError("invalid_state", "Its dependencies are not achieved yet.", { blockedBy: open.map((x) => x.id) }); }
    const r = (await store.update("objective", a.tenantId, id, { ...patch, ...(patch.dependsOn ? { dependsOn: [...new Set(patch.dependsOn)] } : {}), updatedAt: now() })) as ObjectiveRecord;
    const e = await ports.employee(a, o.employeeKey);
    await rec(a, { action: patch.status ? `workforce.objective.${patch.status}` : "workforce.objective.updated", summary: `Objective ${patch.status ?? "updated"}: ${o.title}`, subjectKind: "objective", subjectId: id, ...(e ? { employeeKey: e.activityKey } : {}), reversible: Boolean(patch.status), ...(patch.status ? { revertHint: { objectiveId: id, status: o.status } } : {}) });
    return r;
  }

  /* ───────────── Budget ───────────── */

  const sumUsed = (a: Actor, period: string, employeeKey?: string) => st.sum("usage", a.tenantId, "costMicros", [{ col: "period", op: "eq", value: period }, ...(employeeKey ? [{ col: "employeeKey" as const, op: "eq" as const, value: employeeKey }] : [])]);
  const sumSimulated = (a: Actor, period: string) => st.sum("usage", a.tenantId, "costMicros", [{ col: "period", op: "eq", value: period }, { col: "mode", op: "eq", value: "simulation" }]);
  const sumApproved = (a: Actor, period: string, employeeKey?: string) => st.sum("budgetRequest", a.tenantId, "amountMicros", [{ col: "period", op: "eq", value: period }, { col: "status", op: "eq", value: "approved" }, ...(employeeKey ? [{ col: "employeeKey" as const, op: "eq" as const, value: employeeKey }] : [])]);
  const budgetRow = async (a: Actor, scope: string): Promise<BudgetRecord | null> => (await st.query("budget", a.tenantId, { where: [{ col: "scope", op: "eq", value: scope }], limit: 1 }))[0] ?? null;

  /** What an employee may still spend this month. Provider-independent: it only counts micros in the usage ledger. */
  async function availability(a: Actor, employeeKey: string, period: string) {
    const [company, own] = await Promise.all([budgetRow(a, "company"), budgetRow(a, employeeKey)]);
    const [usedAll, usedOwn, extraAll, extraOwn] = await Promise.all([sumUsed(a, period), sumUsed(a, period, employeeKey), sumApproved(a, period), sumApproved(a, period, employeeKey)]);
    const companyCap = company ? company.monthlyMicros + extraAll : 0, companyLeft = Math.max(0, companyCap - usedAll);
    const ownCap = own ? own.monthlyMicros + extraOwn : null, ownLeft = ownCap === null ? null : Math.max(0, ownCap - usedOwn);
    return { configured: Boolean(company), companyCap, companyLeft, ownCap, ownLeft, usedAll, usedOwn, available: ownLeft === null ? companyLeft : Math.min(companyLeft, ownLeft) };
  }
  async function budget(a: Actor) {
    need(a, "view");
    const period = monthOf(now()), company = await budgetRow(a, "company"), allocs = await all("budget", a, {}), usageKeys = new Set<string>();
    for (const u of await all("usage", a, { where: [{ col: "period", op: "eq", value: period }] })) usageKeys.add(u.employeeKey);
    const keys = new Set([...allocs.filter((b) => b.scope !== "company").map((b) => b.scope), ...usageKeys]);
    const employees = await Promise.all([...keys].sort().map(async (k) => { const v = await availability(a, k, period); return { employeeKey: k, assigned: v.ownCap, used: v.usedOwn, available: v.ownLeft === null ? null : v.ownLeft }; }));
    const [used, simulated, extra, pending] = await Promise.all([sumUsed(a, period), sumSimulated(a, period), sumApproved(a, period), st.count("budgetRequest", a.tenantId, [{ col: "status", op: "eq", value: "pending" }])]);
    const assigned = company ? company.monthlyMicros + extra : 0;
    return { period, currency: company?.currency ?? "USD", configured: Boolean(company), company: { assigned, used, available: Math.max(0, assigned - used), simulatedUsed: simulated, authorizedExtra: extra }, employees, pendingRequests: pending, status: !company ? "not_configured" as const : used >= assigned ? "exhausted" as const : used >= assigned * 0.8 ? "warning" as const : "ok" as const };
  }
  async function setBudget(a: Actor, scope: string, input: unknown): Promise<BudgetRecord> {
    need(a, "approve");
    const { monthlyMicros } = parse(budgetInput, input);
    if (scope !== "company") await resolveEmployee(a, scope);
    else if (monthlyMicros === 0) throw new WorkforceError("validation_failed", "The company budget must be greater than zero.");
    const t = now(), cur = await budgetRow(a, scope);
    const row = cur ? (await store.update("budget", a.tenantId, cur.id, { monthlyMicros, updatedBy: a.userId, updatedAt: t })) as BudgetRecord
      : await (async () => { const r: BudgetRecord = { id: deps.newId(), tenantId: a.tenantId, scope, monthlyMicros, currency: "USD", updatedBy: a.userId, createdAt: t, updatedAt: t }; await store.insert("budget", r); return r; })();
    await rec(a, { action: scope === "company" ? "workforce.budget.company_set" : "workforce.budget.employee_set", summary: `Monthly AI budget ${scope === "company" ? "for the company" : `for ${scope}`}: ${monthlyMicros / 1e6} USD`, subjectKind: "budget", subjectId: row.id, reversible: Boolean(cur), ...(cur ? { revertHint: { scope, monthlyMicros: cur.monthlyMicros } } : {}) });
    return row;
  }
  /** The employee reached its limit: ask a person to authorize more. One pending request per employee and month. */
  async function askForMore(a: Actor, e: EmployeeInfo, period: string, needMicros: number, reason: string): Promise<BudgetRequestRecord> {
    const pending = (await st.query("budgetRequest", a.tenantId, { where: [{ col: "employeeKey", op: "eq", value: e.key }, { col: "period", op: "eq", value: period }, { col: "status", op: "eq", value: "pending" }], limit: 1 }))[0];
    if (pending) return pending;
    const t = now(), row: BudgetRequestRecord = { id: deps.newId(), tenantId: a.tenantId, employeeKey: e.key, period, amountMicros: Math.max(MIN_REQUEST_MICROS, needMicros), reason, status: "pending", requestedBy: a.userId, decidedBy: null, decidedAt: null, createdAt: t, updatedAt: t };
    await store.insert("budgetRequest", row);
    await rec(a, { action: "workforce.budget.authorization_requested", summary: `${e.name} reached its AI budget and asks for ${row.amountMicros / 1e6} USD more`, subjectKind: "budget_request", subjectId: row.id, employeeKey: e.activityKey, actorKind: "employee", outcome: "skipped" });
    return row;
  }
  async function listBudgetRequests(a: Actor, status?: string): Promise<BudgetRequestRecord[]> {
    need(a, "view");
    return all("budgetRequest", a, { where: status ? [{ col: "status", op: "eq", value: status }] : [], orderBy: { col: "createdAt", dir: "desc" } });
  }
  async function decideBudgetRequest(a: Actor, id: string, input: unknown): Promise<BudgetRequestRecord> {
    need(a, "approve");
    const { approve } = parse(decisionInput, input), r = await getOr("budgetRequest", a, id, "Request");
    if (r.status !== "pending") throw new WorkforceError("invalid_state", "That request was already decided.");
    const t = now(), out = (await store.update("budgetRequest", a.tenantId, id, { status: approve ? "approved" : "denied", decidedBy: a.userId, decidedAt: t, updatedAt: t })) as BudgetRequestRecord;
    const e = await ports.employee(a, r.employeeKey);
    await rec(a, { action: approve ? "workforce.budget.authorized" : "workforce.budget.denied", summary: `${approve ? "Authorized" : "Denied"} ${r.amountMicros / 1e6} USD more for ${e?.name ?? r.employeeKey}`, subjectKind: "budget_request", subjectId: id, ...(e ? { employeeKey: e.activityKey } : {}) });
    return out;
  }
  async function gate(a: Actor, e: EmployeeInfo, estimateMicros: number, why: string): Promise<void> {
    const period = monthOf(now()), v = await availability(a, e.key, period);
    if (v.configured && v.available >= estimateMicros) return;
    const req = v.configured ? await askForMore(a, e, period, estimateMicros, why) : null;
    throw new WorkforceError("budget_exceeded", v.configured ? "This AI employee reached its monthly budget. A person must authorize more." : "Set a monthly AI budget for the company before AI employees can work.", { configured: v.configured, requestId: req?.id ?? null, available: v.available });
  }
  async function spend(a: Actor, e: EmployeeInfo, p: AiProvider, r: { costMicros: number; inputTokens: number; outputTokens: number; mode: Mode }, ref: { kind: string; id: string }): Promise<void> {
    await store.insert("usage", { id: deps.newId(), tenantId: a.tenantId, employeeKey: e.key, period: monthOf(now()), costMicros: r.costMicros, tokens: r.inputTokens + r.outputTokens, provider: p.id, mode: r.mode, refKind: ref.kind, refId: ref.id, createdAt: now() });
  }

  /* ───────────── Context and the provider call ───────────── */

  async function buildContext(a: Actor, e: EmployeeInfo, extra: string) {
    const [objectives, memory, sk] = await Promise.all([listObjectives(a, { employeeKey: e.key, status: "active" }), listMemory(a, { employeeKey: e.key }), effectiveSkills(a, e)]);
    const enabled = sk.filter((x) => x.enabled).map((x) => x.skill);
    const by = (k: string) => memory.filter((m) => m.kind === k).map((m) => `- ${m.title}: ${m.body}`);
    const system = [
      e.instructions, `Goal: ${e.goal}`,
      "Rules: you reason and recommend only. Never claim to have done anything you cannot do. If information is missing, say so.",
      enabled.length ? `Skills:\n${enabled.map((s) => `- ${s.name}: ${s.prompt}`).join("\n")}` : "",
      objectives.length ? `Objectives (by priority):\n${objectives.slice(0, 8).map((o) => `- P${o.priority} ${o.title}${o.blockedBy.length ? " (blocked)" : ""}`).join("\n")}` : "",
      ...(["constraint", "preference", "decision", "context", "history"] as const).map((k) => { const l = by(k).slice(0, 8); return l.length ? `${k}:\n${l.join("\n")}` : ""; }),
      extra,
    ].filter(Boolean).join("\n\n").slice(0, 8000);
    return { system, facts: { objectives: objectives.length, memories: memory.length, skills: enabled.map((s) => s.name) } };
  }
  const escalate = (n: number) => Math.ceil((n / 1000) * SIMULATED_MICROS_PER_1K_TOKENS);

  /* ───────────── Conversations ───────────── */

  async function ownThread(a: Actor, id: string): Promise<ThreadRecord> {
    const t = await getOr("thread", a, id, "Conversation");
    if (t.userId !== a.userId) throw new WorkforceError("not_found", "Conversation not found."); // private: another person's thread does not exist for you
    return t;
  }
  async function startThread(a: Actor, input: unknown): Promise<ThreadRecord> {
    need(a, "converse");
    const i = parse(startThreadInput, input), e = await resolveEmployee(a, i.employeeKey);
    if (!e.entitled) throw new WorkforceError("plan_required", "This AI employee is available when you upgrade your plan.");
    if (!e.active) throw new WorkforceError("invalid_state", "Activate this AI employee before talking to it.");
    const t = now(), row: ThreadRecord = { id: deps.newId(), tenantId: a.tenantId, employeeKey: i.employeeKey, userId: a.userId, title: i.title || e.name, status: "open", messageCount: 0, lastMessageAt: t, createdAt: t, updatedAt: t };
    await store.insert("thread", row);
    await rec(a, { action: "workforce.thread.started", summary: `Conversation started with ${e.name}`, subjectKind: "thread", subjectId: row.id, employeeKey: e.activityKey });
    return row;
  }
  async function listThreads(a: Actor, q: { employeeKey?: string; status?: string } = {}): Promise<ThreadRecord[]> {
    need(a, "converse");
    return all("thread", a, { where: [{ col: "userId", op: "eq", value: a.userId }, ...(q.employeeKey ? [{ col: "employeeKey" as const, op: "eq" as const, value: q.employeeKey }] : []), ...(q.status ? [{ col: "status" as const, op: "eq" as const, value: q.status }] : [])], orderBy: { col: "lastMessageAt", dir: "desc" } });
  }
  async function getThread(a: Actor, id: string): Promise<{ thread: ThreadRecord; messages: MessageRecord[] }> {
    need(a, "converse");
    const thread = await ownThread(a, id);
    return { thread, messages: await all("message", a, { where: [{ col: "threadId", op: "eq", value: id }], orderBy: { col: "createdAt", dir: "asc" } }) };
  }
  async function archiveThread(a: Actor, id: string): Promise<ThreadRecord> {
    need(a, "converse");
    await ownThread(a, id);
    return (await store.update("thread", a.tenantId, id, { status: "archived", updatedAt: now() })) as ThreadRecord;
  }
  async function send(a: Actor, threadId: string, input: unknown): Promise<{ thread: ThreadRecord; user: MessageRecord; reply: MessageRecord; usage: { costMicros: number; tokens: number; mode: Mode } }> {
    need(a, "converse");
    const i = parse(sendInput, input), thread = await ownThread(a, threadId);
    if (thread.status !== "open") throw new WorkforceError("invalid_state", "This conversation is archived.");
    const e = await resolveEmployee(a, thread.employeeKey);
    if (!e.entitled) throw new WorkforceError("plan_required", "This AI employee is available when you upgrade your plan.");
    if (!e.active) throw new WorkforceError("invalid_state", "This AI employee is not active.");
    const p = provider(a), history = (await all("message", a, { where: [{ col: "threadId", op: "eq", value: threadId }], orderBy: { col: "createdAt", dir: "desc" } })).slice(0, HISTORY_MESSAGES).reverse();
    const ctx = await buildContext(a, e, ""), msgs = [...history.filter((m) => m.role !== "system").map((m) => ({ role: m.role as "user" | "employee", content: m.body })), { role: "user" as const, content: i.body }];
    const estimate = escalate(estimateTokens(ctx.system) + msgs.reduce((n, m) => n + estimateTokens(m.content), 0) + MAX_OUTPUT_TOKENS);
    await gate(a, e, estimate, `Conversation: ${i.body.slice(0, 80)}`);
    const t0 = now(), userMsg: MessageRecord = { id: deps.newId(), tenantId: a.tenantId, threadId, role: "user", body: i.body, mode: modeOf(p), provider: p.id, links: i.links as Link[], attachments: i.attachments, createdBy: a.userId, createdAt: t0 };
    const res = await p.complete({ tenantId: a.tenantId, employeeKey: e.key, employeeName: e.name, system: ctx.system, messages: msgs, maxOutputTokens: MAX_OUTPUT_TOKENS, locale, facts: { ...ctx.facts, lastUserMessage: i.body } });
    const t1 = Math.max(now(), t0 + 1), reply: MessageRecord = { id: deps.newId(), tenantId: a.tenantId, threadId, role: "employee", body: res.text, mode: res.mode, provider: p.id, links: [], attachments: [], createdBy: `employee:${e.key}`, createdAt: t1 };
    await store.batch([{ op: "insert", kind: "message", row: userMsg }, { op: "insert", kind: "message", row: reply }, { op: "update", kind: "thread", tenantId: a.tenantId, id: threadId, patch: { messageCount: thread.messageCount + 2, lastMessageAt: t1, updatedAt: t1, ...(thread.messageCount === 0 && thread.title === e.name ? { title: i.body.slice(0, 60) } : {}) } }]);
    await spend(a, e, p, res, { kind: "message", id: reply.id });
    await rec(a, { action: "workforce.message.answered", summary: `${e.name} answered a message${res.mode === "simulation" ? " (simulation)" : ""}`, subjectKind: "thread", subjectId: threadId, employeeKey: e.activityKey, actorKind: "employee", actorId: e.activityKey, mode: res.mode, quantity: 1, idempotencyKey: `wf-msg:${reply.id}` });
    return { thread: (await store.get("thread", a.tenantId, threadId)) as ThreadRecord, user: userMsg, reply, usage: { costMicros: res.costMicros, tokens: res.inputTokens + res.outputTokens, mode: res.mode } };
  }

  /* ───────────── Agenda / scheduler ───────────── */

  async function createAgenda(a: Actor, input: unknown): Promise<AgendaRecord> {
    need(a, "manage");
    const i = parse(agendaInput, input), e = await resolveEmployee(a, i.employeeKey);
    if (i.objectiveId) await getOr("objective", a, i.objectiveId, "Objective");
    for (const d of i.dependsOn) await getOr("agenda", a, d, "Dependency");
    const t = now(), row: AgendaRecord = { id: deps.newId(), tenantId: a.tenantId, employeeKey: i.employeeKey, objectiveId: i.objectiveId, title: i.title, instruction: i.instruction, triggerKind: i.triggerKind, eventAction: i.triggerKind === "event" ? i.eventAction : null, everyMinutes: i.triggerKind === "schedule" ? i.everyMinutes : null, priority: i.priority, status: "active", requiresApproval: i.requiresApproval, dependsOn: [...new Set(i.dependsOn)], nextRunAt: i.triggerKind === "schedule" ? t + (i.everyMinutes as number) * 60_000 : null, lastRunAt: null, runCount: 0, createdBy: a.userId, createdAt: t, updatedAt: t };
    await store.insert("agenda", row);
    await rec(a, { action: "workforce.agenda.created", summary: `Agenda for ${e.name}: ${i.title}`, subjectKind: "agenda", subjectId: row.id, employeeKey: e.activityKey });
    return row;
  }
  async function listAgenda(a: Actor, q: { employeeKey?: string } = {}): Promise<AgendaRecord[]> {
    need(a, "view");
    return (await all("agenda", a, { where: q.employeeKey ? [{ col: "employeeKey", op: "eq", value: q.employeeKey }] : [], orderBy: { col: "createdAt", dir: "asc" } })).sort((x, y) => x.priority - y.priority || x.createdAt - y.createdAt);
  }
  async function patchAgenda(a: Actor, id: string, input: unknown): Promise<AgendaRecord> {
    need(a, "manage");
    const patch = parse(agendaPatch, input), cur = await getOr("agenda", a, id, "Agenda entry");
    if (patch.everyMinutes && cur.triggerKind !== "schedule") throw new WorkforceError("validation_failed", "Only scheduled entries have an interval.");
    const t = now(), r = (await store.update("agenda", a.tenantId, id, { ...patch, ...(patch.everyMinutes ? { nextRunAt: t + patch.everyMinutes * 60_000 } : {}), updatedAt: t })) as AgendaRecord;
    await rec(a, { action: patch.status ? `workforce.agenda.${patch.status === "paused" ? "paused" : "resumed"}` : "workforce.agenda.updated", summary: `Agenda ${patch.status ?? "updated"}: ${cur.title}`, subjectKind: "agenda", subjectId: id });
    return r;
  }
  async function listRuns(a: Actor, q: { status?: string; agendaId?: string } = {}): Promise<RunRecord[]> {
    need(a, "view");
    return all("run", a, { where: [...(q.status ? [{ col: "status" as const, op: "eq" as const, value: q.status }] : []), ...(q.agendaId ? [{ col: "agendaId" as const, op: "eq" as const, value: q.agendaId }] : [])], orderBy: { col: "createdAt", dir: "desc" } });
  }
  async function runResult(a: Actor, runId: string): Promise<{ run: RunRecord; messages: MessageRecord[] }> {
    need(a, "view");
    const run = await getOr("run", a, runId, "Run");
    const thread = run.threadId ? await all("message", a, { where: [{ col: "threadId", op: "eq", value: run.threadId }], orderBy: { col: "createdAt", dir: "asc" } }) : [];
    return { run, messages: thread.filter((m) => m.links.some((l) => l.kind === "task" && l.id === runId)) };
  }

  /** Why an entry cannot run right now (dependencies), or null. */
  async function blockedBy(a: Actor, entry: AgendaRecord): Promise<string | null> {
    if (entry.objectiveId) {
      const o = await store.get("objective", a.tenantId, entry.objectiveId);
      if (o && o.status !== "active") return `objective_${o.status}`;
      const deps_ = o ? await Promise.all(o.dependsOn.map((d) => store.get("objective", a.tenantId, d))) : [];
      if (deps_.some((d) => !d || d.status !== "achieved")) return "objective_dependency";
    }
    for (const d of entry.dependsOn) {
      const last = (await st.query("run", a.tenantId, { where: [{ col: "agendaId", op: "eq", value: d }, { col: "status", op: "in", value: ["succeeded", "failed", "rejected"] }], limit: 1 }))[0];
      if (!last || last.status !== "succeeded") return "agenda_dependency";
    }
    return null;
  }
  async function finishRun(a: Actor, run: RunRecord, e: EmployeeInfo | null, entry: AgendaRecord, patch: Partial<RunRecord>, outcome: "success" | "failed" | "skipped"): Promise<RunRecord> {
    const t = now(), r = (await store.update("run", a.tenantId, run.id, { ...patch, updatedAt: t, finishedAt: t })) as RunRecord;
    await rec(a, { action: `workforce.agenda.run_${r.status}`, summary: `${e?.name ?? entry.employeeKey}: ${entry.title} → ${r.status}${r.reason ? ` (${r.reason})` : ""}`, subjectKind: "run", subjectId: r.id, ...(e ? { employeeKey: e.activityKey } : {}), actorKind: "employee", actorId: e?.activityKey ?? entry.employeeKey, outcome, mode: r.mode, quantity: 1, idempotencyKey: `wf-run:${r.id}:${r.status}` });
    return r;
  }
  /** Runs one entry once: dependency check, budget gate, approval gate, then the work itself through the provider port. */
  async function runEntry(a: Actor, entry: AgendaRecord, firedBy: RunRecord["firedBy"], opts: { approved?: boolean; existing?: RunRecord } = {}): Promise<RunRecord> {
    const t = now(), p = provider(a);
    const run: RunRecord = opts.existing ?? { id: deps.newId(), tenantId: a.tenantId, agendaId: entry.id, employeeKey: entry.employeeKey, firedBy, status: "queued", reason: "", threadId: null, costMicros: 0, tokens: 0, mode: modeOf(p), decidedBy: null, createdAt: t, updatedAt: t, finishedAt: null };
    if (!opts.existing) await store.insert("run", run);
    const advance = async () => { await store.update("agenda", a.tenantId, entry.id, { lastRunAt: t, runCount: entry.runCount + 1, ...(entry.triggerKind === "schedule" ? { nextRunAt: t + num(entry.everyMinutes) * 60_000 } : {}), updatedAt: t }); };
    let e: EmployeeInfo | null = null;
    try { e = await resolveEmployee(a, entry.employeeKey); } catch { /* handled below */ }
    if (!e || !e.active || !e.entitled) { await advance(); return finishRun(a, run, e, entry, { status: "skipped", reason: "employee_not_active" }, "skipped"); }
    const blocked = await blockedBy(a, entry);
    if (blocked) { await advance(); return finishRun(a, run, e, entry, { status: "skipped", reason: blocked }, "skipped"); }
    if (entry.requiresApproval && !opts.approved) {
      await advance();
      const r = (await store.update("run", a.tenantId, run.id, { status: "awaiting_approval", reason: "needs_approval", updatedAt: now() })) as RunRecord;
      await rec(a, { action: "workforce.agenda.run_awaiting_approval", summary: `${e.name} asks to run: ${entry.title}`, subjectKind: "run", subjectId: r.id, employeeKey: e.activityKey, actorKind: "employee", actorId: e.activityKey, outcome: "skipped", mode: r.mode, idempotencyKey: `wf-run:${r.id}:awaiting` });
      return r;
    }
    const ctx = await buildContext(a, e, `Task from your agenda: ${entry.instruction}`), est = escalate(estimateTokens(ctx.system) + MAX_OUTPUT_TOKENS);
    try { await gate(a, e, est, `Agenda: ${entry.title}`); } catch (err) {
      if ((err as { code?: string }).code === "budget_exceeded") { await advance(); return finishRun(a, run, e, entry, { status: "skipped", reason: "budget_exceeded" }, "skipped"); }
      throw err;
    }
    try {
      const res = await p.complete({ tenantId: a.tenantId, employeeKey: e.key, employeeName: e.name, system: ctx.system, messages: [{ role: "user", content: entry.instruction }], maxOutputTokens: MAX_OUTPUT_TOKENS, locale, facts: { ...ctx.facts, lastUserMessage: entry.instruction } });
      const th = (await st.query("thread", a.tenantId, { where: [{ col: "userId", op: "eq", value: SYSTEM_THREAD_USER }, { col: "employeeKey", op: "eq", value: e.key }], limit: 1 }))[0]
        ?? await (async () => { const x: ThreadRecord = { id: deps.newId(), tenantId: a.tenantId, employeeKey: e.key, userId: SYSTEM_THREAD_USER, title: "Agenda", status: "open", messageCount: 0, lastMessageAt: t, createdAt: t, updatedAt: t }; await store.insert("thread", x); return x; })();
      const tt = Math.max(now(), t + 1), m1: MessageRecord = { id: deps.newId(), tenantId: a.tenantId, threadId: th.id, role: "system", body: entry.instruction, mode: res.mode, provider: p.id, links: [{ kind: "task", id: run.id, label: entry.title }], attachments: [], createdBy: "system:agenda", createdAt: tt }, m2: MessageRecord = { id: deps.newId(), tenantId: a.tenantId, threadId: th.id, role: "employee", body: res.text, mode: res.mode, provider: p.id, links: [{ kind: "task", id: run.id, label: entry.title }], attachments: [], createdBy: `employee:${e.key}`, createdAt: tt + 1 };
      await store.batch([{ op: "insert", kind: "message", row: m1 }, { op: "insert", kind: "message", row: m2 }, { op: "update", kind: "thread", tenantId: a.tenantId, id: th.id, patch: { messageCount: th.messageCount + 2, lastMessageAt: tt + 1, updatedAt: tt + 1 } }]);
      await spend(a, e, p, res, { kind: "run", id: run.id });
      await advance();
      return finishRun(a, run, e, entry, { status: "succeeded", reason: "", threadId: th.id, costMicros: res.costMicros, tokens: res.inputTokens + res.outputTokens, mode: res.mode }, "success");
    } catch (err) {
      await advance();
      return finishRun(a, run, e, entry, { status: "failed", reason: (err as { code?: string }).code ?? "provider_error" }, "failed");
    }
  }
  async function tick(a: Actor): Promise<{ checked: number; runs: RunRecord[] }> {
    need(a, "manage");
    const t = now(), due = await st.query("agenda", a.tenantId, { where: [{ col: "status", op: "eq", value: "active" }, { col: "triggerKind", op: "eq", value: "schedule" }, { col: "nextRunAt", op: "lte", value: t }], orderBy: { col: "nextRunAt", dir: "asc" }, limit: 200 });
    const ordered = due.sort((x, y) => x.priority - y.priority || num(x.nextRunAt) - num(y.nextRunAt)).slice(0, TICK_LIMIT), runs: RunRecord[] = [];
    for (const entry of ordered) {
      if (await hasOpenRun(a, entry.id)) continue;
      runs.push(await runEntry(a, entry, "schedule"));
    }
    return { checked: due.length, runs };
  }
  const hasOpenRun = async (a: Actor, agendaId: string) => (await st.count("run", a.tenantId, [{ col: "agendaId", op: "eq", value: agendaId }, { col: "status", op: "in", value: ["queued", "awaiting_approval"] }])) > 0;
  async function fire(a: Actor, input: unknown): Promise<{ runs: RunRecord[] }> {
    need(a, "manage");
    const { action } = parse(fireInput, input), entries = (await st.query("agenda", a.tenantId, { where: [{ col: "status", op: "eq", value: "active" }, { col: "triggerKind", op: "eq", value: "event" }, { col: "eventAction", op: "eq", value: action }], limit: 100 })).sort((x, y) => x.priority - y.priority), runs: RunRecord[] = [];
    for (const entry of entries) { if (await hasOpenRun(a, entry.id)) continue; runs.push(await runEntry(a, entry, "event")); }
    return { runs };
  }
  async function runNow(a: Actor, agendaId: string): Promise<RunRecord> {
    need(a, "manage");
    const entry = await getOr("agenda", a, agendaId, "Agenda entry");
    if (entry.status !== "active") throw new WorkforceError("invalid_state", "The entry is paused.");
    if (await hasOpenRun(a, entry.id)) throw new WorkforceError("conflict", "There is already a run waiting for a decision.");
    return runEntry(a, entry, "manual");
  }
  async function decideRun(a: Actor, runId: string, input: unknown): Promise<RunRecord> {
    need(a, "approve");
    const { approve, reason } = parse(decisionInput, input), run = await getOr("run", a, runId, "Run");
    if (run.status !== "awaiting_approval") throw new WorkforceError("invalid_state", "That run is not waiting for a decision.");
    const entry = await getOr("agenda", a, run.agendaId, "Agenda entry"), e = await ports.employee(a, run.employeeKey);
    if (!approve) return finishRun(a, { ...run, decidedBy: a.userId }, e, entry, { status: "rejected", reason: reason || "rejected", decidedBy: a.userId }, "skipped");
    await store.update("run", a.tenantId, runId, { decidedBy: a.userId, status: "queued", updatedAt: now() });
    return runEntry(a, entry, run.firedBy, { approved: true, existing: { ...run, status: "queued", decidedBy: a.userId } });
  }

  /* ───────────── Mission Control summary ───────────── */

  async function summary(a: Actor) {
    need(a, "view");
    const [b, objectives, agenda, awaiting, pkgs] = await Promise.all([budget(a), st.count("objective", a.tenantId, [{ col: "status", op: "eq", value: "active" }]), st.count("agenda", a.tenantId, [{ col: "status", op: "eq", value: "active" }]), st.count("run", a.tenantId, [{ col: "status", op: "eq", value: "awaiting_approval" }]), st.count("package", a.tenantId, [{ col: "status", op: "eq", value: "active" }])]);
    return { budget: b, objectives, agenda, awaitingApproval: awaiting, packages: pkgs, provider: { id: provider(a).id, connected: provider(a).connected, mode: modeOf(provider(a)) } };
  }

  return {
    providers: async (a: Actor) => { need(a, "view"); return { active: provider(a).id, providers: listProviders().map((x) => ({ id: x.id, label: x.label, connected: x.connected })) }; },
    employees: async (a: Actor) => { need(a, "view"); const pk = (await packages(a)).filter((p) => p.kind === "employee" && p.status === "active").map((p) => employeeManifest.parse(p.manifest)); return [...(await ports.roster(a)), ...pk.map((m): EmployeeInfo => ({ key: m.key, name: m.name, department: m.department, goal: m.goal, instructions: m.instructions, activityKey: `pkg_${m.key}`.slice(0, 63), active: true, entitled: true, origin: "package" }))].map((e) => ({ key: e.key, name: e.name, department: e.department, active: e.active, entitled: e.entitled, origin: e.origin })); },
    skills, setSkill, installPackage, listPackages, disablePackage, addMemory, listMemory, patchMemory,
    createObjective, listObjectives, patchObjective, budget, setBudget, listBudgetRequests, decideBudgetRequest,
    startThread, listThreads, getThread, archiveThread, send,
    createAgenda, listAgenda, patchAgenda, listRuns, runResult, tick, fire, runNow, decideRun, summary,
    permissions: (a: Actor) => ({ role: a.role, capabilities: (["view", "converse", "manage", "approve"] as const).filter((c) => allows(a.role, c)) }),
  };
}
