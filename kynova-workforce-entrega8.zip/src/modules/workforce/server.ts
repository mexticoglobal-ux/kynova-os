import { employeeRegistry, getEmployeeFramework } from "@/platform/ai-employees";
import { getActivitySink } from "@/platform/activity";
import { getDb, plansRepo, tenantDb } from "@/platform/db";
import { DEPARTMENT_GOALS, ROSTER, ROSTER_BY_KEY, blueprintOf, employeeKeyOf, isEntitled, teamOf } from "@/modules/team";
import { getWorkforceStore } from "./runtime";
import { createWorkforceService, type Actor, type EmployeeInfo, type WorkforcePorts, type WorkforceService } from "./service";

/** Composition root: the only file that meets the Team roster, the AI Employees framework and the plan catalog. */
async function planOf(a: Actor): Promise<string | null> {
  const db = await getDb(), sub = await tenantDb(db, { tenantId: a.tenantId }).subscriptions.current();
  return sub ? ((await plansRepo(db).findById(sub.planId))?.code ?? null) : null;
}
type Records = Awaited<ReturnType<ReturnType<typeof getEmployeeFramework>["employees"]["list"]>>;
function describe(r: (typeof ROSTER)[number], records: Records, plan: string | null): EmployeeInfo {
  const bp = blueprintOf(r), blueprint = employeeRegistry().blueprint(bp), rec = records.find((e) => e.blueprint === bp && e.status !== "retired");
  return {
    key: r.key, name: r.name, department: r.department, goal: rec?.goal ?? DEPARTMENT_GOALS[r.department], instructions: blueprint?.defaultInstructions ?? `You are ${r.name}.`,
    activityKey: rec ? employeeKeyOf(rec.id) : r.key, active: Boolean(rec), entitled: isEntitled(teamOf(plan), r.key), origin: "roster",
  };
}
export const workforcePorts: WorkforcePorts = {
  async employee(a, key) {
    const r = ROSTER_BY_KEY.get(key);
    if (!r) return null;
    const [records, plan] = await Promise.all([getEmployeeFramework().employees.list(a).catch(() => []), planOf(a).catch(() => null)]);
    return describe(r, records, plan);
  },
  async roster(a) {
    const [records, plan] = await Promise.all([getEmployeeFramework().employees.list(a).catch(() => []), planOf(a).catch(() => null)]);
    return ROSTER.map((r) => describe(r, records, plan));
  },
  plan: (a) => planOf(a).catch(() => null),
  capabilities: () => new Set(employeeRegistry().capabilities().map((c) => c.key)),
};
export async function getWorkforceService(): Promise<WorkforceService> {
  return createWorkforceService({ store: await getWorkforceStore(), ports: workforcePorts, newId: () => crypto.randomUUID().replace(/-/g, ""), activity: await getActivitySink("workforce") });
}
