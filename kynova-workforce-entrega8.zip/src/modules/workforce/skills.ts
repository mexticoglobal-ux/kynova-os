import type { SkillManifest } from "./domain";

/**
 * A Skill is something an AI Employee knows how to do, owned separately from the employee: it can be enabled, disabled, upgraded or replaced
 * without touching the employee, and a marketplace can later sell one. Skills here are the built-in ones (versioned with the product); installed
 * packages add more per company. A skill is DATA (a prompt and the Core capabilities it needs). `stage: "reasoning"` is honest: no skill
 * can act on external systems until its tools exist, so each one only reasons, explains and proposes.
 */
export interface SkillDef { key: string; name: string; description: string; category: string; version: string; prompt: string; requires: readonly string[]; stage: "reasoning" | "tools"; source: "builtin" | "marketplace" | "custom" }

const S = (key: string, name: string, category: string, description: string, prompt: string): SkillDef => ({ key, name, category, description, version: "1.0.0", prompt, requires: [], stage: "reasoning", source: "builtin" });

export const BUILTIN_SKILLS: readonly SkillDef[] = [
  S("seo", "SEO", "marketing", "Keyword and on-page recommendations from the information provided.", "Recommend SEO improvements (keywords, titles, structure, internal links) only from pages and data you are given."),
  S("meta_ads", "Meta Ads", "marketing", "Reasons about Meta campaigns from reports the person shares.", "Analyse Meta Ads results the person provides and propose budget, audience and creative changes. Never claim to have changed anything."),
  S("google_ads", "Google Ads", "marketing", "Reasons about Google Ads from reports the person shares.", "Analyse Google Ads results the person provides and propose keyword, bidding and copy changes. Never claim to have changed anything."),
  S("email_marketing", "Email Marketing", "marketing", "Drafts and critiques email campaigns.", "Draft email campaigns, subject lines and sequences in the company's voice. Drafts are never sent by you."),
  S("analytics", "Analytics", "analytics", "Reads figures the platform records and explains them.", "Explain the numbers you are given, point out what changed and what is missing. Say plainly when data is not available."),
  S("invoicing", "Facturación", "finance", "Explains and reviews invoicing from recorded data.", "Review invoicing information you are given and flag inconsistencies. You cannot issue or change invoices."),
  S("budgeting", "Presupuestos", "finance", "Builds and critiques budgets from recorded data.", "Help structure budgets and compare plan versus actual using figures you are given."),
  S("cash_flow", "Flujo de caja", "finance", "Projects cash flow from figures provided.", "Project cash flow from the figures you are given and name the assumptions. Never invent balances."),
  S("taxes", "Impuestos", "finance", "General tax organisation support; not tax advice.", "Help organise tax-related information. You are not a tax advisor; recommend a qualified professional for decisions."),
  S("prospecting", "Prospecting", "sales", "Profiles and prioritises prospects from information provided.", "Prioritise prospects and draft outreach from the information you are given. Do not contact anyone."),
  S("pipeline_review", "Pipeline review", "sales", "Reviews deal stages and next steps.", "Review the pipeline information you are given and propose next steps per deal."),
  S("customer_onboarding", "Customer onboarding", "customer_success", "Plans onboarding steps for a customer.", "Propose onboarding plans and check-ins from what you know about the customer."),
  S("churn_watch", "Churn watch", "customer_success", "Points out customers at risk from signals provided.", "Point out churn risk from the signals you are given and propose actions. Never contact customers yourself."),
  S("executive_briefing", "Executive briefing", "management", "Summarises what happened and what needs a decision.", "Summarise recorded activity for an executive and list the decisions that are pending."),
  S("integration_planning", "Integration planning", "operations", "Plans integrations with other systems.", "Plan integrations step by step from the requirements you are given. You cannot connect systems."),
];

/** Which skills each roster member starts with. Everything else a company enables itself. */
export const DEFAULT_SKILLS: Readonly<Record<string, readonly string[]>> = {
  marketing_manager: ["seo", "meta_ads", "google_ads", "email_marketing", "analytics"],
  finance_manager: ["invoicing", "budgeting", "cash_flow", "taxes"],
  sales_manager: ["prospecting", "pipeline_review"],
  customer_success_manager: ["customer_onboarding", "churn_watch"],
  ceo_ai: ["executive_briefing", "analytics"],
  integration_manager: ["integration_planning"],
  analytics_advisor: ["analytics"],
};

const g = globalThis as unknown as { __kynovaWfSkills?: Map<string, SkillDef> };
/** On globalThis like the employee registry: Next bundles startup code and routes separately. */
const reg = (): Map<string, SkillDef> => (g.__kynovaWfSkills ??= new Map(BUILTIN_SKILLS.map((s) => [s.key, s])));
export const builtinSkill = (key: string): SkillDef | undefined => reg().get(key);
export const builtinSkills = (): SkillDef[] => [...reg().values()];
/** Product modules can add built-in skills at startup. A key can be defined once. */
export function defineSkill(s: SkillDef): void { if (reg().has(s.key)) throw new Error(`Skill "${s.key}" is already defined.`); reg().set(s.key, s); }
export const skillFromManifest = (m: SkillManifest, source: SkillDef["source"]): SkillDef => ({ key: m.key, name: m.name, description: m.description, category: m.category, version: m.version, prompt: m.prompt, requires: m.requires, stage: "reasoning", source });
