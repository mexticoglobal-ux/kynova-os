import { z } from "zod";
import { ROLES } from "@/config/roles";

/** Capabilities INSIDE Workforce. Whether a role may open /app/workforce at all is decided only by src/config/modules.ts. */
export const CAPABILITIES = ["view", "converse", "manage", "approve"] as const;
export type Capability = (typeof CAPABILITIES)[number];
const ALL: readonly Capability[] = CAPABILITIES;
export const DEFAULT_CAPABILITIES: Record<(typeof ROLES)[number], readonly Capability[]> = {
  super_admin: ALL, owner: ALL, administrator: ALL, ceo: ALL, manager: ["view", "converse", "manage"],
  marketing: ["view", "converse"], sales: ["view", "converse"], finance: ["view", "converse"], support: [], hr: [], employee: [], guest: [],
};

export const MODES = ["simulation", "production"] as const;
export type Mode = (typeof MODES)[number];
export const PACKAGE_KINDS = ["employee", "skill"] as const;
export const PACKAGE_STATUS = ["active", "superseded", "disabled"] as const;
export const PACKAGE_SOURCES = ["builtin", "marketplace", "custom"] as const;
export const SKILL_STATUS = ["enabled", "disabled"] as const;
export const THREAD_STATUS = ["open", "archived"] as const;
export const MESSAGE_ROLES = ["user", "employee", "system"] as const;
export const LINK_KINDS = ["objective", "activity", "evidence", "approval", "document", "recommendation", "task"] as const;
export const OBJECTIVE_STATUS = ["active", "paused", "achieved", "cancelled"] as const;
export const TRIGGER_KINDS = ["schedule", "event", "manual"] as const;
export const AGENDA_STATUS = ["active", "paused"] as const;
export const RUN_STATUS = ["queued", "awaiting_approval", "succeeded", "failed", "skipped", "rejected"] as const;
export const MEMORY_KINDS = ["preference", "decision", "context", "constraint", "history"] as const;
export const MEMORY_SOURCES = ["user", "employee", "system"] as const;
export const REQUEST_STATUS = ["pending", "approved", "denied"] as const;
export const MIN_EVERY_MINUTES = 15;
export const MAX_MONTHLY_MICROS = 1_000_000_000_000; // 1,000,000 currency units; one micro = 1e-6.

type V<T extends readonly string[]> = T[number];
export interface Link { kind: V<typeof LINK_KINDS>; id: string; label?: string }
export interface Attachment { name: string; ref: string; mime?: string }

/** A tenant-installed package. Packages are DATA (no code): that is what lets a marketplace employee or skill install without touching the Core. */
export interface PackageRecord { id: string; tenantId: string; packageKey: string; kind: V<typeof PACKAGE_KINDS>; version: string; name: string; manifest: Record<string, unknown>; status: V<typeof PACKAGE_STATUS>; source: V<typeof PACKAGE_SOURCES>; installedBy: string; createdAt: number; updatedAt: number }
export interface SkillInstallRecord { id: string; tenantId: string; employeeKey: string; skillKey: string; version: string; status: V<typeof SKILL_STATUS>; installedBy: string; createdAt: number; updatedAt: number }
export interface ThreadRecord { id: string; tenantId: string; employeeKey: string; userId: string; title: string; status: V<typeof THREAD_STATUS>; messageCount: number; lastMessageAt: number; createdAt: number; updatedAt: number }
export interface MessageRecord { id: string; tenantId: string; threadId: string; role: V<typeof MESSAGE_ROLES>; body: string; mode: Mode; provider: string; links: Link[]; attachments: Attachment[]; createdBy: string; createdAt: number }
export interface ObjectiveRecord { id: string; tenantId: string; employeeKey: string; title: string; description: string; priority: number; status: V<typeof OBJECTIVE_STATUS>; dependsOn: string[]; metric: string; dueAt: number | null; createdBy: string; createdAt: number; updatedAt: number }
export interface AgendaRecord { id: string; tenantId: string; employeeKey: string; objectiveId: string | null; title: string; instruction: string; triggerKind: V<typeof TRIGGER_KINDS>; eventAction: string | null; everyMinutes: number | null; priority: number; status: V<typeof AGENDA_STATUS>; requiresApproval: boolean; dependsOn: string[]; nextRunAt: number | null; lastRunAt: number | null; runCount: number; createdBy: string; createdAt: number; updatedAt: number }
export interface RunRecord { id: string; tenantId: string; agendaId: string; employeeKey: string; firedBy: V<typeof TRIGGER_KINDS>; status: V<typeof RUN_STATUS>; reason: string; threadId: string | null; costMicros: number; tokens: number; mode: Mode; decidedBy: string | null; createdAt: number; updatedAt: number; finishedAt: number | null }
export interface MemoryRecord { id: string; tenantId: string; employeeKey: string; kind: V<typeof MEMORY_KINDS>; title: string; body: string; source: V<typeof MEMORY_SOURCES>; active: boolean; createdBy: string; createdAt: number; updatedAt: number }
/** scope = "company" (the monthly pool) or an employee key (that employee's own allocation). */
export interface BudgetRecord { id: string; tenantId: string; scope: string; monthlyMicros: number; currency: string; updatedBy: string; createdAt: number; updatedAt: number }
export interface UsageRecord { id: string; tenantId: string; employeeKey: string; period: string; costMicros: number; tokens: number; provider: string; mode: Mode; refKind: string; refId: string; createdAt: number }
export interface BudgetRequestRecord { id: string; tenantId: string; employeeKey: string; period: string; amountMicros: number; reason: string; status: V<typeof REQUEST_STATUS>; requestedBy: string; decidedBy: string | null; decidedAt: number | null; createdAt: number; updatedAt: number }

const text = (max: number) => z.string().trim().max(max);
const key = z.string().trim().toLowerCase().regex(/^[a-z][a-z0-9_]{1,47}$/, "Use lowercase letters, digits and underscores.");
const id = z.string().trim().min(1).max(64);
export const linkSchema = z.object({ kind: z.enum(LINK_KINDS), id, label: text(120).optional() }).strict();
export const attachmentSchema = z.object({ name: text(120).min(1), ref: text(300).min(1), mime: text(80).optional() }).strict();

export const startThreadInput = z.object({ employeeKey: key, title: text(120).default("") }).strict();
export const sendInput = z.object({ body: text(4000).min(1), links: z.array(linkSchema).max(10).default([]), attachments: z.array(attachmentSchema).max(5).default([]) }).strict();
export const skillToggleInput = z.object({ enabled: z.boolean() }).strict();

/** The manifest an external package ships. Declarative only: it can name Core capabilities it needs, never carry code. */
export const skillManifest = z.object({
  kind: z.literal("skill"), key, version: z.string().regex(/^\d+\.\d+\.\d+$/), name: text(80).min(1), description: text(300).min(1), category: text(40).default("general"),
  prompt: text(2000).min(1), requires: z.array(z.string().trim().regex(/^[a-z][a-z0-9_.]{1,63}$/)).max(10).default([]),
}).strict();
export const employeeManifest = z.object({
  kind: z.literal("employee"), key, version: z.string().regex(/^\d+\.\d+\.\d+$/), name: text(80).min(1), description: text(300).min(1), department: text(40).min(1),
  goal: text(300).min(1), instructions: text(4000).min(1), skills: z.array(key).max(30).default([]),
}).strict();
export const manifestInput = z.discriminatedUnion("kind", [skillManifest, employeeManifest]);
export type SkillManifest = z.output<typeof skillManifest>;
export type EmployeeManifest = z.output<typeof employeeManifest>;
export const installInput = z.object({ manifest: manifestInput, source: z.enum(["marketplace", "custom"]).default("custom") }).strict();

export const objectiveInput = z.object({
  employeeKey: key, title: text(140).min(1), description: text(1000).default(""), priority: z.number().int().min(1).max(5).default(3),
  dependsOn: z.array(id).max(10).default([]), metric: text(140).default(""), dueAt: z.number().int().positive().nullable().default(null),
}).strict();
export const objectivePatch = z.object({
  title: text(140).min(1).optional(), description: text(1000).optional(), priority: z.number().int().min(1).max(5).optional(), status: z.enum(OBJECTIVE_STATUS).optional(),
  dependsOn: z.array(id).max(10).optional(), metric: text(140).optional(), dueAt: z.number().int().positive().nullable().optional(),
}).strict();

export const agendaInput = z.object({
  employeeKey: key, objectiveId: id.nullable().default(null), title: text(140).min(1), instruction: text(1000).min(1), triggerKind: z.enum(TRIGGER_KINDS),
  eventAction: z.string().trim().regex(/^[a-z][a-z0-9_]*\.[a-z][a-z0-9_.]*$/, "Use module.action.").nullable().default(null),
  everyMinutes: z.number().int().min(MIN_EVERY_MINUTES).max(60 * 24 * 31).nullable().default(null),
  priority: z.number().int().min(1).max(5).default(3), requiresApproval: z.boolean().default(true), dependsOn: z.array(id).max(10).default([]),
}).strict().superRefine((v, ctx) => {
  if (v.triggerKind === "schedule" && !v.everyMinutes) ctx.addIssue({ code: "custom", path: ["everyMinutes"], message: "A scheduled entry needs an interval." });
  if (v.triggerKind === "event" && !v.eventAction) ctx.addIssue({ code: "custom", path: ["eventAction"], message: "An event entry names the event." });
});
export const agendaPatch = z.object({ title: text(140).min(1).optional(), instruction: text(1000).min(1).optional(), priority: z.number().int().min(1).max(5).optional(), status: z.enum(AGENDA_STATUS).optional(), requiresApproval: z.boolean().optional(), everyMinutes: z.number().int().min(MIN_EVERY_MINUTES).max(60 * 24 * 31).optional() }).strict();
export const decisionInput = z.object({ approve: z.boolean(), reason: text(240).default("") }).strict();
export const fireInput = z.object({ action: z.string().trim().regex(/^[a-z][a-z0-9_]*\.[a-z][a-z0-9_.]*$/) }).strict();

export const memoryInput = z.object({ employeeKey: key, kind: z.enum(MEMORY_KINDS), title: text(120).min(1), body: text(1000).min(1) }).strict();
export const memoryPatch = z.object({ title: text(120).min(1).optional(), body: text(1000).min(1).optional(), active: z.boolean().optional() }).strict();

export const budgetInput = z.object({ monthlyMicros: z.number().int().min(0).max(MAX_MONTHLY_MICROS) }).strict();

export const monthOf = (t: number): string => new Date(t).toISOString().slice(0, 7);
