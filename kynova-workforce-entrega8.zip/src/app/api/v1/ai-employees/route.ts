import type { NextRequest } from "next/server";
import { z } from "zod";
import { ok, readJson } from "@/platform/auth/http";
import { getEmployeeFramework, EMPLOYEE_STATUS } from "@/platform/ai-employees";
import { employeeRoute } from "@/platform/ai-employees/http";
import { employeeDto } from "@/platform/ai-employees/serialize";
import { getTeamService, isTeamError } from "@/modules/team";
import { problem } from "@/platform/auth/http";

export const GET = employeeRoute("employee:read", async (req: NextRequest, _c, { actor, rid }) => {
  const status = req.nextUrl.searchParams.get("status");
  const parsed = z.enum(EMPLOYEE_STATUS).safeParse(status);
  return ok((await getEmployeeFramework().employees.list(actor, parsed.success ? { status: parsed.data } : {})).map(employeeDto), rid);
});

export const POST = employeeRoute("employee:manage", async (req: NextRequest, _c, { actor, rid }) => {
  const body = await readJson(req, z.record(z.string(), z.unknown()));
  // One plan check for every way of hiring (Entrega 8): the same rule the Team page applies.
  try { if (typeof body.blueprint === "string") await (await getTeamService()).assertBlueprintAllowed(actor, body.blueprint); }
  catch (e) { if (isTeamError(e)) return problem(e.code, e.status, e.message, rid); throw e; }
  return ok(employeeDto(await getEmployeeFramework().employees.hire(actor, body as never)), rid, 201);
}, { mutating: true });
