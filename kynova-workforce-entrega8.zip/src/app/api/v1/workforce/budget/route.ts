import { workforceRoute, readBody, respond } from "@/modules/workforce/http";

export const GET = workforceRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.budget(actor), rid); });
export const PUT = workforceRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.setBudget(actor, "company", await readBody(req)), rid); }, { mutating: true });
