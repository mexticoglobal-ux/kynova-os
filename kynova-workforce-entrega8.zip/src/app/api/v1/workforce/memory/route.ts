import { workforceRoute, readBody, respond } from "@/modules/workforce/http";

export const GET = workforceRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.listMemory(actor, { employeeKey: req.nextUrl.searchParams.get("employee_key") ?? "", includeInactive: req.nextUrl.searchParams.get("include_inactive") === "true" }), rid); });
export const POST = workforceRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.addMemory(actor, await readBody(req)), rid, 201); }, { mutating: true });
