import { workforceRoute, readBody, respond } from "@/modules/workforce/http";

type Ctx = { params: Promise<{ id: string }> };

export const PATCH = workforceRoute<Ctx>(async (req, c, { actor, svc, rid }) => { void req; void c; const p = await c.params; return respond(await svc.patchMemory(actor, p.id, await readBody(req)), rid); }, { mutating: true });
