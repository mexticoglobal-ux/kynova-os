import { workforceRoute, readBody, respond } from "@/modules/workforce/http";

export const GET = workforceRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.listRuns(actor, { status: req.nextUrl.searchParams.get("status") ?? undefined, agendaId: req.nextUrl.searchParams.get("agenda_id") ?? undefined }), rid); });
