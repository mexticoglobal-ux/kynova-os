import { workforceRoute, readBody, respond } from "@/modules/workforce/http";

type Ctx = { params: Promise<{ id: string }> };

export const POST = workforceRoute<Ctx>(async (req, c, { actor, svc, rid }) => { void req; void c; const p = await c.params; return respond(await svc.runNow(actor, p.id), rid, 201); }, { mutating: true });
