import { workforceRoute, readBody, respond } from "@/modules/workforce/http";

export const POST = workforceRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.fire(actor, await readBody(req)), rid); }, { mutating: true });
