import { workforceRoute, readBody, respond } from "@/modules/workforce/http";

export const GET = workforceRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.listAgenda(actor, { employeeKey: req.nextUrl.searchParams.get("employee_key") ?? undefined }), rid); });
export const POST = workforceRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.createAgenda(actor, await readBody(req)), rid, 201); }, { mutating: true });
