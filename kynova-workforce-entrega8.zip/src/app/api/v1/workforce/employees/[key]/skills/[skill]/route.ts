import { workforceRoute, readBody, respond } from "@/modules/workforce/http";

type Ctx = { params: Promise<{ key: string; skill: string }> };

export const PUT = workforceRoute<Ctx>(async (req, c, { actor, svc, rid }) => { void req; void c; const p = await c.params; return respond(await svc.setSkill(actor, p.key, p.skill, await readBody(req)), rid); }, { mutating: true });
