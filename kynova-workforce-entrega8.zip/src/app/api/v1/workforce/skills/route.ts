import { workforceRoute, readBody, respond } from "@/modules/workforce/http";

export const GET = workforceRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.skills(actor, req.nextUrl.searchParams.get("employee_key") ?? undefined), rid); });
