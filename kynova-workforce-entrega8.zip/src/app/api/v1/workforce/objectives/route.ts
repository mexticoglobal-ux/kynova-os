import { workforceRoute, readBody, respond } from "@/modules/workforce/http";

export const GET = workforceRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.listObjectives(actor, { employeeKey: req.nextUrl.searchParams.get("employee_key") ?? undefined, status: req.nextUrl.searchParams.get("status") ?? undefined }), rid); });
export const POST = workforceRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.createObjective(actor, await readBody(req)), rid, 201); }, { mutating: true });
