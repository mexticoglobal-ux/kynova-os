import { teamContext } from "@/components/team/context";
import { MissionHome } from "@/components/team/MissionHome";
import { BudgetCard } from "@/components/workforce/BudgetCard";
import { WorkforceI18n } from "@/components/workforce/I18n";
import { workforceContext } from "@/components/workforce/context";
import { WORKFORCE_DICTIONARIES } from "@/modules/workforce/i18n";

export const metadata = { title: "Mission Control" };
export const dynamic = "force-dynamic";

/** The first screen after login (CLAUDE.md 2): Mission Control, the company operating. The widget panels it used to show stay available, unchanged, at /app/mission-control. */
export default async function DashboardPage() {
  const ctx = await teamContext("dashboard"), wf = await workforceContext("dashboard").catch(() => null);
  return (
    <main id="main" className="mx-auto w-full max-w-[96rem] p-4 sm:p-6 lg:p-8">
      <MissionHome ctx={ctx} />
      {wf && <div className="mt-5 max-w-2xl"><WorkforceI18n dict={WORKFORCE_DICTIONARIES[wf.locale]} locale={wf.locale}><BudgetCard ctx={wf} /></WorkforceI18n></div>}
    </main>
  );
}
