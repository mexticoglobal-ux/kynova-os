import { BudgetCard } from "@/components/workforce/BudgetCard";
import { workforceContext, usd } from "@/components/workforce/context";
import { AchieveButton, AgendaActions, AgendaForm, BudgetForm, ObjectiveForm, RequestButtons, RunButtons } from "@/components/workforce/Panels";
import { Card, Empty, Notice, Pill, ago } from "@/components/workforce/ui";
import { ARCHITECTURE_STATUS, type WorkforceKey } from "@/modules/workforce";

export const metadata = { title: "Equipo IA" };
export const dynamic = "force-dynamic";

const ST = (v: string) => (v.startsWith("built") ? "built" : v === "not_connected" ? "not_connected" : v.startsWith("partial") ? "partial" : "not_built");
const TONE = { built: "success", partial: "warning", not_built: "muted", not_connected: "muted" } as const;

export default async function WorkforcePage() {
  const ctx = await workforceContext(), { t, locale, svc, actor } = ctx, now = Date.now();
  const [sum, people, objectives, agenda, runs, requests, pkgs, perm] = await Promise.all([svc.summary(actor), svc.employees(actor), svc.listObjectives(actor), svc.listAgenda(actor), svc.listRuns(actor), svc.listBudgetRequests(actor, "pending"), svc.listPackages(actor), svc.permissions(actor)]);
  const names = new Map(people.map((p) => [p.key, p.name])), who = people.filter((p) => p.active && p.entitled), manage = perm.capabilities.includes("manage"), approve = perm.capabilities.includes("approve");
  const waiting = runs.filter((r) => r.status === "awaiting_approval"), agendaTitle = new Map(agenda.map((a) => [a.id, a.title]));
  return (
    <div className="grid gap-5">
      <header><h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{t("title")}</h1></header>
      {!sum.provider.connected || sum.provider.mode === "simulation" ? <Notice>{t("provider.none")}</Notice> : null}
      <div className="grid gap-5 lg:grid-cols-2">
        <div className="grid content-start gap-5">
          <BudgetCard ctx={ctx} link={false} />
          {approve && <Card title={t("budget.title")}><BudgetForm current={sum.budget.configured ? sum.budget.company.assigned - sum.budget.company.authorizedExtra : 0} /></Card>}
          {sum.budget.employees.length > 0 && (
            <Card title={t("budget.perEmployee")}><ul className="grid gap-2">{sum.budget.employees.map((e) => (
              <li key={e.employeeKey} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span>{names.get(e.employeeKey) ?? e.employeeKey}</span>
                <span className="text-xs text-muted">{e.assigned === null ? t("budget.noLimit") : `${usd(e.used, locale)} / ${usd(e.assigned, locale)}`}{e.assigned === null && ` · ${usd(e.used, locale)}`}</span></li>))}</ul></Card>)}
        </div>
        <Card title={t("req.title")}>
          {requests.length === 0 && waiting.length === 0 ? <Empty>{t("req.none")}</Empty> : (
            <ul className="grid gap-2">
              {requests.map((r) => <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span className="min-w-0 flex-1">{t("req.budget", { name: names.get(r.employeeKey) ?? r.employeeKey, amount: usd(r.amountMicros, locale) })}</span>{approve && <RequestButtons id={r.id} />}</li>)}
              {waiting.map((r) => <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span className="min-w-0 flex-1">{t("req.run", { name: names.get(r.employeeKey) ?? r.employeeKey, title: agendaTitle.get(r.agendaId) ?? "—" })}</span>{approve && <RunButtons id={r.id} />}</li>)}
            </ul>
          )}
        </Card>
      </div>
      <Card title={t("obj.title")}>
        {objectives.length === 0 ? <Empty>{t("obj.none")}</Empty> : (
          <ul className="mb-3 grid gap-2">{objectives.map((o) => (
            <li key={o.id} className="flex flex-wrap items-center gap-2 rounded-lg border border-line px-3 py-2 text-sm"><Pill tone="info">P{o.priority}</Pill><span className="min-w-0 flex-1">{o.title} <span className="text-xs text-muted">· {names.get(o.employeeKey) ?? o.employeeKey}</span></span>
              {o.status === "achieved" ? <Pill tone="success">{t("obj.achieved")}</Pill> : o.blockedBy.length > 0 ? <Pill tone="warning">{t("obj.blocked")}</Pill> : manage && <AchieveButton id={o.id} />}</li>))}</ul>)}
        {manage && who.length > 0 && <ObjectiveForm people={who.map((p) => ({ key: p.key, name: p.name }))} />}
      </Card>
      <Card title={t("agenda.title")} action={manage ? <AgendaActions /> : undefined}>
        <p className="mb-3 text-xs text-muted">{t("agenda.worker")}</p>
        {agenda.length === 0 ? <Empty>{t("agenda.none")}</Empty> : (
          <ul className="mb-3 grid gap-2">{agenda.map((a) => (
            <li key={a.id} className="flex flex-wrap items-center gap-2 rounded-lg border border-line px-3 py-2 text-sm"><Pill tone="info">P{a.priority}</Pill><span className="min-w-0 flex-1">{a.title} <span className="text-xs text-muted">· {names.get(a.employeeKey) ?? a.employeeKey} · {a.triggerKind === "schedule" ? t("agenda.schedule", { n: a.everyMinutes ?? 0 }) : a.triggerKind === "event" ? t("agenda.event", { event: a.eventAction ?? "" }) : t("agenda.manual")}</span></span>
              {manage && a.status === "active" && <AgendaActions id={a.id} />}</li>))}</ul>)}
        {manage && who.length > 0 && <AgendaForm people={who.map((p) => ({ key: p.key, name: p.name }))} />}
      </Card>
      <div className="grid gap-5 lg:grid-cols-2">
        <Card title={t("run.title")}>
          {runs.length === 0 ? <Empty>{t("run.none")}</Empty> : <ul className="grid gap-2">{runs.slice(0, 8).map((r) => <li key={r.id} className="flex flex-wrap items-center gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span className="min-w-0 flex-1">{names.get(r.employeeKey) ?? r.employeeKey}: {agendaTitle.get(r.agendaId) ?? "—"}</span><Pill tone={r.status === "succeeded" ? "success" : r.status === "failed" ? "danger" : "warning"}>{r.status}{r.reason ? ` · ${r.reason}` : ""}</Pill>{r.mode === "simulation" && <Pill tone="warning">{t("provider.sim")}</Pill>}<time className="text-xs text-muted" dateTime={new Date(r.createdAt).toISOString()}>{ago(r.createdAt, now, locale)}</time></li>)}</ul>}
        </Card>
        <Card title={t("pkg.title")}>{pkgs.length === 0 ? <Empty>{t("pkg.none")}</Empty> : <ul className="grid gap-2">{pkgs.map((p) => <li key={p.id} className="flex items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span>{p.name} <span className="text-xs text-muted">{p.kind} · {p.version}</span></span><Pill tone={p.status === "active" ? "success" : "muted"}>{p.status}</Pill></li>)}</ul>}</Card>
      </div>
      <Card title={t("arch.title")}>
        <p className="mb-3 text-xs text-muted">{t("arch.notice")}</p>
        <ul className="grid gap-2 sm:grid-cols-2">{Object.entries(ARCHITECTURE_STATUS).map(([k, v]) => <li key={k} className="flex items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span>{t(`wf.${k}` as WorkforceKey)}</span><Pill tone={TONE[ST(v) as keyof typeof TONE]}>{t(`st.${ST(v)}` as WorkforceKey)}</Pill></li>)}</ul>
      </Card>
    </div>
  );
}
