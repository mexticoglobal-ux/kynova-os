import type { ReactNode } from "react";
import { WorkforceI18n } from "@/components/workforce/I18n";
import { workforceContext } from "@/components/workforce/context";
import { WORKFORCE_DICTIONARIES } from "@/modules/workforce/i18n";

export default async function WorkforceLayout({ children }: { children: ReactNode }) {
  const { locale } = await workforceContext();
  return <WorkforceI18n dict={WORKFORCE_DICTIONARIES[locale]} locale={locale}><main id="main" className="mx-auto w-full max-w-[96rem] p-4 sm:p-6 lg:p-8">{children}</main></WorkforceI18n>;
}
