import { notFound } from "next/navigation";
import { Chat, type ChatMessage } from "@/components/workforce/Chat";
import { workforceContext } from "@/components/workforce/context";
import { ForgetButton, MemoryForm, SkillToggle } from "@/components/workforce/Panels";
import { Card, Empty, Notice, Pill } from "@/components/workforce/ui";
import { isWorkforceError, toWire, type WorkforceKey } from "@/modules/workforce";

export const dynamic = "force-dynamic";
type Props = { params: Promise<{ key: string }> };

export default async function TalkPage({ params }: Props) {
  const { key } = await params, ctx = await workforceContext(), { t, svc, actor } = ctx;
  const people = await svc.employees(actor), me = people.find((p) => p.key === key);
  if (!me) notFound();
  const perm = svc.permissions(actor), manage = perm.capabilities.includes("manage");
  const [threads, sk, memory, objectives, budget] = await Promise.all([svc.listThreads(actor, { employeeKey: key, status: "open" }).catch((e) => { if (isWorkforceError(e)) return []; throw e; }), svc.skills(actor, key).catch(() => null), svc.listMemory(actor, { employeeKey: key }).catch(() => []), svc.listObjectives(actor, { employeeKey: key, status: "active" }).catch(() => []), svc.budget(actor)]);
  const thread = threads[0] ?? null, history = thread ? (await svc.getThread(actor, thread.id)).messages : [];
  const ready = me.active && me.entitled;
  return (
    <div className="grid gap-5">
      <header><a href={`/app/team/${key}`} className="text-xs text-muted hover:underline">← {me.name}</a><h1 className="text-xl font-bold tracking-tight sm:text-2xl">{t("chat.title", { name: me.name })}</h1></header>
      {!ready ? <Notice>{me.entitled ? t("chat.inactive") : t("chat.plan")}</Notice> : !budget.configured ? <Notice>{t("chat.budget")} · <a className="underline" href="/app/workforce">{t("budget.open")}</a></Notice> : null}
      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2">{ready ? <Chat employeeKey={key} employeeName={me.name} threadId={thread?.id ?? null} initial={toWire(history) as ChatMessage[]} /> : <Empty>{me.entitled ? t("chat.inactive") : t("chat.plan")}</Empty>}</Card>
        <div className="grid content-start gap-5">
          <Card title={t("skills.title")}>
            <p className="mb-2 text-xs text-muted">{t("skills.hint")}</p>
            {!sk || sk.employee?.length === 0 ? <Empty>{t("skills.none")}</Empty> : <ul className="grid gap-2">{sk.employee?.map((s) => <li key={s.key} className="flex items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span>{s.name} <Pill tone="muted">{t("skills.reasoning")}</Pill></span><SkillToggle employeeKey={key} skillKey={s.key} enabled={s.enabled} canManage={manage} /></li>)}</ul>}
          </Card>
          <Card title={t("memory.title")}>
            {memory.length === 0 ? <Empty>{t("memory.none")}</Empty> : <ul className="mb-3 grid gap-2">{memory.map((m) => <li key={m.id} className="flex items-start justify-between gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span className="min-w-0"><Pill tone="info">{t(`memory.${m.kind}` as WorkforceKey)}</Pill> <b>{m.title}</b><br /><span className="text-muted">{m.body}</span></span>{manage && <ForgetButton id={m.id} />}</li>)}</ul>}
            {manage && <MemoryForm employeeKey={key} />}
          </Card>
          <Card title={t("obj.title")}>{objectives.length === 0 ? <Empty>{t("obj.none")}</Empty> : <ul className="grid gap-2">{objectives.map((o) => <li key={o.id} className="rounded-lg border border-line px-3 py-2 text-sm"><Pill tone="info">P{o.priority}</Pill> {o.title}</li>)}</ul>}</Card>
        </div>
      </div>
    </div>
  );
}
