"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Err, btn, field, primary, useRun } from "./Actions";
import { wfCall } from "./api";
import { useT } from "./I18n";

type Person = { key: string; name: string };

export function BudgetForm({ current }: { current: number }) {
  const { t } = useT(), { busy, err, run } = useRun(), [usd, setUsd] = useState(current ? String(current / 1e6) : "");
  return (
    <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); void run(() => wfCall("PUT", "/workforce/budget", { monthlyMicros: Math.round(Number(usd) * 1e6) })); }}>
      <label className="grid gap-1 text-xs text-muted">{t("budget.label")}<input className={`${field} w-40`} inputMode="decimal" value={usd} onChange={(e) => setUsd(e.target.value)} required /></label>
      <button type="submit" className={primary} disabled={busy || !(Number(usd) > 0)}>{busy ? t("common.saving") : t("budget.set")}</button><Err err={err} />
    </form>
  );
}
export function RequestButtons({ id }: { id: string }) {
  const { t } = useT(), { busy, err, run } = useRun();
  return <div className="grid gap-1"><div className="flex gap-2">
    <button type="button" className={primary} disabled={busy} onClick={() => void run(() => wfCall("POST", `/workforce/budget/requests/${id}/decision`, { approve: true }))}>{t("common.approve")}</button>
    <button type="button" className={btn} disabled={busy} onClick={() => void run(() => wfCall("POST", `/workforce/budget/requests/${id}/decision`, { approve: false }))}>{t("common.deny")}</button></div><Err err={err} /></div>;
}
export function RunButtons({ id }: { id: string }) {
  const { t } = useT(), { busy, err, run } = useRun();
  return <div className="grid gap-1"><div className="flex gap-2">
    <button type="button" className={primary} disabled={busy} onClick={() => void run(() => wfCall("POST", `/workforce/agenda/runs/${id}/decision`, { approve: true }))}>{t("common.approve")}</button>
    <button type="button" className={btn} disabled={busy} onClick={() => void run(() => wfCall("POST", `/workforce/agenda/runs/${id}/decision`, { approve: false }))}>{t("common.reject")}</button></div><Err err={err} /></div>;
}
export function ObjectiveForm({ people }: { people: Person[] }) {
  const { t } = useT(), { busy, err, run } = useRun(), [title, setTitle] = useState(""), [who, setWho] = useState(people[0]?.key ?? ""), [priority, setPriority] = useState("3");
  return (
    <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); void run(() => wfCall("POST", "/workforce/objectives", { employeeKey: who, title, priority: Number(priority) }), () => { setTitle(""); location.reload(); }); }}>
      <label className="grid gap-1 text-xs text-muted">{t("obj.employee")}<select className={field} value={who} onChange={(e) => setWho(e.target.value)}>{people.map((p) => <option key={p.key} value={p.key}>{p.name}</option>)}</select></label>
      <label className="grid min-w-48 flex-1 gap-1 text-xs text-muted">{t("obj.name")}<input className={field} value={title} onChange={(e) => setTitle(e.target.value)} maxLength={140} required /></label>
      <label className="grid gap-1 text-xs text-muted">{t("common.priority")}<select className={field} value={priority} onChange={(e) => setPriority(e.target.value)}>{[1, 2, 3, 4, 5].map((n) => <option key={n}>{n}</option>)}</select></label>
      <button type="submit" className={primary} disabled={busy || !title.trim() || !who}>{t("common.add")}</button><Err err={err} />
    </form>
  );
}
export function AchieveButton({ id }: { id: string }) {
  const { t } = useT(), { busy, err, run } = useRun();
  return <span className="grid gap-1"><button type="button" className={btn} disabled={busy} onClick={() => void run(() => wfCall("PATCH", `/workforce/objectives/${id}`, { status: "achieved" }))}>{t("obj.mark")}</button><Err err={err} /></span>;
}
export function AgendaForm({ people }: { people: Person[] }) {
  const { t } = useT(), { busy, err, run } = useRun(), [title, setTitle] = useState(""), [ins, setIns] = useState(""), [who, setWho] = useState(people[0]?.key ?? ""), [every, setEvery] = useState(""), [ask, setAsk] = useState(true);
  const body = () => ({ employeeKey: who, title, instruction: ins, triggerKind: every ? "schedule" : "manual", ...(every ? { everyMinutes: Number(every) } : {}), requiresApproval: ask });
  return (
    <form className="grid gap-2" onSubmit={(e) => { e.preventDefault(); void run(() => wfCall("POST", "/workforce/agenda", body()), () => { setTitle(""); setIns(""); location.reload(); }); }}>
      <div className="flex flex-wrap gap-2">
        <label className="grid gap-1 text-xs text-muted">{t("obj.employee")}<select className={field} value={who} onChange={(e) => setWho(e.target.value)}>{people.map((p) => <option key={p.key} value={p.key}>{p.name}</option>)}</select></label>
        <label className="grid min-w-40 flex-1 gap-1 text-xs text-muted">{t("agenda.new")}<input className={field} value={title} onChange={(e) => setTitle(e.target.value)} maxLength={140} required /></label>
        <label className="grid w-44 gap-1 text-xs text-muted">{t("agenda.every")}<input className={field} inputMode="numeric" value={every} onChange={(e) => setEvery(e.target.value.replace(/\D/g, ""))} /></label>
      </div>
      <label className="grid gap-1 text-xs text-muted">{t("agenda.instruction")}<textarea className={field} rows={2} value={ins} onChange={(e) => setIns(e.target.value)} maxLength={1000} required /></label>
      <div className="flex flex-wrap items-center gap-3"><label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={ask} onChange={(e) => setAsk(e.target.checked)} />{t("agenda.approval")}</label>
        <button type="submit" className={primary} disabled={busy || !title.trim() || !ins.trim() || !who}>{t("common.add")}</button></div><Err err={err} />
    </form>
  );
}
export function AgendaActions({ id }: { id?: string }) {
  const { t } = useT(), { busy, err, run } = useRun();
  return <span className="grid gap-1"><button type="button" className={btn} disabled={busy} onClick={() => void run(() => (id ? wfCall("POST", `/workforce/agenda/${id}/run`, {}) : wfCall("POST", "/workforce/agenda/tick", {})))}>{id ? t("agenda.run") : t("agenda.tick")}</button><Err err={err} /></span>;
}
export function MemoryForm({ employeeKey }: { employeeKey: string }) {
  const { t } = useT(), { busy, err, run } = useRun(), [kind, setKind] = useState("preference"), [name, setName] = useState(""), [body, setBody] = useState("");
  return (
    <form className="grid gap-2" onSubmit={(e) => { e.preventDefault(); void run(() => wfCall("POST", "/workforce/memory", { employeeKey, kind, title: name, body }), () => { setName(""); setBody(""); location.reload(); }); }}>
      <div className="flex flex-wrap gap-2">
        <label className="grid gap-1 text-xs text-muted">{t("memory.kind")}<select className={field} value={kind} onChange={(e) => setKind(e.target.value)}>{["preference", "decision", "context", "constraint", "history"].map((k) => <option key={k} value={k}>{t(`memory.${k}` as "memory.preference")}</option>)}</select></label>
        <label className="grid min-w-40 flex-1 gap-1 text-xs text-muted">{t("memory.name")}<input className={field} value={name} onChange={(e) => setName(e.target.value)} maxLength={120} required /></label>
      </div>
      <label className="grid gap-1 text-xs text-muted">{t("memory.body")}<textarea className={field} rows={2} value={body} onChange={(e) => setBody(e.target.value)} maxLength={1000} required /></label>
      <div><button type="submit" className={primary} disabled={busy || !name.trim() || !body.trim()}>{t("common.add")}</button></div><Err err={err} />
    </form>
  );
}
export function ForgetButton({ id }: { id: string }) {
  const { t } = useT(), { busy, run } = useRun();
  return <button type="button" className={btn} disabled={busy} onClick={() => void run(() => wfCall("PATCH", `/workforce/memory/${id}`, { active: false }))}>{t("memory.forget")}</button>;
}
export function SkillToggle({ employeeKey, skillKey, enabled, canManage }: { employeeKey: string; skillKey: string; enabled: boolean; canManage: boolean }) {
  const { t } = useT(), router = useRouter(), { busy, err, run } = useRun();
  return <span className="grid gap-1"><button type="button" className={btn} disabled={busy || !canManage} aria-pressed={enabled} onClick={() => void run(() => wfCall("PUT", `/workforce/employees/${employeeKey}/skills/${skillKey}`, { enabled: !enabled }), () => router.refresh())}>{enabled ? t("skills.on") : t("skills.off")}</button><Err err={err} /></span>;
}
