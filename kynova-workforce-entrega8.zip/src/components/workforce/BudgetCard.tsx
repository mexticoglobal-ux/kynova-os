import type { WorkforceContext } from "./context";
import { usd } from "./context";
import { Card, LinkBtn, Notice, Pill, Stat } from "./ui";

const TONE = { ok: "success", warning: "warning", exhausted: "danger", not_configured: "muted" } as const;

/** Assigned, used and available AI budget of the company. Shown in Mission Control and in the AI team page; only reads. */
export async function BudgetCard({ ctx, link = true }: { ctx: WorkforceContext; link?: boolean }) {
  const { t, locale } = ctx, b = await ctx.svc.budget(ctx.actor).catch(() => null);
  if (!b) return null;
  return (
    <Card title={t("budget.title")} action={<Pill tone={TONE[b.status]}>{t(`budget.st.${b.status}`)}</Pill>}>
      {!b.configured ? <Notice>{t("budget.notSet")}</Notice> : (
        <dl className="grid grid-cols-3 gap-3"><Stat label={t("budget.assigned")} value={usd(b.company.assigned, locale)} /><Stat label={t("budget.used")} value={usd(b.company.used, locale)} /><Stat label={t("budget.available")} value={usd(b.company.available, locale)} /></dl>
      )}
      {b.company.simulatedUsed > 0 && <p className="mt-2 text-xs text-muted">{t("budget.simulated", { amount: usd(b.company.simulatedUsed, locale) })}</p>}
      {b.company.authorizedExtra > 0 && <p className="mt-1 text-xs text-muted">{t("budget.extra", { amount: usd(b.company.authorizedExtra, locale) })}</p>}
      {link && <div className="mt-3"><LinkBtn href="/app/workforce">{t("budget.open")}</LinkBtn></div>}
    </Card>
  );
}
