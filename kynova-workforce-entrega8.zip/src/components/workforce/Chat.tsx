"use client";
import { useEffect, useRef, useState } from "react";
import { Err, field, primary } from "./Actions";
import { wfCall } from "./api";
import { useT } from "./I18n";
import { Pill } from "./ui";

export interface ChatMessage { id: string; role: "user" | "employee" | "system"; body: string; mode: "simulation" | "production"; created_at: string }
type Sent = { thread: { id: string }; user: ChatMessage; reply: ChatMessage };

/** A private conversation. The thread is created on the first message, so opening this page never writes anything. Every reply shows whether it is a Simulation. */
export function Chat({ employeeKey, employeeName, threadId, initial }: { employeeKey: string; employeeName: string; threadId: string | null; initial: ChatMessage[] }) {
  const { t } = useT(), [msgs, setMsgs] = useState(initial), [text, setText] = useState(""), [busy, setBusy] = useState(false), [err, setErr] = useState<string | null>(null), [stop, setStop] = useState(false), [tid, setTid] = useState(threadId), end = useRef<HTMLDivElement>(null);
  useEffect(() => { end.current?.scrollIntoView({ block: "end" }); }, [msgs.length]);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const body = text.trim();
    if (!body || busy) return;
    setBusy(true); setErr(null); setStop(false);
    let id = tid;
    if (!id) {
      const s = await wfCall<{ id: string }>("POST", "/workforce/threads", { employeeKey });
      if (!s.ok || !s.data) { setBusy(false); setErr(s.message ?? t("common.error")); return; }
      id = s.data.id; setTid(id);
    }
    const r = await wfCall<Sent>("POST", `/workforce/threads/${id}/messages`, { body });
    setBusy(false);
    if (!r.ok || !r.data) { if (r.status === 402) setStop(true); setErr(r.status === 402 ? null : (r.message ?? t("common.error"))); return; }
    setMsgs((m) => [...m, r.data!.user, r.data!.reply]); setText("");
  }
  return (
    <div className="grid gap-3">
      <div className="max-h-[28rem] min-h-48 overflow-y-auto rounded-xl border border-line p-3" role="log" aria-live="polite">
        {msgs.length === 0 ? <p className="py-8 text-center text-sm text-muted">{t("chat.empty")}</p> : (
          <ol className="grid gap-3">{msgs.filter((m) => m.role !== "system").map((m) => (
            <li key={m.id} className={`max-w-[85%] rounded-xl px-3 py-2 text-sm ${m.role === "user" ? "ml-auto bg-ac/10" : "border border-line"}`}>
              <p className="mb-1 flex items-center gap-2 text-xs text-muted">{m.role === "user" ? t("chat.you") : employeeName}{m.role === "employee" && m.mode === "simulation" && <Pill tone="warning">{t("provider.sim")}</Pill>}</p>
              <p className="whitespace-pre-wrap">{m.body}</p>
            </li>))}</ol>
        )}
        <div ref={end} />
      </div>
      {stop && <p role="alert" className="rounded-xl border border-amber-500/40 bg-amber-500/5 px-4 py-3 text-sm">{t("chat.budgetStop", { name: employeeName })} <a className="underline" href="/app/workforce">{t("budget.open")}</a></p>}
      <form className="flex items-end gap-2" onSubmit={(e) => void submit(e)}>
        <label className="sr-only" htmlFor="wf-msg">{t("chat.placeholder")}</label>
        <textarea id="wf-msg" className={`${field} min-h-11 flex-1`} rows={2} maxLength={4000} placeholder={t("chat.placeholder")} value={text} onChange={(e) => setText(e.target.value)} />
        <button type="submit" className={primary} disabled={busy || !text.trim()}>{busy ? t("chat.sending") : t("chat.send")}</button>
      </form>
      <Err err={err} />
    </div>
  );
}
