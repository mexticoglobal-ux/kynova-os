import { redirect } from "next/navigation";
import { requireModuleAccess } from "@/platform/auth/session";
import { getWorkforceService, tr, workforceLocale, type Actor, type WorkforceKey } from "@/modules/workforce";

/** Server-side context of the workforce pages: verified session, actor, service and translator. The tenant always comes from the session. */
export async function workforceContext(slug: "workforce" | "dashboard" = "workforce") {
  const s = await requireModuleAccess(slug);
  if (!s.tenantId) redirect("/app/profile");
  const actor: Actor = { tenantId: s.tenantId, userId: s.user.id, role: s.role };
  const locale = workforceLocale(s.user.locale);
  return { actor, locale, svc: await getWorkforceService(), t: (k: WorkforceKey, v?: Record<string, string | number>) => tr(locale, k, v) };
}
export type WorkforceContext = Awaited<ReturnType<typeof workforceContext>>;
export const usd = (micros: number, locale: string) => new Intl.NumberFormat(locale, { style: "currency", currency: "USD", maximumFractionDigits: micros < 10_000_000 ? 4 : 2 }).format(micros / 1e6);
