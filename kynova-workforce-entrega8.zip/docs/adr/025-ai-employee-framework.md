# ADR 025 · AI Employee Framework (módulo `workforce`)

**Estado:** aceptado · **Entrega 8**

**Contexto.** KYNOVA necesita una base común para miles de AI Employees y un futuro marketplace, sin conectar aún ningún proveedor de IA.

**Decisión.** Un módulo nuevo (`workforce`) con skills, paquetes declarativos, conversaciones privadas por tenant, objetivos con dependencias, agenda, memoria, presupuesto mensual con autorización, y un puerto de proveedor (`AiProvider`) con solo una simulación conectada. Toda acción deja evidencia en el Activity Engine. El módulo no importa el AI Kernel ni SDKs de proveedores.

**Alternativas descartadas.** Ampliar `platform/ai-employees` (congelado y centrado en tareas); código ejecutable en paquetes (riesgo de seguridad y de tocar el Core); contar presupuesto por tokens de un proveedor (no es independiente del proveedor).

**Consecuencias.** Conectar un proveedor = registrar un adaptador. Instalar un empleado/skill externo = guardar un manifest. Pendiente: worker 24/7, herramientas reales, venta en marketplace, aprendizaje entre empresas.

**¿Escala a 10,000 empresas sin rediseñar?** Sí: todo es `tenant_id`-first, sumas en servidor, sin borrados, paquetes y skills resueltos por empresa.

**Cambios en código existente (aditivos):** `config/modules.ts` (slug `workforce`), `platform/db/catalog/plans.ts` (`workforce` en Starter), `modules/team` (`assertBlueprintAllowed`, exports), `app/api/v1/ai-employees/route.ts` (chequeo de plan), páginas `dashboard` y `team/[key]` (tarjeta de presupuesto y botón Hablar), tests de módulos (30).
