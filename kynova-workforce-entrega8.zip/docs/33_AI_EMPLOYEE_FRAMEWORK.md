# 33 · AI Employee Framework (Workforce) — Entrega 8

Módulo `src/modules/workforce` · API `/api/v1/workforce/*` · UI `/app/workforce`, `/app/workforce/talk/[key]` · migración `1800_workforce.sql` (tablas `wf_*`).

## Qué es
La base común de todos los AI Employees actuales y futuros. No es un chat: es lo que hace que un AI Employee sea un empleado (skills, conversaciones, objetivos, agenda, memoria, presupuesto, evidencia), igual para todos. Se apoya en el Team (roster y planes), el framework de empleados (activación) y el Activity Engine (evidencia).

## Piezas
| Pieza | Qué hay | Tablas |
|---|---|---|
| **Skills** | Entidad propia. Se activan/desactivan por empleado sin reemplazarlo. Las incluidas son solo de razonamiento (`stage: reasoning`). Marketing: SEO, Meta Ads, Google Ads, Email Marketing, Analytics. Finanzas: Facturación, Presupuestos, Flujo de caja, Impuestos. | `wf_skill_installs` |
| **Paquetes instalables** | Un empleado o una skill externa se instala con un *manifest declarativo* (sin código). Versionado: una versión activa por paquete, las anteriores quedan `superseded`. Solo Business/Enterprise. Una skill solo puede requerir capacidades que el Core ya tiene. | `wf_packages` |
| **Conversaciones** | Hilos privados usuario↔empleado por `tenant_id`. Los mensajes admiten vínculos a objetivos, actividad, evidencia, aprobaciones, documentos, recomendaciones y tareas, y adjuntos (referencias). Mensajes inmutables. El historial y el contexto (objetivos, memoria, skills) se arman en cada respuesta. | `wf_threads`, `wf_messages` |
| **Objetivos** | Por empleado, prioridad 1–5, dependencias entre objetivos (también de otros empleados), sin ciclos. | `wf_objectives` |
| **Agenda** | Entradas por horario (mín. 15 min), evento o manual; prioridad; dependencias; aprobación previa por defecto. Cada ejecución verifica empleado activo → dependencias → presupuesto → aprobación y deja su resultado y su evidencia. | `wf_agenda`, `wf_runs` |
| **Memoria** | Por empleado y empresa: preferencias, decisiones, contexto, restricciones, historial. Se “olvida” desactivando (nada se borra). | `wf_memory` |
| **Presupuesto** | Mensual por empresa (y asignación opcional por empleado), independiente del proveedor (cuenta micros-USD en un libro de uso inmutable, sumados en el servidor). Asignado / usado / disponible. Al llegar al límite el empleado pide autorización (una solicitud pendiente por empleado y mes) y una persona aprueba o deniega. Sin presupuesto configurado, nadie trabaja. | `wf_budgets`, `wf_usage`, `wf_budget_requests` |
| **Evidencia** | Cada acción relevante se registra en el Activity Engine (`workforce.*`, `mode` simulation/production). Mission Control las muestra con las del resto. | (Activity Engine) |
| **Proveedor de IA** | `AiProvider`: puerto con adaptadores declarados para Claude, OpenAI, Gemini, Mistral y DeepSeek. **Ninguno está conectado.** Solo existe `simulated`; todo lo que genera se marca Simulación y su costo es una estimación, no un cobro. | — |

## Decisiones
- **Un solo punto de activación con validación de plan.** `POST /api/v1/ai-employees` ahora llama a `team.assertBlueprintAllowed` antes de contratar, la misma regla del botón Activar. (Cierra el hueco señalado en la Entrega 7.)
- **Sin proveedor real.** El Framework no importa SDKs ni el AI Kernel (lo verifica un test de arquitectura). Al conectar uno se registra con `registerProvider()` y no cambia nada más.
- **Paquetes = datos, no código.** Es lo que permite un marketplace sin tocar el Core ni ejecutar código de terceros.
- **Conversaciones privadas de verdad:** otra persona de la misma empresa recibe `not_found`, también un owner.
- **Presupuesto fail-closed:** sin presupuesto o sin saldo el empleado no gasta; la causa se muestra y se pide autorización.
- **Escala (10,000 empresas):** todo es por `tenant_id` con índices que empiezan por él; las sumas del presupuesto son `SUM` en el servidor sobre un índice `(tenant_id, period, employee_key)`; ninguna tabla se borra; los paquetes y skills se resuelven por empresa sin cambios en el Core.

## Lo que NO existe (dicho en la UI)
- **Proceso 24/7 en segundo plano:** la agenda corre al pulsar “Ejecutar lo pendiente”/“Ejecutar ahora” o al disparar un evento por API. Falta el Cron Trigger/Queue de Cloudflare que recorra empresas y llame a `tick`.
- **Proveedor de IA real conectado.**
- **Herramientas de empleados** (siguen siendo de solo lectura donde existen).
- **Venta de skills/empleados** en el marketplace (los paquetes se instalan por API; falta catálogo, pago y comisión).
- **Aprendizaje entre empresas** (requiere diseño de privacidad).
- **Adjuntos con archivos:** solo referencias (nombre + ref); no hay subida.
- El precio simulado (2000 micros por 1.000 tokens) es un estimado para ejercitar presupuesto y aprobaciones; no es un cobro.

## API
`GET summary · permissions/mine · providers · skills?employee_key= · employees` (vía summary/page) · `PUT employees/{key}/skills/{skill}` · `GET/POST packages` · `POST packages/{id}/disable` · `GET/POST memory` · `PATCH memory/{id}` · `GET/POST objectives` · `PATCH objectives/{id}` · `GET/PUT budget` · `PUT budget/employees/{key}` · `GET budget/requests` · `POST budget/requests/{id}/decision` · `GET/POST threads` · `GET threads/{id}` · `POST threads/{id}/messages` · `POST threads/{id}/archive` · `GET/POST agenda` · `PATCH agenda/{id}` · `POST agenda/{id}/run` · `POST agenda/tick` · `POST agenda/fire` · `GET agenda/runs` · `GET agenda/runs/{id}` · `POST agenda/runs/{id}/decision`.
Errores RFC 9457; `budget_exceeded` = 402 con `details.request_id`; `plan_required` = 403.

## Siguiente (en el orden acordado)
1. Conectar proveedores reales por el adaptador. 2. KYNOVA como primer cliente con datos reales. 3. Herramientas reales con aprobación humana, una capacidad por entrega. 4. Worker 24/7. 5. Marketplace de Skills/Employees.
