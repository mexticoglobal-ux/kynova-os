-- Workforce (Entrega 8): the generic AI Employee Framework. Owned by src/modules/workforce.
-- Every table is tenant-owned (tenant_id references companies, every index leads with tenant_id, tenant_id is frozen). Nothing is deleted.
-- Messages and usage are append-only evidence.

CREATE TABLE `wf_packages` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `package_key` text NOT NULL, `kind` text NOT NULL, `version` text NOT NULL, `name` text NOT NULL,
	`manifest` text NOT NULL, `status` text DEFAULT 'active' NOT NULL, `source` text DEFAULT 'custom' NOT NULL, `installed_by` text NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`kind` IN ('employee', 'skill')), CHECK (`status` IN ('active', 'superseded', 'disabled')), CHECK (`source` IN ('builtin', 'marketplace', 'custom')),
	CHECK (length(`package_key`) BETWEEN 2 AND 48), CHECK (length(`manifest`) <= 12000)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `wf_packages_tenant_id_uq` ON `wf_packages` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `wf_packages_version_uq` ON `wf_packages` (`tenant_id`,`package_key`,`version`);--> statement-breakpoint
CREATE UNIQUE INDEX `wf_packages_active_uq` ON `wf_packages` (`tenant_id`,`package_key`) WHERE `status` = 'active';--> statement-breakpoint

CREATE TABLE `wf_skill_installs` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `employee_key` text NOT NULL, `skill_key` text NOT NULL, `version` text NOT NULL, `status` text DEFAULT 'enabled' NOT NULL,
	`installed_by` text NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade, CHECK (`status` IN ('enabled', 'disabled'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `wf_skill_installs_tenant_id_uq` ON `wf_skill_installs` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `wf_skill_installs_key_uq` ON `wf_skill_installs` (`tenant_id`,`employee_key`,`skill_key`);--> statement-breakpoint

CREATE TABLE `wf_threads` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `employee_key` text NOT NULL, `user_id` text NOT NULL, `title` text DEFAULT '' NOT NULL, `status` text DEFAULT 'open' NOT NULL,
	`message_count` integer DEFAULT 0 NOT NULL, `last_message_at` integer NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade, CHECK (`status` IN ('open', 'archived')), CHECK (`message_count` >= 0)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `wf_threads_tenant_id_uq` ON `wf_threads` (`tenant_id`,`id`);--> statement-breakpoint
CREATE INDEX `wf_threads_user_idx` ON `wf_threads` (`tenant_id`,`user_id`,`employee_key`,`last_message_at`);--> statement-breakpoint

CREATE TABLE `wf_messages` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `thread_id` text NOT NULL, `role` text NOT NULL, `body` text NOT NULL, `mode` text NOT NULL, `provider` text NOT NULL,
	`links` text DEFAULT '[]' NOT NULL, `attachments` text DEFAULT '[]' NOT NULL, `created_by` text NOT NULL, `created_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`tenant_id`, `thread_id`) REFERENCES `wf_threads`(`tenant_id`, `id`) ON UPDATE no action ON DELETE no action,
	CHECK (`role` IN ('user', 'employee', 'system')), CHECK (`mode` IN ('simulation', 'production')), CHECK (length(`body`) BETWEEN 1 AND 8000)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `wf_messages_tenant_id_uq` ON `wf_messages` (`tenant_id`,`id`);--> statement-breakpoint
CREATE INDEX `wf_messages_thread_idx` ON `wf_messages` (`tenant_id`,`thread_id`,`created_at`);--> statement-breakpoint

CREATE TABLE `wf_objectives` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `employee_key` text NOT NULL, `title` text NOT NULL, `description` text DEFAULT '' NOT NULL, `priority` integer DEFAULT 3 NOT NULL,
	`status` text DEFAULT 'active' NOT NULL, `depends_on` text DEFAULT '[]' NOT NULL, `metric` text DEFAULT '' NOT NULL, `due_at` integer, `created_by` text NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`status` IN ('active', 'paused', 'achieved', 'cancelled')), CHECK (`priority` BETWEEN 1 AND 5)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `wf_objectives_tenant_id_uq` ON `wf_objectives` (`tenant_id`,`id`);--> statement-breakpoint
CREATE INDEX `wf_objectives_employee_idx` ON `wf_objectives` (`tenant_id`,`employee_key`,`status`,`priority`);--> statement-breakpoint

CREATE TABLE `wf_agenda` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `employee_key` text NOT NULL, `objective_id` text, `title` text NOT NULL, `instruction` text NOT NULL, `trigger_kind` text NOT NULL,
	`event_action` text, `every_minutes` integer, `priority` integer DEFAULT 3 NOT NULL, `status` text DEFAULT 'active' NOT NULL, `requires_approval` integer DEFAULT 1 NOT NULL,
	`depends_on` text DEFAULT '[]' NOT NULL, `next_run_at` integer, `last_run_at` integer, `run_count` integer DEFAULT 0 NOT NULL, `created_by` text NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`trigger_kind` IN ('schedule', 'event', 'manual')), CHECK (`status` IN ('active', 'paused')), CHECK (`priority` BETWEEN 1 AND 5), CHECK (`requires_approval` IN (0, 1)),
	CHECK (`every_minutes` IS NULL OR `every_minutes` >= 15), CHECK (`trigger_kind` <> 'schedule' OR `every_minutes` IS NOT NULL), CHECK (`trigger_kind` <> 'event' OR `event_action` IS NOT NULL)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `wf_agenda_tenant_id_uq` ON `wf_agenda` (`tenant_id`,`id`);--> statement-breakpoint
CREATE INDEX `wf_agenda_due_idx` ON `wf_agenda` (`tenant_id`,`status`,`next_run_at`);--> statement-breakpoint
CREATE INDEX `wf_agenda_employee_idx` ON `wf_agenda` (`tenant_id`,`employee_key`);--> statement-breakpoint

CREATE TABLE `wf_runs` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `agenda_id` text NOT NULL, `employee_key` text NOT NULL, `fired_by` text NOT NULL, `status` text NOT NULL, `reason` text DEFAULT '' NOT NULL,
	`thread_id` text, `cost_micros` integer DEFAULT 0 NOT NULL, `tokens` integer DEFAULT 0 NOT NULL, `mode` text NOT NULL, `decided_by` text, `created_at` integer NOT NULL, `updated_at` integer NOT NULL, `finished_at` integer,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`fired_by` IN ('schedule', 'event', 'manual')), CHECK (`status` IN ('queued', 'awaiting_approval', 'succeeded', 'failed', 'skipped', 'rejected')), CHECK (`mode` IN ('simulation', 'production')),
	CHECK (`cost_micros` >= 0), CHECK (`tokens` >= 0)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `wf_runs_tenant_id_uq` ON `wf_runs` (`tenant_id`,`id`);--> statement-breakpoint
CREATE INDEX `wf_runs_agenda_idx` ON `wf_runs` (`tenant_id`,`agenda_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `wf_runs_status_idx` ON `wf_runs` (`tenant_id`,`status`,`created_at`);--> statement-breakpoint

CREATE TABLE `wf_memory` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `employee_key` text NOT NULL, `kind` text NOT NULL, `title` text NOT NULL, `body` text NOT NULL, `source` text NOT NULL,
	`active` integer DEFAULT 1 NOT NULL, `created_by` text NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`kind` IN ('preference', 'decision', 'context', 'constraint', 'history')), CHECK (`source` IN ('user', 'employee', 'system')), CHECK (`active` IN (0, 1))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `wf_memory_tenant_id_uq` ON `wf_memory` (`tenant_id`,`id`);--> statement-breakpoint
CREATE INDEX `wf_memory_employee_idx` ON `wf_memory` (`tenant_id`,`employee_key`,`active`,`kind`);--> statement-breakpoint

CREATE TABLE `wf_budgets` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `scope` text NOT NULL, `monthly_micros` integer NOT NULL, `currency` text DEFAULT 'USD' NOT NULL, `updated_by` text NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade, CHECK (`monthly_micros` >= 0)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `wf_budgets_tenant_id_uq` ON `wf_budgets` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `wf_budgets_scope_uq` ON `wf_budgets` (`tenant_id`,`scope`);--> statement-breakpoint

CREATE TABLE `wf_usage` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `employee_key` text NOT NULL, `period` text NOT NULL, `cost_micros` integer NOT NULL, `tokens` integer NOT NULL, `provider` text NOT NULL,
	`mode` text NOT NULL, `ref_kind` text NOT NULL, `ref_id` text NOT NULL, `created_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade, CHECK (`mode` IN ('simulation', 'production')), CHECK (`cost_micros` >= 0), CHECK (`tokens` >= 0), CHECK (length(`period`) = 7)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `wf_usage_tenant_id_uq` ON `wf_usage` (`tenant_id`,`id`);--> statement-breakpoint
CREATE INDEX `wf_usage_period_idx` ON `wf_usage` (`tenant_id`,`period`,`employee_key`);--> statement-breakpoint

CREATE TABLE `wf_budget_requests` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `employee_key` text NOT NULL, `period` text NOT NULL, `amount_micros` integer NOT NULL, `reason` text DEFAULT '' NOT NULL, `status` text DEFAULT 'pending' NOT NULL,
	`requested_by` text NOT NULL, `decided_by` text, `decided_at` integer, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade, CHECK (`status` IN ('pending', 'approved', 'denied')), CHECK (`amount_micros` > 0)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `wf_budget_requests_tenant_id_uq` ON `wf_budget_requests` (`tenant_id`,`id`);--> statement-breakpoint
CREATE INDEX `wf_budget_requests_status_idx` ON `wf_budget_requests` (`tenant_id`,`status`,`created_at`);--> statement-breakpoint

CREATE TRIGGER wf_packages_tenant_frozen BEFORE UPDATE OF tenant_id, package_key, version, kind ON wf_packages BEGIN SELECT RAISE(ABORT, 'workforce package identity cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER wf_skill_installs_frozen BEFORE UPDATE OF tenant_id, employee_key, skill_key ON wf_skill_installs BEGIN SELECT RAISE(ABORT, 'workforce skill identity cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER wf_threads_frozen BEFORE UPDATE OF tenant_id, employee_key, user_id ON wf_threads BEGIN SELECT RAISE(ABORT, 'workforce thread identity cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER wf_objectives_frozen BEFORE UPDATE OF tenant_id, employee_key ON wf_objectives BEGIN SELECT RAISE(ABORT, 'workforce objective identity cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER wf_agenda_frozen BEFORE UPDATE OF tenant_id, employee_key ON wf_agenda BEGIN SELECT RAISE(ABORT, 'workforce agenda identity cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER wf_runs_frozen BEFORE UPDATE OF tenant_id, agenda_id, employee_key ON wf_runs BEGIN SELECT RAISE(ABORT, 'workforce run identity cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER wf_memory_frozen BEFORE UPDATE OF tenant_id, employee_key ON wf_memory BEGIN SELECT RAISE(ABORT, 'workforce memory identity cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER wf_budgets_frozen BEFORE UPDATE OF tenant_id, scope ON wf_budgets BEGIN SELECT RAISE(ABORT, 'workforce budget identity cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER wf_budget_requests_frozen BEFORE UPDATE OF tenant_id, employee_key, period, amount_micros ON wf_budget_requests BEGIN SELECT RAISE(ABORT, 'workforce budget request identity cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER wf_messages_append_only_u BEFORE UPDATE ON wf_messages BEGIN SELECT RAISE(ABORT, 'wf_messages is append-only'); END;
--> statement-breakpoint
CREATE TRIGGER wf_usage_append_only_u BEFORE UPDATE ON wf_usage BEGIN SELECT RAISE(ABORT, 'wf_usage is append-only'); END;
--> statement-breakpoint
CREATE TRIGGER wf_packages_no_delete BEFORE DELETE ON wf_packages BEGIN SELECT RAISE(ABORT, 'wf_packages rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER wf_skill_installs_no_delete BEFORE DELETE ON wf_skill_installs BEGIN SELECT RAISE(ABORT, 'wf_skill_installs rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER wf_threads_no_delete BEFORE DELETE ON wf_threads BEGIN SELECT RAISE(ABORT, 'wf_threads rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER wf_messages_no_delete BEFORE DELETE ON wf_messages BEGIN SELECT RAISE(ABORT, 'wf_messages rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER wf_objectives_no_delete BEFORE DELETE ON wf_objectives BEGIN SELECT RAISE(ABORT, 'wf_objectives rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER wf_agenda_no_delete BEFORE DELETE ON wf_agenda BEGIN SELECT RAISE(ABORT, 'wf_agenda rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER wf_runs_no_delete BEFORE DELETE ON wf_runs BEGIN SELECT RAISE(ABORT, 'wf_runs rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER wf_memory_no_delete BEFORE DELETE ON wf_memory BEGIN SELECT RAISE(ABORT, 'wf_memory rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER wf_budgets_no_delete BEFORE DELETE ON wf_budgets BEGIN SELECT RAISE(ABORT, 'wf_budgets rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER wf_usage_no_delete BEFORE DELETE ON wf_usage BEGIN SELECT RAISE(ABORT, 'wf_usage rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER wf_budget_requests_no_delete BEFORE DELETE ON wf_budget_requests BEGIN SELECT RAISE(ABORT, 'wf_budget_requests rows cannot be deleted'); END;
