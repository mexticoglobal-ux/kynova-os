import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { COLUMNS, TABLE } from "../../../src/modules/workforce/columns";
import { createD1WorkforceStore } from "../../../src/modules/workforce/store-d1";
import type { WorkforceStore } from "../../../src/modules/workforce/store";
import { createWorkforceService, type Actor, type EmployeeInfo, type WorkforcePorts } from "../../../src/modules/workforce/service";
import { createTestDb, newCompany, newUser } from "../db/helpers";

let t: Awaited<ReturnType<typeof createTestDb>>;
let store: WorkforceStore;
const snake = (s: string) => s.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
const refused = async (p: Promise<unknown>) => { try { await p; return "no error"; } catch { return "refused"; } };
const code = async (p: Promise<unknown>) => { try { await p; return "ok"; } catch (e) { return (e as { code?: string }).code ?? "other"; } };
const fresh = async (): Promise<Actor> => { const u = await newUser(t.db), c = await newCompany(t.db, u.id); return { tenantId: c.companyId, userId: u.id, role: "owner" }; };
const ports: WorkforcePorts = {
  async employee(_a, key): Promise<EmployeeInfo | null> { return key === "marketing_manager" ? { key, name: "Marketing Manager", department: "marketing", goal: "Grow", instructions: "You are Marketing Manager.", activityKey: "emp_mm", active: true, entitled: true, origin: "roster" } : null; },
  async roster(a) { const e = await ports.employee(a, "marketing_manager"); return e ? [e] : []; },
  plan: async () => "business", capabilities: () => new Set(),
};

beforeAll(async () => { t = await createTestDb(); store = createD1WorkforceStore(t.d1); }, 60_000);
afterAll(async () => { await t.dispose(); });

describe("schema contract", () => {
  it("every whitelisted column exists in the migration, and every column is whitelisted", async () => {
    for (const [kind, table] of Object.entries(TABLE)) {
      const info = (await t.d1.prepare(`PRAGMA table_info(${table})`).all<{ name: string }>()).results.map((c) => c.name).sort();
      expect(COLUMNS[kind as keyof typeof COLUMNS].map(snake).sort(), table).toEqual(info);
    }
  });
});

const harness = async () => {
  const A = await fresh(); let n = 0; const salt = crypto.randomUUID().slice(0, 8), clock = { t: Date.UTC(2026, 9, 20, 12) };
  const svc = createWorkforceService({ store, ports, newId: () => `id${salt}${String(++n).padStart(6, "0")}`, now: () => clock.t });
  return { A, svc, clock };
};

describe("the service on D1", () => {
  it("talks, spends from the budget with a server-side SUM, and stops at the limit", async () => {
    const { A, svc } = await harness();
    await svc.setBudget(A, "company", { monthlyMicros: 5_000_000 });
    const th = await svc.startThread(A, { employeeKey: "marketing_manager" });
    const r = await svc.send(A, th.id, { body: "Hola" });
    expect(r.reply.mode).toBe("simulation");
    const b = await svc.budget(A);
    expect(b.company.used).toBe(r.usage.costMicros); expect(b.company.available).toBe(5_000_000 - r.usage.costMicros);
    await svc.setBudget(A, "company", { monthlyMicros: 1 });
    expect(await code(svc.send(A, th.id, { body: "otra" }))).toBe("budget_exceeded");
    const [req] = await svc.listBudgetRequests(A, "pending"); await svc.decideBudgetRequest(A, req.id, { approve: true });
    expect(await code(svc.send(A, th.id, { body: "otra" }))).toBe("ok");
    expect((await svc.getThread(A, th.id)).messages.length).toBe(4);
  });
  it("runs the agenda with objectives, dependencies and approval", async () => {
    const { A, svc, clock } = await harness(); await svc.setBudget(A, "company", { monthlyMicros: 5_000_000 });
    const o = await svc.createObjective(A, { employeeKey: "marketing_manager", title: "Leads", dependsOn: [] });
    await svc.createAgenda(A, { employeeKey: "marketing_manager", objectiveId: o.id, title: "Review", instruction: "Review", triggerKind: "schedule", everyMinutes: 60, requiresApproval: true });
    clock.t += 61 * 60_000;
    const { runs } = await svc.tick(A); expect(runs[0].status).toBe("awaiting_approval");
    expect((await svc.decideRun(A, runs[0].id, { approve: true })).status).toBe("succeeded");
    expect((await svc.runResult(A, runs[0].id)).messages).toHaveLength(2);
  });
  it("the database refuses what the service would never do", async () => {
    const { A, svc } = await harness(), B = await fresh(); await svc.setBudget(A, "company", { monthlyMicros: 5_000_000 });
    const th = await svc.startThread(A, { employeeKey: "marketing_manager" }); await svc.send(A, th.id, { body: "x" });
    const msg = await t.d1.prepare("SELECT id FROM wf_messages WHERE tenant_id = ?").bind(A.tenantId).first<{ id: string }>();
    const use = await t.d1.prepare("SELECT id FROM wf_usage WHERE tenant_id = ?").bind(A.tenantId).first<{ id: string }>();
    expect(await refused(t.d1.prepare("UPDATE wf_messages SET body = 'edited' WHERE id = ?").bind(msg!.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("DELETE FROM wf_messages WHERE id = ?").bind(msg!.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE wf_usage SET cost_micros = 0 WHERE id = ?").bind(use!.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE wf_threads SET tenant_id = ? WHERE id = ?").bind(B.tenantId, th.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE wf_threads SET user_id = 'someone-else' WHERE id = ?").bind(th.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("DELETE FROM wf_budgets WHERE tenant_id = ?").bind(A.tenantId).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE wf_objectives SET priority = 9 WHERE tenant_id = ?").bind(A.tenantId).run())).toBe("no error"); // no rows: allowed to run, changes nothing
    expect(await refused(t.d1.prepare("INSERT INTO wf_agenda (id, tenant_id, employee_key, title, instruction, trigger_kind, created_by, created_at, updated_at) VALUES ('a1', ?, 'k', 't', 'i', 'schedule', 'u', 1, 1)").bind(A.tenantId).run())).toBe("refused"); // schedule without interval
    expect(await refused(t.d1.prepare("INSERT INTO wf_agenda (id, tenant_id, employee_key, title, instruction, trigger_kind, every_minutes, created_by, created_at, updated_at) VALUES ('a2', ?, 'k', 't', 'i', 'schedule', 5, 'u', 1, 1)").bind(A.tenantId).run())).toBe("refused"); // interval below 15
  });
  it("one active version per package and one budget per scope are enforced by indexes", async () => {
    const { A, svc } = await harness();
    await svc.installPackage(A, { manifest: { kind: "skill", key: "tiktok_ads", version: "1.0.0", name: "T", description: "d", prompt: "p" } });
    await svc.installPackage(A, { manifest: { kind: "skill", key: "tiktok_ads", version: "1.1.0", name: "T", description: "d", prompt: "p" } });
    const rows = await t.d1.prepare("SELECT status FROM wf_packages WHERE tenant_id = ? ORDER BY version").bind(A.tenantId).all<{ status: string }>();
    expect(rows.results.map((r) => r.status)).toEqual(["superseded", "active"]);
    expect(await refused(t.d1.prepare("UPDATE wf_packages SET status = 'active' WHERE tenant_id = ? AND version = '1.0.0'").bind(A.tenantId).run())).toBe("refused");
  });
  it("companies never see each other's data", async () => {
    const a = await harness(), b = await harness(); await a.svc.createObjective(a.A, { employeeKey: "marketing_manager", title: "private" });
    expect(await b.svc.listObjectives(b.A)).toEqual([]);
  });
});
