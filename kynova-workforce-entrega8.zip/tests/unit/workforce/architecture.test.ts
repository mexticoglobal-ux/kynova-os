import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES, canAccess } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { COLUMNS, TABLE } from "../../../src/modules/workforce/columns";
import { ARCHITECTURE_STATUS } from "../../../src/modules/workforce/contracts";
import { CAPABILITIES, DEFAULT_CAPABILITIES } from "../../../src/modules/workforce/domain";
import { WORKFORCE_DICTIONARIES } from "../../../src/modules/workforce/i18n";
import { listProviders } from "../../../src/modules/workforce/provider";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => { try { return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; }); } catch { return []; } };
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "workforce");
const bad = (dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const badExcept = (skip: string, dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).filter((f) => !f.endsWith(skip)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "workforce"), join(SRC, "app", "(app)", "app", "workforce")];
const strip = (s: string) => s.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");
const OTHERS = "crm|marketing|seo|ai-studio|finance|communications|billing|security|analytics|analytics-bi|mission-control|integrations|marketplace|partners|referrals|portal|activation";

describe("Workforce module boundaries", () => {
  it("never depends on a vendor SDK, the AI Kernel or its providers: the Framework talks only to its own provider port", () => {
    expect(bad([MOD, ...UI], /ai-kernel|@anthropic-ai|openai|@google\/generative|mistral|deepseek/i)).toEqual([]);
    expect(files(MOD).filter((f) => /(?<![.\w])fetch\(|XMLHttpRequest|new WebSocket|node:https?|node:net/.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
  });
  it("only server.ts meets the database, the employees framework, the roster and the plans", () => {
    expect(badExcept("server.ts", [MOD], new RegExp(`drizzle-orm|platform/db|ai-employees|modules/team|modules/(${OTHERS})`))).toEqual([]);
    expect(bad([MOD, ...UI], /platform\/activity\/(?!$)/)).toEqual([]);
  });
  it("only the store layer knows SQL", () => {
    expect(files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f))).toEqual(["store-d1.ts"]);
  });
  it("frozen code does not know Workforce", () => {
    const frozen = ["platform/db", "platform/auth", "platform/ai-kernel", "platform/ai-employees", "platform/activity", ...OTHERS.split("|").map((m) => `modules/${m}`), "modules/team"].map((d) => join(SRC, d));
    expect(bad(frozen, /modules\/workforce|components\/workforce/)).toEqual([]);
  });
  it("UI uses the module's public interface only, and client components stay free of server-only imports", () => {
    expect(bad(UI, new RegExp(`platform/db|drizzle|modules/workforce/(store|columns|runtime|server)|modules/(${OTHERS}|team)|components/(${OTHERS}|team)`))).toEqual([]);
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThanOrEqual(3);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/workforce\/(service|server|http|store|runtime)/.test(i)))).toEqual([]);
  });
});

describe("providers", () => {
  it("only the simulation is connected; Claude, OpenAI, Gemini, Mistral and DeepSeek are declared behind the same port", () => {
    expect(listProviders().filter((p) => p.connected).map((p) => p.id)).toEqual(["simulated"]);
    expect(listProviders().map((p) => p.id).sort()).toEqual(["claude", "deepseek", "gemini", "mistral", "openai", "simulated"]);
  });
  it("states plainly what it does not do", () => {
    expect(ARCHITECTURE_STATUS).toMatchObject({ real_ai_provider: "not_connected", continuous_scheduler_worker: "not_built", cross_company_learning: "not_built", skill_marketplace_sales: "not_built", skills: "built_reasoning_only" });
  });
});

describe("API surface: only /api/v1/workforce/*", () => {
  const API = join(SRC, "app", "api", "v1", "workforce"), routes = files(API).filter((f) => f.endsWith("route.ts"));
  it("every handler goes through workforceRoute; every mutating verb enables CSRF checks", () => {
    expect(routes.length).toBeGreaterThanOrEqual(20);
    for (const f of routes) {
      const src = readFileSync(f, "utf8");
      for (const m of src.matchAll(/export const (GET|POST|PATCH|PUT|DELETE) = (\w+)/g)) {
        expect(m[2], `${relative(SRC, f)} ${m[1]}`).toBe("workforceRoute");
        const decl = src.slice(src.indexOf(m[0])), next = decl.indexOf("\nexport const", 10), block = decl.slice(0, next === -1 ? decl.length : next);
        if (m[1] !== "GET") expect(block, `${relative(SRC, f)} ${m[1]}`).toContain("mutating: true"); else expect(block).not.toContain("mutating");
      }
    }
  });
  it("the AI Employees hire route applies the same plan check as the Team page", () => {
    const src = readFileSync(join(SRC, "app", "api", "v1", "ai-employees", "route.ts"), "utf8");
    expect(src).toContain("assertBlueprintAllowed");
    expect(src.indexOf("assertBlueprintAllowed")).toBeLessThan(src.indexOf("employees.hire"));
  });
});

describe("migration 1800_workforce.sql", () => {
  const sql = readFileSync(join(process.cwd(), "drizzle/migrations/1800_workforce.sql"), "utf8");
  const tables = [...sql.matchAll(/CREATE TABLE `(wf_\w+)` \(([\s\S]*?)\n\);/g)];
  it("creates exactly the wf_ tables and touches nothing else", () => {
    expect(tables).toHaveLength(Object.keys(TABLE).length); expect(Object.values(TABLE).sort()).toEqual(tables.map((t) => t[1]).sort());
    expect(sql.replace(/^--.*$/gm, "")).not.toMatch(/ALTER TABLE|DROP TABLE|DROP INDEX|INSERT INTO|DELETE FROM/);
    for (const o of sql.matchAll(/CREATE (?:UNIQUE )?INDEX `(\w+)`/g)) expect(o[1]).toMatch(/^wf_/);
  });
  it("every table is tenant-owned with tenant-first indexes, a frozen identity and no deletes", () => {
    for (const [, name, body] of tables) {
      expect(body, name).toContain("`tenant_id` text NOT NULL"); expect(body, name).toContain("FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`)");
      for (const ix of sql.matchAll(new RegExp(`CREATE (?:UNIQUE )?INDEX \`\\w+\` ON \`${name}\` \\(([^)]*)\\)`, "g"))) expect(ix[1], name).toMatch(/^`tenant_id`/);
      expect(sql, name).toMatch(new RegExp(`CREATE TRIGGER ${name}\\w*_no_delete`)); expect(sql, name).toMatch(new RegExp(`CREATE TRIGGER ${name}\\w*_(tenant_)?frozen|CREATE TRIGGER ${name.replace(/s$/, "")}\\w*_frozen|CREATE TRIGGER ${name}_append_only_u`));
    }
    expect(sql).toContain("wf_messages_append_only_u"); expect(sql).toContain("wf_usage_append_only_u");
  });
  it("whitelists cover each kind and carry the tenant column", () => { for (const k of Object.keys(TABLE) as (keyof typeof TABLE)[]) { expect(COLUMNS[k]).toContain("id"); expect(COLUMNS[k]).toContain("tenantId"); } });
});

describe("access and texts", () => {
  it("module access is the outer gate; default capabilities only narrow it", () => {
    for (const r of ROLES) { if (!canAccess(r, "workforce")) expect(DEFAULT_CAPABILITIES[r].length, r).toBe(0); else expect(DEFAULT_CAPABILITIES[r].includes("view") || DEFAULT_CAPABILITIES[r].length === 0, r).toBe(true); }
    expect(DEFAULT_CAPABILITIES.owner).toHaveLength(CAPABILITIES.length);
    expect(MODULES.filter((m) => m.slug === "workforce")).toHaveLength(1);
  });
  it("English and Spanish have the same keys and no empty text", () => {
    const en = WORKFORCE_DICTIONARIES.en as Record<string, string>, es = WORKFORCE_DICTIONARIES.es as Record<string, string>;
    expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort());
    for (const [k, v] of Object.entries(es)) expect(v.trim(), k).not.toBe("");
    for (const k of Object.keys(ARCHITECTURE_STATUS)) expect(en[`wf.${k}`], k).toBeTruthy();
  });
});
