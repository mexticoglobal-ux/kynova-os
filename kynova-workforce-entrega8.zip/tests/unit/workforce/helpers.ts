import type { Role } from "@/config/roles";
import type { ActivitySink, SinkEvent } from "@/platform/activity";
import { createSimulatedProvider, type AiProvider } from "../../../src/modules/workforce/provider";
import { createWorkforceService, type Actor, type EmployeeInfo, type WorkforcePorts } from "../../../src/modules/workforce/service";
import { createMemoryWorkforceStore } from "../../../src/modules/workforce/store-memory";

export const T1 = "tenant-one", T2 = "tenant-two", START = Date.UTC(2026, 9, 20, 12), H = 3_600_000, MIN = 60_000;
export const actor = (role: Role, tenantId = T1, userId = `${role}-1`): Actor => ({ tenantId, userId, role });
export const OWNER = actor("owner"), MARKETING = actor("marketing"), SUPPORT = actor("support");
export const code = async (p: Promise<unknown>) => { try { await p; return "ok"; } catch (e) { return (e as { code?: string }).code ?? `other:${(e as Error).message}`; } };

export interface Fixture { plan: string | null; active: Set<string>; notEntitled: Set<string>; capabilities: Set<string> }
export function harness(o: Partial<Fixture> & { provider?: AiProvider } = {}) {
  const f: Fixture = { plan: "business", active: new Set(["marketing_manager", "finance_manager", "sales_manager"]), notEntitled: new Set(["legal_assistant"]), capabilities: new Set(["marketing.read_summary"]), ...o };
  const events: (SinkEvent & { tenantId: string })[] = [], clock = { t: START };
  const names: Record<string, string> = { marketing_manager: "Marketing Manager", finance_manager: "Finance Manager", sales_manager: "Sales Manager", legal_assistant: "Legal Assistant", hr_manager: "HR Manager" };
  const ports: WorkforcePorts = {
    async employee(_a, key): Promise<EmployeeInfo | null> {
      if (!names[key]) return null;
      return { key, name: names[key], department: "x", goal: "Grow", instructions: `You are ${names[key]}.`, activityKey: `emp_${key.replace(/_/g, "")}`, active: f.active.has(key), entitled: !f.notEntitled.has(key), origin: "roster" };
    },
    async roster(a) { return (await Promise.all(Object.keys(names).map((k) => ports.employee(a, k)))).filter((e): e is EmployeeInfo => Boolean(e)); },
    plan: async () => f.plan, capabilities: () => f.capabilities,
  };
  const activity: ActivitySink = {
    async record(ctx, e) { events.push({ tenantId: ctx.tenantId, ...e }); return { ok: false, error: { code: "test", message: "captured" } }; },
    async recordStrict(ctx, e) { events.push({ tenantId: ctx.tenantId, ...e }); throw new Error("captured"); },
  };
  let n = 0;
  const store = createMemoryWorkforceStore();
  const svc = createWorkforceService({ store, ports, newId: () => `id${String(++n).padStart(6, "0")}`, now: () => clock.t, activity, provider: () => o.provider ?? createSimulatedProvider(), locale: "es" });
  return { f, svc, store, events, clock, advance: (ms: number) => { clock.t += ms; } };
}
export type H = ReturnType<typeof harness>;
export const actions = (h: H) => h.events.map((e) => e.action);
export const setBudget = (h: H, usd = 10) => h.svc.setBudget(OWNER, "company", { monthlyMicros: usd * 1e6 });
