import { describe, expect, it } from "vitest";
import { createSimulatedProvider } from "../../../src/modules/workforce/provider";
import { MARKETING, MIN, OWNER, SUPPORT, actions, actor, code, harness, setBudget, T2 } from "./helpers";

const skillManifest = (o: Record<string, unknown> = {}) => ({ manifest: { kind: "skill", key: "tiktok_ads", version: "1.0.0", name: "TikTok Ads", description: "TikTok campaigns", prompt: "Analyse TikTok results.", ...o } });
const employeeManifest = (o: Record<string, unknown> = {}) => ({ manifest: { kind: "employee", key: "pr_manager", version: "1.0.0", name: "PR Manager", description: "Press relations", department: "communications", goal: "Earn coverage", instructions: "You are the PR Manager.", skills: [], ...o } });

describe("skills", () => {
  it("a roster employee starts with its default skills and a company can switch one off without touching the employee", async () => {
    const h = harness(), s = await h.svc.skills(OWNER, "marketing_manager");
    expect(s.employee?.map((x) => x.key)).toEqual(expect.arrayContaining(["seo", "meta_ads", "google_ads", "email_marketing", "analytics"]));
    await h.svc.setSkill(OWNER, "marketing_manager", "meta_ads", { enabled: false });
    expect((await h.svc.skills(OWNER, "marketing_manager")).employee?.find((x) => x.key === "meta_ads")?.enabled).toBe(false);
    expect(actions(h)).toContain("workforce.skill.disabled");
  });
  it("finance has its own skills and every built-in skill is honest about being reasoning-only", async () => {
    const h = harness(), s = await h.svc.skills(OWNER, "finance_manager");
    expect(s.employee?.map((x) => x.key)).toEqual(expect.arrayContaining(["invoicing", "budgeting", "cash_flow", "taxes"]));
    expect(s.catalog.every((x) => x.stage === "reasoning")).toBe(true);
  });
  it("an optional skill can be added to any employee; an unknown skill or employee is not found", async () => {
    const h = harness();
    await h.svc.setSkill(OWNER, "sales_manager", "seo", { enabled: true });
    expect((await h.svc.skills(OWNER, "sales_manager")).employee?.map((x) => x.key)).toContain("seo");
    expect(await code(h.svc.setSkill(OWNER, "sales_manager", "nope", { enabled: true }))).toBe("not_found");
    expect(await code(h.svc.setSkill(OWNER, "ghost", "seo", { enabled: true }))).toBe("not_found");
  });
  it("only people who manage can change skills", async () => { const h = harness(); expect(await code(h.svc.setSkill(MARKETING, "marketing_manager", "seo", { enabled: false }))).toBe("forbidden"); });
});

describe("packages (marketplace-ready, no Core changes)", () => {
  it("installs a skill package, makes it available to employees, and upgrades by version", async () => {
    const h = harness();
    await h.svc.installPackage(OWNER, skillManifest());
    await h.svc.setSkill(OWNER, "marketing_manager", "tiktok_ads", { enabled: true });
    expect((await h.svc.skills(OWNER, "marketing_manager")).employee?.map((x) => x.key)).toContain("tiktok_ads");
    await h.svc.installPackage(OWNER, skillManifest({ version: "1.1.0", name: "TikTok Ads Pro" }));
    const list = await h.svc.listPackages(OWNER);
    expect(list.filter((p) => p.status === "active")).toHaveLength(1);
    expect(list.find((p) => p.version === "1.0.0")?.status).toBe("superseded");
    expect(await code(h.svc.installPackage(OWNER, skillManifest({ version: "1.1.0" })))).toBe("duplicate");
    expect(await code(h.svc.installPackage(OWNER, skillManifest({ version: "0.9.0" })))).toBe("invalid_state");
    expect(actions(h)).toContain("workforce.package.upgraded");
  });
  it("an installed AI employee package can be talked to like any other, and cannot take a built-in key", async () => {
    const h = harness();
    await h.svc.installPackage(OWNER, employeeManifest());
    await setBudget(h);
    const t = await h.svc.startThread(OWNER, { employeeKey: "pr_manager" });
    const r = await h.svc.send(OWNER, t.id, { body: "Hola" });
    expect(r.reply.body).toContain("PR Manager");
    expect(await code(h.svc.installPackage(OWNER, employeeManifest({ key: "marketing_manager" })))).toBe("conflict");
  });
  it("rejects a package that needs a capability the platform does not have, and plans below Business", async () => {
    const h = harness();
    expect(await code(h.svc.installPackage(OWNER, skillManifest({ requires: ["crm.delete_everything"] })))).toBe("validation_failed");
    await h.svc.installPackage(OWNER, skillManifest({ key: "ok_skill", requires: ["marketing.read_summary"] }));
    expect(await code(harness({ plan: "starter" }).svc.installPackage(OWNER, skillManifest()))).toBe("plan_required");
    expect(await code(harness({ plan: null }).svc.installPackage(OWNER, skillManifest()))).toBe("plan_required");
  });
  it("a manifest cannot carry code or unknown fields", async () => {
    const h = harness();
    expect(await code(h.svc.installPackage(OWNER, skillManifest({ run: "process.exit(1)" })))).toBe("validation_failed");
    expect(await code(h.svc.installPackage(OWNER, { manifest: { kind: "script", key: "x" } }))).toBe("validation_failed");
  });
  it("a disabled package stops providing its skill", async () => {
    const h = harness(); const p = await h.svc.installPackage(OWNER, skillManifest());
    await h.svc.disablePackage(OWNER, p.id);
    expect((await h.svc.skills(OWNER)).catalog.map((s) => s.key)).not.toContain("tiktok_ads");
  });
});

describe("conversations", () => {
  it("are private, simulated while no provider is connected, and leave evidence", async () => {
    const h = harness(); await setBudget(h);
    const t = await h.svc.startThread(OWNER, { employeeKey: "marketing_manager" }), r = await h.svc.send(OWNER, t.id, { body: "¿Cómo va el SEO?", links: [{ kind: "objective", id: "o1" }] });
    expect(r.reply.mode).toBe("simulation"); expect(r.reply.body).toMatch(/Simulación/); expect(r.reply.body).toMatch(/no puedo razonar/);
    expect(r.user.links).toEqual([{ kind: "objective", id: "o1" }]);
    expect(h.events.find((e) => e.action === "workforce.message.answered")).toMatchObject({ mode: "simulation", actorKind: "employee", employeeKey: "emp_marketingmanager" });
    const other = actor("owner", "tenant-one", "owner-2");
    expect(await code(h.svc.getThread(other, t.id))).toBe("not_found");
    expect(await code(h.svc.send(other, t.id, { body: "hi" }))).toBe("not_found");
    expect(await h.svc.listThreads(other)).toEqual([]);
    expect((await h.svc.getThread(OWNER, t.id)).messages).toHaveLength(2);
  });
  it("need an active, entitled employee and a role that may converse", async () => {
    const h = harness(); await setBudget(h);
    expect(await code(h.svc.startThread(OWNER, { employeeKey: "hr_manager" }))).toBe("invalid_state");
    expect(await code(h.svc.startThread(OWNER, { employeeKey: "legal_assistant" }))).toBe("plan_required");
    expect(await code(h.svc.startThread(SUPPORT, { employeeKey: "marketing_manager" }))).toBe("forbidden");
    expect(await code(h.svc.startThread(MARKETING, { employeeKey: "marketing_manager" }))).toBe("ok");
  });
  it("use what the employee has on record (objectives and memory) and say so", async () => {
    const h = harness(); await setBudget(h);
    await h.svc.createObjective(OWNER, { employeeKey: "marketing_manager", title: "Reach 100 leads" });
    await h.svc.addMemory(OWNER, { employeeKey: "marketing_manager", kind: "preference", title: "Tone", body: "Friendly" });
    const t = await h.svc.startThread(OWNER, { employeeKey: "marketing_manager" }), r = await h.svc.send(OWNER, t.id, { body: "hola" });
    expect(r.reply.body).toMatch(/1 objetivo/); expect(r.reply.body).toMatch(/1 dato/);
  });
  it("memory is per employee and per company and can be forgotten", async () => {
    const h = harness();
    const m = await h.svc.addMemory(OWNER, { employeeKey: "marketing_manager", kind: "constraint", title: "No weekends", body: "Never schedule on weekends" });
    expect(await h.svc.listMemory(OWNER, { employeeKey: "finance_manager" })).toEqual([]);
    expect(await h.svc.listMemory(actor("owner", T2), { employeeKey: "marketing_manager" })).toEqual([]);
    await h.svc.patchMemory(OWNER, m.id, { active: false });
    expect(await h.svc.listMemory(OWNER, { employeeKey: "marketing_manager" })).toEqual([]);
    expect(await h.svc.listMemory(OWNER, { employeeKey: "marketing_manager", includeInactive: true })).toHaveLength(1);
    expect(await code(h.svc.patchMemory(actor("owner", T2), m.id, { active: true }))).toBe("not_found");
  });
  it("archived threads stop accepting messages; a not-connected provider fails closed", async () => {
    const h = harness(); await setBudget(h);
    const t = await h.svc.startThread(OWNER, { employeeKey: "marketing_manager" }); await h.svc.archiveThread(OWNER, t.id);
    expect(await code(h.svc.send(OWNER, t.id, { body: "x" }))).toBe("invalid_state");
    const { resolveProvider } = await import("../../../src/modules/workforce/provider");
    expect(resolveProvider("t", "claude").connected).toBe(false);
    const h2 = harness({ provider: resolveProvider("t", "openai") }); await setBudget(h2);
    const t2 = await h2.svc.startThread(OWNER, { employeeKey: "marketing_manager" });
    expect(await code(h2.svc.send(OWNER, t2.id, { body: "x" }))).toBe("provider_not_connected");
    expect((await h2.svc.getThread(OWNER, t2.id)).messages).toEqual([]);
  });
});

describe("budget", () => {
  it("fails closed until the company sets a monthly budget, then tracks assigned, used and available", async () => {
    const h = harness();
    const t = await h.svc.startThread(OWNER, { employeeKey: "marketing_manager" });
    expect(await code(h.svc.send(OWNER, t.id, { body: "x" }))).toBe("budget_exceeded");
    expect((await h.svc.budget(OWNER)).status).toBe("not_configured");
    await setBudget(h, 5);
    await h.svc.send(OWNER, t.id, { body: "x" });
    const b = await h.svc.budget(OWNER);
    expect(b.company.assigned).toBe(5e6); expect(b.company.used).toBeGreaterThan(0); expect(b.company.available).toBe(5e6 - b.company.used);
    expect(b.company.simulatedUsed).toBe(b.company.used);
    expect(b.employees.find((e) => e.employeeKey === "marketing_manager")?.used).toBe(b.company.used);
  });
  it("at the limit the employee asks for authorization once, and a person decides", async () => {
    const h = harness(); await h.svc.setBudget(OWNER, "company", { monthlyMicros: 1 });
    const t = await h.svc.startThread(OWNER, { employeeKey: "marketing_manager" });
    const e1 = await h.svc.send(OWNER, t.id, { body: "x" }).catch((e) => e);
    expect(e1.code).toBe("budget_exceeded"); expect(e1.details.requestId).toBeTruthy();
    await h.svc.send(OWNER, t.id, { body: "y" }).catch(() => undefined);
    const pending = await h.svc.listBudgetRequests(OWNER, "pending"); expect(pending).toHaveLength(1);
    expect(actions(h).filter((a) => a === "workforce.budget.authorization_requested")).toHaveLength(1);
    expect(await code(h.svc.decideBudgetRequest(MARKETING, pending[0].id, { approve: true }))).toBe("forbidden");
    await h.svc.decideBudgetRequest(OWNER, pending[0].id, { approve: true });
    expect(await code(h.svc.decideBudgetRequest(OWNER, pending[0].id, { approve: true }))).toBe("invalid_state");
    expect(await code(h.svc.send(OWNER, t.id, { body: "z" }))).toBe("ok");
    expect((await h.svc.budget(OWNER)).company.authorizedExtra).toBe(pending[0].amountMicros);
  });
  it("a denied request keeps the employee stopped; an employee allocation caps it below the company pool", async () => {
    const h = harness(); await setBudget(h, 100); await h.svc.setBudget(OWNER, "marketing_manager", { monthlyMicros: 1 });
    const t = await h.svc.startThread(OWNER, { employeeKey: "marketing_manager" }), t2 = await h.svc.startThread(OWNER, { employeeKey: "finance_manager" });
    expect(await code(h.svc.send(OWNER, t.id, { body: "x" }))).toBe("budget_exceeded");
    expect(await code(h.svc.send(OWNER, t2.id, { body: "x" }))).toBe("ok");
    const [r] = await h.svc.listBudgetRequests(OWNER, "pending"); await h.svc.decideBudgetRequest(OWNER, r.id, { approve: false });
    expect(await code(h.svc.send(OWNER, t.id, { body: "x" }))).toBe("budget_exceeded");
  });
  it("is per company and the next month starts fresh", async () => {
    const h = harness(); await setBudget(h, 5);
    const t = await h.svc.startThread(OWNER, { employeeKey: "marketing_manager" }); await h.svc.send(OWNER, t.id, { body: "x" });
    expect((await h.svc.budget(actor("owner", T2))).company.used).toBe(0);
    h.advance(40 * 24 * 60 * MIN);
    expect((await h.svc.budget(OWNER)).company.used).toBe(0);
    expect(await code(h.svc.setBudget(OWNER, "company", { monthlyMicros: 0 }))).toBe("validation_failed");
    expect(await code(h.svc.setBudget(MARKETING, "company", { monthlyMicros: 5 }))).toBe("forbidden");
  });
});

describe("objectives", () => {
  it("have priorities and dependencies, including on another employee, and reject cycles", async () => {
    const h = harness();
    const a = await h.svc.createObjective(OWNER, { employeeKey: "marketing_manager", title: "Launch landing", priority: 2 });
    const b = await h.svc.createObjective(OWNER, { employeeKey: "sales_manager", title: "Close 5 deals", priority: 1, dependsOn: [a.id] });
    const list = await h.svc.listObjectives(OWNER);
    expect(list.map((o) => o.title)).toEqual(["Close 5 deals", "Launch landing"]);
    expect(list.find((o) => o.id === b.id)?.blockedBy).toEqual([a.id]);
    expect(await code(h.svc.patchObjective(OWNER, a.id, { dependsOn: [b.id] }))).toBe("validation_failed");
    expect(await code(h.svc.patchObjective(OWNER, b.id, { status: "achieved" }))).toBe("invalid_state");
    await h.svc.patchObjective(OWNER, a.id, { status: "achieved" });
    expect(await code(h.svc.patchObjective(OWNER, b.id, { status: "achieved" }))).toBe("ok");
    expect(await code(h.svc.createObjective(OWNER, { employeeKey: "marketing_manager", title: "x", dependsOn: ["ghost"] }))).toBe("validation_failed");
  });
});

describe("agenda and scheduler", () => {
  const entry = (o: Record<string, unknown> = {}) => ({ employeeKey: "marketing_manager", title: "Weekly SEO review", instruction: "Review SEO status", triggerKind: "schedule", everyMinutes: 60, requiresApproval: false, ...o });
  it("runs due entries in priority order, within budget, and leaves the result and the evidence", async () => {
    const h = harness(); await setBudget(h);
    const low = await h.svc.createAgenda(OWNER, entry({ title: "low", priority: 5 })), high = await h.svc.createAgenda(OWNER, entry({ title: "high", priority: 1 }));
    expect((await h.svc.tick(OWNER)).runs).toEqual([]);
    h.advance(61 * MIN);
    const { runs } = await h.svc.tick(OWNER);
    expect(runs.map((r) => r.agendaId)).toEqual([high.id, low.id]); expect(runs.every((r) => r.status === "succeeded" && r.mode === "simulation")).toBe(true);
    expect((await h.svc.runResult(OWNER, runs[0].id)).messages.map((m) => m.role)).toEqual(["system", "employee"]);
    expect((await h.svc.tick(OWNER)).runs).toEqual([]);
    expect((await h.svc.listAgenda(OWNER))[0].runCount).toBe(1);
    expect(actions(h)).toContain("workforce.agenda.run_succeeded");
    expect((await h.svc.budget(OWNER)).company.used).toBeGreaterThan(0);
  });
  it("waits for approval when required, and runs only after a person approves", async () => {
    const h = harness(); await setBudget(h);
    await h.svc.createAgenda(OWNER, entry({ requiresApproval: true })); h.advance(61 * MIN);
    const { runs } = await h.svc.tick(OWNER); expect(runs[0].status).toBe("awaiting_approval");
    expect((await h.svc.budget(OWNER)).company.used).toBe(0);
    expect(await code(h.svc.decideRun(MARKETING, runs[0].id, { approve: true }))).toBe("forbidden");
    const done = await h.svc.decideRun(OWNER, runs[0].id, { approve: true }); expect(done.status).toBe("succeeded"); expect(done.decidedBy).toBe("owner-1");
    expect(await code(h.svc.decideRun(OWNER, runs[0].id, { approve: true }))).toBe("invalid_state");
    h.advance(61 * MIN); const second = (await h.svc.tick(OWNER)).runs[0];
    expect((await h.svc.decideRun(OWNER, second.id, { approve: false, reason: "not now" })).status).toBe("rejected");
  });
  it("skips, and says why, when the budget is exhausted or a dependency is not met", async () => {
    const h = harness(); await h.svc.setBudget(OWNER, "company", { monthlyMicros: 1 });
    await h.svc.createAgenda(OWNER, entry()); h.advance(61 * MIN);
    const r = (await h.svc.tick(OWNER)).runs[0]; expect(r).toMatchObject({ status: "skipped", reason: "budget_exceeded" });
    expect(await h.svc.listBudgetRequests(OWNER, "pending")).toHaveLength(1);
    const h2 = harness(); await setBudget(h2);
    const base = await h2.svc.createAgenda(OWNER, entry({ title: "base", triggerKind: "manual", everyMinutes: null }));
    await h2.svc.createAgenda(OWNER, entry({ title: "after", dependsOn: [base.id] })); h2.advance(61 * MIN);
    expect((await h2.svc.tick(OWNER)).runs[0]).toMatchObject({ status: "skipped", reason: "agenda_dependency" });
    await h2.svc.runNow(OWNER, base.id); h2.advance(61 * MIN);
    expect((await h2.svc.tick(OWNER)).runs[0].status).toBe("succeeded");
  });
  it("respects objective dependencies and an employee that is no longer active", async () => {
    const h = harness(); await setBudget(h);
    const o1 = await h.svc.createObjective(OWNER, { employeeKey: "marketing_manager", title: "first" }), o2 = await h.svc.createObjective(OWNER, { employeeKey: "marketing_manager", title: "second", dependsOn: [o1.id] });
    const e = await h.svc.createAgenda(OWNER, entry({ objectiveId: o2.id })); h.advance(61 * MIN);
    expect((await h.svc.tick(OWNER)).runs[0].reason).toBe("objective_dependency");
    await h.svc.patchObjective(OWNER, o1.id, { status: "achieved" }); h.advance(61 * MIN);
    expect((await h.svc.tick(OWNER)).runs[0].status).toBe("succeeded");
    h.f.active.delete("marketing_manager"); h.advance(61 * MIN);
    expect((await h.svc.tick(OWNER)).runs[0]).toMatchObject({ status: "skipped", reason: "employee_not_active" });
    expect(e.id).toBeTruthy();
  });
  it("event entries fire on their event, manual ones on demand; paused ones never run", async () => {
    const h = harness(); await setBudget(h);
    const ev = await h.svc.createAgenda(OWNER, entry({ title: "on referral", triggerKind: "event", eventAction: "referrals.referral.converted", everyMinutes: null }));
    expect((await h.svc.fire(OWNER, { action: "referrals.referral.converted" })).runs).toHaveLength(1);
    expect((await h.svc.fire(OWNER, { action: "partners.partner.created" })).runs).toHaveLength(0);
    await h.svc.patchAgenda(OWNER, ev.id, { status: "paused" });
    expect((await h.svc.fire(OWNER, { action: "referrals.referral.converted" })).runs).toHaveLength(0);
    expect(await code(h.svc.runNow(OWNER, ev.id))).toBe("invalid_state");
    expect(await code(h.svc.createAgenda(OWNER, entry({ everyMinutes: 5 })))).toBe("validation_failed");
    expect(await code(h.svc.createAgenda(OWNER, entry({ triggerKind: "event", eventAction: null })))).toBe("validation_failed");
  });
});

describe("isolation, roles and the simulated provider", () => {
  it("never shows one company's records to another", async () => {
    const h = harness(); await setBudget(h);
    const o = await h.svc.createObjective(OWNER, { employeeKey: "marketing_manager", title: "mine" }); const B = actor("owner", T2);
    expect(await h.svc.listObjectives(B)).toEqual([]); expect(await h.svc.listAgenda(B)).toEqual([]); expect(await h.svc.listPackages(B)).toEqual([]);
    expect(await code(h.svc.patchObjective(B, o.id, { title: "hijack" }))).toBe("not_found");
    expect((await h.svc.budget(B)).configured).toBe(false);
  });
  it("roles: viewers cannot manage, outsiders see nothing, the summary reports the provider honestly", async () => {
    const h = harness();
    expect(await code(h.svc.createObjective(MARKETING, { employeeKey: "marketing_manager", title: "x" }))).toBe("forbidden");
    expect(await code(h.svc.summary(SUPPORT))).toBe("forbidden");
    const s = await h.svc.summary(OWNER); expect(s.provider).toEqual({ id: "simulated", connected: true, mode: "simulation" });
    expect((await h.svc.providers(OWNER)).providers.filter((p) => !p.connected).map((p) => p.id).sort()).toEqual(["claude", "deepseek", "gemini", "mistral", "openai"]);
  });
  it("the simulated provider is deterministic, labelled, and its price is a clearly simulated estimate", async () => {
    const p = createSimulatedProvider(), req = { tenantId: "t", employeeKey: "k", employeeName: "Ana", system: "s", messages: [{ role: "user" as const, content: "hi" }], maxOutputTokens: 10, locale: "en" as const, facts: { objectives: 0, memories: 0, skills: [], lastUserMessage: "hi" } };
    const a = await p.complete(req), b = await p.complete(req);
    expect(a).toEqual(b); expect(a.mode).toBe("simulation"); expect(a.text).toMatch(/^\[Simulation\]/);
  });
});
