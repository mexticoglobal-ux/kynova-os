import { describe, expect, it } from "vitest";
import { OWNER, code, fixture } from "./helpers";

describe("assertBlueprintAllowed: one plan check for every way of hiring", () => {
  it("refuses a roster blueprint outside the plan or not available yet, and lets the rest through", async () => {
    const { svc } = fixture({ plan: "starter", registered: ["marketing_manager", "partner_manager", "legal_assistant"] });
    expect(await code(svc.assertBlueprintAllowed(OWNER, "partner_manager"))).toBe("plan_required");
    expect(await code(svc.assertBlueprintAllowed(OWNER, "marketing_manager"))).toBe("ok");
    expect(await code(svc.assertBlueprintAllowed(OWNER, "custom"))).toBe("ok");
    const business = fixture({ plan: "business" }).svc;
    expect(await code(business.assertBlueprintAllowed(OWNER, "partner_manager"))).toBe("ok");
    expect(await code(business.assertBlueprintAllowed(OWNER, "legal_assistant"))).toBe("invalid_state");
  });
  it("an unreadable plan means the smallest team, like the Activate button", async () => {
    const { svc } = fixture({ broken: new Set(["plan"]) });
    expect(await code(svc.assertBlueprintAllowed(OWNER, "partner_manager"))).toBe("plan_required");
    expect(await code(svc.assertBlueprintAllowed(OWNER, "marketing_manager"))).toBe("ok");
  });
});
