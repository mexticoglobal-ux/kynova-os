import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES, canAccess } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { COLUMNS, TABLE } from "../../../src/modules/marketplace/columns";
import { MARKETPLACE_DICTIONARIES } from "../../../src/modules/marketplace/i18n";
import { ARCHITECTURE_STATUS } from "../../../src/modules/marketplace/contracts";
import { AI_TOPICS, CAPABILITIES, COMMISSION_SCOPES, CURRENCIES, DEFAULT_CAPABILITIES, DENY_HELP, DOWNLOAD_STATUS, FEATURED_SLOTS, GENERIC_STATUS, LICENSE_KINDS, LICENSE_STATUS, ORDER_STATUS, PAYMENT_MODES, PRICING_MODELS, PRODUCT_SORTS, PRODUCT_STATUS, PRODUCT_TYPES, PUBLISHER_KINDS, PUBLISHER_STATUS, REVIEW_STATUS, SEVERITIES, VERSION_STATUS, BILLING_PERIODS, COLLECTION_STATUS } from "../../../src/modules/marketplace/domain";
import { MARKETPLACE_BLUEPRINT } from "../../../src/modules/marketplace/employee";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => { try { return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; }); } catch { return []; } };
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "marketplace");
const bad = (dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "marketplace"), join(SRC, "app", "(app)", "app", "marketplace")];
const strip = (s: string) => s.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");
const OTHERS = "crm|marketing|seo|ai-studio|finance|communications|billing|security|analytics|analytics-bi|mission-control|integrations";

describe("Marketplace module boundaries", () => {
  it("never touches Drizzle, database internals, kernel internals or other product modules", () => {
    expect(bad([MOD], new RegExp(`drizzle-orm|platform/db|ai-kernel/|ai-employees/|platform/dashboard|components/dashboard|modules/(${OTHERS})`))).toEqual([]);
  });
  it("only the store layer knows SQL; no payment host and no network call exist in the module", () => {
    expect(files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f))).toEqual(["store-d1.ts"]);
    expect(files(MOD).filter((f) => /api\.openai\.com|api\.anthropic\.com|api\.stripe\.com|api\.paypal\.com|paypal\.com\/v|maka|checkout\.stripe/i.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
    expect(files(MOD).filter((f) => /(?<![.\w])fetch\(|XMLHttpRequest|new WebSocket|node:https?|node:net/.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
  });
  it("states plainly what it does not do", () => {
    expect(ARCHITECTURE_STATUS.payments).toBe("simulated_only"); expect(ARCHITECTURE_STATUS.payment_providers).toBe("not_connected"); expect(ARCHITECTURE_STATUS.file_delivery).toBe("no_file_store"); expect(ARCHITECTURE_STATUS.ai_actions).toBe("never_executed");
  });
  it("UI uses the module's public interface only", () => {
    expect(bad(UI, new RegExp(`platform/db|drizzle|modules/marketplace/(store|columns|runtime|ai|server)|modules/(${OTHERS})|components/(${OTHERS})`))).toEqual([]);
  });
  it("frozen code does not know the Marketplace; it joins through startup registration only", () => {
    const frozen = ["platform/db", "platform/auth", "platform/ai-kernel", "platform/ai-employees", "platform/dashboard", ...OTHERS.split("|").map((m) => `modules/${m}`)].map((d) => join(SRC, d));
    expect(bad(frozen, /modules\/marketplace|components\/marketplace/)).toEqual([]);
    const ins = readFileSync(join(SRC, "instrumentation.ts"), "utf8"); expect(ins).toContain("registerMarketplaceWidget"); expect(ins).toContain("registerMarketplaceEmployee");
  });
  it("registers exactly one widget: marketplace-overview", () => {
    const w = readFileSync(join(SRC, "components", "marketplace", "DashboardWidget.tsx"), "utf8");
    expect([...w.matchAll(/registerWidget</g)]).toHaveLength(1); expect(w).toContain('id: "marketplace-overview"');
  });
  it("client components do not import server-only parts", () => {
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThanOrEqual(5);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/marketplace$|modules\/marketplace\/(service|server|http|store|runtime|ai)/.test(i)))).toEqual([]);
  });
  it("reuses the existing module slug: no new slug, open to all staff", () => {
    expect(MODULES).toHaveLength(30); expect(MODULES.filter((m) => m.slug === "marketplace")).toHaveLength(1);
    expect(readFileSync(join(MOD, "http.ts"), "utf8")).toContain('MARKETPLACE_SLUG = "marketplace"');
    expect(canAccess("owner", "marketplace")).toBe(true); expect(canAccess("employee", "marketplace")).toBe(true); expect(canAccess("guest", "marketplace")).toBe(false);
  });
  it("the Marketplace Advisor never executes actions: its blueprint is read only", () => {
    expect(MARKETPLACE_BLUEPRINT.maxAutonomy).toBe(1); expect(MARKETPLACE_BLUEPRINT.defaultInstructions).toMatch(/read only/i); expect(MARKETPLACE_BLUEPRINT.defaultInstructions).toMatch(/never buy/i);
    expect(MARKETPLACE_BLUEPRINT.name).toBe("Marketplace Advisor AI"); expect(AI_TOPICS).toHaveLength(6);
    for (const c of MARKETPLACE_BLUEPRINT.capabilities) expect(c).toMatch(/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/);
    expect(MARKETPLACE_BLUEPRINT.capabilities).toHaveLength(7); expect(MARKETPLACE_BLUEPRINT.key).toMatch(/^[a-z][a-z0-9_]*$/);
  });
});

describe("API surface: only /api/v1/marketplace/*", () => {
  const API = join(SRC, "app", "api", "v1", "marketplace");
  const routes = files(API).filter((f) => f.endsWith("route.ts"));
  it("every handler goes through marketplaceRoute; every mutating verb enables CSRF checks", () => {
    expect(routes.length).toBeGreaterThanOrEqual(40);
    for (const f of routes) {
      const src = readFileSync(f, "utf8");
      for (const m of src.matchAll(/export const (GET|POST|PATCH|PUT|DELETE) = (\w+)/g)) {
        expect(m[2], `${relative(SRC, f)} ${m[1]}`).toBe("marketplaceRoute");
        const decl = src.slice(src.indexOf(m[0])), next = decl.indexOf("\nexport const", 10), block = decl.slice(0, next === -1 ? decl.length : next);
        if (m[1] !== "GET") expect(block, `${relative(SRC, f)} ${m[1]}`).toContain("mutating: true"); else expect(block).not.toContain("mutating");
      }
    }
  });
  it("there is no public storefront endpoint, no payment webhook and no outbound call", () => {
    expect(routes.filter((f) => !readFileSync(f, "utf8").includes("marketplaceRoute"))).toEqual([]);
    expect(routes.filter((f) => /fetch\(/.test(readFileSync(f, "utf8")))).toEqual([]);
    expect(routes.map((f) => relative(API, f)).filter((r) => /webhook|stripe|paypal|maka|checkout-session/i.test(r))).toEqual([]);
  });
  it("covers every section and action", () => {
    const rel = new Set(routes.map((f) => relative(API, f).replace(/\/?route\.ts$/, "")));
    for (const p of ["setup", "summary", "permissions/mine", "categories", "categories/[id]", "publishers", "publishers/[id]", "products", "products/[id]", "products/[id]/publish", "products/[id]/suspend", "products/[id]/archive", "products/[id]/versions", "versions/[id]/publish", "versions/[id]/deprecate", "orders", "orders/[id]", "orders/[id]/pay", "orders/[id]/cancel", "orders/[id]/refund", "licenses", "licenses/[id]", "licenses/[id]/revoke", "downloads", "reviews", "reviews/[id]", "ratings", "collections", "collections/[id]", "featured", "featured/[id]", "commissions", "commissions/preview", "commissions/[id]", "revenue", "revenue/summary", "notifications", "notifications/unread", "notifications/read-all", "notifications/[id]/read", "settings", "ai/[id]"]) expect(rel.has(p), p).toBe(true);
  });
});

describe("pages", () => {
  it("has the 14 views plus the product detail", () => {
    const base = join(SRC, "app", "(app)", "app", "marketplace"), pages = new Set(files(base).filter((f) => f.endsWith("page.tsx")).map((f) => relative(base, f).replace(/\/?page\.tsx$/, "")));
    expect([...pages].sort()).toEqual(["", "categories", "collections", "commissions", "downloads", "featured", "licenses", "notifications", "orders", "products", "products/[id]", "publishers", "revenue", "reviews", "settings"]);
  });
});

describe("migration 1200_marketplace.sql", () => {
  const sql = readFileSync(join(process.cwd(), "drizzle/migrations/1200_marketplace.sql"), "utf8");
  const tables = [...sql.matchAll(/CREATE TABLE `(mp_\w+)` \(([\s\S]*?)\n\);/g)];
  it("creates exactly the 16 mp_* tables and touches nothing else", () => {
    expect(tables).toHaveLength(16); expect(Object.values(TABLE).sort()).toEqual(tables.map((t) => t[1]).sort());
    for (const n of ["categories", "products", "product_versions", "publishers", "orders", "order_items", "licenses", "downloads", "reviews", "ratings", "collections", "featured", "commissions", "revenue", "notifications", "settings"]) expect(Object.values(TABLE)).toContain(`mp_${n}`);
    expect(sql.replace(/^--.*$/gm, "")).not.toMatch(/ALTER TABLE|DROP TABLE|DROP INDEX|INSERT INTO|DELETE FROM/);
    for (const o of sql.matchAll(/CREATE (?:UNIQUE )?INDEX `(\w+)`/g)) expect(o[1]).toMatch(/^mp_/);
    for (const o of sql.matchAll(/CREATE TRIGGER (\w+)/g)) expect(o[1]).toMatch(/^mp_/);
  });
  it("every table is tenant-owned with cascade and tenant-first indexes", () => {
    for (const [, name, body] of tables) {
      expect(body, name).toContain("`tenant_id` text NOT NULL"); expect(body, name).toContain("FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`)");
      for (const ix of sql.matchAll(new RegExp(`CREATE (?:UNIQUE )?INDEX \`\\w+\` ON \`${name}\` \\(([^)]*)\\)`, "g"))) expect(ix[1], name).toMatch(/^`tenant_id`/);
    }
  });
  it("the database enforces tenant freezing, append-only ledgers, no deletes, no stored files and consistent money", () => {
    for (const t of Object.values(TABLE)) { expect(sql, t).toContain(`${t}_tenant_frozen`); expect(sql, t).toContain(`${t}_no_delete`); }
    for (const t of ["order_items", "downloads", "revenue"]) expect(sql).toContain(`mp_${t}_immutable`);
    expect(sql).toContain("CHECK (`artifact_ref` IS NULL)"); expect(sql).toContain("`commission_cents` + `net_cents` = `unit_price_cents`"); expect(sql).toContain("`gross_cents` = `commission_cents` + `net_cents`");
    expect(sql).toContain("CHECK (`stars` BETWEEN 1 AND 5)"); expect(sql).toContain("mp_licenses_key_uq");
  });
  it("whitelists cover each kind and carry the tenant column", () => {
    for (const k of Object.keys(TABLE) as (keyof typeof TABLE)[]) { expect(COLUMNS[k]).toContain("id"); expect(COLUMNS[k]).toContain("tenantId"); }
    expect(COLUMNS.license.some((c) => /^(key|licenseKey|secret|token)$/.test(c))).toBe(false);
  });
});

describe("architecture-only promises", () => {
  it("no payment provider, SDK or outbound call exists anywhere in the module or its UI", () => {
    const all = [...files(MOD), ...UI.flatMap(files)].map((f) => ({ f, src: strip(readFileSync(f, "utf8")) }));
    expect(all.filter((x) => /api\.stripe|js\.stripe|api\.paypal|paypal\.com|checkout\.stripe|hooks\.stripe|\bmaka\b/i.test(x.src)).map((x) => relative(SRC, x.f))).toEqual([]);
    expect(all.filter((x) => /from\s+["'](stripe|@stripe|@paypal|paypal-rest-sdk|maka)/.test(x.src)).map((x) => relative(SRC, x.f))).toEqual([]);
  });
  it("lists the ten product types, and all the sale functions exist as service operations", () => {
    expect(PRODUCT_TYPES).toEqual(["ai_agent", "automation", "template", "dashboard", "workflow", "integration", "prompt", "design_template", "extension", "add_on"]);
    const src = readFileSync(join(MOD, "service.ts"), "utf8");
    for (const op of ["checkout", "pay", "refund", "publish", "request", "revoke", "rate", "submit", "moderate", "summary", "preview"]) expect(src, op).toContain(`async ${op}(`);
  });
});

describe("capabilities and texts", () => {
  it("module access is the outer gate; default capabilities only narrow it", () => {
    expect(CAPABILITIES).toHaveLength(13);
    for (const r of ROLES) { if (!canAccess(r, "marketplace")) expect(DEFAULT_CAPABILITIES[r].length, r).toBe(0); else expect(DEFAULT_CAPABILITIES[r].includes("view"), r).toBe(true); }
    expect(DEFAULT_CAPABILITIES.owner).toHaveLength(CAPABILITIES.length); expect(DEFAULT_CAPABILITIES.employee).not.toContain("buy"); expect(DEFAULT_CAPABILITIES.finance).toContain("view_revenue"); expect(DEFAULT_CAPABILITIES.manager).not.toContain("view_revenue");
  });
  it("English and Spanish have the same keys, and every vocabulary used by the UI has texts", () => {
    const en = MARKETPLACE_DICTIONARIES.en as Record<string, string>, es = MARKETPLACE_DICTIONARIES.es as Record<string, string>;
    expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort());
    const groups: [string, readonly string[]][] = [["ptype", PRODUCT_TYPES], ["pm", PRICING_MODELS], ["per", BILLING_PERIODS], ["pst", PRODUCT_STATUS], ["vst", VERSION_STATUS], ["pk", PUBLISHER_KINDS], ["pbs", PUBLISHER_STATUS], ["ost", ORDER_STATUS], ["pmode", PAYMENT_MODES], ["lk", LICENSE_KINDS], ["lst", LICENSE_STATUS],
      ["dst", DOWNLOAD_STATUS], ["rvs", REVIEW_STATUS], ["cst", COLLECTION_STATUS], ["slot", FEATURED_SLOTS], ["gen", GENERIC_STATUS], ["scope", COMMISSION_SCOPES], ["sv", SEVERITIES], ["sort", PRODUCT_SORTS], ["topic", AI_TOPICS], ["cap", CAPABILITIES], ["role", ROLES], ["deny", Object.keys(DENY_HELP)], ["arch", Object.keys(ARCHITECTURE_STATUS)], ["arch.state", Object.values(ARCHITECTURE_STATUS)]];
    for (const [p, list] of groups) for (const k of list) expect(en[`${p}.${k}`], `${p}.${k}`).toBeDefined();
    expect(CURRENCIES).toContain("USD"); for (const [k, v] of Object.entries(es)) expect(v.trim(), k).not.toBe("");
  });
});
