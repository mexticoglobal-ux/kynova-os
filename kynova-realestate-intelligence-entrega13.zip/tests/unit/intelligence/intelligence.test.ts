import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { ceoBrief, confidence, heatOf, inWindow, rankBy, runRate, timeSaved, trend, weeklyReport, type Finding } from "@/platform/intelligence";

const f = (o: Partial<Finding>): Finding => ({ id: "x", kind: "action", employee: "e", code: "c", params: {}, subjectKind: null, subjectId: null, priority: "medium", points: 0, confidence: confidence([]), ...o });
describe("Executive Intelligence Layer (generic, pure)", () => {
  it("confidence is the share of weighted evidence present, never 100 and never invented", () => {
    expect(confidence([{ code: "a", weight: 50, met: true }, { code: "b", weight: 50, met: false }]).pct).toBe(50);
    expect(confidence([{ code: "a", weight: 1, met: true }]).pct).toBe(99); expect(confidence([{ code: "a", weight: 1, met: false }]).pct).toBe(5); expect(confidence([]).pct).toBe(0);
  });
  it("trend: no data is not a trend; ±10% is flat", () => {
    expect(trend(0, 0).direction).toBe("insufficient"); expect(trend(3, 0)).toMatchObject({ direction: "up", deltaPct: null }); expect(trend(105, 100).direction).toBe("flat");
    expect(trend(2, 4)).toMatchObject({ direction: "down", deltaPct: -50 }); expect(trend(6, 4)).toMatchObject({ direction: "up", deltaPct: 50 });
  });
  it("run-rate shows its own formula inputs", () => { expect(runRate(2, 28, 30)).toEqual({ count: 2, windowDays: 28, horizonDays: 30, projected: 2.1 }); });
  it("heat maps the opportunity level", () => { expect([heatOf("high"), heatOf("medium"), heatOf("low")]).toEqual(["hot", "warm", "cold"]); });
  it("time saved is the sum of fixed estimates per unit, ignoring unknown or empty kinds", () => {
    expect(timeSaved({ a: 2, b: 1, c: 0, z: 5 }, { a: 25, b: 60, c: 40 })).toEqual({ minutes: 110, parts: [{ key: "a", count: 2, minutesEach: 25, minutes: 50 }, { key: "b", count: 1, minutesEach: 60, minutes: 60 }] });
  });
  it("the CEO brief interprets: priority, opportunity, risk, and at most 3 actions for today", () => {
    const b = ceoBrief([f({ id: "1", priority: "low" }), f({ id: "2", priority: "high", points: 5 }), f({ id: "3", priority: "high", points: 9 }), f({ id: "4" }), f({ id: "5" }), f({ id: "o1", kind: "opportunity", points: 10 }), f({ id: "o2", kind: "opportunity", points: 70 }), f({ id: "r1", kind: "risk", points: 3 })]);
    expect(b.today.map((x) => x.id)).toEqual(["3", "2", "4"]); expect(b.priority?.id).toBe("3"); expect(b.opportunity?.id).toBe("o2"); expect(b.risk?.id).toBe("r1");
    expect(ceoBrief([])).toEqual({ today: [], priority: null, opportunity: null, risk: null });
  });
  it("windows and weekly rows count only what falls inside", () => {
    const now = 100 * 86_400_000, d = (n: number) => now - n * 86_400_000;
    expect(inWindow([d(1), d(6), d(8), d(20)], now, 7, 0)).toBe(2); expect(inWindow([d(1), d(6), d(8), d(20)], now, 7, 1)).toBe(1);
    expect(weeklyReport([{ key: "k", cur: 1, prev: 2 }])[0]!.trend.direction).toBe("down"); expect(rankBy([{ points: 0 }, { points: 5 }, { points: 9 }], 1)).toEqual([{ points: 9 }]);
  });
  it("is generic: no business module, no Real Estate vocabulary, no network and no AI", () => {
    const src = readFileSync("src/platform/intelligence/index.ts", "utf8");
    expect(src).not.toMatch(/@\/modules\//); expect(src.replace(/\/\*[\s\S]*?\*\//g, "").toLowerCase()).not.toMatch(/propert|buyer|owner|real.?estate/); expect(src).not.toMatch(/\bfetch\(|Date\.now|new Date\(|ai-kernel|@anthropic|openai|Math\.random/);
  });
});
