"use client";
import { useEffect, useState } from "react";
import { useT } from "./I18n";

/** The greeting depends on the person's local time, which the server does not know. */
export function Greeting({ name }: { name: string }) {
  const { t } = useT(), [h, setH] = useState<number | null>(null);
  useEffect(() => setH(new Date().getHours()), []);
  const key = h === null ? "ex.hi.am" : h < 12 ? "ex.hi.am" : h < 19 ? "ex.hi.pm" : "ex.hi.night";
  return <h2 className="text-lg font-semibold" suppressHydrationWarning>{t(key, { name })}</h2>;
}
