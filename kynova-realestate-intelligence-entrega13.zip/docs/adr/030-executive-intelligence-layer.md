# ADR 030 – Executive Intelligence Layer (Entrega 13)

**Estado:** aceptado.

**Contexto.** Se pide convertir datos ya existentes en inteligencia para el dueño, sin IA, sin módulos ni motores nuevos, y reutilizable por otros sistemas.

**Decisión.**
1. `src/platform/intelligence`: funciones puras (confianza, heat, tendencia, run-rate, tiempo ahorrado, CEO brief, reporte semanal). No es un motor: no tiene estado, almacenamiento ni scheduler.
2. Real Estate aporta un adaptador puro (`executive.ts`) y un método `executive()` de solo lectura en su servicio. Reutiliza `scores`/`workflows` (sin modificarlos), los hallazgos del Workflow Engine, el digest y los datos de la Foundation.
3. Sin persistencia: se calcula bajo demanda, por tenant. Cero tablas y cero eventos nuevos.
4. La UI recibe datos estructurados (códigos + números) y los redacta en el idioma de la persona: no hay prosa fija.
5. Mission Control sigue siendo el único destino: su layout muestra el resumen ejecutivo en lugar del digest simple (el digest sigue en la página de Real Estate y dentro del resumen).

**Alternativas descartadas.** Guardar reportes (estado nuevo y datos duplicados); un "motor de insights" con reglas configurables (infraestructura nueva); IA para redactar (fuera de alcance).

**¿Escala a 10.000 empresas sin rediseño?** Sí: cálculo por tenant, sin estado global; el costo es una lectura acotada (≤2000 registros por tipo y ≤1000 hallazgos). Si una empresa creciera más, el resultado se puede cachear o precalcular en el barrido sin cambiar la capa.
