# 38 – Executive Intelligence Layer + Real Estate Executive Insights (Entrega 13)

Al abrir Mission Control el dueño ve el análisis de un Director Ejecutivo. Todo sale de datos registrados, con reglas, sin IA, sin texto fijo (las frases se construyen con plantillas y números reales; si no hay datos, el bloque no aparece o dice que no hay datos).

## Capa reutilizable: `src/platform/intelligence` (funciones puras)
| Pieza | Qué hace |
|---|---|
| `confidence(signals)` | % = peso de la evidencia presente ÷ peso total (entre 5 y 99; nunca 100). Devuelve las señales para mostrar **por qué**. |
| `heatOf(level)` | Alta/Media/Baja → 🔥 Muy caliente / 🟡 Intermedio / 🔵 Bajo. |
| `trend(cur, prev)` | Últimos 7 días vs. 7 anteriores; ±10% = sin cambios; sin datos = "insuficiente". |
| `runRate(n, ventana, horizonte)` | Proyección simple: n ÷ ventana × horizonte (la fórmula se muestra). |
| `ceoBrief(findings)` | CEO AI: hoy (máx. 3), prioridad, mayor oportunidad, riesgo. No conversa; solo interpreta. |
| `timeSaved(counts, minutos)` | Tiempo **estimado** ahorrado con minutos fijos por tarea. |
| `weeklyReport`, `inWindow`, `rankBy`, `topBy` | Reporte semanal y ranking. |

La capa no importa módulos, no conoce Real Estate, no tiene red ni reloj. YouTube, Ecommerce, CRM, Finanzas, Restaurantes, Clínicas, Hoteles o Constructoras solo escriben un adaptador (como `src/modules/realestate/executive.ts`).

## Adaptador de Real Estate
`GET /api/v1/realestate/executive` → `{ summary, ceo, insights, ranking, trends, forecast, weekly, timeSaved, value }`. No escribe nada (sin tablas nuevas, sin eventos): calcula sobre propiedades, compradores, propietarios, actividades, publicaciones y los hallazgos del Workflow Engine.

- **Resumen ejecutivo:** el digest por empleado + línea del Analytics Manager si hay riesgo + tiempo del equipo en 24 h.
- **CEO AI:** ¿Qué hacer hoy? (trabajo abierto priorizado), prioridad, mayor oportunidad, riesgo (propiedad ≥30 días sin visitas, o comprador/propietario "alta" inactivo ≥7 días). Cada uno con confianza y razones.
- **Insights:** mayor potencial, riesgo, oportunidad, actividad, caída y crecimiento (cada uno explicado).
- **Ranking + Heat:** top 5 mezclado de compradores, propietarios y propiedades, con nivel y motivos (puntos de las reglas).
- **Tendencias y forecast:** clientes nuevos, captación, actividad, cierres, propiedades. Forecast = cierres de 28 días ÷ 28 × 30.
- **Reporte semanal:** propiedades, compradores, matching, seguimientos, publicaciones, cierres, conversión histórica.
- **Tiempo ahorrado / valor:** matching 25 min, seguimiento 40, revisión 30, oportunidad 10, rendimiento 15, crecimiento 20, publicaciones 60 min por propiedad. Siempre estimado.

## Límites honestos
- Confianza ≠ probabilidad: mide cuánta de la evidencia que pide la regla está registrada.
- "Consultas" no existe como dato: se usan clientes nuevos (compradores + propietarios).
- Conversión: solo la histórica (los cambios de etapa no tienen fecha, no hay tendencia).
- Con más de 1000 hallazgos o 2000 registros por tipo se analizan los más recientes (se avisa).
- El saludo usa la hora local del navegador; el nombre sale de la sesión.
