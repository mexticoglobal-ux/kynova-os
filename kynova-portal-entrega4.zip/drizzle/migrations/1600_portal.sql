-- Portal (Entrega 4). Owned by src/modules/portal. A portal link = a secret token; only its SHA-256 is stored. No login, no email delivery, read-only for partners.
-- Tenant-owned: tenant_id references companies and every index leads with tenant_id. Nothing is deleted: a link is revoked.
-- subject_id points at a partner or a referral link of the same company; it is validated by the service (no cross-module foreign key on purpose).

CREATE TABLE `pl_access` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`kind` text NOT NULL,
	`subject_id` text NOT NULL,
	`label` text DEFAULT '' NOT NULL,
	`token_hash` text NOT NULL,
	`token_hint` text NOT NULL,
	`status` text DEFAULT 'active' NOT NULL,
	`expires_at` integer NOT NULL,
	`last_used_at` integer,
	`use_count` integer DEFAULT 0 NOT NULL,
	`submit_day` integer DEFAULT 0 NOT NULL,
	`submit_count` integer DEFAULT 0 NOT NULL,
	`created_by` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`kind` IN ('partner', 'referrer')),
	CHECK (`status` IN ('active', 'revoked')),
	CHECK (`use_count` >= 0 AND `submit_count` >= 0)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pl_access_tenant_id_uq` ON `pl_access` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `pl_access_token_uq` ON `pl_access` (`tenant_id`,`token_hash`);--> statement-breakpoint
CREATE INDEX `pl_access_subject_idx` ON `pl_access` (`tenant_id`,`kind`,`subject_id`);--> statement-breakpoint
CREATE INDEX `pl_access_status_idx` ON `pl_access` (`tenant_id`,`status`,`created_at`);--> statement-breakpoint
CREATE TRIGGER pl_access_tenant_frozen BEFORE UPDATE OF tenant_id ON pl_access BEGIN SELECT RAISE(ABORT, 'portal tenant cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER pl_access_frozen BEFORE UPDATE OF kind, subject_id, token_hash ON pl_access
BEGIN SELECT RAISE(ABORT, 'portal access identity and secret cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER pl_access_no_delete BEFORE DELETE ON pl_access
BEGIN SELECT RAISE(ABORT, 'pl_access rows cannot be deleted'); END;
