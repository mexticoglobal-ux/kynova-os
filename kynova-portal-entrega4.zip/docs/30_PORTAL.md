# 30 · Portal (Entrega 4, Bloque Comercial)

Acceso externo de solo lectura para **partners** y **referentes**, sin tocar la autenticación (congelada).

## Cómo funciona
- Un administrador (propietario, administrador, CEO, super admin o gerente) crea un **enlace del portal** para un partner o un enlace de referido. El enlace es `/portal/<tenantId>.<secreto>`.
- El secreto (192 bits aleatorios) **se muestra una sola vez**; la base solo guarda su SHA-256 y 4 caracteres de pista. Vigencia 1–365 días (90 por defecto); se puede **revocar**.
- Cualquier fallo (mal formado, desconocido, otro tenant, alterado, vencido, revocado) responde **el mismo 404**: no se revela qué enlaces existen.
- **Partner**: ve su nivel, tasa, clientes, oportunidades y últimas comisiones. Solo lectura.
- **Referente**: ve sus referidos (solo nombre y estado, nunca el correo) y recompensas, y puede **enviar referidos** (tope de 20 por día UTC; un envío rechazado no gasta el tope). El envío entra a Referidos con el portal como actor.
- La página pública es `noindex`, `Referrer-Policy: no-referrer` y `force-dynamic`. La API pública usa `Authorization: Bearer` (sin cookies, por eso no hay CSRF).

## Arquitectura
`server.ts` es el **único** archivo que une el Portal con Partners y Referidos, mediante puertos estrechos que devuelven formas fijas para **un** partner o **un** enlace. El resto del módulo no importa otros módulos. Evidencia en el Activity Engine (`portal.access.created|revoked`, `portal.referral.submitted`).

## Estado honesto (`ARCHITECTURE_STATUS`)
access link_with_token · portal_login not_built · link_delivery not_connected · anonymous_referral_page not_built · partner_actions read_only · payouts simulated_only.

## Escala (10 000 empresas)
El token lleva el tenant, así que la búsqueda es siempre `tenant_id` + hash (índice único); sin escaneos globales.

## Datos
Migración `1600_portal.sql`: tabla `pl_access` (identidad y secreto congelados por trigger; sin borrado).
