# ADR 022 · Portal

**Estado**: aceptado.
1. Acceso por enlace con token en lugar de cuentas externas: no modifica Auth (congelado) y es revocable.
2. El tenant viaja en el token; el secreto solo existe como hash. Respuesta única 404 ante cualquier fallo.
3. Solo lectura para partners; los referentes solo pueden enviar referidos, con tope diario. No hay página anónima (abuso sin captcha/límite de IP).
4. Puertos inyectados en `server.ts`: el Portal no importa Partners/Referidos fuera de la composición.
5. Sin envío de enlaces por correo ni inicio de sesión: declarados `not_connected`/`not_built`.
6. Cambios aditivos: `modules.ts` (slug `portal`), `plans.ts` (BUSINESS).
