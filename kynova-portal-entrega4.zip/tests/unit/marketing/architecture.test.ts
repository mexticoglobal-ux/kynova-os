import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { POLICIES, mayApprove } from "../../../src/modules/marketing/access";
import { MKT_DICTIONARIES } from "../../../src/modules/marketing/i18n";
import { fromWire, queryObject, toWire } from "../../../src/modules/marketing/wire";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; });
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "marketing");
const bad = (dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "marketing"), join(SRC, "app", "(app)", "app", "social-media")];

describe("Marketing module boundaries (docs/05 section 3)", () => {
  it("never touches Drizzle, the database internals, the kernel/employees internals, the dashboard or the CRM", () => {
    expect(bad([MOD], /drizzle-orm|platform\/db\/|ai-kernel\/|ai-employees|platform\/dashboard|modules\/crm/)).toEqual([]);
  });
  it("reaches the platform only through public entry points", () => {
    const platform = files(MOD).flatMap((f) => imports(f).filter((i) => i.startsWith("@/platform")));
    expect(new Set(platform)).toEqual(new Set(["@/platform/db", "@/platform/ai-kernel", "@/platform/auth/errors", "@/platform/auth/http", "@/platform/auth/session"]));
  });
  it("only the store layer is aware of SQL, and no provider host appears anywhere", () => {
    const sqlFiles = files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f));
    expect(sqlFiles).toEqual(["store-d1.ts"]);
    expect(files(MOD).filter((f) => /api\.openai\.com|api\.anthropic\.com|generativelanguage\.googleapis\.com/.test(readFileSync(f, "utf8")))).toEqual([]);
  });
  it("UI components and pages use the module's public interface, never its store, and never other product modules", () => {
    expect(bad(UI, /platform\/db|drizzle|modules\/marketing\/(store|columns|runtime|members|ai)|modules\/crm|components\/crm/)).toEqual([]);
  });
  it("the Database, CRM and Dashboard code do not know Marketing", () => {
    expect(bad([join(SRC, "platform", "db"), join(SRC, "modules", "crm"), join(SRC, "platform", "dashboard"), join(SRC, "components", "crm"), join(SRC, "components", "dashboard")], /modules\/marketing|components\/marketing/)).toEqual([]);
  });
  it("client components do not import server-only parts of the module", () => {
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThan(5);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/marketing$|modules\/marketing\/(service|server|http)/.test(i)))).toEqual([]);
  });
  it("does not add a product module: Marketing lives under the existing social-media slug", () => {
    expect(MODULES).toHaveLength(27);
    expect(MODULES.some((m) => m.slug === "marketing")).toBe(false);
    expect(readFileSync(join(MOD, "http.ts"), "utf8")).toContain('MARKETING_SLUG = "social-media"');
  });
});

describe("migration 0200_marketing.sql", () => {
  const sql = readFileSync(join(process.cwd(), "drizzle/migrations/0200_marketing.sql"), "utf8");
  const tables = [...sql.matchAll(/CREATE TABLE `(mkt_\w+)` \(([\s\S]*?)\n\);/g)];
  it("creates only mkt_ tables, each tenant-owned with a cascade FK to companies and a tenant-leading index", () => {
    expect(tables.length).toBe(8);
    for (const [, name, body] of tables) {
      expect(body, name).toContain("`tenant_id` text NOT NULL");
      expect(body, name).toMatch(/FOREIGN KEY \(`tenant_id`\) REFERENCES `companies`\(`id`\) ON UPDATE no action ON DELETE cascade/);
      expect(sql, name).toMatch(new RegExp(`INDEX \`\\w+\` ON \`${name}\` \\(\`tenant_id\``));
    }
    expect([...sql.matchAll(/CREATE TABLE `(\w+)`/g)].every((m) => (m[1] as string).startsWith("mkt_"))).toBe(true);
    expect(sql).not.toMatch(/DROP|ALTER TABLE (?!mkt_)/);
  });
  it("keeps the approval history append-only and published posts final", () => {
    expect(sql).toMatch(/mkt_approvals_append_only BEFORE UPDATE/); expect(sql).toMatch(/mkt_approvals_no_delete BEFORE DELETE/); expect(sql).toMatch(/mkt_posts_published_final/);
  });
});

describe("role policy", () => {
  it("covers every role, and grants nothing to roles that cannot open the module", () => {
    const m = MODULES.find((x) => x.slug === "social-media");
    for (const r of ROLES) {
      const levels = Object.values(POLICIES[r].levels);
      if (m?.roles.includes(r)) expect(levels.some((l) => l !== "none"), r).toBe(true);
      else expect(levels.every((l) => l === "none"), r).toBe(true);
    }
  });
  it("only management approves; the author cannot approve unless they run the company", () => {
    expect(ROLES.filter((r) => POLICIES[r].levels.post === "manage").sort()).toEqual(["administrator", "ceo", "manager", "owner", "super_admin"]);
    expect(mayApprove("marketing", "u1", "u2")).toBe(false);
    expect(mayApprove("manager", "u1", "u2")).toBe(true);
    expect(mayApprove("manager", "u1", "u1")).toBe(false);
    expect(mayApprove("owner", "u1", "u1")).toBe(true);
    expect(POLICIES.marketing.levels.channel).toBe("read");
  });
});

describe("wire format and i18n", () => {
  it("translates snake_case and ISO dates both ways, hiding the tenant", () => {
    expect(toWire({ id: "a", tenantId: "t", scheduledAt: 0, channelName: null, spend: { USD: 5 } })).toEqual({ id: "a", scheduled_at: "1970-01-01T00:00:00.000Z", channel_name: null, spend: { USD: 5 } });
    expect(fromWire({ scheduled_at: "2026-01-01T00:00:00Z", occurred_at: "2026-10-15", asset_ids: ["x"] })).toEqual({ scheduledAt: Date.parse("2026-01-01T00:00:00Z"), occurredAt: Date.parse("2026-10-15"), assetIds: ["x"] });
    expect(queryObject(new URLSearchParams("channel_id=c&q=a"))).toEqual({ channelId: "c", q: "a" });
    expect(() => queryObject(new URLSearchParams("q=a&q=b"))).toThrow();
  });
  it("has identical keys in es and en", () => { expect(Object.keys(MKT_DICTIONARIES.es).sort()).toEqual(Object.keys(MKT_DICTIONARIES.en).sort()); });
});
