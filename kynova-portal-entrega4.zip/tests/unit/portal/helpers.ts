import type { Role } from "@/config/roles";
import { createMemoryPortalStore } from "../../../src/modules/portal/store-memory";
import type { PortalStore } from "../../../src/modules/portal/store";
import { PortalError } from "../../../src/modules/portal/errors";
import { createPortalService, type Actor, type PortalPorts, type PortalService } from "../../../src/modules/portal/service";
import type { ActivitySink, SinkEvent } from "../../../src/platform/activity";

export const T1 = "tenant-one", T2 = "tenant-two";
export const DAY = 86_400_000;
export const START = Date.UTC(2026, 9, 20, 12);
export const actor = (role: Role, userId: string, tenantId = T1): Actor => ({ tenantId, userId, role });
export const Q = (o: Record<string, unknown> = {}) => ({ limit: 25, ...o }) as never;
export const code = async (p: Promise<unknown>) => { try { await p; return "ok"; } catch (e) { return (e as { code?: string }).code ?? `other:${(e as Error).message}`; } };
export const OWNER = actor("owner", "owner-1"), MANAGER = actor("manager", "mgr-1"), SALES = actor("sales", "sales-1"), EMP = actor("employee", "emp-1"), GUEST = actor("guest", "guest-1"), OTHER = actor("owner", "owner-2", T2);

/** Fake ports: partner "p1" and referral link "l1" exist in tenant one only. The fake records what the portal asked for, so tests can see the scoping. */
export function fakePorts() {
  const calls: string[] = [], sent: { tenantId: string; linkId: string; accessId: string; referredName: string; referredEmail: string }[] = [];
  const ports: PortalPorts = {
    async subjectName(t, kind, id) { return t === T1 && ((kind === "partner" && id === "p1") || (kind === "referrer" && id === "l1")) ? (kind === "partner" ? "Agencia Uno" : "María Gómez") : null; },
    async subjects(t, kind) { return t === T1 ? [{ id: kind === "partner" ? "p1" : "l1", name: "x" }] : []; },
    async partner(t, id) { calls.push(`partner:${t}:${id}`); return t === T1 && id === "p1" ? { name: "Agencia Uno", tier: "gold", status: "active", currency: "USD", commissionBps: 2000, activeClients: 2, mrrCents: 200_000, openDeals: 1, clients: [{ name: "Cliente", plan: "Pro", status: "active", mrrCents: 100_000 }], deals: [], commissions: [], owed: { accruedCents: 1, approvedCents: 2, paidCents: 3 } } : null; },
    async referrer(t, id) { calls.push(`referrer:${t}:${id}`); return t === T1 && id === "l1" ? { name: "María Gómez", code: "maria", active: true, currency: "USD", counts: { submitted: 1, qualified: 0, converted: 0, rejected: 0 }, referrals: [{ referredName: "Ana", status: "submitted", createdAt: START }], rewards: [], owed: { pendingCents: 0, approvedCents: 0, paidCents: 0 } } : null; },
    async submit(t, linkId, accessId, i) {
      if (i.referredEmail === "dup@x.test") throw new PortalError("invalid_state", "This person was already referred.");
      sent.push({ tenantId: t, linkId, accessId, ...i });
    },
  };
  return { ports, calls, sent };
}
export function memorySink() {
  const events: SinkEvent[] = [];
  const sink: ActivitySink = {
    async record(_c, e) { events.push(e); return { ok: true, duplicate: false, event: {} as never }; },
    async recordStrict(_c, e) { events.push(e); return { duplicate: false, event: {} as never }; },
  };
  return { sink, events };
}
export interface Harness { svc: PortalService; clock: { t: number }; store: PortalStore; events: SinkEvent[]; sent: ReturnType<typeof fakePorts>["sent"]; calls: string[] }
export function setup(o: { store?: PortalStore } = {}): Harness {
  const clock = { t: START }, m = memorySink(), f = fakePorts(), salt = crypto.randomUUID().slice(0, 8); let n = 0;
  const store = o.store ?? createMemoryPortalStore();
  const svc = createPortalService({ store, ports: f.ports, newId: () => `id${salt}${String(++n).padStart(6, "0")}`, now: () => clock.t, activity: m.sink });
  return { svc, clock, store, events: m.events, sent: f.sent, calls: f.calls };
}
export const partnerLink = (h: Harness, a = OWNER, over: Record<string, unknown> = {}) => h.svc.access.create(a, { kind: "partner", subjectId: "p1", ...over });
export const referrerLink = (h: Harness, a = OWNER, over: Record<string, unknown> = {}) => h.svc.access.create(a, { kind: "referrer", subjectId: "l1", ...over });
