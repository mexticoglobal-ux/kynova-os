import { describe, expect, it } from "vitest";
import { parseToken } from "../../../src/modules/portal/compute";
import { DAILY_SUBMISSIONS } from "../../../src/modules/portal/domain";
import { DAY, EMP, GUEST, MANAGER, OTHER, OWNER, Q, SALES, T1, code, partnerLink, referrerLink, setup } from "./helpers";

describe("creating links", () => {
  it("returns the secret once, stores only its hash and never exposes it in lists", async () => {
    const h = setup(), r = await partnerLink(h);
    expect(r.token.startsWith(`${T1}.`)).toBe(true); expect(r.path).toBe(`/portal/${r.token}`); expect(r.access.state).toBe("active");
    expect(JSON.stringify(r.access)).not.toContain(r.token.split(".")[1]!); expect((r.access as unknown as { tokenHash: string }).tokenHash).not.toContain(r.token.split(".")[1]!);
    const list = await h.svc.access.list(OWNER, Q()); expect(JSON.stringify(list)).not.toContain(r.token.split(".")[1]!); expect(list.items[0]!.tokenHint).toBe(r.token.slice(-4));
    expect(JSON.stringify(h.events)).not.toContain(r.token.split(".")[1]!);
  });
  it("two links never share a secret", async () => {
    const h = setup(), a = await partnerLink(h), b = await partnerLink(h); expect(a.token).not.toBe(b.token);
  });
  it("only an existing partner or referral link of this company can get a portal", async () => {
    const h = setup(); expect(await code(h.svc.access.create(OWNER, { kind: "partner", subjectId: "nope" }))).toBe("not_found");
    expect(await code(h.svc.access.create(OTHER, { kind: "partner", subjectId: "p1" }))).toBe("not_found");
    expect(await code(h.svc.access.create(OWNER, { kind: "partner", subjectId: "p1", expiresInDays: 0 }))).toBe("validation_failed");
    expect(await code(h.svc.access.create(OWNER, { kind: "partner", subjectId: "p1", expiresInDays: 400 }))).toBe("validation_failed");
  });
  it("roles: managers manage, sales only view, others are refused; tenants are separate", async () => {
    const h = setup(); expect(await code(partnerLink(h, MANAGER))).toBe("ok"); expect(await code(partnerLink(h, SALES))).toBe("forbidden");
    expect(await code(h.svc.access.list(SALES, Q()))).toBe("ok"); expect(await code(h.svc.access.list(EMP, Q()))).toBe("forbidden"); expect(await code(h.svc.access.list(GUEST, Q()))).toBe("forbidden");
    expect((await h.svc.access.list(OTHER, Q())).items).toEqual([]);
  });
});

describe("opening a link", () => {
  it("shows the partner view and counts the opening", async () => {
    const h = setup(), r = await partnerLink(h), v = await h.svc.portal.view(r.token);
    expect(v.kind).toBe("partner"); expect(v.kind === "partner" && v.commissionBps).toBe(2000);
    expect((await h.svc.access.list(OWNER, Q())).items[0]!.useCount).toBe(1);
  });
  it("always answers the same not_found: malformed, unknown, wrong tenant, tampered secret, revoked, expired", async () => {
    const h = setup(), r = await partnerLink(h, OWNER, { expiresInDays: 1 }), [tenant, secret] = r.token.split(".") as [string, string];
    for (const bad of ["", "abc", "x.y", `${tenant}.`, `${tenant}.${secret.slice(0, -1)}A`, `other-tenant.${secret}`, "a".repeat(300), `${tenant}.${secret}!`]) expect(await code(h.svc.portal.view(bad)), bad).toBe("not_found");
    expect(parseToken(r.token)).toEqual({ tenantId: tenant, secret });
    h.clock.t += 2 * DAY; expect(await code(h.svc.portal.view(r.token))).toBe("not_found");
    h.clock.t -= 2 * DAY; await h.svc.access.revoke(OWNER, r.access.id); expect(await code(h.svc.portal.view(r.token))).toBe("not_found");
    expect(await code(h.svc.access.revoke(OWNER, r.access.id))).toBe("invalid_state");
  });
  it("asks the ports only for the subject of the link, in the tenant of the link", async () => {
    const h = setup(), a = await partnerLink(h), b = await referrerLink(h); await h.svc.portal.view(a.token); await h.svc.portal.view(b.token);
    expect(h.calls).toEqual([`partner:${T1}:p1`, `referrer:${T1}:l1`]);
  });
});

describe("sending referrals from the portal", () => {
  it("a referrer sends referrals and the daily cap holds, then resets the next day", async () => {
    const h = setup(), r = await referrerLink(h);
    for (let i = 0; i < DAILY_SUBMISSIONS; i++) await h.svc.portal.submit(r.token, { referredName: `Persona ${i}`, referredEmail: `p${i}@x.test` });
    expect(h.sent).toHaveLength(DAILY_SUBMISSIONS); expect(h.sent[0]).toMatchObject({ tenantId: T1, linkId: "l1", accessId: r.access.id });
    expect(await code(h.svc.portal.submit(r.token, { referredName: "Extra", referredEmail: "extra@x.test" }))).toBe("limit_exceeded");
    const v = await h.svc.portal.view(r.token); expect(v.kind === "referrer" && v.canSubmit).toBe(false);
    h.clock.t += DAY; expect(await code(h.svc.portal.submit(r.token, { referredName: "Extra", referredEmail: "extra@x.test" }))).toBe("ok");
  });
  it("a refused referral does not use up the cap; a partner link cannot send; bad bodies are rejected", async () => {
    const h = setup(), r = await referrerLink(h), p = await partnerLink(h);
    expect(await code(h.svc.portal.submit(r.token, { referredName: "Dup", referredEmail: "dup@x.test" }))).toBe("invalid_state");
    expect((await h.svc.portal.submit(r.token, { referredName: "Ok", referredEmail: "ok@x.test" })).remainingToday).toBe(DAILY_SUBMISSIONS - 1);
    expect(await code(h.svc.portal.submit(p.token, { referredName: "Ok", referredEmail: "ok2@x.test" }))).toBe("forbidden");
    expect(await code(h.svc.portal.submit(r.token, { referredName: "", referredEmail: "bad" }))).toBe("validation_failed");
    expect(await code(h.svc.portal.submit(r.token, { referredName: "Ok", referredEmail: "ok3@x.test", linkId: "other" }))).toBe("validation_failed");
  });
  it("a revoked link cannot send", async () => {
    const h = setup(), r = await referrerLink(h); await h.svc.access.revoke(OWNER, r.access.id);
    expect(await code(h.svc.portal.submit(r.token, { referredName: "Ok", referredEmail: "ok@x.test" }))).toBe("not_found"); expect(h.sent).toHaveLength(0);
  });
});

describe("activity evidence", () => {
  it("creation, revocation and portal referrals leave events", async () => {
    const h = setup(), r = await referrerLink(h); await h.svc.portal.submit(r.token, { referredName: "Ok", referredEmail: "ok@x.test" }); await h.svc.access.revoke(OWNER, r.access.id);
    expect(h.events.map((e) => e.action)).toEqual(["portal.access.created", "portal.referral.submitted", "portal.access.revoked"]);
  });
});
