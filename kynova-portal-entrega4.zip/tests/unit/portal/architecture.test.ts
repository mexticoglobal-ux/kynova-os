import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES, canAccess } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { COLUMNS, TABLE } from "../../../src/modules/portal/columns";
import { PORTAL_DICTIONARIES } from "../../../src/modules/portal/i18n";
import { ARCHITECTURE_STATUS } from "../../../src/modules/portal/contracts";
import { CAPABILITIES, DEFAULT_CAPABILITIES } from "../../../src/modules/portal/domain";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => { try { return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; }); } catch { return []; } };
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "portal");
const badExcept = (skip: string, dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).filter((f) => !f.endsWith(skip)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const bad = (dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "portal"), join(SRC, "app", "(app)", "app", "portal")];
const strip = (s: string) => s.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");
const OTHERS = "crm|marketing|seo|ai-studio|finance|communications|billing|security|analytics|analytics-bi|mission-control|integrations|marketplace|partners|referrals";

describe("Portal module boundaries", () => {
  it("never touches Drizzle, database internals, kernel internals or other product modules (only server.ts composes Partners and Referrals); the Activity Engine only through its public index", () => {
    expect(badExcept("server.ts", [MOD], new RegExp(`drizzle-orm|platform/db|ai-kernel/|ai-employees/|platform/dashboard|components/dashboard|modules/(${OTHERS})`))).toEqual([]);
    expect(bad([MOD, ...UI], /platform\/activity\/(?!$)/)).toEqual([]);
  });
  it("only the store layer knows SQL; no payment host and no network call exist", () => {
    expect(files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f))).toEqual(["store-d1.ts"]);
    expect(files(MOD).filter((f) => /api\.stripe|api\.paypal|paypal\.com\/v|wise\.com|checkout\.stripe|docusign|maka/i.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
    expect(files(MOD).filter((f) => /(?<![.\w])fetch\(|XMLHttpRequest|new WebSocket|node:https?|node:net/.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
  });
  it("states plainly what it does not do", () => {
    expect(ARCHITECTURE_STATUS).toMatchObject({ access: "link_with_token", portal_login: "not_built", link_delivery: "not_connected", anonymous_referral_page: "not_built", partner_actions: "read_only", payouts: "simulated_only" });
  });
  it("UI uses the module's public interface only", () => {
    expect(bad(UI, new RegExp(`platform/db|drizzle|modules/portal/(store|columns|runtime|ai|server)|modules/(${OTHERS})|components/(${OTHERS})`))).toEqual([]);
  });
  it("frozen code does not know Portal; it joins through startup registration only", () => {
    const frozen = ["platform/db", "platform/auth", "platform/ai-kernel", "platform/ai-employees", "platform/dashboard", "platform/activity", ...OTHERS.split("|").map((m) => `modules/${m}`)].map((d) => join(SRC, d));
    expect(bad(frozen, /modules\/portal|components\/portal/)).toEqual([]);
    const ins = readFileSync(join(SRC, "instrumentation.ts"), "utf8");
    void ins;
  });
  it("keeps client components free of server-only imports", () => {
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThanOrEqual(3);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/portal$|modules\/portal\/(service|server|http|store|runtime|ai)/.test(i)))).toEqual([]);
  });
  it("is a module slug open to executives, sales, marketing and finance only", () => {
    expect(MODULES.filter((m) => m.slug === "portal")).toHaveLength(1); expect(readFileSync(join(MOD, "http.ts"), "utf8")).toContain('"portal"');
    expect(canAccess("owner", "portal")).toBe(true); expect(canAccess("finance", "portal")).toBe(true); expect(canAccess("employee", "portal")).toBe(false); expect(canAccess("guest", "portal")).toBe(false);
  });
});

describe("API surface: only /api/v1/portal/*", () => {
  const API = join(SRC, "app", "api", "v1", "portal");
  const routes = files(API).filter((f) => f.endsWith("route.ts")), admin = routes.filter((f) => !relative(API, f).startsWith("public"));
  it("every handler goes through portalRoute; every mutating verb enables CSRF checks", () => {
    expect(routes.length).toBeGreaterThanOrEqual(5);
    for (const f of admin) {
      const src = readFileSync(f, "utf8");
      for (const m of src.matchAll(/export const (GET|POST|PATCH|PUT|DELETE) = (\w+)/g)) {
        expect(m[2], `${relative(SRC, f)} ${m[1]}`).toBe("portalRoute");
        const decl = src.slice(src.indexOf(m[0])), next = decl.indexOf("\nexport const", 10), block = decl.slice(0, next === -1 ? decl.length : next);
        if (m[1] !== "GET") expect(block, `${relative(SRC, f)} ${m[1]}`).toContain("mutating: true"); else expect(block).not.toContain("mutating");
      }
    }
  });
  it("has no webhook, payment-provider or outbound endpoint", () => {
    expect(routes.filter((f) => /fetch\(/.test(readFileSync(f, "utf8")))).toEqual([]);
    expect(routes.map((f) => relative(API, f)).filter((r) => /webhook|stripe|paypal|wise|docusign/i.test(r))).toEqual([]);
  });
});

describe("public surface", () => {
  const API = join(SRC, "app", "api", "v1", "portal", "public"), pub = files(API).filter((f) => f.endsWith("route.ts"));
  it("public routes use the token wrapper only: no session, no cookie, no request to other hosts", () => {
    expect(pub.map((f) => relative(API, f)).sort()).toEqual(["me/route.ts", "referrals/route.ts"]);
    for (const f of pub) { const src = readFileSync(f, "utf8"); expect(src).toContain("portalPublicRoute"); expect(src).not.toMatch(/requireApiSession|cookies\(|fetch\(/); }
    const http = readFileSync(join(MOD, "http.ts"), "utf8"); expect(http).toMatch(/authorization/i); expect(http).toContain("Bearer");
  });
  it("the public page is never indexed and sends no referrer", () => {
    const page = readFileSync(join(SRC, "app", "(public)", "portal", "[token]", "page.tsx"), "utf8");
    expect(page).toContain("index: false"); expect(page).toContain('referrer: "no-referrer"'); expect(page).toContain("force-dynamic");
  });
  it("only server.ts meets Partners and Referrals; the rest of the module does not", () => {
    const users = files(MOD).filter((f) => /modules\/(partners|referrals)/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f));
    expect(users).toEqual(["server.ts"]);
  });
});

describe("pages", () => {
  it("has the admin page", () => {
    const base = join(SRC, "app", "(app)", "app", "portal"), pages = new Set(files(base).filter((f) => f.endsWith("page.tsx")).map((f) => relative(base, f).replace(/\/?page\.tsx$/, "")));
    expect([...pages].sort()).toEqual([""]);
  });
});

describe("migration 1600_portal.sql", () => {
  const sql = readFileSync(join(process.cwd(), "drizzle/migrations/1600_portal.sql"), "utf8");
  const tables = [...sql.matchAll(/CREATE TABLE `(pl_\w+)` \(([\s\S]*?)\n\);/g)];
  it("creates exactly the pl_access table and touches nothing else", () => {
    expect(tables).toHaveLength(1); expect(Object.values(TABLE).sort()).toEqual(tables.map((t) => t[1]).sort());
    expect(sql.replace(/^--.*$/gm, "")).not.toMatch(/ALTER TABLE|DROP TABLE|DROP INDEX|INSERT INTO|DELETE FROM/);
    for (const o of sql.matchAll(/CREATE (?:UNIQUE )?INDEX `(\w+)`/g)) expect(o[1]).toMatch(/^pl_/);
  });
  it("every table is tenant-owned with tenant-first indexes, frozen tenant and no deletes", () => {
    for (const [, name, body] of tables) {
      expect(body, name).toContain("`tenant_id` text NOT NULL"); expect(body, name).toContain("FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`)");
      for (const ix of sql.matchAll(new RegExp(`CREATE (?:UNIQUE )?INDEX \`\\w+\` ON \`${name}\` \\(([^)]*)\\)`, "g"))) expect(ix[1], name).toMatch(/^`tenant_id`/);
      expect(sql, name).toContain(`${name}_tenant_frozen`); expect(sql, name).toContain(`${name}_no_delete`);
    }
  });
  it("the database freezes the identity and the secret of a link and keeps only a hash", () => {
    expect(sql).toContain("pl_access_frozen"); expect(sql).toContain("pl_access_token_uq"); expect(sql).not.toMatch(/`token` text|`secret`/);
  });
  it("whitelists cover each kind and carry the tenant column; no raw secrets", () => {
    for (const k of Object.keys(TABLE) as (keyof typeof TABLE)[]) { expect(COLUMNS[k]).toContain("id"); expect(COLUMNS[k]).toContain("tenantId"); }
    expect(COLUMNS.access).not.toContain("token"); expect(COLUMNS.access).toContain("tokenHash");
  });
});

describe("capabilities and texts", () => {
  it("module access is the outer gate; default capabilities only narrow it", () => {
    for (const r of ROLES) { if (!canAccess(r, "portal")) expect(DEFAULT_CAPABILITIES[r].length, r).toBe(0); else expect(DEFAULT_CAPABILITIES[r].includes("view"), r).toBe(true); }
    expect(DEFAULT_CAPABILITIES.owner).toHaveLength(CAPABILITIES.length);
  });
  it("English and Spanish have the same keys and no empty text", () => {
    const en = PORTAL_DICTIONARIES.en as Record<string, string>, es = PORTAL_DICTIONARIES.es as Record<string, string>;
    expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort());
    for (const [k, v] of Object.entries(es)) expect(v.trim(), k).not.toBe("");
  });
});
