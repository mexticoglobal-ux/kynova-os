import { beforeAll, describe, expect, it } from "vitest";
import { getPartnersService, setPartnersStore, createMemoryPartnersStore } from "../../../src/modules/partners";
import { getReferralsService, setReferralsStore, createMemoryReferralsStore } from "../../../src/modules/referrals";
import { portalPorts } from "../../../src/modules/portal/server";

const T = "t-adapter", U = "t-other";
const A = { tenantId: T, userId: "u1", role: "owner" as const }, B = { tenantId: U, userId: "u2", role: "owner" as const };
let p1 = "", p2 = "", l1 = "", l2 = "";

beforeAll(async () => {
  setPartnersStore(createMemoryPartnersStore()); setReferralsStore(createMemoryReferralsStore());
  const ps = await getPartnersService(), rs = await getReferralsService();
  for (const a of [A, B]) { await ps.setup.initialize(a); await rs.setup.initialize(a); }
  const mk = async (slug: string, email: string) => {
    const p = await ps.partners.create(A, { slug, name: `Partner ${slug}`, kind: "agency", contactEmail: "private@x.test", notes: "internal note" });
    const inv = await ps.invitations.create(A, { partnerId: p.id, email }); await ps.invitations.accept(A, { code: inv.code });
    await ps.clients.create(A, { partnerId: p.id, name: `Cliente de ${slug}`, status: "active", mrrCents: 100_000 }); return p.id;
  };
  p1 = await mk("uno-agency", "a@x.test"); p2 = await mk("dos-agency", "b@x.test");
  l1 = (await rs.links.create(A, { slug: "ref-uno", referrerName: "Uno", referrerEmail: "uno@x.test" })).id; l2 = (await rs.links.create(A, { slug: "ref-dos", referrerName: "Dos" })).id;
  await rs.referrals.submit(A, { linkId: l1, referredName: "Persona Uno", referredEmail: "pu@x.test" }); await rs.referrals.submit(A, { linkId: l2, referredName: "Persona Dos", referredEmail: "pd@x.test" });
});

describe("portal ports over the real Partners and Referrals services", () => {
  it("a partner sees only its own clients and no internal data", async () => {
    const v = await portalPorts.partner(T, p1); const txt = JSON.stringify(v);
    expect(v?.clients.map((c) => c.name)).toEqual(["Cliente de uno-agency"]); expect(txt).not.toContain("dos-agency"); expect(txt).not.toContain("private@x.test"); expect(txt).not.toContain("internal note"); expect(txt).not.toContain(p2);
  });
  it("a referrer sees only its own referrals and never the referred emails", async () => {
    const v = await portalPorts.referrer(T, l1); const txt = JSON.stringify(v);
    expect(v?.referrals.map((r) => r.referredName)).toEqual(["Persona Uno"]); expect(txt).not.toContain("Persona Dos"); expect(txt).not.toContain("pu@x.test"); expect(txt).not.toContain("uno@x.test");
  });
  it("a subject of another company does not exist", async () => {
    expect(await portalPorts.partner(U, p1)).toBeNull(); expect(await portalPorts.referrer(U, l1)).toBeNull(); expect(await portalPorts.subjectName(U, "partner", p1)).toBeNull();
    expect(await portalPorts.subjectName(T, "partner", p1)).toBe("Partner uno-agency");
  });
  it("sending a referral lands in Referrals with the portal as the actor, and duplicates become a plain message", async () => {
    await portalPorts.submit(T, l1, "acc1", { referredName: "Nueva Persona", referredEmail: "nueva@x.test" });
    const rs = await getReferralsService(); expect((await rs.referrals.list(A, { limit: 50, linkId: l1 })).items.map((r) => r.referredName)).toContain("Nueva Persona");
    await expect(portalPorts.submit(T, l1, "acc1", { referredName: "Otra", referredEmail: "NUEVA@x.test" })).rejects.toMatchObject({ code: "invalid_state", message: "This person was already referred." });
  });
});
