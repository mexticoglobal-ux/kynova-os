import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES, canAccess } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { COLUMNS, TABLE } from "../../../src/modules/security/columns";
import { POLICIES, can } from "../../../src/modules/security/access";
import { SECURITY_DICTIONARIES } from "../../../src/modules/security/i18n";
import { ARCHITECTURE_STATUS, notConnectedMfa, notConnectedRevoker } from "../../../src/modules/security/contracts";
import { ALERT_STATUS, INCIDENT_STATUS, INTEGRITY_KINDS, KEY_STATUS, MFA_PROVIDERS, SEVERITY, SESSION_STATUS, THREAT_KINDS, THREAT_STATUS, TRUST } from "../../../src/modules/security/domain";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => { try { return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; }); } catch { return []; } };
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "security");
const bad = (dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "security"), join(SRC, "app", "(app)", "app", "security")];
const strip = (s: string) => s.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");

describe("Security module boundaries", () => {
  it("never touches Drizzle, database internals, kernel internals or other product modules", () => {
    expect(bad([MOD], /drizzle-orm|platform\/db|ai-kernel\/|ai-employees\/|platform\/dashboard|components\/dashboard|modules\/(marketing|seo|ai-studio|finance|communications|crm|billing)/)).toEqual([]);
  });
  it("only the store layer knows SQL; no provider host and no network call exist in the module", () => {
    expect(files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f))).toEqual(["store-d1.ts"]);
    expect(files(MOD).filter((f) => /api\.openai\.com|api\.anthropic\.com|authy\.com|twilio\.com|login\.microsoftonline\.com|accounts\.google\.com|webauthn\.io/.test(readFileSync(f, "utf8")))).toEqual([]);
    expect(files(MOD).filter((f) => /(?<![.\w])fetch\(|XMLHttpRequest|new WebSocket|node:https?|node:net/.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
  });
  it("second factors and session enforcement are contracts: default implementations are not connected", async () => {
    for (const k of MFA_PROVIDERS) expect(notConnectedMfa(k).kind).toBe(k);
    expect(await notConnectedRevoker.revoke({ sessionRef: "x", userId: "u" } as never)).toEqual({ enforced: false });
    expect(Object.values(ARCHITECTURE_STATUS).every((v) => /interface_only|registry_only|advisory_gate|contract_only|definitions_only/.test(String(v)))).toBe(true);
    expect([...MFA_PROVIDERS]).toEqual(["google_authenticator", "microsoft_authenticator", "authy", "passkeys", "webauthn"]);
  });
  it("UI uses the module's public interface only", () => {
    expect(bad(UI, /platform\/db|drizzle|modules\/security\/(store|columns|runtime|ai|server)|modules\/(crm|marketing|seo|finance|ai-studio|communications|billing)|components\/(crm|marketing|seo|finance|ai-studio|communications|billing)/)).toEqual([]);
  });
  it("frozen code does not know Security; it joins through startup registration only", () => {
    const frozen = ["platform/db", "platform/auth", "platform/ai-kernel", "platform/ai-employees", "platform/dashboard", "modules/crm", "modules/marketing", "modules/seo", "modules/ai-studio", "modules/finance", "modules/communications", "modules/billing", "components/communications", "components/dashboard", "components/crm", "components/marketing", "components/seo", "components/ai-studio", "components/finance", "components/billing"].map((d) => join(SRC, d));
    expect(bad(frozen, /modules\/security|components\/security/)).toEqual([]);
    const ins = readFileSync(join(SRC, "instrumentation.ts"), "utf8"); expect(ins).toContain("registerSecurityWidget"); expect(ins).toContain("registerSecurityEmployee");
  });
  it("registers exactly one widget: security-overview", () => {
    const w = readFileSync(join(SRC, "components", "security", "DashboardWidget.tsx"), "utf8");
    expect([...w.matchAll(/registerWidget</g)]).toHaveLength(1); expect(w).toContain('id: "security-overview"');
  });
  it("client components do not import server-only parts", () => {
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThanOrEqual(5);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/security$|modules\/security\/(service|server|http|store|runtime|ai)/.test(i)))).toEqual([]);
  });
  it("adds exactly one product module slug", () => {
    expect(MODULES).toHaveLength(27); expect(MODULES.filter((m) => m.slug === "security")).toHaveLength(1); expect(MODULES.find((m) => m.slug === "security")!.roles.sort()).toEqual(["administrator", "ceo", "owner", "super_admin"]);
    expect(readFileSync(join(MOD, "http.ts"), "utf8")).toContain('SECURITY_SLUG = "security"');
  });
});

describe("API surface: only /api/v1/security/*", () => {
  const API = join(SRC, "app", "api", "v1", "security");
  const routes = files(API).filter((f) => f.endsWith("route.ts") && !/security\/sessions\//.test(f));
  it("every handler goes through securityRoute; every mutating verb enables CSRF checks", () => {
    expect(routes.length).toBeGreaterThanOrEqual(50);
    for (const f of routes) {
      const src = readFileSync(f, "utf8");
      for (const m of src.matchAll(/export const (GET|POST|PATCH|PUT|DELETE) = (\w+)/g)) {
        expect(m[2], `${relative(SRC, f)} ${m[1]}`).toBe("securityRoute");
        const decl = src.slice(src.indexOf(m[0])), next = decl.indexOf("\nexport const", 10), block = decl.slice(0, next === -1 ? decl.length : next);
        if (m[1] !== "GET") expect(block, `${relative(SRC, f)} ${m[1]}`).toContain("mutating: true"); else expect(block).not.toContain("mutating");
      }
    }
  });
  it("there is no public, unauthenticated inbound endpoint and no outbound delivery", () => {
    expect(routes.filter((f) => !readFileSync(f, "utf8").includes("securityRoute"))).toEqual([]);
    expect(routes.filter((f) => /fetch\(/.test(readFileSync(f, "utf8")))).toEqual([]);
  });
  it("covers the 16 sections, the account actions and the eight Advisor functions", () => {
    const rel = new Set(routes.map((f) => relative(API, f).replace(/\/?route\.ts$/, "")));
    for (const p of ["policies", "roles", "permissions", "session-registry", "logins", "devices", "api-keys", "webhooks", "ip-rules", "alerts", "threats", "incidents", "audit", "recovery", "settings", "integrity", "session-registry/[id]/revoke", "api-keys/[id]/revoke", "ai/risks", "ai/alert", "ai/policies", "ai/incident", "ai/access", "ai/actions", "ai/audit", "ai/risk"]) expect(rel.has(p), p).toBe(true);
  });
});

describe("migration 0800_security.sql", () => {
  const sql = readFileSync(join(process.cwd(), "drizzle/migrations/0800_security.sql"), "utf8");
  const tables = [...sql.matchAll(/CREATE TABLE `(sec_\w+)` \(([\s\S]*?)\n\);/g)];
  it("creates exactly the 16 sec_* tables and touches nothing else", () => {
    expect(tables).toHaveLength(16);
    expect(Object.values(TABLE).sort()).toEqual(["sec_alerts", "sec_api_keys", "sec_audit_events", "sec_devices", "sec_incidents", "sec_integrity_checks", "sec_ip_rules", "sec_login_history", "sec_permissions", "sec_policies", "sec_recovery_codes", "sec_roles", "sec_security_settings", "sec_sessions", "sec_threats", "sec_webhooks"]);
    expect(Object.values(TABLE).sort()).toEqual(tables.map((t) => t[1]).sort());
    expect(sql.replace(/^--.*$/gm, "")).not.toMatch(/ALTER TABLE|DROP TABLE|DROP INDEX|REFERENCES `(crm|mkt|seo|ais|fin|com|bill)_|INSERT INTO|DELETE FROM/);
    for (const o of sql.matchAll(/CREATE (?:UNIQUE )?INDEX `(\w+)`/g)) expect(o[1]).toMatch(/^sec_/);
    for (const o of sql.matchAll(/CREATE TRIGGER (\w+)/g)) expect(o[1]).toMatch(/^sec_/);
  });
  it("every table is tenant-owned with cascade and tenant-first indexes", () => {
    for (const [, name, body] of tables) {
      expect(body, name).toContain("`tenant_id` text NOT NULL");
      expect(body, name).toContain("FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`)");
      for (const ix of sql.matchAll(new RegExp(`CREATE (?:UNIQUE )?INDEX \`\\w+\` ON \`${name}\` \\(([^)]*)\\)`, "g"))) expect(ix[1], name).toMatch(/^`tenant_id`/);
    }
  });
  it("the database enforces tenant freezing, append-only ledgers and https-only webhooks", () => {
    for (const t of Object.values(TABLE)) expect(sql, t).toContain(`${t}_tenant_frozen`);
    expect(sql).toMatch(/_immutable/); expect(sql).toMatch(/_no_delete/); expect(sql).toContain("LIKE 'https://%'"); expect(sql).toMatch(/length\(`key_hash`\) = 64/);
  });
  it("whitelists cover each kind and carry the tenant column; secrets have no plain column", () => {
    for (const k of Object.keys(TABLE) as (keyof typeof TABLE)[]) { expect(COLUMNS[k]).toContain("id"); expect(COLUMNS[k]).toContain("tenantId"); }
    const all = Object.values(COLUMNS).flat(); expect(all.filter((c) => /^(secret|password|token|apiKey)$/i.test(c))).toEqual([]);
  });
});

describe("permissions and texts", () => {
  it("module access is the outer gate; the policy table only narrows it", () => {
    for (const r of ROLES) {
      const levels = Object.values(POLICIES[r].levels);
      if (!canAccess(r, "security")) expect(levels.every((l) => l === "none"), r).toBe(true);
      else expect(levels.some((l) => l !== "none"), r).toBe(true);
    }
    expect(can("owner", "apikey", "manage")).toBe(true); expect(can("ceo", "apikey", "manage")).toBe(false); expect(can("ceo", "alert", "write")).toBe(true); expect(can("ceo", "recovery", "read")).toBe(false); expect(can("sales", "alert", "read")).toBe(false);
  });
  it("English and Spanish have the same keys, and every vocabulary used by the UI has texts", () => {
    const en = SECURITY_DICTIONARIES.en as Record<string, string>, es = SECURITY_DICTIONARIES.es as Record<string, string>;
    expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort());
    for (const k of SEVERITY) expect(en[`sev.${k}`], k).toBeDefined();
    for (const k of [...SESSION_STATUS, ...KEY_STATUS, ...ALERT_STATUS, ...INCIDENT_STATUS, ...THREAT_STATUS, ...TRUST]) expect(en[`st.${k}`], k).toBeDefined();
    for (const k of [...THREAT_KINDS, ...INTEGRITY_KINDS]) expect(en[`kind.${k}`], k).toBeDefined();
    for (const k of MFA_PROVIDERS) expect(en[`mfa.${k}`], k).toBeDefined();
    for (const [k, v] of Object.entries(es)) expect(v.trim(), k).not.toBe("");
  });
});
