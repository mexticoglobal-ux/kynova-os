import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { COLUMNS, TABLE } from "../../../src/modules/portal/columns";
import { createD1PortalStore } from "../../../src/modules/portal/store-d1";
import type { PortalStore } from "../../../src/modules/portal/store";
import type { Actor } from "../../../src/modules/portal/service";
import { createTestDb, newCompany, newUser } from "../db/helpers";
import { DAY, Q, code } from "../../unit/portal/helpers";

let t: Awaited<ReturnType<typeof createTestDb>>;
let store: PortalStore;
const snake = (s: string) => s.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
const refused = async (p: Promise<unknown>) => { try { await p; return "no error"; } catch { return "refused"; } };
const fresh = async (): Promise<Actor> => { const u = await newUser(t.db), c = await newCompany(t.db, u.id); return { tenantId: c.companyId, userId: u.id, role: "owner" }; };

beforeAll(async () => { t = await createTestDb(); store = createD1PortalStore(t.d1); }, 60_000);
afterAll(async () => { await t.dispose(); });

describe("schema contract", () => {
  it("every whitelisted column exists in the migration, and every column is whitelisted", async () => {
    for (const [kind, table] of Object.entries(TABLE)) {
      const info = (await t.d1.prepare(`PRAGMA table_info(${table})`).all<{ name: string }>()).results.map((c) => c.name).sort();
      expect(COLUMNS[kind as keyof typeof COLUMNS].map(snake).sort(), table).toEqual(info);
    }
  });
});

/** The fake ports only know subjects "p1" and "l1"; the rows use the real company id of each test. */
import { createPortalService } from "../../../src/modules/portal/service";
import { fakePorts } from "../../unit/portal/helpers";
const harness = async () => {
  const A = await fresh(), f = fakePorts(); let n = 0; const salt = crypto.randomUUID().slice(0, 8), clock = { t: Date.UTC(2026, 9, 20, 12) };
  const ports = { ...f.ports, subjectName: async (_t: string, kind: string, id: string) => ((kind === "partner" && id === "p1") || (kind === "referrer" && id === "l1") ? "Sujeto" : null), partner: async (_t: string, id: string) => f.ports.partner("tenant-one", id), referrer: async (_t: string, id: string) => f.ports.referrer("tenant-one", id) };
  const svc = createPortalService({ store, ports: ports as never, newId: () => `id${salt}${String(++n).padStart(6, "0")}`, now: () => clock.t });
  return { A, svc, clock, tenantId: A.tenantId };
};

describe("the service on D1", () => {
  it("creates, opens, caps, expires and revokes a link with real constraints", async () => {
    const { A, svc, clock } = await harness(), r = await svc.access.create(A, { kind: "referrer", subjectId: "l1", expiresInDays: 2 });
    expect((await svc.portal.view(r.token)).kind).toBe("referrer"); expect((await svc.access.list(A, Q())).items[0]!.useCount).toBe(1);
    expect((await svc.portal.submit(r.token, { referredName: "Ana", referredEmail: "ana@x.test" })).remainingToday).toBe(19);
    clock.t += 3 * DAY; expect(await code(svc.portal.view(r.token))).toBe("not_found");
    clock.t -= 3 * DAY; await svc.access.revoke(A, r.access.id); expect(await code(svc.portal.view(r.token))).toBe("not_found");
  });
  it("the database refuses what the service would never do", async () => {
    const { A, svc } = await harness(), B = await fresh(), r = await svc.access.create(A, { kind: "partner", subjectId: "p1" });
    expect(await refused(t.d1.prepare("UPDATE pl_access SET token_hash = 'x' WHERE id = ?").bind(r.access.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE pl_access SET subject_id = 'other' WHERE id = ?").bind(r.access.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE pl_access SET tenant_id = ? WHERE id = ?").bind(B.tenantId, r.access.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("DELETE FROM pl_access WHERE id = ?").bind(r.access.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE pl_access SET status = 'weird' WHERE id = ?").bind(r.access.id).run())).toBe("refused");
  });
  it("a link of one company cannot be opened with another company's id in the token", async () => {
    const a = await harness(), b = await harness(), r = await a.svc.access.create(a.A, { kind: "partner", subjectId: "p1" });
    const forged = `${b.tenantId}.${r.token.split(".")[1]}`; expect(await code(b.svc.portal.view(forged))).toBe("not_found");
  });
});
