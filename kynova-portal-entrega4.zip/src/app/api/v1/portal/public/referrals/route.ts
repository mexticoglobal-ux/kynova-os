import { portalPublicRoute } from "@/modules/portal/http";
import { ok } from "@/platform/auth/http";
import { readBody } from "@/modules/portal/http";
import { toWire } from "@/modules/portal/wire";

export const POST = portalPublicRoute(async (req, _c, { token, svc, rid }) => ok(toWire(await svc.portal.submit(token, await readBody(req))), rid, 201));
