import { portalPublicRoute } from "@/modules/portal/http";
import { ok } from "@/platform/auth/http";
import { toWire } from "@/modules/portal/wire";

export const GET = portalPublicRoute(async (_req, _c, { token, svc, rid }) => ok(toWire(await svc.portal.view(token)), rid));
