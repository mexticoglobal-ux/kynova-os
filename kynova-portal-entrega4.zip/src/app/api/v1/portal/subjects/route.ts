import { portalRoute, respond } from "@/modules/portal/http";

export const GET = portalRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.access.subjects(actor, req.nextUrl.searchParams.get("kind") === "referrer" ? "referrer" : "partner"), rid); });
