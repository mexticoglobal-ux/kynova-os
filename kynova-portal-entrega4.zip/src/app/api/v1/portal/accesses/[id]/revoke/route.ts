import { portalRoute, noContent, parseListQuery, readBody, respond } from "@/modules/portal/http";

type Ctx = { params: Promise<{ id: string }> };

export const POST = portalRoute<Ctx>(async (req, c, { actor, svc, rid }) => { const p = await c.params; return respond(await svc.access.revoke(actor, p.id), rid); }, { mutating: true });
