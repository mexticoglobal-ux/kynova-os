import { portalRoute, noContent, parseListQuery, readBody, respond } from "@/modules/portal/http";

export const GET = portalRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.access.list(actor, parseListQuery(req)), rid); });
export const POST = portalRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.access.create(actor, await readBody(req)), rid, 201); }, { mutating: true });
