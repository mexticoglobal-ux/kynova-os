import { portalRoute, noContent, parseListQuery, readBody, respond } from "@/modules/portal/http";

export const GET = portalRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.summary(actor), rid); });
