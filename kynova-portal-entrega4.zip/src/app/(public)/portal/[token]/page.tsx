import { headers } from "next/headers";
import { notFound } from "next/navigation";
import { PortalI18n } from "@/components/portal/I18n";
import SubmitReferral from "@/components/portal/SubmitReferral";
import { K } from "@/components/portal/helpers";
import { Card, Empty, Stat } from "@/components/portal/ui";
import { StatusPill, Table, fmtMoney } from "@/components/portal/view";
import { PORTAL_DICTIONARIES, getPortalService, isPortalError, portalLocale, tr } from "@/modules/portal";

export const dynamic = "force-dynamic";
/** A private link: never indexed, never leaked through the Referer header. */
export const metadata = { title: "Portal", robots: { index: false, follow: false }, referrer: "no-referrer" as const };

export default async function Page({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params, locale = portalLocale((await headers()).get("accept-language")?.slice(0, 2));
  const t = (k: Parameters<typeof tr>[1], v?: Record<string, string | number>) => tr(locale, k, v);
  let v; try { v = await (await getPortalService()).portal.view(decodeURIComponent(token)); } catch (e) { if (isPortalError(e) && e.code === "not_found") notFound(); throw e; }
  const money = (c: number) => fmtMoney(c, v.currency, locale), date = (ms: number) => new Intl.DateTimeFormat(locale, { dateStyle: "medium", timeZone: "UTC" }).format(ms);
  return (
    <PortalI18n dict={PORTAL_DICTIONARIES[locale]} locale={locale}>
      <main className="mx-auto w-full max-w-4xl p-4 sm:p-8">
        <h1 className="mb-1 text-xl font-semibold">{v.name}</h1>
        <p className="mb-5 text-sm text-muted">{v.kind === "partner" ? t("pub.partnerIntro") : t("pub.referrerIntro", { code: v.code })}</p>
        {v.kind === "partner" ? (
          <>
            <dl className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Stat label={t("pub.tier")} value={t(K(`tier.${v.tier}`))} /><Stat label={t("pub.rate")} value={v.commissionBps === null ? "—" : `${v.commissionBps / 100}%`} /><Stat label={t("pub.clients")} value={v.activeClients} /><Stat label={t("pub.mrr")} value={money(v.mrrCents)} />
              <Stat label={t("pub.accrued")} value={money(v.owed.accruedCents)} /><Stat label={t("pub.approved")} value={money(v.owed.approvedCents)} /><Stat label={t("pub.paid")} value={money(v.owed.paidCents)} /><Stat label={t("pub.deals")} value={v.openDeals} />
            </dl>
            <Card title={t("pub.clientsTitle")}>{v.clients.length === 0 ? <Empty>{t("common.noResults")}</Empty> : <Table right={[3]} head={[t("common.name"), t("pub.plan"), t("common.status"), t("pub.mrr")]} rows={v.clients.map((c, i) => ({ key: String(i), cells: [c.name, c.plan || "—", <StatusPill key="s" status={c.status} label={t(K(`cst.${c.status}`))} />, money(c.mrrCents)] }))} />}</Card>
            <Card title={t("pub.dealsTitle")} className="mt-4">{v.deals.length === 0 ? <Empty>{t("common.noResults")}</Empty> : <Table right={[2]} head={[t("pub.client"), t("pub.stage"), t("pub.value"), t("pub.until")]} rows={v.deals.map((d, i) => ({ key: String(i), cells: [d.clientName, <StatusPill key="s" status={d.stage} label={t(K(`dst.${d.stage}`))} />, money(d.valueCents), date(d.expiresAt)] }))} />}</Card>
            <Card title={t("pub.commissionsTitle")} className="mt-4">{v.commissions.length === 0 ? <Empty>{t("common.noResults")}</Empty> : <Table right={[1]} head={[t("pub.period"), t("pub.amount"), t("common.status")]} rows={v.commissions.map((c, i) => ({ key: String(i), cells: [c.period, money(c.amountCents), <StatusPill key="s" status={c.status} label={t(K(`cmst.${c.status}`))} />] }))} />}<p className="mt-2 text-xs text-muted">{t("pub.simulated")}</p></Card>
          </>
        ) : (
          <>
            <dl className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Stat label={t("pub.sent")} value={v.counts.submitted + v.counts.qualified} /><Stat label={t("pub.converted")} value={v.counts.converted} /><Stat label={t("pub.pending")} value={money(v.owed.pendingCents)} /><Stat label={t("pub.approved")} value={money(v.owed.approvedCents)} />
              <Stat label={t("pub.paid")} value={money(v.owed.paidCents)} />
            </dl>
            {v.canSubmit ? <Card title={t("sub.title")}><SubmitReferral token={decodeURIComponent(token)} remaining={v.remainingToday} /></Card> : <Empty>{v.active ? t("sub.limit") : t("sub.inactive")}</Empty>}
            <Card title={t("pub.referralsTitle")} className="mt-4">{v.referrals.length === 0 ? <Empty>{t("common.noResults")}</Empty> : <Table head={[t("sub.name"), t("common.status"), t("pub.date")]} rows={v.referrals.map((r, i) => ({ key: String(i), cells: [r.referredName, <StatusPill key="s" status={r.status} label={t(K(`rst.${r.status}`))} />, date(r.createdAt)] }))} />}</Card>
            <Card title={t("pub.rewardsTitle")} className="mt-4">{v.rewards.length === 0 ? <Empty>{t("common.noResults")}</Empty> : <Table right={[0]} head={[t("pub.amount"), t("common.status"), t("pub.date")]} rows={v.rewards.map((r, i) => ({ key: String(i), cells: [money(r.amountCents), <StatusPill key="s" status={r.status} label={t(K(`wst.${r.status}`))} />, date(r.createdAt)] }))} />}<p className="mt-2 text-xs text-muted">{t("pub.simulated")}</p></Card>
          </>
        )}
        <p className="mt-6 text-xs text-muted">{t("pub.private")}</p>
      </main>
    </PortalI18n>
  );
}
