import { PortalI18n } from "@/components/portal/I18n";
import { portalContext } from "@/components/portal/context";
import { PORTAL_DICTIONARIES } from "@/modules/portal";

export default async function PortalLayout({ children }: { children: React.ReactNode }) {
  const { locale } = await portalContext();
  return (
    <PortalI18n dict={PORTAL_DICTIONARIES[locale]} locale={locale}>
      <div className="mx-auto w-full max-w-[96rem] p-4 sm:p-6 lg:p-8">{children}</div>
    </PortalI18n>
  );
}
