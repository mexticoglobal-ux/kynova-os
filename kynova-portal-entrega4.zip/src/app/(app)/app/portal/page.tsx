import ActionButton from "@/components/portal/ActionButton";
import CreateAccess from "@/components/portal/CreateAccess";
import LocalTime from "@/components/portal/LocalTime";
import { portalContext } from "@/components/portal/context";
import { K } from "@/components/portal/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/portal/ui";
import { StatusPill, Table } from "@/components/portal/view";
import { ACCESS_KINDS, ACCESS_STATUS, ARCHITECTURE_STATUS } from "@/modules/portal";

type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
export default async function Page({ searchParams }: SP) {
  const { actor, svc, t, locale, can } = await portalContext(), p = await searchParams;
  const q: Record<string, string> = { limit: "50" }; for (const k of ["cursor", "status", "kind"]) { const v = sp1(p[k]); if (v) q[k] = v; }
  const [s, r] = await Promise.all([svc.summary(actor), svc.access.list(actor, q)]), params = { status: sp1(p.status), kind: sp1(p.kind) }, mg = can("manage_access");
  return (
    <>
      <PageHeader title={t("title")} />
      <p role="note" className="mb-4 rounded-xl border border-line px-3 py-2 text-xs text-muted">{t("arch.notice")}</p>
      <dl className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label={t("dash.active")} value={s.active} sub={t("dash.of", { n: s.total })} /><Stat label={t("dash.partners")} value={s.partners} /><Stat label={t("dash.referrers")} value={s.referrers} /><Stat label={t("dash.revoked")} value={s.revoked + s.expired} />
      </dl>
      <FilterForm t={t} q={false} params={params} selects={[
        { name: "status", label: t("common.status"), options: ACCESS_STATUS.map((x) => ({ value: x, label: t(K(`ast.${x}`)) })) },
        { name: "kind", label: t("acc.kind"), options: ACCESS_KINDS.map((x) => ({ value: x, label: t(K(`kind.${x}`)) })) },
      ]} />
      {r.items.length === 0 ? <Empty>{t("acc.none")}</Empty> : (
        <Table head={[t("acc.label"), t("acc.kind"), t("acc.hint"), t("common.status"), t("acc.expires"), t("acc.lastUsed"), t("acc.uses"), ...(mg ? [t("common.actions")] : [])]} right={[6]} rows={r.items.map((x) => ({ key: x.id, cells: [
          x.label, t(K(`kind.${x.kind}`)), `…${x.tokenHint}`, <StatusPill key="s" status={x.state} label={t(K(`ast.${x.state}`))} />, <LocalTime key="e" ms={x.expiresAt} locale={locale} withTime={false} />,
          x.lastUsedAt ? <LocalTime key="l" ms={x.lastUsedAt} locale={locale} /> : "—", x.useCount,
          ...(mg ? [x.state === "revoked" ? "—" : <ActionButton key="a" path={`/accesses/${x.id}/revoke`} label="acc.revoke" tone="danger" confirm />] : [])] }))} />
      )}
      <Pager t={t} base="/app/portal" params={params} next={r.nextCursor} />
      {mg && <Card title={t("acc.new")} className="mt-5"><CreateAccess /></Card>}
      <h2 className="mb-2 mt-6 text-sm font-semibold">{t("arch.title")}</h2>
      <Table head={[t("arch.part"), t("common.status")]} rows={Object.entries(ARCHITECTURE_STATUS).map(([k, v]) => ({ key: k, cells: [t(K(`arch.${k}`)), <Pill key="v" tone={v === "not_applicable" ? "success" : "warning"}>{t(K(`arch.state.${v}`))}</Pill>] }))} />
    </>
  );
}
