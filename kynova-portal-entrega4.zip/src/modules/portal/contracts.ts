/** Honest status of every part that is not fully working yet; the UI and the docs read it. */
export const ARCHITECTURE_STATUS = {
  access: "link_with_token", portal_login: "not_built", link_delivery: "not_connected", anonymous_referral_page: "not_built", partner_actions: "read_only", payouts: "simulated_only", ai_actions: "not_applicable",
} as const;
