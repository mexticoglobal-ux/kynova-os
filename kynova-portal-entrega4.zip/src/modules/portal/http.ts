import { NextResponse, type NextRequest } from "next/server";
import { canAccess } from "@/config/modules";
import { isConfigError } from "@/platform/auth/errors";
import { assertSameOrigin, getAuthConfig, ok, problem, route } from "@/platform/auth/http";
import { requireApiSession } from "@/platform/auth/session";
import { isAiError } from "@/platform/ai-kernel";
import { isEmployeeError } from "@/platform/ai-employees";
import { listQuery } from "./domain";
import { PortalError, isPortalError } from "./errors";
import { getPortalService } from "./server";
import type { Actor, PortalService } from "./service";
import { fromWire, queryObject, toWire } from "./wire";

/** Portal has its own module slug in src/config/modules.ts. */
export const PORTAL_SLUG = "portal";
export interface PortalRouteContext { actor: Actor; rid: string; svc: PortalService }

/** Verified session, module access for the role, an active company, CSRF checks on mutations, and Portal/AI errors as problem+json. */
export function portalRoute<C = unknown>(fn: (req: NextRequest, ctx: C, a: PortalRouteContext) => Promise<NextResponse>, opts: { mutating?: boolean } = {}) {
  return route<C>(async (req, ctx, rid) => {
    try {
      if (opts.mutating) assertSameOrigin(req, getAuthConfig());
      const s = await requireApiSession();
      if (!s.tenantId) throw new PortalError("forbidden", "Select or create a company first.");
      if (!canAccess(s.role, PORTAL_SLUG)) throw new PortalError("forbidden", "Your role cannot use Portal.");
      const actor: Actor = { tenantId: s.tenantId, userId: s.user.id, role: s.role, requestId: rid };
      return await fn(req, ctx, { actor, rid, svc: await getPortalService() });
    } catch (e) {
      if (isPortalError(e)) return problem(e.code, e.status, e.message, rid, { ...(e.details?.fields ? { errors: e.details.fields } : {}), ...(e.details && !e.details.fields ? { details: e.details } : {}) });
      if (isEmployeeError(e)) return problem(e.code, e.status, e.message, rid, e.details ? { details: e.details } : {});
      if (isAiError(e)) return problem(e.code, e.status, e.message, rid, e.details ? { details: e.details } : {});
      if (isConfigError(e) && !(e as { name?: string }).name?.startsWith("Missing")) return problem("ai_unavailable", 503, "This service is temporarily unavailable.", rid);
      throw e;
    }
  });
}
export async function readBody(req: NextRequest): Promise<unknown> {
  if (!req.headers.get("content-type")?.toLowerCase().startsWith("application/json")) throw new PortalError("validation_failed", "Content-Type must be application/json.");
  const text = await req.text();
  if (!text.trim()) return {};
  try { const b = JSON.parse(text) as unknown; if (b === null || typeof b !== "object" || Array.isArray(b)) throw 0; return fromWire(b); }
  catch { throw new PortalError("validation_failed", "The body must be a JSON object."); }
}
export const parseListQuery = (req: NextRequest) => {
  const r = listQuery.safeParse(queryObject(req.nextUrl.searchParams));
  if (!r.success) throw new PortalError("validation_failed", "Invalid query.", { fields: r.error.issues.map((i) => ({ field: i.path.join("."), message: i.message })) });
  return r.data;
};
export const respond = (data: unknown, rid: string, status = 200) => ok(toWire(data), rid, status);
export const noContent = (rid: string) => new NextResponse(null, { status: 204, headers: { "X-Request-Id": rid, "Cache-Control": "no-store" } });

/**
 * Routes used by the outside person who holds a portal link. There is NO session and NO cookie here: the link's secret travels in the
 * Authorization header, so there is no ambient credential to forge (hence no CSRF check). Every failure to identify the link is one and the same 404.
 */
export interface PortalPublicContext { token: string; rid: string; svc: PortalService }
export function portalPublicRoute<C = unknown>(fn: (req: NextRequest, ctx: C, a: PortalPublicContext) => Promise<NextResponse>) {
  return route<C>(async (req, ctx, rid) => {
    try {
      const m = /^Bearer\s+(\S+)$/i.exec(req.headers.get("authorization") ?? "");
      if (!m) throw new PortalError("not_found", "This link is not valid.");
      return await fn(req, ctx, { token: m[1] as string, rid, svc: await getPortalService() });
    } catch (e) {
      if (isPortalError(e)) return problem(e.code, e.status, e.message, rid, { ...(e.details?.fields ? { errors: e.details.fields } : {}), ...(e.details && !e.details.fields ? { details: e.details } : {}) });
      if (isConfigError(e) && !(e as { name?: string }).name?.startsWith("Missing")) return problem("unavailable", 503, "This service is temporarily unavailable.", rid);
      throw e;
    }
  });
}
