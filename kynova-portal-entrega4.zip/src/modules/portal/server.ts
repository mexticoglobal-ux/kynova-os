import { getActivitySink } from "@/platform/activity";
import { getPartnersService, type Actor as PartnersActor } from "@/modules/partners";
import { getReferralsService, isReferralsError, type Actor as ReferralsActor } from "@/modules/referrals";
import { PortalError } from "./errors";
import { getPortalStore } from "./runtime";
import { createPortalService, type PortalPorts, type PortalService } from "./service";

/**
 * Composition root and the ONLY place where the Portal meets Partners and Referrals, through their public interfaces. The portal acts as a
 * system actor of one company; every call below is pinned to one partner or one referral link and returns only the fixed portal shapes.
 */
const sys = (tenantId: string, tag: string) => ({ tenantId, userId: `portal:${tag}`, role: "owner" as const });

export const portalPorts: PortalPorts = {
  async subjectName(tenantId, kind, id) {
    try {
      if (kind === "partner") return (await (await getPartnersService()).partners.get(sys(tenantId, "admin") as PartnersActor, id)).partner.name;
      return (await (await getReferralsService()).links.get(sys(tenantId, "admin") as ReferralsActor, id)).link.referrerName;
    } catch (e) { if ((e as { code?: string } | null)?.code === "not_found") return null; throw e; }
  },
  async subjects(tenantId, kind) {
    if (kind === "partner") return (await (await getPartnersService()).partners.list(sys(tenantId, "admin") as PartnersActor, { limit: 100, status: "active" })).items.map((p) => ({ id: p.id, name: p.name }));
    return (await (await getReferralsService()).links.list(sys(tenantId, "admin") as ReferralsActor, { limit: 100, status: "active" })).items.map((l) => ({ id: l.id, name: l.referrerName }));
  },
  async partner(tenantId, partnerId) {
    const svc = await getPartnersService(), a = sys(tenantId, "view") as PartnersActor;
    let d; try { d = await svc.partners.get(a, partnerId); } catch (e) { if ((e as { code?: string } | null)?.code === "not_found") return null; throw e; }
    const coms = await svc.commissions.list(a, { partnerId, limit: 12 }), c = d.commissions;
    return {
      name: d.partner.name, tier: d.partner.tier, status: d.partner.status, currency: (await svc.settings.get(a)).currency, commissionBps: d.rate.bps,
      activeClients: d.activeClients, mrrCents: d.mrrCents, openDeals: d.deals.filter((x) => (x.stage === "registered" || x.stage === "qualified") && !x.expired).length,
      clients: d.clients.slice(0, 50).map((x) => ({ name: x.name, plan: x.plan, status: x.status, mrrCents: x.mrrCents })),
      deals: d.deals.slice(0, 50).map((x) => ({ clientName: x.clientName, stage: x.stage, valueCents: x.valueCents, expiresAt: x.expiresAt })),
      commissions: coms.items.map((x) => ({ period: x.period, amountCents: x.amountCents, status: x.status })),
      owed: { accruedCents: c?.accruedCents ?? 0, approvedCents: c?.approvedCents ?? 0, paidCents: c?.paidCents ?? 0 },
    };
  },
  async referrer(tenantId, linkId) {
    const svc = await getReferralsService(), a = sys(tenantId, "view") as ReferralsActor;
    let d; try { d = await svc.links.get(a, linkId); } catch (e) { if ((e as { code?: string } | null)?.code === "not_found") return null; throw e; }
    const [rs, rw, st] = await Promise.all([svc.referrals.list(a, { linkId, limit: 50 }), svc.rewards.list(a, { linkId, limit: 50 }), svc.settings.get(a)]);
    return {
      name: d.link.referrerName, code: d.link.slug, active: d.link.status === "active", currency: st.currency, counts: d.referrals,
      referrals: rs.items.map((x) => ({ referredName: x.referredName, status: x.status, createdAt: x.createdAt })),
      rewards: rw.items.map((x) => ({ amountCents: x.amountCents, status: x.status, createdAt: x.createdAt })),
      owed: { pendingCents: d.rewards?.pendingCents ?? 0, approvedCents: d.rewards?.approvedCents ?? 0, paidCents: d.rewards?.paidCents ?? 0 },
    };
  },
  async submit(tenantId, linkId, accessId, input) {
    try { await (await getReferralsService()).referrals.submit(sys(tenantId, accessId) as ReferralsActor, { linkId, ...input }); }
    catch (e) {
      if (isReferralsError(e) && (e.code === "invalid_state" || e.code === "validation_failed")) throw new PortalError(e.code, e.code === "invalid_state" && e.details?.reason === "already_referred" ? "This person was already referred." : e.message);
      throw e;
    }
  },
};

export async function getPortalService(): Promise<PortalService> {
  return createPortalService({ store: await getPortalStore(), ports: portalPorts, newId: () => crypto.randomUUID().replace(/-/g, ""), activity: await getActivitySink("portal") });
}
