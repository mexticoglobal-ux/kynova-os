import { z } from "zod";
import { ROLES } from "@/config/roles";

export const ACCESS_KINDS = ["partner", "referrer"] as const;
export const ACCESS_STATUS = ["active", "revoked"] as const;
export const CAPABILITIES = ["view", "manage_access"] as const;
export type Capability = (typeof CAPABILITIES)[number];
export const DEFAULT_CAPABILITIES: Record<(typeof ROLES)[number], readonly Capability[]> = {
  super_admin: [...CAPABILITIES], owner: [...CAPABILITIES], administrator: [...CAPABILITIES], ceo: [...CAPABILITIES], manager: [...CAPABILITIES],
  marketing: ["view"], sales: ["view"], finance: ["view"], support: [], hr: [], employee: [], guest: [],
};
/** A portal link lives this many days unless the person chooses another (1-365). */
export const DEFAULT_ACCESS_DAYS = 90;
/** Referrals a referrer can send through the portal per UTC day. */
export const DAILY_SUBMISSIONS = 20;

const text = (max: number) => z.string().trim().max(max);
const id = z.string().trim().min(1).max(64);
export const accessInput = z.object({ kind: z.enum(ACCESS_KINDS), subjectId: id, label: text(80).default(""), expiresInDays: z.number().int().min(1).max(365).default(DEFAULT_ACCESS_DAYS) }).strict();
export const submitInput = z.object({ referredName: text(120).min(2), referredEmail: z.string().trim().email().max(120) }).strict();
export const listQuery = z.object({ status: text(20).optional(), kind: text(20).optional(), cursor: text(300).optional(), limit: z.coerce.number().int().min(1).max(100).default(25) }).strict();
export type ListQuery = z.output<typeof listQuery>;

type V<T extends readonly string[]> = T[number];
export interface AccessRecord {
  id: string; tenantId: string; kind: V<typeof ACCESS_KINDS>; subjectId: string; label: string; tokenHash: string; tokenHint: string; status: V<typeof ACCESS_STATUS>;
  expiresAt: number; lastUsedAt: number | null; useCount: number; submitDay: number; submitCount: number; createdBy: string; createdAt: number; updatedAt: number;
}

/** What the outside person is allowed to see. These are the ONLY shapes that leave the module through the portal. */
export interface PartnerView {
  kind: "partner"; name: string; tier: string; status: string; currency: string; commissionBps: number | null;
  activeClients: number; mrrCents: number; openDeals: number;
  clients: { name: string; plan: string; status: string; mrrCents: number }[];
  deals: { clientName: string; stage: string; valueCents: number; expiresAt: number }[];
  commissions: { period: string; amountCents: number; status: string }[];
  owed: { accruedCents: number; approvedCents: number; paidCents: number };
}
export interface ReferrerView {
  kind: "referrer"; name: string; code: string; active: boolean; currency: string; canSubmit: boolean; remainingToday: number;
  counts: { submitted: number; qualified: number; converted: number; rejected: number };
  referrals: { referredName: string; status: string; createdAt: number }[];
  rewards: { amountCents: number; status: string; createdAt: number }[];
  owed: { pendingCents: number; approvedCents: number; paidCents: number };
}
export type PortalView = PartnerView | ReferrerView;
