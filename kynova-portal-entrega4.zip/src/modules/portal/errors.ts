export type PortalErrorCode = "forbidden" | "not_found" | "validation_failed" | "conflict" | "duplicate" | "invalid_state" | "limit_exceeded" | "unavailable" | "ai_unavailable";
const STATUS: Record<PortalErrorCode, number> = { forbidden: 403, not_found: 404, validation_failed: 422, conflict: 409, duplicate: 409, invalid_state: 409, limit_exceeded: 403, unavailable: 503, ai_unavailable: 503 };
export class PortalError extends Error {
  readonly status: number;
  constructor(readonly code: PortalErrorCode, message: string, readonly details?: Record<string, unknown>) { super(message); this.name = "PortalError"; this.status = STATUS[code]; }
}
export const isPortalError = (e: unknown): e is PortalError => e instanceof PortalError || (typeof e === "object" && e !== null && (e as { name?: string }).name === "PortalError");
