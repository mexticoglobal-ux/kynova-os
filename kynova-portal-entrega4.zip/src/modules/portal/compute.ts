const b64url = (b: Uint8Array): string => btoa(String.fromCharCode(...b)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
export const sha256 = async (s: string): Promise<string> => [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)))].map((b) => b.toString(16).padStart(2, "0")).join("");
/** `<tenantId>.<192 random bits>`: the tenant id is not a secret (it only routes the lookup to one tenant); the second part is. Only the hash is stored. */
export const newToken = (tenantId: string): string => `${tenantId}.${b64url(crypto.getRandomValues(new Uint8Array(24)))}`;
export function parseToken(raw: string): { tenantId: string; secret: string } | null {
  const t = raw.trim(), i = t.indexOf(".");
  if (i < 1 || t.length > 200 || !/^[A-Za-z0-9._-]+$/.test(t)) return null;
  const secret = t.slice(i + 1);
  return secret.length >= 30 ? { tenantId: t.slice(0, i), secret } : null;
}
export const tokenHint = (token: string): string => token.slice(-4);
export const dayStart = (t: number): number => Math.floor(t / 86_400_000) * 86_400_000;
