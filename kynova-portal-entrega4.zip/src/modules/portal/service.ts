import type { z } from "zod";
import { canAccess } from "@/config/modules";
import type { Role } from "@/config/roles";
import type { ActivitySink, SinkEvent } from "@/platform/activity";
import { allows } from "./access";
import { dayStart, newToken, parseToken, sha256, tokenHint } from "./compute";
import { DAILY_SUBMISSIONS, accessInput, listQuery, submitInput, type AccessRecord, type Capability, type ListQuery, type PartnerView, type PortalView, type ReferrerView } from "./domain";
import { PortalError } from "./errors";
import type { Cond, Kind, KindMap, PortalStore } from "./store";

export interface Actor { tenantId: string; userId: string; role: Role; requestId?: string; agentId?: string }
export interface Page<T> { items: T[]; nextCursor: string | null }

/**
 * How the Portal reaches the data it shows. The Portal never imports another product module: the composition root (server.ts) supplies
 * these narrow ports, each of which can only return the fixed shapes in domain.ts for ONE partner or ONE referral link.
 */
export interface PortalPorts {
  /** Display name of the partner / referral link, or null when it does not exist in this company. */
  subjectName(tenantId: string, kind: AccessRecord["kind"], subjectId: string): Promise<string | null>;
  /** Choices for the admin form: partners or referral links of this company (at most 200). */
  subjects(tenantId: string, kind: AccessRecord["kind"]): Promise<{ id: string; name: string }[]>;
  partner(tenantId: string, partnerId: string): Promise<Omit<PartnerView, "kind"> | null>;
  referrer(tenantId: string, linkId: string): Promise<Omit<ReferrerView, "kind" | "canSubmit" | "remainingToday"> | null>;
  /** Records one referral on the link. Throws PortalError(invalid_state | validation_failed) with a plain message when it is refused. */
  submit(tenantId: string, linkId: string, accessId: string, input: { referredName: string; referredEmail: string }): Promise<void>;
}
export interface PortalDeps { store: PortalStore; ports: PortalPorts; newId: () => string; now?: () => number; activity?: ActivitySink }

const enc = (v: string | number, id: string): string => btoa(JSON.stringify({ v, id })).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
function dec(c: string | undefined): { value: string | number; id: string } | undefined {
  if (!c) return undefined;
  try { const o = JSON.parse(atob(c.replace(/-/g, "+").replace(/_/g, "/"))) as { v?: unknown; id?: unknown }; if ((typeof o.v === "string" || typeof o.v === "number") && typeof o.id === "string") return { value: o.v, id: o.id }; } catch { /* falls through */ }
  throw new PortalError("validation_failed", "Invalid cursor.");
}
export const eq = <K extends Kind>(col: keyof KindMap[K] & string, value: string | number | boolean): Cond<K> => ({ col, op: "eq", value });
const LIMIT = 5000;

export function createPortalService(deps: PortalDeps) {
  const { store, ports } = deps;
  const now = deps.now ?? Date.now;
  const parse = <S extends z.ZodType>(schema: S, input: unknown): z.output<S> => {
    const r = schema.safeParse(input);
    if (!r.success) throw new PortalError("validation_failed", "One or more fields are invalid.", { fields: r.error.issues.map((i) => ({ field: i.path.join(".") || "_", message: i.message })) });
    return r.data;
  };
  const state = (message: string, details?: Record<string, unknown>): never => { throw new PortalError("invalid_state", message, details); };
  const can = (a: Actor, c: Capability): boolean => canAccess(a.role, "portal") && allows(a.role, c) && (!a.agentId || c === "view");
  function need(a: Actor, c: Capability): void {
    if (can(a, c)) return;
    throw new PortalError("forbidden", a.agentId && c !== "view" ? "AI employees cannot manage portal access." : `Your role cannot do this in the Portal (${c}).`);
  }
  async function rec(tenantId: string, actorId: string, requestId: string | undefined, e: SinkEvent): Promise<void> {
    if (!deps.activity) return;
    await deps.activity.record({ tenantId, requestId }, { actorKind: "user", actorId, ...e });
  }
  const stateOf = (r: AccessRecord, t: number): "active" | "expired" | "revoked" => (r.status === "revoked" ? "revoked" : r.expiresAt <= t ? "expired" : "active");
  const view = (r: AccessRecord, t: number) => ({ ...r, state: stateOf(r, t) });

  /* ---------------- admin: who has a portal link ---------------- */
  const access = {
    async list(a: Actor, q: unknown = {}) {
      need(a, "view"); const p: ListQuery = parse(listQuery, q), t = now(), where: Cond<"access">[] = [];
      if (p.status) where.push(eq<"access">("status", p.status)); if (p.kind) where.push(eq<"access">("kind", p.kind));
      const rows = await store.query("access", a.tenantId, { where, limit: p.limit + 1, after: dec(p.cursor) });
      const page = rows.slice(0, p.limit), last = page.at(-1);
      return { items: page.map((r) => view(r, t)), nextCursor: rows.length > p.limit && last ? enc(last.createdAt, last.id) : null } satisfies Page<unknown>;
    },
    async subjects(a: Actor, kind: AccessRecord["kind"]) { need(a, "view"); return { items: await ports.subjects(a.tenantId, kind) }; },
    /** Creates a link for a partner or a referrer. The secret is returned ONCE; only its hash is stored. */
    async create(a: Actor, input: unknown) {
      need(a, "manage_access"); const i = parse(accessInput, input), name = await ports.subjectName(a.tenantId, i.kind, i.subjectId);
      if (!name) throw new PortalError("not_found", i.kind === "partner" ? "Partner not found." : "Referral link not found.");
      if ((await store.count("access", a.tenantId)) >= LIMIT) throw new PortalError("limit_exceeded", `You reached the limit of ${LIMIT} portal links.`);
      const t = now(), token = newToken(a.tenantId);
      const row: AccessRecord = { id: deps.newId(), tenantId: a.tenantId, kind: i.kind, subjectId: i.subjectId, label: i.label || name, tokenHash: await sha256(token), tokenHint: tokenHint(token), status: "active", expiresAt: t + i.expiresInDays * 86_400_000, lastUsedAt: null, useCount: 0, submitDay: 0, submitCount: 0, createdBy: a.userId, createdAt: t, updatedAt: t };
      await store.insert("access", row);
      await rec(a.tenantId, a.userId, a.requestId, { action: "portal.access.created", summary: `Portal link created for ${row.label}`, subjectKind: i.kind, subjectId: i.subjectId });
      return { access: view(row, t), token, path: `/portal/${token}` };
    },
    async revoke(a: Actor, id: string) {
      need(a, "manage_access"); const r = await store.get("access", a.tenantId, id); if (!r) throw new PortalError("not_found", "Portal link not found.");
      if (r.status === "revoked") state("This link is already revoked.", { reason: "already_revoked" });
      const t = now(), row = (await store.update("access", a.tenantId, id, { status: "revoked", updatedAt: t })) as AccessRecord;
      await rec(a.tenantId, a.userId, a.requestId, { action: "portal.access.revoked", summary: `Portal link revoked for ${r.label}`, subjectKind: r.kind, subjectId: r.subjectId });
      return view(row, t);
    },
  };

  /* ---------------- outside: someone holding a link ---------------- */
  /** One answer for every failure (unknown, malformed, revoked, expired): the outside person learns nothing about which links exist. */
  const nope = (): never => { throw new PortalError("not_found", "This link is not valid."); };
  async function resolve(raw: string): Promise<AccessRecord> {
    const tk = parseToken(raw); if (!tk) return nope();
    const r = (await store.query("access", tk.tenantId, { where: [eq<"access">("tokenHash", await sha256(`${tk.tenantId}.${tk.secret}`))], limit: 1 }))[0];
    if (!r || stateOf(r, now()) !== "active") return nope();
    return r;
  }
  const remaining = (r: AccessRecord, t: number): number => (r.submitDay === dayStart(t) ? Math.max(0, DAILY_SUBMISSIONS - r.submitCount) : DAILY_SUBMISSIONS);

  const portal = {
    async view(raw: string): Promise<PortalView> {
      const r = await resolve(raw), t = now();
      await store.update("access", r.tenantId, r.id, { lastUsedAt: t, useCount: r.useCount + 1, updatedAt: t });
      if (r.kind === "partner") { const v = await ports.partner(r.tenantId, r.subjectId); return v ? { kind: "partner", ...v } : nope(); }
      const v = await ports.referrer(r.tenantId, r.subjectId); if (!v) return nope();
      const left = remaining(r, t);
      return { kind: "referrer", ...v, canSubmit: v.active && left > 0, remainingToday: left };
    },
    async submit(raw: string, input: unknown): Promise<{ remainingToday: number }> {
      const r = await resolve(raw); if (r.kind !== "referrer") throw new PortalError("forbidden", "This link cannot send referrals.");
      const i = parse(submitInput, input), t = now(), today = dayStart(t), used = r.submitDay === today ? r.submitCount : 0;
      if (used >= DAILY_SUBMISSIONS) throw new PortalError("limit_exceeded", "You reached today's limit. Try again tomorrow.", { reason: "daily_limit" });
      await ports.submit(r.tenantId, r.subjectId, r.id, i);
      await store.update("access", r.tenantId, r.id, { submitDay: today, submitCount: used + 1, lastUsedAt: t, updatedAt: t });
      await rec(r.tenantId, `portal:${r.id}`, undefined, { action: "portal.referral.submitted", summary: `Referral sent through the portal by ${r.label}`, subjectKind: "link", subjectId: r.subjectId });
      return { remainingToday: DAILY_SUBMISSIONS - used - 1 };
    },
  };

  const permissions = { async mine(a: Actor) { return { role: a.role, capabilities: (["view", "manage_access"] as const).filter((c) => can(a, c)) }; } };
  async function summary(a: Actor) {
    need(a, "view"); const t = now(), all = await store.query("access", a.tenantId, { limit: LIMIT });
    const st = (s: string) => all.filter((r) => stateOf(r, t) === s).length;
    return { total: all.length, active: st("active"), expired: st("expired"), revoked: st("revoked"), partners: all.filter((r) => r.kind === "partner").length, referrers: all.filter((r) => r.kind === "referrer").length };
  }
  return { summary, permissions, access, portal };
}
export type PortalService = ReturnType<typeof createPortalService>;
