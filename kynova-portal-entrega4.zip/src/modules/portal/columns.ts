import type { Kind } from "./store";

export const TABLE: Record<Kind, string> = { access: "pl_access" };
export const KIND_LIST = Object.keys(TABLE) as Kind[];
/** Nothing in the Portal is deleted: an access is revoked. */
export const SOFT_DELETE: ReadonlySet<Kind> = new Set<Kind>();
export const REMOVABLE: ReadonlySet<Kind> = new Set<Kind>();
export const IMMUTABLE_KINDS: ReadonlySet<Kind> = new Set<Kind>();
/** Identity of an access never changes after insert (who it is for and its secret). The migration enforces the same with a trigger. */
export const FROZEN_COLS: Partial<Record<Kind, readonly string[]>> = { access: ["kind", "subjectId", "tokenHash"] };
export const BOOLEAN_COLS: ReadonlySet<string> = new Set();
export const JSON_COLS: ReadonlySet<string> = new Set();
export const COLUMNS: Record<Kind, readonly string[]> = {
  access: ["id", "tenantId", "kind", "subjectId", "label", "tokenHash", "tokenHint", "status", "expiresAt", "lastUsedAt", "useCount", "submitDay", "submitCount", "createdBy", "createdAt", "updatedAt"],
};
export const UNIQUE: Partial<Record<Kind, readonly (readonly string[])[]>> = { access: [["tokenHash"]] };
export const UNIQUE_WHEN: Partial<Record<Kind, readonly { cols: readonly string[]; col: string; in: readonly string[] }[]>> = {};
export const snake = (k: string) => k.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
export const camel = (k: string) => k.replace(/_([a-z0-9])/g, (_m, c: string) => c.toUpperCase());
