export interface ApiResult<T = unknown> { ok: boolean; status: number; data?: T; message?: string; fields?: { field: string; message: string }[] }
const snakeKey = (k: string) => k.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
/** Converts camelCase keys to the snake_case of the public API (deeply). Values are never touched. */
export function snake(v: unknown): unknown {
  if (Array.isArray(v)) return v.map(snake);
  if (v && typeof v === "object") return Object.fromEntries(Object.entries(v as Record<string, unknown>).map(([k, x]) => [snakeKey(k), snake(x)]));
  return v;
}
/** Browser-side calls to the Analytics API. Bodies are written in camelCase and converted; errors arrive as RFC 9457 problem documents. */
export async function portalCall<T = unknown>(method: "GET" | "POST" | "PATCH" | "PUT" | "DELETE", path: string, body?: unknown): Promise<ApiResult<T>> {
  try {
    const res = await fetch(`/api/v1/portal${path}`, { method, credentials: "same-origin", headers: body === undefined ? undefined : { "content-type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(snake(body)) });
    if (res.status === 204) return { ok: true, status: 204 };
    const json = (await res.json().catch(() => null)) as { data?: T; detail?: string; errors?: { field: string; message: string }[] } | null;
    return res.ok ? { ok: true, status: res.status, data: json?.data } : { ok: false, status: res.status, message: json?.detail, fields: json?.errors };
  } catch { return { ok: false, status: 0 }; }
}
