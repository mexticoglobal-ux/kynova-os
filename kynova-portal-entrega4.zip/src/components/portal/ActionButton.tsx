"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useT } from "./I18n";
import { Err, btn, primary, useRun } from "./Actions";
import { portalCall } from "./api";
import type { PortalKey } from "@/modules/portal/i18n";

/** A state-changing button (post, issue, approve, close, void...). `ask` collects a required reason or comment first. */
export default function ActionButton({ path, label, method = "POST", body, ask, confirm, tone = "plain", backTo }: { path: string; label: PortalKey; method?: "POST" | "DELETE" | "PATCH"; body?: Record<string, unknown>; ask?: { field: string; label: PortalKey; required?: boolean }; confirm?: boolean; tone?: "plain" | "primary" | "danger"; backTo?: string }) {
  const { t } = useT(), router = useRouter(), { busy, err, run } = useRun(), [open, setOpen] = useState(false), [text, setText] = useState("");
  const cls = tone === "primary" ? primary : `${btn} ${tone === "danger" ? "text-rose-700 dark:text-rose-300" : ""}`;
  const go = () => void run(() => portalCall(method, path, ask && text.trim() ? { ...body, [ask.field]: text.trim() } : body), () => { setOpen(false); setText(""); if (backTo) router.push(backTo); else router.refresh(); });
  return (
    <div className="grid gap-1.5">
      {!open ? <button type="button" className={cls} disabled={busy} onClick={() => { if (ask) setOpen(true); else if (!confirm || window.confirm(t("common.confirm"))) go(); }}>{t(label)}</button> : (
        <div className="flex flex-wrap items-center gap-2">
          <input aria-label={t(ask?.label ?? label)} placeholder={t(ask?.label ?? label)} className="min-w-48 rounded-lg border border-line bg-transparent px-3 py-1.5 text-sm" value={text} onChange={(e) => setText(e.target.value)} />
          <button type="button" className={cls} disabled={busy || (ask?.required !== false && !text.trim())} onClick={go}>{t(label)}</button>
          <button type="button" className={btn} onClick={() => setOpen(false)}>{t("common.cancel")}</button>
        </div>
      )}
      <Err err={err} />
    </div>
  );
}
