import { redirect } from "next/navigation";
import { requireModuleAccess } from "@/platform/auth/session";
import { getPortalService, portalLocale, tr, type Actor, type Capability, type PortalKey } from "@/modules/portal";

/** Server-side context of every Portal page: verified session, actor, service, translator and the capabilities of the role. The tenant always comes from the session. */
export async function portalContext() {
  const s = await requireModuleAccess("portal");
  if (!s.tenantId) redirect("/app/profile");
  const actor: Actor = { tenantId: s.tenantId, userId: s.user.id, role: s.role };
  const locale = portalLocale(s.user.locale), svc = await getPortalService(), mine = await svc.permissions.mine(actor).catch(() => ({ role: s.role, capabilities: [] as Capability[] }));
  const caps = new Set<string>(mine.capabilities);
  return {
    actor, locale, svc, role: s.role,
    t: (k: PortalKey, v?: Record<string, string | number>) => tr(locale, k, v),
    can: (p: Capability) => caps.has(p),
  };
}
export type PortalContext = Awaited<ReturnType<typeof portalContext>>;
