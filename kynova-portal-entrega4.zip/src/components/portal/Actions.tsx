"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useT } from "./I18n";
import { portalCall } from "./api";

export const btn = "rounded-lg border border-line px-3 py-1.5 text-sm hover:bg-ac/10 disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-ac2";
export const primary = "rounded-lg bg-ac px-3 py-1.5 text-sm font-medium text-white disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ac2";
export const field = "w-full rounded-lg border border-line bg-transparent px-3 py-2 text-sm focus-visible:outline-2 focus-visible:outline-ac2";
export function useRun() {
  const router = useRouter(), { t } = useT();
  const [busy, setBusy] = useState(false), [err, setErr] = useState<string | null>(null);
  async function run(fn: () => ReturnType<typeof portalCall>, after?: () => void) {
    setBusy(true); setErr(null);
    const r = await fn();
    setBusy(false);
    if (!r.ok) { setErr(r.status === 503 ? t("common.aiUnavailable") : r.message ?? t("common.error")); return false; }
    after ? after() : router.refresh();
    return true;
  }
  return { busy, err, run };
}
export const Err = ({ err }: { err: string | null }) => <p role="status" aria-live="polite" className="text-xs text-rose-700 dark:text-rose-300">{err}</p>;

export function DeleteButton({ path, backTo }: { path: string; backTo?: string }) {
  const { t } = useT(), router = useRouter(), { busy, err, run } = useRun();
  return (
    <div><button type="button" className={`${btn} text-rose-700 dark:text-rose-300`} disabled={busy} onClick={() => { if (window.confirm(t("common.confirmDelete"))) void run(() => portalCall("DELETE", path), backTo ? () => router.push(backTo) : undefined); }}>{t("common.delete")}</button><Err err={err} /></div>
  );
}

