"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useT } from "./I18n";
import { Err, primary } from "./Actions";
import { Labeled, input } from "./Form";

/** Sends a referral through the portal. The link's secret travels in the Authorization header (no cookies, no session). */
export default function SubmitReferral({ token, remaining }: { token: string; remaining: number }) {
  const { t } = useT(), router = useRouter(), [name, setName] = useState(""), [email, setEmail] = useState(""), [busy, setBusy] = useState(false), [err, setErr] = useState<string | null>(null), [done, setDone] = useState(false);
  return (
    <form className="grid gap-3 sm:grid-cols-2" onSubmit={async (e) => {
      e.preventDefault(); setBusy(true); setErr(null); setDone(false);
      try {
        const r = await fetch("/api/v1/portal/public/referrals", { method: "POST", headers: { "content-type": "application/json", authorization: `Bearer ${token}` }, body: JSON.stringify({ referred_name: name, referred_email: email }) });
        if (r.ok) { setName(""); setEmail(""); setDone(true); router.refresh(); } else { const b = (await r.json().catch(() => ({}))) as { detail?: string }; setErr(b.detail ?? t("common.error")); }
      } catch { setErr(t("common.error")); } finally { setBusy(false); }
    }}>
      <Labeled label={t("sub.name")}>{(id) => <input id={id} required minLength={2} maxLength={120} className={input} value={name} onChange={(e) => setName(e.target.value)} />}</Labeled>
      <Labeled label={t("common.email")}>{(id) => <input id={id} type="email" required maxLength={120} className={input} value={email} onChange={(e) => setEmail(e.target.value)} />}</Labeled>
      <div className="flex items-center gap-3 sm:col-span-2"><button className={primary} disabled={busy || remaining < 1}>{busy ? t("common.saving") : t("sub.send")}</button>{done && <span role="status" className="text-xs text-muted">{t("sub.sent")}</span>}<span className="text-xs text-muted">{t("sub.remaining", { n: remaining })}</span><Err err={err} /></div>
    </form>
  );
}
