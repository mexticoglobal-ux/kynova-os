"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useT } from "./I18n";
import { Err, primary, useRun } from "./Actions";
import { Labeled, input } from "./Form";
import { portalCall } from "./api";

interface Created { token: string; path: string }
/** Creates a portal link. The full link is shown ONCE (only its hash is stored), so the person must copy it now. */
export default function CreateAccess() {
  const { t } = useT(), router = useRouter(), { busy, err, run } = useRun();
  const [kind, setKind] = useState("partner"), [subjects, setSubjects] = useState<{ id: string; name: string }[]>([]), [subjectId, setSubjectId] = useState(""), [label, setLabel] = useState(""), [days, setDays] = useState("90"), [made, setMade] = useState<Created | null>(null), [copied, setCopied] = useState(false);
  useEffect(() => {
    let live = true; setSubjectId("");
    void portalCall<{ items: { id: string; name: string }[] }>("GET", `/subjects?kind=${kind}`).then((r) => { if (live && r.ok && r.data) setSubjects(r.data.items); });
    return () => { live = false; };
  }, [kind]);
  const url = made ? `${window.location.origin}${made.path}` : "";
  return (
    <div className="grid gap-3">
      <form className="grid gap-3 sm:grid-cols-2" onSubmit={(e) => {
        e.preventDefault(); setMade(null); setCopied(false); const n = Number(days);
        if (!subjectId || !Number.isInteger(n) || n < 1 || n > 365) return;
        void run(async () => { const r = await portalCall<Created>("POST", "/accesses", { kind, subjectId, label: label.trim() || undefined, expiresInDays: n }); if (r.ok && r.data) setMade(r.data); return r; }, () => router.refresh());
      }}>
        <Labeled label={t("acc.kind")}>{(id) => <select id={id} className={input} value={kind} onChange={(e) => setKind(e.target.value)}><option value="partner">{t("kind.partner")}</option><option value="referrer">{t("kind.referrer")}</option></select>}</Labeled>
        <Labeled label={t("acc.subject")}>{(id) => <select id={id} className={input} value={subjectId} onChange={(e) => setSubjectId(e.target.value)} required><option value="">—</option>{subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select>}</Labeled>
        <Labeled label={t("acc.label")}>{(id) => <input id={id} className={input} maxLength={80} value={label} onChange={(e) => setLabel(e.target.value)} />}</Labeled>
        <Labeled label={t("acc.days")} hint={t("acc.daysHint")}>{(id) => <input id={id} type="number" min={1} max={365} className={input} value={days} onChange={(e) => setDays(e.target.value)} />}</Labeled>
        <div className="flex items-center gap-3 sm:col-span-2"><button className={primary} disabled={busy || !subjectId}>{busy ? t("common.saving") : t("acc.create")}</button><Err err={err} /></div>
      </form>
      {made && (
        <div role="status" className="rounded-xl border border-line p-3">
          <p className="mb-2 text-sm font-medium">{t("acc.once")}</p>
          <code className="block break-all rounded-lg bg-black/5 px-3 py-2 text-xs dark:bg-white/10">{url}</code>
          <button type="button" className="mt-2 text-sm underline" onClick={() => { void navigator.clipboard?.writeText(url).then(() => setCopied(true)); }}>{copied ? t("acc.copied") : t("acc.copy")}</button>
          <p className="mt-2 text-xs text-muted">{t("acc.noEmail")}</p>
        </div>
      )}
    </div>
  );
}
