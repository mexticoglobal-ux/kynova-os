import { describe, expect, it } from "vitest";
import { BLUEPRINTS, SYSTEMS, type BlueprintDef, type SystemDef } from "../../../src/modules/blueprints/catalog";
import { OTHER, OWNER, VIEWER, code, harness } from "./helpers";

const ins = (id: string, extra: Record<string, unknown> = {}) => ({ blueprintId: id, ...extra });
const states = async (h: ReturnType<typeof harness>) => Object.fromEntries((await h.svc.current(OWNER))!.items.map((i) => [i.ref, i.state]));

describe("catalog", () => {
  it("has the twelve requested industries plus KYNOVA, all versioned, all supporting Bootstrap through the marketing system", () => {
    for (const id of ["kynova", "from_scratch", "real_estate", "ecommerce", "restaurant", "clinic", "hotel", "law_firm", "architecture", "marketing", "agency", "construction", "consulting"]) expect(BLUEPRINTS.find((b) => b.id === id), id).toBeTruthy();
    for (const b of BLUEPRINTS) { expect(b.version).toMatch(/^\d+\.\d+\.\d+$/); expect(b.systems.some((s) => s.id === "marketing_growth"), b.id).toBe(true); }
  });
  it("YouTube, Ecommerce, CRM, Academy, Marketplace, Finance and HR are independent systems, and none of them lives inside Marketing", () => {
    for (const id of ["youtube", "ecommerce", "sales_crm", "academy", "marketplace_system", "finance_system", "hr_system"]) expect(SYSTEMS.find((s) => s.id === id)?.status, id).toBe("planned");
    const mk = SYSTEMS.find((s) => s.id === "marketing_growth")!;
    expect(JSON.stringify(mk).toLowerCase()).not.toContain("youtube");
  });
});

describe("install", () => {
  it("installs a whole business in one call: employees, skills, objectives, schedule, KPIs, integrations, recommendations and a zero-investment growth plan", async () => {
    const h = harness({ plan: "business" }); const cur = (await h.svc.install(OWNER, ins("real_estate")))!;
    const kinds = new Set(cur.items.map((i) => i.kind));
    for (const k of ["employee", "skill", "objective", "agenda", "kpi", "integration", "recommendation", "growth_plan"]) expect(kinds.has(k as never), k).toBe(true);
    expect(h.f.calls).toContain("growthplan:leads"); expect(cur.health.status).toBe("healthy");
    expect(h.f.calls.some((c) => c.startsWith("agenda:content_manager:40320:obj"))).toBe(true); // 28 days, linked to its objective
  });
  it("Bootstrap never installs advertising: paid skills, goals and integrations are left optional", async () => {
    const h = harness({ plan: "business" }); await h.svc.install(OWNER, ins("restaurant"));
    expect(h.f.calls.filter((c) => /meta_ads|google_ads/.test(c))).toEqual([]);
    const s = await states(h); expect(s["marketing_growth:skill:s4"]).toBe("skipped_paid"); expect(s["marketing_growth:objective:o2"]).toBe("skipped_paid");
  });
  it("without Bootstrap it does not set a growth plan: the client chooses the investment", async () => {
    const h = harness({ plan: "business" }); await h.svc.install(OWNER, ins("restaurant", { bootstrap: false }));
    expect(h.f.calls.some((c) => c.startsWith("growthplan"))).toBe(false);
  });
  it("is honest when the plan does not include a member: skipped_plan, dependents follow, and the rest still installs", async () => {
    const h = harness({ plan: "business", notInPlan: ["seo_manager", "email_manager"] }); const cur = (await h.svc.install(OWNER, ins("from_scratch")))!;
    const s = await states(h); expect(s["employee:seo_manager"]).toBe("skipped_plan"); expect(s["marketing_growth:skill:s1"]).toBe("skipped_plan"); expect(s["employee:marketing_manager"]).toBe("applied");
    expect(cur.health.status).toBe("attention"); expect(cur.actions.map((a) => a.key)).toContain("upgrade_plan");
  });
  it("a failure on one item never aborts the install, and sync retries only what is not done", async () => {
    const h = harness({ plan: "business" }); h.f.failing.add("content_manager"); await h.svc.install(OWNER, ins("from_scratch"));
    expect((await states(h))["employee:content_manager"]).toBe("failed"); h.f.failing.clear(); h.f.calls.length = 0;
    await h.svc.sync(OWNER, {}); const s = await states(h);
    expect(s["employee:content_manager"]).toBe("applied"); expect(h.f.calls).not.toContain("activate:marketing_manager"); // applied items are never touched again
  });
  it("plans a Blueprint above the company's plan are refused, one Blueprint per company, and unknown ids are not found", async () => {
    const h = harness({ plan: "starter" });
    expect(await code(h.svc.install(OWNER, ins("ecommerce")))).toBe("plan_required");
    expect(await code(h.svc.install(OWNER, ins("nope_bp")))).toBe("not_found");
    expect(await code(h.svc.install(OWNER, ins("restaurant")))).toBe("ok"); expect(await code(h.svc.install(OWNER, ins("clinic")))).toBe("conflict");
  });
  it("only managers install; viewers can read; companies never see each other's install", async () => {
    const h = harness();
    expect(await code(h.svc.install(VIEWER, ins("restaurant")))).toBe("forbidden"); await h.svc.install(OWNER, ins("restaurant"));
    expect((await h.svc.current(VIEWER))?.version).toBe("1.0.0"); expect(await h.svc.current(OTHER)).toBeNull();
  });
  it("records the evidence in the Activity Engine", async () => {
    const h = harness(); await h.svc.install(OWNER, ins("restaurant")); expect(h.events.map((e) => e.action)).toContain("blueprints.install.completed");
  });
});

describe("versions", () => {
  const sys: SystemDef[] = [...SYSTEMS];
  const v = (version: string, extra: Partial<BlueprintDef> = {}): BlueprintDef => ({ ...BLUEPRINTS.find((b) => b.id === "restaurant")!, version, ...extra });
  it("a minor upgrade only ADDS: nothing existing is removed, rewritten or re-created", async () => {
    const v1 = v("1.0.0"), v11 = v("1.1.0", { kpis: [...(v1.kpis ?? []), { id: "k9", name: { es: "Nuevo", en: "New" }, unit: "count", since: "1.1.0" }] });
    const cat: BlueprintDef[] = [v1], hh = harness({ blueprints: cat, systems: sys, plan: "business" }); await hh.svc.install(OWNER, ins("restaurant")); const calls = hh.f.calls.length;
    cat[0] = v11;
    expect((await hh.svc.preview(OWNER)).newItems.map((i) => i.ref)).toEqual(["blueprint:kpi:k9"]);
    const cur = (await hh.svc.upgrade(OWNER, {}))!; expect(cur.version).toBe("1.1.0"); expect(cur.items.some((i) => i.ref === "blueprint:kpi:k9")).toBe(true); expect(hh.f.calls.length).toBe(calls);
    expect(await code(hh.svc.upgrade(OWNER, {}))).toBe("invalid_state");
  });
  it("a major upgrade needs explicit confirmation and is flagged as breaking", async () => {
    const cat: BlueprintDef[] = [v("1.0.0")], h = harness({ blueprints: cat, systems: sys, plan: "business" }); await h.svc.install(OWNER, ins("restaurant"));
    cat[0] = v("2.0.0", { kpis: [...(cat[0]!.kpis ?? []), { id: "k8", name: { es: "X", en: "X" }, unit: "count", since: "2.0.0" }] });
    expect((await h.svc.preview(OWNER)).breaking).toBe(true); expect((await h.svc.current(OWNER))?.upgrade).toMatchObject({ to: "2.0.0", breaking: true });
    expect(await code(h.svc.upgrade(OWNER, {}))).toBe("conflict"); expect(await code(h.svc.upgrade(OWNER, { confirm: true }))).toBe("ok");
  });
  it("a system that did not exist yet arrives later by sync, replacing its placeholder", async () => {
    const yt = SYSTEMS.find((s) => s.id === "youtube")!, live = [...SYSTEMS.filter((s) => s.id !== "youtube")] as SystemDef[];
    const planned: SystemDef[] = [...live, yt], bp: BlueprintDef = { ...BLUEPRINTS.find((b) => b.id === "from_scratch")!, systems: [{ id: "marketing_growth" }, { id: "youtube" }] };
    const systems = [...planned], h = harness({ blueprints: [bp], systems, plan: "business" }); await h.svc.install(OWNER, ins("from_scratch"));
    expect((await states(h))["system:youtube"]).toBe("unavailable");
    systems[systems.length - 1] = { ...yt, status: "available", employees: ["content_creator"], objectives: [{ id: "y1", employee: "content_creator", title: { es: "Primer video", en: "First video" }, priority: 2 }] };
    await h.svc.sync(OWNER, {}); const s = await states(h);
    expect(s["system:youtube"]).toBeUndefined(); expect(s["youtube:objective:y1"]).toBe("applied");
  });
});
