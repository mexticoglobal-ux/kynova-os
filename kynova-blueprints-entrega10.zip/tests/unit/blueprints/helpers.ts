import type { ActivitySink, SinkEvent } from "@/platform/activity";
import type { BlueprintDef, SystemDef } from "../../../src/modules/blueprints/catalog";
import { BLUEPRINTS, SYSTEMS } from "../../../src/modules/blueprints/catalog";
import { createBlueprintsService, type Actor, type BlueprintsPorts } from "../../../src/modules/blueprints/service";
import { createMemoryBlueprintsStore } from "../../../src/modules/blueprints/store-memory";

export const OWNER: Actor = { tenantId: "t1", userId: "u1", role: "owner" }, VIEWER: Actor = { tenantId: "t1", userId: "u2", role: "manager" }, OTHER: Actor = { tenantId: "t2", userId: "u3", role: "owner" };
export const code = async (p: Promise<unknown>) => { try { await p; return "ok"; } catch (e) { return (e as { code?: string }).code ?? `other:${(e as Error).message}`; } };
export interface Fx { plan: string | null; notInPlan: Set<string>; unavailable: Set<string>; failing: Set<string>; active: Set<string>; calls: string[] }
export function harness(o: { blueprints?: readonly BlueprintDef[]; systems?: readonly SystemDef[]; plan?: string | null; notInPlan?: string[] } = {}) {
  const f: Fx = { plan: o.plan === undefined ? "starter" : o.plan, notInPlan: new Set(o.notInPlan ?? []), unavailable: new Set(), failing: new Set(), active: new Set(), calls: [] };
  const events: (SinkEvent & { tenantId: string })[] = []; let n = 0;
  const ports: BlueprintsPorts = {
    async activate(_a, key) { f.calls.push(`activate:${key}`); if (f.failing.has(key)) throw new Error("boom"); if (f.unavailable.has(key)) return "unavailable"; if (f.notInPlan.has(key)) return "skipped_plan"; f.active.add(key); return "applied"; },
    async enableSkill(_a, e, s) { f.calls.push(`skill:${e}:${s}`); },
    async createObjective(_a, i) { f.calls.push(`objective:${i.employeeKey}`); return { id: `obj${++n}` }; },
    async createAgenda(_a, i) { f.calls.push(`agenda:${i.employeeKey}:${i.everyMinutes}:${i.objectiveId ?? "-"}`); return { id: `ag${++n}` }; },
    async growthPlan(_a, obj) { f.calls.push(`growthplan:${obj}`); },
    plan: async () => f.plan, activeEmployees: async () => [...f.active], employeeName: (k) => k,
  };
  const activity: ActivitySink = { async record(ctx, e) { events.push({ tenantId: ctx.tenantId, ...e }); return { ok: false, error: { code: "test", message: "captured" } }; }, async recordStrict() { throw new Error("captured"); } };
  const svc = createBlueprintsService({ store: createMemoryBlueprintsStore(), ports, newId: () => `id${++n}`, now: () => 1_800_000_000_000, activity, blueprints: o.blueprints ?? BLUEPRINTS, systems: o.systems ?? SYSTEMS });
  return { svc, f, events };
}
