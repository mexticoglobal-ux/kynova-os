# 35 · Blueprints + Industry Systems

Un **Blueprint instala un negocio completo**; el **Marketplace instala extensiones**. Módulo `src/modules/blueprints`, API `/api/v1/blueprints/*`, pantallas `/app/onboarding` ("¿Qué tipo de empresa tienes?"), `/app/blueprints` y una tarjeta en Mission Control.

## Qué es un Blueprint
Definición **declarativa** (datos, nunca código) en `catalog.ts`: id, nombre, industria, descripción, versión, autor, estado, plan mínimo (Starter/Business/Enterprise), dependencias, **AI Business Systems** que instala y sus propios elementos de industria: AI Employees, Skills, objetivos, calendario de trabajo (agenda programada, con aprobación), KPIs, integraciones sugeridas y recomendaciones.

Catálogo: KYNOVA (primer Blueprint oficial), Empresa desde cero, Inmobiliaria, Ecommerce, Restaurante, Clínica, Hotel, Abogado, Arquitectura, Marketing, Agencia, Constructora, Consultoría.

## AI Business Systems independientes
Un Blueprint compone sistemas. Hoy solo **Marketing & Growth** está construido. YouTube, Ecommerce, CRM & Ventas, Academy, Marketplace, Finanzas y RRHH están declarados como `planned`: el Blueprint deja un marcador "aún no disponible" y, cuando el sistema exista, `sync` instala sus elementos reales. **YouTube no vive dentro de Marketing.**

## Instalación (un paso)
`POST /blueprints/install` aplica todo y registra qué pasó con cada elemento: `applied`, `skipped_plan` (el plan no lo incluye; se reintenta al subir de plan), `skipped_paid` (publicidad, opcional), `unavailable` (sistema/miembro aún no existe), `failed` (se reintenta con `sync`). Un fallo nunca aborta la instalación. Usa los servicios públicos de Team, Workforce y Growth, así que sus reglas (plan, roles, aprobación) siguen vigentes.

## Bootstrap
Activo por defecto en todos los Blueprints: no se instala nada de publicidad (skills, objetivos, integraciones de pago) y se fija un plan de Growth con **inversión $0**. Sin Bootstrap no se fija plan: el cliente elige su inversión.

## Versiones y migraciones
Cada elemento declara `since`. Una actualización **solo agrega** lo nuevo: nunca borra ni reescribe lo existente (el cliente pudo cambiarlo). Una versión **mayor** exige confirmación explícita (`confirm`). `preview` muestra qué se agregará antes de aplicar.

## Mission Control
Tarjeta con Blueprint, versión, salud (% instalado, atención/ok), AI Employees activos y próximas recomendaciones. La salud también detecta empleados que se desactivaron después.

## Qué no hace todavía
KPIs: definidos, aún no medidos automáticamente. Integraciones (Shopify, Stripe, Meta, Google, MLS, DocuSign, Canva…): solo declaradas, nada conectado. Instalar desde el Marketplace y Blueprints propios: no construido. No hay dashboard propio por Blueprint (se usa el de Mission Control).

## Datos
`bp_installs` (migración 2000): una fila por empresa, `applied` en JSON, identidad congelada, sin DELETE.
