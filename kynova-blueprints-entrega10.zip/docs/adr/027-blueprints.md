# ADR 027 · Blueprint Engine

**Estado:** aceptado · **Fecha:** 2026-10-21

## Contexto
El cliente debe sentir que instala un negocio completo, no 40 módulos. Habrá cientos de Blueprints y AI Business Systems.

## Decisión
1. Blueprint = definición declarativa versionada que compone **AI Business Systems** independientes más elementos de industria. Blueprint ≠ Marketplace (extensiones).
2. Una sola instalación por empresa, registrada elemento por elemento con estados honestos; los servicios existentes (Team, Workforce, Growth) hacen el trabajo y conservan sus reglas.
3. Migraciones **aditivas**: nunca se borra ni reescribe; versión mayor requiere confirmación; sistemas futuros llegan por `sync`.
4. Bootstrap por defecto; la publicidad nunca se instala sola.
5. Sin proveedores ni integraciones reales: solo se declara el contrato.
6. Core sin cambios: se agregó el slug `blueprints` (config/modules.ts, plan Starter) y una tarjeta en el layout de Mission Control.

## Escala a 10,000 empresas
Sí: el catálogo es código compartido (no filas por empresa), cada empresa guarda una fila pequeña, la instalación es idempotente y reanudable, y agregar un Blueprint es agregar datos.

## Consecuencias
Próximos productos vendibles: Real Estate, YouTube, Ecommerce, Finanzas, CRM & Ventas como AI Business Systems que se activan en los Blueprints existentes mediante `sync`.
