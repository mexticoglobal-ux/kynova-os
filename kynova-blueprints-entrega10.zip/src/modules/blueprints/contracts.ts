/** What is and is not implemented in the Blueprint Engine. Shown as-is in the UI so nothing is presented as more than it is. */
export const ARCHITECTURE_STATUS = {
  catalog: "built_13_blueprints",
  one_click_install: "built",
  bootstrap_mode: "built",
  versioned_upgrades: "built_additive_only",
  mission_control_view: "built",
  ai_business_systems: "built_marketing_only",
  kpi_measurement: "declared_not_measured",
  automations: "built_scheduled_with_approval",
  marketplace_install: "not_built",
  integrations: "declared_not_connected",
  custom_blueprints: "not_built",
} as const;
