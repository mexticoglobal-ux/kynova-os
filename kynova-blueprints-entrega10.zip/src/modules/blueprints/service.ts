import { z } from "zod";
import type { Role } from "@/config/roles";
import type { ActivitySink, SinkEvent } from "@/platform/activity";
import { allows } from "./access";
import { BLUEPRINTS, BLUEPRINT_BY_ID, SYSTEM_BY_ID, emptyContent, type BlueprintDef, type Content, type L, type SystemDef } from "./catalog";
import { PLAN_RANK, cmpVersion, installInput, major, upgradeInput, type AppliedItem, type Capability, type InstallRecord, type ItemKind, type ItemState } from "./domain";
import { BlueprintsError } from "./errors";
import type { BlueprintsStore } from "./store";

export interface Actor { tenantId: string; userId: string; role: Role; requestId?: string }
/** What the installer may do on the company's behalf. Every port is an existing, already-approved capability; failures never abort the install. */
export interface BlueprintsPorts {
  /** Activates a roster member. `skipped_plan` = not in the company's plan; `unavailable` = no such member. */
  activate(a: Actor, key: string): Promise<"applied" | "skipped_plan" | "unavailable">;
  enableSkill(a: Actor, employeeKey: string, skillKey: string): Promise<void>;
  createObjective(a: Actor, i: { employeeKey: string; title: string; priority: number; metric: string }): Promise<{ id: string }>;
  createAgenda(a: Actor, i: { employeeKey: string; objectiveId: string | null; title: string; instruction: string; everyMinutes: number; priority: number }): Promise<{ id: string }>;
  /** Sets a Growth plan with zero investment (Bootstrap) when the company has none. Never invests. */
  growthPlan(a: Actor, objective: string): Promise<void>;
  plan(a: Actor): Promise<string | null>;
  /** Roster keys of the employees that are active right now. */
  activeEmployees(a: Actor): Promise<string[]>;
  employeeName(key: string): string;
}
export interface BlueprintsDeps { store: BlueprintsStore; ports: BlueprintsPorts; newId: () => string; now?: () => number; activity?: ActivitySink; blueprints?: readonly BlueprintDef[]; systems?: readonly SystemDef[] }
export type BlueprintsService = ReturnType<typeof createBlueprintsService>;

function parse<T extends z.ZodType>(schema: T, input: unknown): z.output<T> {
  const r = schema.safeParse(input);
  if (!r.success) throw new BlueprintsError("validation_failed", "The request is not valid.", { fields: r.error.issues.map((i) => ({ field: i.path.join("."), message: i.message })) });
  return r.data;
}
const localeInput = z.object({ locale: z.enum(["es", "en"]).default("es") });
interface Item { ref: string; kind: ItemKind; system: string; since: string; paid: boolean; name: L; data: Record<string, unknown> }
const t2 = (s: string): L => ({ es: s, en: s });

export function createBlueprintsService(deps: BlueprintsDeps) {
  const { store, ports } = deps, now = deps.now ?? Date.now, catalog = deps.blueprints ?? BLUEPRINTS;
  /** Read live on every call so a catalog update (new version, a system that has just been built) is seen without restarting. */
  const systems = { get: (id: string) => (deps.systems ?? [...SYSTEM_BY_ID.values()]).find((s) => s.id === id) };
  const byId = { get: (id: string) => catalog.find((b) => b.id === id) };
  const need = (a: Actor, c: Capability): void => { if (!allows(a.role, c)) throw new BlueprintsError("forbidden", "Your role cannot do this."); };
  const rec = async (a: Actor, e: SinkEvent): Promise<void> => {
    if (!deps.activity) return;
    await deps.activity.record({ tenantId: a.tenantId, ...(a.requestId ? { requestId: a.requestId } : {}) }, { module: "blueprints", source: "blueprints", actorKind: "user", actorId: a.userId, mode: "production", ...e });
  };
  const installOf = async (a: Actor): Promise<InstallRecord | null> => (await store.query("install", a.tenantId, { limit: 1 }))[0] ?? null;
  const defOf = (id: string): BlueprintDef => { const d = byId.get(id); if (!d) throw new BlueprintsError("not_found", "Blueprint not found."); return d; };

  /** The full list of things a Blueprint puts in a company at a given version. Pure: same inputs, same list. Items appear once (an employee shared by two systems is activated once). */
  function resolve(def: BlueprintDef, version: string, bootstrap: boolean): Item[] {
    const out: Item[] = [], seen = new Set<string>();
    const add = (it: Item) => { if (cmpVersion(it.since, version) <= 0 && !seen.has(it.ref)) { seen.add(it.ref); out.push(it); } };
    const emit = (sys: string, c: Content, base: string) => {
      for (const e of c.employees) add({ ref: `employee:${e}`, kind: "employee", system: sys, since: base, paid: false, name: t2(ports.employeeName(e)), data: { key: e } });
      for (const s of c.skills) add({ ref: `${sys}:skill:${s.id}`, kind: "skill", system: sys, since: s.since ?? base, paid: Boolean(s.paid), name: t2(s.skill), data: { employee: s.employee, skill: s.skill } });
      for (const o of c.objectives) add({ ref: `${sys}:objective:${o.id}`, kind: "objective", system: sys, since: o.since ?? base, paid: Boolean(o.paid), name: o.title, data: { employee: o.employee, priority: o.priority, metric: o.metric ?? "" } });
      for (const g of c.agenda) add({ ref: `${sys}:agenda:${g.id}`, kind: "agenda", system: sys, since: g.since ?? base, paid: Boolean(g.paid), name: g.title, data: { employee: g.employee, objective: g.objective ? `${sys}:objective:${g.objective}` : null, instruction: g.instruction, everyDays: g.everyDays, priority: g.priority ?? 3 } });
      for (const k of c.kpis) add({ ref: `${sys}:kpi:${k.id}`, kind: "kpi", system: sys, since: k.since ?? base, paid: Boolean(k.paid), name: k.name, data: { unit: k.unit, target: k.target ?? null } });
      for (const i of c.integrations) add({ ref: `${sys}:integration:${i.id}`, kind: "integration", system: sys, since: i.since ?? base, paid: Boolean(i.paid), name: i.name, data: {} });
      for (const r of c.recommendations) add({ ref: `${sys}:recommendation:${r.id}`, kind: "recommendation", system: sys, since: r.since ?? base, paid: Boolean(r.paid), name: r.text, data: {} });
    };
    const own: Content = { ...emptyContent, ...(def.employees ? { employees: def.employees } : {}), ...(def.skills ? { skills: def.skills } : {}), ...(def.objectives ? { objectives: def.objectives } : {}), ...(def.agenda ? { agenda: def.agenda } : {}), ...(def.kpis ? { kpis: def.kpis } : {}), ...(def.integrations ? { integrations: def.integrations } : {}), ...(def.recommendations ? { recommendations: def.recommendations } : {}) };
    for (const r of def.systems) {
      const base = r.since ?? "1.0.0", s = systems.get(r.id);
      if (cmpVersion(base, version) > 0) continue;
      if (!s || s.status === "planned") add({ ref: `system:${r.id}`, kind: "system", system: r.id, since: base, paid: false, name: s?.name ?? t2(r.id), data: {} });
      else { emit(s.id, s, base); if (s.id === "marketing_growth" && bootstrap) add({ ref: "marketing_growth:growth_plan:bootstrap", kind: "growth_plan", system: s.id, since: base, paid: false, name: t2("bootstrap"), data: { objective: def.growthObjective } }); }
    }
    emit("blueprint", own, "1.0.0");
    return out;
  }
  const ORDER: ItemKind[] = ["system", "employee", "skill", "objective", "agenda", "growth_plan", "kpi", "integration", "recommendation"];

  /** Applies what is missing. Items already applied are never touched (the company may have changed them); failed, plan-blocked and system-pending ones are retried. */
  async function apply(a: Actor, def: BlueprintDef, version: string, bootstrap: boolean, prev: AppliedItem[], locale: "es" | "en"): Promise<AppliedItem[]> {
    const state = new Map(prev.map((p) => [p.ref, p])), items = resolve(def, version, bootstrap).sort((x, y) => ORDER.indexOf(x.kind) - ORDER.indexOf(y.kind));
    const done = (it: Item, s: ItemState, refId?: string): AppliedItem => ({ ref: it.ref, kind: it.kind, system: it.system, state: s, since: it.since, ...(refId ? { refId } : {}) });
    const next: AppliedItem[] = [...prev]; // placeholders for pending systems are rebuilt below
    const out = new Map(next.map((p) => [p.ref, p]));
    for (const it of items) {
      const cur = state.get(it.ref);
      if (cur && (cur.state === "applied" || cur.state === "skipped_paid")) { out.set(it.ref, cur); continue; }
      const empState = (key: string): ItemState => out.get(`employee:${key}`)?.state ?? "unavailable";
      try {
        if (it.kind === "system") { out.set(it.ref, done(it, "unavailable")); continue; }
        if (it.paid && bootstrap) { out.set(it.ref, done(it, "skipped_paid")); continue; }
        if (it.kind === "employee") { out.set(it.ref, done(it, await ports.activate(a, String(it.data.key)))); continue; }
        if (it.kind === "skill" || it.kind === "objective" || it.kind === "agenda") {
          const emp = String(it.data.employee), es = empState(emp);
          if (es !== "applied") { out.set(it.ref, done(it, es === "unavailable" ? "unavailable" : "skipped_plan")); continue; }
          if (it.kind === "skill") { await ports.enableSkill(a, emp, String(it.data.skill)); out.set(it.ref, done(it, "applied")); }
          else if (it.kind === "objective") { const o = await ports.createObjective(a, { employeeKey: emp, title: it.name[locale], priority: Number(it.data.priority), metric: String(it.data.metric) }); out.set(it.ref, done(it, "applied", o.id)); }
          else { const obj = it.data.objective ? out.get(String(it.data.objective))?.refId ?? null : null, g = await ports.createAgenda(a, { employeeKey: emp, objectiveId: obj, title: it.name[locale], instruction: String((it.data.instruction as L)[locale]), everyMinutes: Number(it.data.everyDays) * 1440, priority: Number(it.data.priority) }); out.set(it.ref, done(it, "applied", g.id)); }
          continue;
        }
        if (it.kind === "growth_plan") { await ports.growthPlan(a, String(it.data.objective)); out.set(it.ref, done(it, "applied")); continue; }
        out.set(it.ref, done(it, "applied")); // kpi, integration (declared, not connected) and recommendation: recorded, nothing else to do
      } catch { out.set(it.ref, done(it, "failed")); }
    }
    for (const [ref, p] of [...out]) if (p.kind === "system" && !items.some((i) => i.ref === ref)) out.delete(ref); // the system became available: its real items replace the placeholder
    return [...out.values()];
  }
  const counts = (items: AppliedItem[]) => { const c: Record<ItemState, number> = { applied: 0, skipped_plan: 0, skipped_paid: 0, unavailable: 0, failed: 0 }; for (const i of items) c[i.state]++; return c; };
  const summary = (b: BlueprintDef) => ({ id: b.id, name: b.name, industry: b.industry, description: b.description, version: b.version, author: b.author, status: b.status, tier: b.tier, dependencies: b.dependencies, systems: b.systems.map((s) => ({ id: s.id, name: systems.get(s.id)?.name ?? t2(s.id), status: systems.get(s.id)?.status ?? "planned" })), bootstrap: true });

  async function list(a: Actor) {
    need(a, "view");
    const cur = await installOf(a);
    return { installed: cur?.blueprintId ?? null, items: catalog.map(summary) };
  }
  async function get(a: Actor, id: string) {
    need(a, "view");
    const b = defOf(id), items = resolve(b, b.version, true);
    return { ...summary(b), history: b.history, contents: items.map((i) => ({ ref: i.ref, kind: i.kind, system: i.system, name: i.name, paid: i.paid, since: i.since })) };
  }
  async function install(a: Actor, input: unknown) {
    need(a, "manage");
    const i = parse(installInput.extend(localeInput.shape).strict(), input), def = defOf(i.blueprintId);
    if (await installOf(a)) throw new BlueprintsError("conflict", "This company already has a Blueprint installed.");
    const plan = (await ports.plan(a).catch(() => null)) ?? "starter", need_ = { starter: 0, business: 2, enterprise: 3 }[def.tier];
    if ((PLAN_RANK[plan] ?? 0) < need_) throw new BlueprintsError("plan_required", `This Blueprint requires the ${def.tier} plan.`);
    const applied = await apply(a, def, def.version, i.bootstrap, [], i.locale), t = now();
    const row: InstallRecord = { id: deps.newId(), tenantId: a.tenantId, blueprintId: def.id, version: def.version, bootstrap: i.bootstrap, applied, installedBy: a.userId, createdAt: t, updatedAt: t };
    await store.insert("install", row);
    const c = counts(applied);
    await rec(a, { action: "blueprints.install.completed", summary: `Installed Blueprint ${def.id} v${def.version}: ${c.applied} applied, ${c.skipped_plan} need a higher plan, ${c.failed} failed`, subjectKind: "blueprint", subjectId: def.id, quantity: c.applied, idempotencyKey: `bp-install:${row.id}`, reversible: false });
    return current(a);
  }
  const latestOf = (cur: InstallRecord) => byId.get(cur.blueprintId);
  async function current(a: Actor) {
    need(a, "view");
    const cur = await installOf(a);
    if (!cur) return null;
    const def = latestOf(cur), c = counts(cur.applied), active = new Set(await ports.activeEmployees(a).catch(() => [] as string[]));
    const emps = cur.applied.filter((x) => x.kind === "employee" && x.state === "applied"), inactive = emps.filter((x) => !active.has(x.ref.slice(9)));
    const resolved = def ? new Map(resolve(def, cur.version, cur.bootstrap).map((r) => [r.ref, r])) : new Map<string, Item>();
    const items = cur.applied.map((x) => ({ ...x, name: resolved.get(x.ref)?.name ?? t2(x.ref), paid: resolved.get(x.ref)?.paid ?? false, data: resolved.get(x.ref)?.data ?? {} }));
    const upgrade = def && cmpVersion(def.version, cur.version) > 0 ? { to: def.version, breaking: major(def.version) !== major(cur.version) } : null;
    const attention = c.failed + c.skipped_plan + inactive.length;
    const denom = cur.applied.length - c.skipped_paid - c.unavailable;
    const actions: { key: string; count: number }[] = [];
    if (c.failed) actions.push({ key: "retry_failed", count: c.failed });
    if (inactive.length) actions.push({ key: "reactivate_employees", count: inactive.length });
    if (c.skipped_plan) actions.push({ key: "upgrade_plan", count: c.skipped_plan });
    if (upgrade) actions.push({ key: upgrade.breaking ? "review_major_upgrade" : "apply_upgrade", count: 1 });
    if (c.unavailable) actions.push({ key: "systems_coming", count: c.unavailable });
    if (c.skipped_paid) actions.push({ key: "paid_optional", count: c.skipped_paid });
    return {
      id: cur.id, blueprint: def ? summary(def) : { id: cur.blueprintId }, version: cur.version, latestVersion: def?.version ?? cur.version, bootstrap: cur.bootstrap, installedAt: cur.createdAt, upgrade,
      health: { status: attention ? "attention" as const : "healthy" as const, score: denom > 0 ? Math.round((c.applied / denom) * 100) : 100, counts: c, inactiveEmployees: inactive.length },
      items, actions, recommendations: items.filter((x) => x.kind === "recommendation" && x.state === "applied").map((x) => x.name),
    };
  }
  async function preview(a: Actor) {
    need(a, "view");
    const cur = await installOf(a);
    if (!cur) throw new BlueprintsError("not_found", "No Blueprint installed.");
    const def = defOf(cur.blueprintId), have = new Set(cur.applied.map((x) => x.ref)), news = resolve(def, def.version, cur.bootstrap).filter((i) => !have.has(i.ref));
    return { from: cur.version, to: def.version, breaking: major(def.version) !== major(cur.version), notes: def.history.filter((h) => cmpVersion(h.version, cur.version) > 0 && cmpVersion(h.version, def.version) <= 0), newItems: news.map((i) => ({ ref: i.ref, kind: i.kind, name: i.name, paid: i.paid })), removes: 0 };
  }
  /** Adds what the new version brings. Never removes or rewrites anything. A major version needs an explicit confirmation. */
  async function upgrade(a: Actor, input: unknown) {
    need(a, "manage");
    const i = parse(upgradeInput.extend(localeInput.shape).strict(), input), cur = await installOf(a);
    if (!cur) throw new BlueprintsError("not_found", "No Blueprint installed.");
    const def = defOf(cur.blueprintId);
    if (cmpVersion(def.version, cur.version) <= 0) throw new BlueprintsError("invalid_state", "Already on the latest version.");
    if (major(def.version) !== major(cur.version) && !i.confirm) throw new BlueprintsError("conflict", "A major version needs your confirmation.", { requiresConfirm: true, to: def.version });
    const applied = await apply(a, def, def.version, cur.bootstrap, cur.applied, i.locale);
    await store.update("install", a.tenantId, cur.id, { version: def.version, applied, updatedAt: now() });
    await rec(a, { action: "blueprints.upgrade.completed", summary: `Blueprint ${def.id} upgraded v${cur.version} → v${def.version}`, subjectKind: "blueprint", subjectId: def.id, idempotencyKey: `bp-up:${cur.id}:${def.version}`, reversible: false });
    return current(a);
  }
  /** Retries what failed or was blocked (for example after the plan was upgraded) and picks up systems that have since been built. */
  async function sync(a: Actor, input: unknown = {}) {
    need(a, "manage");
    const i = parse(localeInput.strict(), input), cur = await installOf(a);
    if (!cur) throw new BlueprintsError("not_found", "No Blueprint installed.");
    const applied = await apply(a, defOf(cur.blueprintId), cur.version, cur.bootstrap, cur.applied, i.locale);
    await store.update("install", a.tenantId, cur.id, { applied, updatedAt: now() });
    await rec(a, { action: "blueprints.sync.completed", summary: `Blueprint ${cur.blueprintId} synchronised`, subjectKind: "blueprint", subjectId: cur.blueprintId, quantity: counts(applied).applied, idempotencyKey: `bp-sync:${cur.id}:${now()}` });
    return current(a);
  }
  return { list, get, install, current, preview, upgrade, sync, permissions: (a: Actor) => ({ role: a.role, capabilities: (["view", "manage"] as const).filter((c) => allows(a.role, c)) }) };
}
