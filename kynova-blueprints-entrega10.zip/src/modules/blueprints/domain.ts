import { z } from "zod";
import { ROLES } from "@/config/roles";

/** Capabilities INSIDE Blueprints. Whether a role may open /app/blueprints at all is decided only by src/config/modules.ts. */
export const CAPABILITIES = ["view", "manage"] as const;
export type Capability = (typeof CAPABILITIES)[number];
export const DEFAULT_CAPABILITIES: Record<(typeof ROLES)[number], readonly Capability[]> = {
  super_admin: [...CAPABILITIES], owner: [...CAPABILITIES], administrator: [...CAPABILITIES], ceo: [...CAPABILITIES], manager: ["view"],
  marketing: ["view"], sales: ["view"], finance: ["view"], support: [], hr: [], employee: [], guest: [],
};
export const ITEM_KINDS = ["system", "employee", "skill", "objective", "agenda", "kpi", "integration", "recommendation", "growth_plan"] as const;
export type ItemKind = (typeof ITEM_KINDS)[number];
/** applied = done · skipped_plan = the plan does not include it (retry after upgrading) · skipped_paid = paid work, left out in Bootstrap · unavailable = the system is not built yet · failed = retry with sync. */
export const ITEM_STATES = ["applied", "skipped_plan", "skipped_paid", "unavailable", "failed"] as const;
export type ItemState = (typeof ITEM_STATES)[number];
export interface AppliedItem { ref: string; kind: ItemKind; system: string; state: ItemState; refId?: string; since: string }
export interface InstallRecord { id: string; tenantId: string; blueprintId: string; version: string; bootstrap: boolean; applied: AppliedItem[]; installedBy: string; createdAt: number; updatedAt: number }

export const semver = z.string().regex(/^\d+\.\d+\.\d+$/);
export const installInput = z.object({ blueprintId: z.string().trim().regex(/^[a-z][a-z0-9_]{1,40}$/), bootstrap: z.boolean().default(true) }).strict();
export const upgradeInput = z.object({ confirm: z.boolean().default(false) }).strict();
export const cmpVersion = (a: string, b: string): number => { const x = a.split(".").map(Number), y = b.split(".").map(Number); for (let i = 0; i < 3; i++) if ((x[i] ?? 0) !== (y[i] ?? 0)) return (x[i] ?? 0) - (y[i] ?? 0); return 0; };
export const major = (v: string): number => Number(v.split(".")[0]);
export const PLAN_RANK: Record<string, number> = { starter: 0, professional: 1, business: 2, enterprise: 3 };
