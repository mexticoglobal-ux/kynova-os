import { getActivitySink } from "@/platform/activity";
import { getEmployeeFramework } from "@/platform/ai-employees";
import { getDb, plansRepo, tenantDb } from "@/platform/db";
import { getGrowthService } from "@/modules/growth";
import { ROSTER_BY_KEY, blueprintOf, getTeamService } from "@/modules/team";
import { getWorkforceService } from "@/modules/workforce";
import { getBlueprintsStore } from "./runtime";
import { createBlueprintsService, type Actor, type BlueprintsPorts, type BlueprintsService } from "./service";

/** Composition root: the only file that meets the Team, Workforce and Growth modules. Everything is done through their public services, so their own rules (plan, roles, approval) still apply. */
const code = (e: unknown): string => (typeof e === "object" && e !== null ? String((e as { code?: unknown }).code ?? "") : "");
export const blueprintsPorts: BlueprintsPorts = {
  async activate(a, key) {
    try { await (await getTeamService()).activate(a, key); return "applied"; }
    catch (e) {
      if (code(e) === "conflict") return "applied"; // already active
      if (code(e) === "plan_required") return "skipped_plan";
      if (code(e) === "not_found" || code(e) === "invalid_state") return "unavailable";
      throw e;
    }
  },
  async enableSkill(a, employeeKey, skillKey) { await (await getWorkforceService()).setSkill(a, employeeKey, skillKey, { enabled: true }); },
  async createObjective(a, i) { return { id: (await (await getWorkforceService()).createObjective(a, { ...i, dependsOn: [] })).id }; },
  async createAgenda(a, i) { return { id: (await (await getWorkforceService()).createAgenda(a, { ...i, triggerKind: "schedule", requiresApproval: true, dependsOn: [] })).id }; },
  async growthPlan(a, objective) { const g = await getGrowthService(); if (!(await g.plan(a))) await g.setPlan(a, { objective, investmentMinor: 0 }); },
  async plan(a) {
    const db = await getDb(), sub = await tenantDb(db, { tenantId: a.tenantId }).subscriptions.current();
    return sub ? ((await plansRepo(db).findById(sub.planId))?.code ?? null) : null;
  },
  async activeEmployees(a) {
    const records = await getEmployeeFramework().employees.list(a);
    return [...ROSTER_BY_KEY.values()].filter((r) => records.some((e) => e.blueprint === blueprintOf(r) && e.status !== "retired")).map((r) => r.key);
  },
  employeeName: (key) => ROSTER_BY_KEY.get(key)?.name ?? key,
};
export async function getBlueprintsService(): Promise<BlueprintsService> {
  return createBlueprintsService({ store: await getBlueprintsStore(), ports: blueprintsPorts, newId: () => crypto.randomUUID().replace(/-/g, ""), activity: await getActivitySink("blueprints") });
}
export type { Actor };
