/** Blueprints UI texts (CLAUDE.md rule 4). One entry = [key, Spanish, English]. Blueprint names and contents live in catalog.ts as {es,en}. */
const E = [
  ["title", "Tu negocio", "Your business"], ["sub", "Instalamos un negocio completo, no módulos sueltos. Tú decides cada cambio.", "We install a complete business, not loose modules. You decide every change."],
  ["common.error", "Algo salió mal. Inténtalo de nuevo.", "Something went wrong. Try again."], ["common.working", "Instalando tu negocio…", "Installing your business…"],
  ["ask.title", "¿Qué tipo de empresa tienes?", "What kind of company do you have?"], ["ask.sub", "Elige una y dejamos todo listo: equipo, objetivos, indicadores y plan de trabajo.", "Pick one and we set everything up: team, goals, KPIs and work plan."],
  ["ask.boot", "Sin inversión por ahora (trabajo orgánico, sin publicidad)", "No investment for now (organic work, no advertising)"], ["ask.bootHint", "Puedes decidir invertir más adelante. Nunca te obligamos a anunciar.", "You can decide to invest later. We never force advertising."],
  ["ask.install", "Instalar este negocio", "Install this business"], ["ask.tier", "Plan {tier}", "{tier} plan"], ["ask.official", "Oficial", "Official"],
  ["ask.includes", "Incluye: {systems}", "Includes: {systems}"], ["ask.soon", "{n} sistemas llegarán con una actualización", "{n} systems will arrive with an upgrade"],
  ["tier.starter", "Starter", "Starter"], ["tier.business", "Business", "Business"], ["tier.enterprise", "Enterprise", "Enterprise"],
  ["cur.title", "Blueprint instalado", "Installed Blueprint"], ["cur.version", "Versión {v}", "Version {v}"], ["cur.none", "Aún no has instalado un Blueprint.", "You have not installed a Blueprint yet."], ["cur.choose", "Elegir mi tipo de empresa", "Choose my company type"],
  ["cur.bootstrap", "Modo Bootstrap: trabajo orgánico, sin publicidad obligatoria.", "Bootstrap mode: organic work, no forced advertising."],
  ["health.title", "Salud del sistema", "System health"], ["health.healthy", "Todo en orden", "All good"], ["health.attention", "Requiere atención", "Needs attention"], ["health.score", "{n}% instalado", "{n}% installed"],
  ["sec.employees", "AI Employees", "AI Employees"], ["sec.skills", "Skills", "Skills"], ["sec.objectives", "Objetivos", "Goals"], ["sec.agenda", "Calendario de trabajo", "Work calendar"], ["sec.kpis", "KPIs", "KPIs"],
  ["sec.integrations", "Integraciones sugeridas", "Suggested integrations"], ["sec.recs", "Próximas recomendaciones", "Next recommendations"], ["sec.systems", "AI Business Systems", "AI Business Systems"],
  ["st.applied", "Listo", "Ready"], ["st.skipped_plan", "Requiere un plan superior", "Needs a higher plan"], ["st.skipped_paid", "Opcional: publicidad", "Optional: advertising"], ["st.unavailable", "Aún no disponible", "Not available yet"], ["st.failed", "Falló: reintentar", "Failed: retry"],
  ["every", "Cada {n} días", "Every {n} days"], ["kpi.note", "Definido; todavía no se mide solo.", "Defined; not measured automatically yet."], ["int.note", "Se instala desde el Marketplace. No conectado.", "Installed from the Marketplace. Not connected."],
  ["act.retry_failed", "Reintentar lo que falló ({n})", "Retry what failed ({n})"], ["act.reactivate_employees", "Hay {n} AI Employees inactivos: reactívalos en Equipo", "{n} AI Employees are inactive: reactivate them in Team"],
  ["act.upgrade_plan", "{n} elementos se activan al subir de plan", "{n} items unlock when you upgrade your plan"], ["act.apply_upgrade", "Hay una versión nueva disponible", "A new version is available"], ["act.review_major_upgrade", "Hay una versión mayor: revísala antes de aplicar", "A major version is available: review it before applying"],
  ["act.systems_coming", "{n} sistemas independientes se instalarán cuando existan", "{n} independent systems will install once they exist"], ["act.paid_optional", "{n} elementos de publicidad quedan opcionales", "{n} advertising items stay optional"],
  ["up.title", "Actualización", "Update"], ["up.text", "De {from} a {to}. Solo se agrega lo nuevo: no se borra ni se cambia nada de lo que ya tienes.", "From {from} to {to}. Only new things are added: nothing you have is removed or changed."],
  ["up.breaking", "Versión mayor: confirma que quieres aplicarla.", "Major version: confirm you want to apply it."], ["up.apply", "Aplicar actualización", "Apply update"], ["up.confirm", "Entiendo y confirmo", "I understand and confirm"], ["up.new", "{n} elementos nuevos", "{n} new items"],
  ["sync", "Revisar y completar", "Check and complete"],
  ["mc.title", "Blueprint", "Blueprint"], ["mc.agents", "AI Employees activos", "Active AI Employees"], ["mc.open", "Ver mi negocio", "View my business"],
  ["arch.title", "Qué está y qué no está construido", "What is and is not built"], ["arch.notice", "Cada línea dice lo que existe. Nada aquí se presenta como más de lo que es.", "Each line says what exists. Nothing here is presented as more than it is."],
  ["s.built", "Construido", "Built"], ["s.partial", "Parcial", "Partial"], ["s.declared", "Declarado", "Declared"], ["s.not_built", "No construido", "Not built"],
  ["a.catalog", "Catálogo de Blueprints", "Blueprint catalog"], ["a.one_click_install", "Instalación en un paso", "One-step install"], ["a.bootstrap_mode", "Modo Bootstrap", "Bootstrap mode"], ["a.versioned_upgrades", "Actualizaciones por versión", "Versioned upgrades"],
  ["a.mission_control_view", "Vista en Mission Control", "Mission Control view"], ["a.ai_business_systems", "AI Business Systems", "AI Business Systems"], ["a.kpi_measurement", "Medición de KPIs", "KPI measurement"], ["a.automations", "Automatizaciones", "Automations"],
  ["a.marketplace_install", "Instalar desde el Marketplace", "Install from the Marketplace"], ["a.integrations", "Integraciones", "Integrations"], ["a.custom_blueprints", "Blueprints propios", "Custom Blueprints"],
] as const;
type Entry = (typeof E)[number];
export type BlueprintsKey = Entry[0];
export type BlueprintsLocale = "en" | "es";
const build = (i: 1 | 2): Record<BlueprintsKey, string> => Object.fromEntries(E.map((e) => [e[0], e[i]])) as Record<BlueprintsKey, string>;
export const BLUEPRINTS_DICTIONARIES: Record<BlueprintsLocale, Record<BlueprintsKey, string>> = { es: build(1), en: build(2) };
export const blueprintsLocale = (l: string | null | undefined): BlueprintsLocale => (l?.toLowerCase().startsWith("es") ? "es" : "en");
export const tr = (locale: BlueprintsLocale, key: BlueprintsKey, vars: Record<string, string | number> = {}): string => (BLUEPRINTS_DICTIONARIES[locale][key] ?? String(key)).replace(/\{(\w+)\}/g, (_m, k: string) => String(vars[k] ?? ""));
