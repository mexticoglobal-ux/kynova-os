export type BlueprintsErrorCode = "forbidden" | "not_found" | "validation_failed" | "conflict" | "duplicate" | "invalid_state" | "limit_exceeded" | "unavailable" | "ai_unavailable" | "plan_required";
const STATUS: Record<BlueprintsErrorCode, number> = { forbidden: 403, not_found: 404, validation_failed: 422, conflict: 409, duplicate: 409, invalid_state: 409, limit_exceeded: 403, unavailable: 503, ai_unavailable: 503, plan_required: 403 };
export class BlueprintsError extends Error {
  readonly status: number;
  constructor(readonly code: BlueprintsErrorCode, message: string, readonly details?: Record<string, unknown>) { super(message); this.name = "BlueprintsError"; this.status = STATUS[code]; }
}
export const isBlueprintsError = (e: unknown): e is BlueprintsError => e instanceof BlueprintsError || (typeof e === "object" && e !== null && (e as { name?: string }).name === "BlueprintsError");
