import type { Kind } from "./store";

export const TABLE: Record<Kind, string> = { install: "bp_installs" };
export const KIND_LIST = Object.keys(TABLE) as Kind[];
export const SOFT_DELETE: ReadonlySet<Kind> = new Set<Kind>();
export const REMOVABLE: ReadonlySet<Kind> = new Set<Kind>();
export const IMMUTABLE_KINDS: ReadonlySet<Kind> = new Set<Kind>();
export const FROZEN_COLS: Partial<Record<Kind, readonly string[]>> = { install: ["blueprintId"] };
export const BOOLEAN_COLS: ReadonlySet<string> = new Set(["bootstrap"]);
export const JSON_COLS: ReadonlySet<string> = new Set(["applied"]);
export const COLUMNS: Record<Kind, readonly string[]> = { install: ["id", "tenantId", "blueprintId", "version", "bootstrap", "applied", "installedBy", "createdAt", "updatedAt"] };
/** One Blueprint per company. */
export const UNIQUE: Partial<Record<Kind, readonly (readonly string[])[]>> = { install: [[]] };
export const UNIQUE_WHEN: Partial<Record<Kind, readonly { cols: readonly string[]; col: string; in: readonly string[] }[]>> = {};
export const snake = (k: string) => k.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
export const camel = (k: string) => k.replace(/_([a-z0-9])/g, (_m, c: string) => c.toUpperCase());
