"use client";
import { createContext, useCallback, useContext, type ReactNode } from "react";
import type { BlueprintsKey } from "@/modules/blueprints/i18n";

const Ctx = createContext<{ dict: Record<BlueprintsKey, string>; locale: string } | null>(null);
export function BlueprintsI18n({ dict, locale, children }: { dict: Record<BlueprintsKey, string>; locale: string; children: ReactNode }) { return <Ctx.Provider value={{ dict, locale }}>{children}</Ctx.Provider>; }
export function useT() {
  const c = useContext(Ctx);
  const t = useCallback((key: BlueprintsKey, vars: Record<string, string | number> = {}) => (c?.dict[key] ?? key).replace(/\{(\w+)\}/g, (_m, k: string) => String(vars[k] ?? "")), [c]);
  return { t, locale: c?.locale ?? "en" };
}
