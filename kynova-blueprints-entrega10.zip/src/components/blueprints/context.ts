import { redirect } from "next/navigation";
import { requireModuleAccess } from "@/platform/auth/session";
import { getBlueprintsService, tr, blueprintsLocale, type Actor, type BlueprintsKey } from "@/modules/blueprints";

/** Server-side context of the Blueprints pages: verified session, actor, service and translator. The tenant always comes from the session. */
export async function blueprintsContext() {
  const s = await requireModuleAccess("blueprints");
  if (!s.tenantId) redirect("/app/profile");
  const actor: Actor = { tenantId: s.tenantId, userId: s.user.id, role: s.role };
  const locale = blueprintsLocale(s.user.locale);
  return { actor, locale, svc: await getBlueprintsService(), t: (k: BlueprintsKey, v?: Record<string, string | number>) => tr(locale, k, v) };
}
