"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { wfCall } from "@/components/workforce/api";
import { useT } from "./I18n";

const btn = "rounded-lg border border-line px-3 py-1.5 text-sm hover:bg-ac/10 disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-ac2";
const primary = "rounded-lg bg-ac px-3 py-1.5 text-sm font-medium text-white disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ac2";
function useRun(to?: string) {
  const router = useRouter(), { t } = useT(), [busy, setBusy] = useState(false), [err, setErr] = useState<string | null>(null);
  async function run(fn: () => ReturnType<typeof wfCall>) {
    setBusy(true); setErr(null); const r = await fn(); setBusy(false);
    if (!r.ok) { setErr(r.status === 503 ? t("common.error") : r.message ?? t("common.error")); return; }
    if (to) router.push(to); else router.refresh();
  }
  return { busy, err, run };
}
const Err = ({ err }: { err: string | null }) => <p role="status" aria-live="polite" className="text-xs text-rose-700 dark:text-rose-300">{err}</p>;
export type Option = { id: string; name: string; description: string; tier: string; systems: string; soon: number };

/** "¿Qué tipo de empresa tienes?" One choice installs the whole business. Bootstrap is on by default and advertising is never required. */
export function Chooser({ options }: { options: Option[] }) {
  const { t, locale } = useT(), { busy, err, run } = useRun("/app/blueprints"), [pick, setPick] = useState(options[0]?.id ?? ""), [boot, setBoot] = useState(true);
  const sel = options.find((o) => o.id === pick);
  return (
    <div className="grid gap-4">
      <fieldset className="grid gap-2"><legend className="sr-only">{t("ask.title")}</legend>
        <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">{options.map((o) => (
          <button key={o.id} type="button" aria-pressed={pick === o.id} onClick={() => setPick(o.id)} className={`grid gap-1 rounded-xl border p-3 text-start text-sm hover:bg-ac/10 focus-visible:outline-2 focus-visible:outline-ac2 ${pick === o.id ? "border-ac bg-ac/10" : "border-line"}`}>
            <span className="font-medium">{o.name}</span><span className="text-xs text-muted">{o.description}</span></button>))}</div>
      </fieldset>
      {sel && <p className="text-xs text-muted">{t("ask.includes", { systems: sel.systems })} · {t("ask.tier", { tier: t(`tier.${sel.tier}` as never) })}{sel.soon > 0 ? ` · ${t("ask.soon", { n: sel.soon })}` : ""}</p>}
      <label className="flex items-start gap-2 text-sm"><input type="checkbox" className="mt-1" checked={boot} onChange={(e) => setBoot(e.target.checked)} /><span>{t("ask.boot")}<span className="block text-xs text-muted">{t("ask.bootHint")}</span></span></label>
      <div className="flex flex-wrap items-center gap-3"><button type="button" className={primary} disabled={busy || !pick} onClick={() => void run(() => wfCall("POST", "/blueprints/install", { blueprintId: pick, bootstrap: boot, locale }))}>{busy ? t("common.working") : t("ask.install")}</button><Err err={err} /></div>
    </div>
  );
}
export function SyncButton() {
  const { t, locale } = useT(), { busy, err, run } = useRun();
  return <div className="grid gap-1"><button type="button" className={btn} disabled={busy} onClick={() => void run(() => wfCall("POST", "/blueprints/sync", { locale }))}>{t("sync")}</button><Err err={err} /></div>;
}
export function UpgradeBox({ from, to, breaking, count }: { from: string; to: string; breaking: boolean; count: number }) {
  const { t, locale } = useT(), { busy, err, run } = useRun(), [ok, setOk] = useState(!breaking);
  return (
    <div className="grid gap-2 text-sm"><p>{t("up.text", { from, to })} {t("up.new", { n: count })}</p>
      {breaking && <label className="flex items-center gap-2"><input type="checkbox" checked={ok} onChange={(e) => setOk(e.target.checked)} />{t("up.confirm")}</label>}
      <div className="flex items-center gap-3"><button type="button" className={primary} disabled={busy || !ok} onClick={() => void run(() => wfCall("POST", "/blueprints/upgrade", { confirm: ok, locale }))}>{t("up.apply")}</button><Err err={err} /></div></div>
  );
}
