import Link from "next/link";
import type { BlueprintsService } from "@/modules/blueprints";
import { Card, Pill, Stat } from "@/components/workforce/ui";
import type { BlueprintsKey } from "@/modules/blueprints";

type Cur = NonNullable<Awaited<ReturnType<BlueprintsService["current"]>>>;
export type Tx = (k: BlueprintsKey, v?: Record<string, string | number>) => string;
/** Compact summary used by Mission Control: Blueprint, version, health, active AI Employees, next recommendations. */
export function MissionControlBlueprint({ cur, t, locale }: { cur: Cur; t: Tx; locale: "es" | "en" }) {
  const name = "name" in cur.blueprint ? (cur.blueprint.name as { es: string; en: string })[locale] : String(cur.blueprint.id);
  const emps = cur.items.filter((i) => i.kind === "employee" && i.state === "applied").length;
  return (
    <Card title={t("mc.title")} action={<Link href="/app/blueprints" className="text-sm underline">{t("mc.open")}</Link>} className="mb-4">
      <div className="grid gap-3 sm:grid-cols-4">
        <Stat label={name} value={t("cur.version", { v: cur.version })} /><Stat label={t("mc.agents")} value={emps} /><Stat label={t("health.title")} value={cur.health.status === "healthy" ? t("health.healthy") : t("health.attention")} /><Stat label="%" value={t("health.score", { n: cur.health.score })} />
      </div>
      {cur.recommendations.length > 0 && <ul className="mt-3 grid gap-1 text-sm">{cur.recommendations.slice(0, 2).map((r, n) => <li key={n}>• {r[locale]}</li>)}</ul>}
      <p className="mt-2"><Pill tone={cur.health.status === "healthy" ? "success" : "warning"}>{cur.health.status === "healthy" ? t("health.healthy") : t("health.attention")}</Pill></p>
    </Card>
  );
}
