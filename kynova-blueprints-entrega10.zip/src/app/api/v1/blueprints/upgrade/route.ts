import { blueprintsRoute, readBody, respond } from "@/modules/blueprints/http";
export const GET = blueprintsRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.preview(actor), rid); });
export const POST = blueprintsRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.upgrade(actor, await readBody(req)), rid); }, { mutating: true });
