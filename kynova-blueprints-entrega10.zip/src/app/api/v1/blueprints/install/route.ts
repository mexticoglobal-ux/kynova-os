import { blueprintsRoute, readBody, respond } from "@/modules/blueprints/http";
export const POST = blueprintsRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.install(actor, await readBody(req)), rid, 201); }, { mutating: true });
