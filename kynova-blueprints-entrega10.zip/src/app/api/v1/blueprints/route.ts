import { blueprintsRoute, readBody, respond } from "@/modules/blueprints/http";
export const GET = blueprintsRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.list(actor), rid); });
