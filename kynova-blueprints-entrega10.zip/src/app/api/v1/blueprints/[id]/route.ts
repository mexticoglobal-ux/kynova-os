import { blueprintsRoute, readBody, respond } from "@/modules/blueprints/http";
type Ctx = { params: Promise<{ id: string }> };
export const GET = blueprintsRoute<Ctx>(async (req, c, { actor, svc, rid }) => { void req; return respond(await svc.get(actor, (await c.params).id), rid); });
