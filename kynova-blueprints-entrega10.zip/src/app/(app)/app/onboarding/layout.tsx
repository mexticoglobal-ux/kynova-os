import type { ReactNode } from "react";
import { BlueprintsI18n } from "@/components/blueprints/I18n";
import { blueprintsContext } from "@/components/blueprints/context";
import { BLUEPRINTS_DICTIONARIES } from "@/modules/blueprints";

export default async function OnboardingLayout({ children }: { children: ReactNode }) {
  const { locale } = await blueprintsContext();
  return <BlueprintsI18n dict={BLUEPRINTS_DICTIONARIES[locale]} locale={locale}><main id="main" className="mx-auto w-full max-w-5xl p-4 sm:p-6 lg:p-8">{children}</main></BlueprintsI18n>;
}
