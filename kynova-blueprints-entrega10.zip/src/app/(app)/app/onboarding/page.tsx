import { redirect } from "next/navigation";
import { blueprintsContext } from "@/components/blueprints/context";
import { Chooser } from "@/components/blueprints/Panels";
import { Card, Empty } from "@/components/workforce/ui";

export const metadata = { title: "Onboarding" };
export const dynamic = "force-dynamic";

/** Company onboarding: "¿Qué tipo de empresa tienes?" One choice installs the whole business. */
export default async function OnboardingPage() {
  const { t, locale, svc, actor } = await blueprintsContext();
  if (await svc.current(actor)) redirect("/app/blueprints");
  const [cat, perm] = await Promise.all([svc.list(actor), svc.permissions(actor)]);
  return (
    <div className="grid gap-5">
      <header><h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{t("ask.title")}</h1><p className="mt-1 text-sm text-muted">{t("ask.sub")}</p></header>
      <Card>{perm.capabilities.includes("manage") ? <Chooser options={cat.items.map((b) => ({ id: b.id, name: b.name[locale], description: b.description[locale], tier: b.tier, systems: b.systems.filter((s) => s.status === "available").map((s) => s.name[locale]).join(", "), soon: b.systems.filter((s) => s.status === "planned").length }))} /> : <Empty>{t("cur.none")}</Empty>}</Card>
    </div>
  );
}
