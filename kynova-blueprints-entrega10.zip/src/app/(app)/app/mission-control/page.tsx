import WidgetView from "@/components/mission-control/WidgetView";
import { MODULES } from "@/config/modules";
import ActionButton from "@/components/mission-control/ActionButton";
import EntityForm from "@/components/mission-control/EntityForm";
import LocalTime from "@/components/mission-control/LocalTime";
import { missionControlContext } from "@/components/mission-control/context";
import { K, fmtVal, nm } from "@/components/mission-control/helpers";
import { Card, Empty, PageHeader, Pager, Pill, Stat, sp1, scoreTone } from "@/components/mission-control/ui";
import { StatusPill, Table, orNotFound } from "@/components/mission-control/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
void ActionButton; void EntityForm; void LocalTime; void K; void fmtVal; void nm; void Card; void Empty; void Pager; void Pill; void Stat; void scoreTone; void StatusPill; void Table; void orNotFound; void cur;
void MODULES;
export default async function Page({ searchParams }: SP) {
  const { actor, svc, t, locale } = await missionControlContext(), want = sp1((await searchParams).d);
  const st = await svc.settings.get(actor), list = await svc.dashboards.list(actor);
  const code = list.some((d) => d.code === want) ? want : list.some((d) => d.code === st.defaultDashboard) ? st.defaultDashboard : list[0]?.code;
  const view = code ? await svc.dashboards.view(actor, code) : null;
  return (
    <>
      <PageHeader title={view ? nm(t, "dashname", view.dashboard.code, view.dashboard.name) : t("title")} />
      {list.length > 1 && <nav aria-label={t("dash.switch")} className="mb-4 flex flex-wrap gap-2">{list.map((d) => <a key={d.id} href={`/app/mission-control?d=${d.code}`} className="rounded-lg border border-line px-3 py-1 text-sm hover:bg-ac/10">{nm(t, "dashname", d.code, d.name)}</a>)}</nav>}
      {!view ? <Empty>{t("common.noResults")}</Empty> : <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{view.widgets.map((w) => <WidgetView key={w.widget.id} w={w} t={t} locale={locale} />)}</div>}
    </>
  );
}
