import Link from "next/link";
import { blueprintsContext } from "@/components/blueprints/context";
import { Chooser, SyncButton, UpgradeBox } from "@/components/blueprints/Panels";
import { Card, Empty, Notice, Pill } from "@/components/workforce/ui";
import { ARCHITECTURE_STATUS, type BlueprintsKey, type BlueprintsService } from "@/modules/blueprints";

type Row = NonNullable<Awaited<ReturnType<BlueprintsService["current"]>>>["items"][number];

export const metadata = { title: "Blueprints" };
export const dynamic = "force-dynamic";
const k = (s: string) => s as BlueprintsKey;
const STONE = { applied: "success", skipped_plan: "warning", skipped_paid: "muted", unavailable: "muted", failed: "danger" } as const;
const ST = (v: string) => (v.includes("only") ? "partial" : v.startsWith("built") ? "built" : v.startsWith("declared") ? "declared" : "not_built");

export default async function BlueprintsPage() {
  const { t, locale, svc, actor } = await blueprintsContext();
  const [cur, perm] = await Promise.all([svc.current(actor), svc.permissions(actor)]), manage = perm.capabilities.includes("manage");
  if (!cur) {
    const cat = await svc.list(actor);
    return (
      <div className="grid gap-5">
        <header><h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{t("ask.title")}</h1><p className="mt-1 text-sm text-muted">{t("ask.sub")}</p></header>
        <Card>{manage ? <Chooser options={cat.items.map((b) => ({ id: b.id, name: b.name[locale], description: b.description[locale], tier: b.tier, systems: b.systems.filter((s) => s.status === "available").map((s) => s.name[locale]).join(", "), soon: b.systems.filter((s) => s.status === "planned").length }))} /> : <Empty>{t("cur.none")}</Empty>}</Card>
      </div>
    );
  }
  const c = cur, up = c.upgrade ? await svc.preview(actor) : null, by = (kind: string) => c.items.filter((i) => i.kind === kind);
  const bp = cur.blueprint as { name?: { es: string; en: string }; id: string }, label = (i: Row) => i.name[locale];
  const row = (i: Row, extra?: string) => <li key={i.ref} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span className="min-w-0 flex-1">{label(i)}{extra && <span className="text-xs text-muted"> · {extra}</span>}</span><Pill tone={STONE[i.state]}>{t(k(`st.${i.state}`))}</Pill></li>;
  const section = (title: BlueprintsKey, kind: string, extra?: (i: Row) => string) => by(kind).length > 0 && <Card title={t(title)}><ul className="grid gap-2 sm:grid-cols-2">{by(kind).map((i) => row(i, extra?.(i)))}</ul></Card>;
  return (
    <div className="grid gap-5">
      <header><h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{bp.name?.[locale] ?? bp.id}</h1><p className="mt-1 text-sm text-muted">{t("cur.version", { v: cur.version })} · {t("sub")}</p></header>
      {cur.bootstrap && <Notice>{t("cur.bootstrap")}</Notice>}
      <Card title={t("health.title")} action={manage ? <SyncButton /> : undefined}>
        <p className="mb-2 flex flex-wrap items-center gap-2 text-sm"><Pill tone={cur.health.status === "healthy" ? "success" : "warning"}>{cur.health.status === "healthy" ? t("health.healthy") : t("health.attention")}</Pill>{t("health.score", { n: cur.health.score })}</p>
        <ul className="grid gap-1 text-sm">{cur.actions.map((a) => <li key={a.key}>• {t(k(`act.${a.key}`), { n: a.count })}</li>)}</ul>
      </Card>
      {up && manage && <Card title={t("up.title")}><UpgradeBox from={up.from} to={up.to} breaking={up.breaking} count={up.newItems.length} /></Card>}
      {section("sec.employees", "employee")}
      <div className="grid gap-5 lg:grid-cols-2">{section("sec.objectives", "objective")}{section("sec.agenda", "agenda", (i) => t("every", { n: Number(i.data.everyDays ?? 0) }))}</div>
      {section("sec.skills", "skill")}
      <div className="grid gap-5 lg:grid-cols-2">{section("sec.kpis", "kpi", () => t("kpi.note"))}{section("sec.integrations", "integration", () => t("int.note"))}</div>
      {section("sec.systems", "system")}
      <Card title={t("sec.recs")}>{cur.recommendations.length === 0 ? <Empty>{t("cur.none")}</Empty> : <ul className="grid gap-1 text-sm">{cur.recommendations.map((r, n) => <li key={n}>• {r[locale]}</li>)}</ul>}</Card>
      <Card title={t("arch.title")}><p className="mb-3 text-xs text-muted">{t("arch.notice")}</p>
        <ul className="grid gap-2 sm:grid-cols-2">{Object.entries(ARCHITECTURE_STATUS).map(([key, v]) => <li key={key} className="flex items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span>{t(k(`a.${key}`))}</span><Pill tone={ST(v) === "built" ? "success" : ST(v) === "not_built" ? "muted" : "warning"}>{t(k(`s.${ST(v)}`))}</Pill></li>)}</ul></Card>
      <p className="text-xs text-muted"><Link href="/app/growth" className="underline">Marketing & Growth</Link></p>
    </div>
  );
}
