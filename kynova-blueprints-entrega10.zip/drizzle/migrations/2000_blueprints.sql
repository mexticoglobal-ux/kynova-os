-- Blueprints (Entrega 10): the Blueprint a company installed. Owned by src/modules/blueprints.
-- Tenant-owned: tenant_id references companies. One Blueprint per company; nothing is deleted.

CREATE TABLE `bp_installs` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `blueprint_id` text NOT NULL, `version` text NOT NULL, `bootstrap` integer DEFAULT 1 NOT NULL, `applied` text DEFAULT '[]' NOT NULL,
	`installed_by` text NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`bootstrap` IN (0, 1)), CHECK (`version` GLOB '[0-9]*.[0-9]*.[0-9]*'), CHECK (length(`blueprint_id`) BETWEEN 2 AND 41)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `bp_installs_tenant_uq` ON `bp_installs` (`tenant_id`);--> statement-breakpoint
CREATE TRIGGER bp_installs_frozen BEFORE UPDATE OF tenant_id, blueprint_id ON bp_installs BEGIN SELECT RAISE(ABORT, 'blueprint install identity cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER bp_installs_no_delete BEFORE DELETE ON bp_installs BEGIN SELECT RAISE(ABORT, 'bp_installs rows cannot be deleted'); END;
