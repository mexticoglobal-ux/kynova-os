import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES, canAccess } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { employeeRegistry } from "@/platform/ai-employees";
import { ISSUE_TYPES, ISSUE_RULES, REPORT_TYPES, SUGGESTION_KIND } from "../../../src/modules/seo/domain";
import { POLICIES, can, mayApprove } from "../../../src/modules/seo/access";
import { SEO_BLUEPRINT, SEO_CAPABILITIES, registerSeoEmployee } from "../../../src/modules/seo/employee";
import { SEO_DICTIONARIES } from "../../../src/modules/seo/i18n";
import { fromWire, queryObject, toWire } from "../../../src/modules/seo/wire";
import { COLUMNS, TABLE } from "../../../src/modules/seo/columns";
import { notConnectedIntegrations, integrationStatuses } from "../../../src/modules/seo/integrations";
import { HANDOFF_KINDS, SEO_COLLABORATION, SPECIALIST_KEYS } from "../../../src/modules/seo/contracts";
import { actor, setup } from "./helpers";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; });
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "seo");
const bad = (dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "seo"), join(SRC, "app", "(app)", "app", "seo")];

describe("SEO module boundaries (docs/05 section 3)", () => {
  it("never touches Drizzle, the database internals, the kernel/employee internals, the dashboard, the CRM or Marketing", () => {
    expect(bad([MOD], /drizzle-orm|platform\/db|ai-kernel\/|ai-employees\/|platform\/dashboard|components\/dashboard|modules\/crm|modules\/marketing/)).toEqual([]);
  });
  it("reaches the platform only through public entry points", () => {
    const platform = files(MOD).flatMap((f) => imports(f).filter((i) => i.startsWith("@/platform")));
    expect(new Set(platform)).toEqual(new Set(["@/platform/ai-kernel", "@/platform/ai-employees", "@/platform/auth/errors", "@/platform/auth/http", "@/platform/auth/session"]));
  });
  it("only the store layer is aware of SQL; no provider host appears anywhere; only the fetcher performs network calls", () => {
    const sqlFiles = files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f));
    expect(sqlFiles).toEqual(["store-d1.ts"]);
    expect(files(MOD).filter((f) => /api\.openai\.com|api\.anthropic\.com|generativelanguage\.googleapis\.com/.test(readFileSync(f, "utf8")))).toEqual([]);
    expect(files(MOD).filter((f) => /(?<![.\w])fetch\(|\?\? fetch\b|XMLHttpRequest|new WebSocket/.test(readFileSync(f, "utf8").replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, ""))).map((f) => relative(MOD, f)).sort()).toEqual([join("crawl", "fetcher.ts")]);
  });
  it("integrations are interfaces only: nothing is fetched and nothing is faked", async () => {
    const src = readFileSync(join(MOD, "integrations.ts"), "utf8").replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");
    expect(src).not.toMatch(/fetch|https?:\/\//);
    const st = await integrationStatuses("t1");
    expect(st.map((s) => s.key).sort()).toEqual(["bing_webmaster", "google_analytics", "google_search_console", "pagespeed"]);
    expect(st.every((s) => s.state === "not_connected")).toBe(true);
    expect(await notConnectedIntegrations.searchConsole.queryPerformance("t", "p", { from: 0, to: 1 })).toEqual([]);
    expect(await notConnectedIntegrations.pageSpeed.measure("t", "https://x.com", "mobile")).toBeNull();
    expect(await notConnectedIntegrations.searchConsole.indexedPages("t", "p")).toBeNull();
  });
  it("UI uses the module's public interface, never its store or crawler, and never other product modules", () => {
    expect(bad(UI, /platform\/db|drizzle|modules\/seo\/(store|columns|runtime|ai|crawl|audit|employee)|modules\/crm|components\/crm|modules\/marketing|components\/marketing/)).toEqual([]);
  });
  it("platform, CRM, Marketing, Dashboard and Landing code do not know SEO (it joins only through startup registration)", () => {
    const frozen = ["platform/db", "platform/auth", "platform/ai-kernel", "platform/ai-employees", "platform/dashboard", "modules/crm", "modules/marketing", "components/dashboard", "components/crm", "components/marketing", "components/landing", "app/(marketing)"].map((d) => join(SRC, d)).filter((d) => { try { return statSync(d).isDirectory(); } catch { return false; } });
    expect(bad(frozen, /modules\/seo|components\/seo/)).toEqual([]);
    expect(bad([join(SRC, "app", "(app)", "app", "social-media"), join(SRC, "app", "(app)", "app", "crm"), join(SRC, "app", "(app)", "app", "dashboard"), join(SRC, "app", "api", "v1", "marketing"), join(SRC, "app", "api", "v1", "crm")].filter((d) => { try { return statSync(d).isDirectory(); } catch { return false; } }), /modules\/seo|components\/seo/)).toEqual([]);
    const startup = readFileSync(join(SRC, "instrumentation.ts"), "utf8");
    expect(startup).toContain("registerSeoEmployee"); expect(startup).toContain("registerSeoWidget");
  });
  it("client components do not import server-only parts of the module", () => {
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThanOrEqual(4);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/seo$|modules\/seo\/(service|server|http|specialist|employee)/.test(i)))).toEqual([]);
  });
  it("does not add a product module: SEO uses the existing slug and roles", () => {
    expect(MODULES).toHaveLength(26);
    expect(MODULES.filter((m) => m.slug === "seo")).toHaveLength(1);
    expect(readFileSync(join(MOD, "http.ts"), "utf8")).toContain('SEO_SLUG = "seo"');
  });
});

describe("API surface: only /api/v1/seo/*", () => {
  const API = join(SRC, "app", "api", "v1", "seo");
  const routes = files(API).filter((f) => f.endsWith("route.ts"));
  it("exists and every handler goes through seoRoute; every mutating verb enables CSRF checks", () => {
    expect(routes.length).toBeGreaterThanOrEqual(35);
    for (const f of routes) {
      const src = readFileSync(f, "utf8");
      for (const m of src.matchAll(/export const (GET|POST|PATCH|PUT|DELETE) = (\w+)/g)) {
        expect(m[2], `${relative(SRC, f)} ${m[1]}`).toBe("seoRoute");
        const decl = src.slice(src.indexOf(m[0]));
        const end = decl.indexOf("\nexport const", 10) === -1 ? decl.length : decl.indexOf("\nexport const", 10);
        const block = decl.slice(0, end);
        if (m[1] !== "GET") expect(block, `${relative(SRC, f)} ${m[1]}`).toContain("mutating: true");
        else expect(block).not.toContain("mutating");
      }
    }
  });
  it("is the only API this module adds", () => {
    const strays = files(join(SRC, "app", "api")).filter((f) => /modules\/seo/.test(readFileSync(f, "utf8"))).filter((f) => !f.startsWith(API));
    expect(strays).toEqual([]);
  });
});

describe("migration 0300_seo.sql", () => {
  const sql = readFileSync(join(process.cwd(), "drizzle/migrations/0300_seo.sql"), "utf8");
  const tables = [...sql.matchAll(/CREATE TABLE `(seo_\w+)` \(([\s\S]*?)\n\);/g)];
  it("is independent: it only creates seo_* objects and touches nothing else", () => {
    expect(tables).toHaveLength(13);
    expect(Object.values(TABLE).sort()).toEqual(tables.map((t) => t[1]).sort());
    expect(sql).not.toMatch(/ALTER TABLE|DROP |mkt_|crm_|INSERT |UPDATE .* SET|DELETE FROM/);
    for (const o of sql.matchAll(/CREATE (?:UNIQUE )?INDEX `(\w+)`/g)) expect(o[1]).toMatch(/^seo_/);
    for (const o of sql.matchAll(/CREATE TRIGGER (\w+)/g)) expect(o[1]).toMatch(/^seo_/);
  });
  it("every table is tenant-owned (FK to companies with cascade, tenant first in every index)", () => {
    for (const [, name, body] of tables) {
      expect(body, name).toContain("`tenant_id` text NOT NULL");
      expect(body, name).toContain("FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`)");
      for (const ix of sql.matchAll(new RegExp(`CREATE (?:UNIQUE )?INDEX \`\\w+\` ON \`${name}\` \\(([^)]*)\\)`, "g"))) expect(ix[1], name).toMatch(/^`tenant_id`/);
      expect(body, name).toMatch(/CONSTRAINT "\w+_chk" CHECK/);
    }
  });
  it("the audit log, keyword uniqueness and tenant immutability are enforced by the database itself", () => {
    expect(sql).toContain("seo_activity_append_only"); expect(sql).toContain("seo_activity_no_delete");
    for (const t of Object.values(TABLE)) expect(sql, t).toContain(`${t}_tenant_frozen`);
    expect(sql).toMatch(/seo_keywords_site_kw_uq[\s\S]*WHERE `deleted_at` IS NULL/);
    expect(sql).toMatch(/seo_sites_domain_uq[\s\S]*WHERE `deleted_at` IS NULL/);
  });
  it("whitelists cover each kind and carry the tenant column", () => {
    for (const k of Object.keys(TABLE) as (keyof typeof TABLE)[]) { expect(COLUMNS[k]).toContain("id"); expect(COLUMNS[k]).toContain("tenantId"); }
  });
});

describe("permissions", () => {
  it("module access (config/modules.ts) is the outer gate; the policy table only narrows it", () => {
    for (const r of ROLES) {
      const levels = Object.values(POLICIES[r].levels);
      if (!canAccess(r, "seo")) expect(levels.every((l) => l === "none"), r).toBe(true);
      else expect(levels.some((l) => l !== "none"), r).toBe(true);
    }
    expect(can("marketing", "site", "write")).toBe(true); expect(can("marketing", "site", "manage")).toBe(false); expect(can("marketing", "roadmap", "manage")).toBe(false);
    expect(can("manager", "roadmap", "manage")).toBe(true);
  });
  it("four-eyes approval rule", () => {
    expect(mayApprove("manager", "u1", "u1")).toBe(false); expect(mayApprove("manager", "u1", "u2")).toBe(true);
    expect(mayApprove("owner", "u1", "u1")).toBe(true); expect(mayApprove("marketing", "u1", "u2")).toBe(false);
  });
});

let current = setup();
describe("AI SEO Specialist is an AI Employee built on the public framework", () => {
  it("registers one blueprint and its capabilities, all read/draft, restricted to SEO roles; idempotent", async () => {
    registerSeoEmployee(async () => current.svc);
    registerSeoEmployee(async () => setup().svc); // second call is a no-op
    const reg = employeeRegistry();
    expect(reg.blueprint("seo_specialist")).toMatchObject({ key: "seo_specialist", taskClass: "reason", maxAutonomy: 3 });
    expect(SEO_BLUEPRINT.capabilities).toEqual(SEO_CAPABILITIES);
    for (const key of SEO_CAPABILITIES) {
      const c = reg.capability(key);
      expect(c, key).not.toBeNull(); expect(["read", "draft"]).toContain(c?.risk); expect(c?.roles.includes("guest")).toBe(false); expect(c?.roles).toEqual(expect.arrayContaining(["owner", "marketing"]));
      expect(c?.roles.includes("sales")).toBe(false);
    }
    expect(SEO_CAPABILITIES).toEqual(expect.arrayContaining(["seo.run_audit", "seo.suggest_meta", "seo.suggest_schema", "seo.suggest_keywords", "seo.cluster_keywords", "seo.analyze_audit", "seo.create_roadmap", "seo.read_summary"]));
  });
  it("capability handlers act as the agent on behalf of the person, in their tenant", async () => {
    const s = (current = setup());
    const site = await s.svc.sites.create(s.owner, { domain: "example.com" });
    registerSeoEmployee(async () => s.svc);
    const cap = employeeRegistry().capability("seo.run_audit");
    expect(cap).not.toBeNull();
    const ctx = { tenantId: "tenant-one", employeeId: "emp7", taskId: "t1", agent: "agent:emp7", onBehalfOf: { userId: "owner1", role: "owner" as const }, now: 1 };
    const out = (await cap?.handler(ctx, cap.input.parse({ siteId: site.id }))) as { source: string; createdBy: string };
    expect(out).toMatchObject({ source: "employee", createdBy: "agent:emp7" });
    await expect(cap?.handler({ ...ctx, tenantId: "tenant-two" }, { siteId: site.id })).rejects.toMatchObject({ code: "not_found" });
    await expect(cap?.handler({ ...ctx, onBehalfOf: { userId: "u", role: "sales" } }, { siteId: site.id })).rejects.toMatchObject({ code: "forbidden" });
    expect(cap?.input.safeParse({ siteId: site.id, extra: 1 }).success).toBe(false);
  });
  it("collaboration contracts exist and cover the four specialists, with nothing implemented", () => {
    expect([...SPECIALIST_KEYS]).toEqual(["seo_specialist", "marketing_specialist", "crm_specialist", "analytics_specialist"]);
    for (const k of SPECIALIST_KEYS) for (const h of [...SEO_COLLABORATION[k].offers, ...SEO_COLLABORATION[k].asks]) expect(HANDOFF_KINDS).toContain(h);
    const src = readFileSync(join(MOD, "contracts.ts"), "utf8");
    expect(src).not.toMatch(/export (async )?function|export const \w+ = (async )?\(/);
  });
});

describe("wire format and texts", () => {
  it("snake_case and ISO dates on the way out, the reverse on the way in, tenant hidden", () => {
    expect(toWire({ tenantId: "t", siteId: "s", recordedAt: 0, nested: [{ createdAt: 86_400_000, pagesCrawled: 3 }] })).toEqual({ site_id: "s", recorded_at: "1970-01-01T00:00:00.000Z", nested: [{ created_at: "1970-01-02T00:00:00.000Z", pages_crawled: 3 }] });
    expect(fromWire({ site_id: "s", recorded_at: "1970-01-01T00:00:00.000Z" })).toEqual({ siteId: "s", recordedAt: 0 });
    expect(() => queryObject(new URLSearchParams("a=1&a=2"))).toThrow();
  });
  it("Spanish and English have the same keys, no empty texts, and cover every enum shown in the UI", () => {
    const en = SEO_DICTIONARIES.en, es = SEO_DICTIONARIES.es;
    expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort());
    for (const v of [...Object.values(en), ...Object.values(es)]) expect(v.length).toBeGreaterThan(0);
    for (const t of ISSUE_TYPES) expect(en[`type.${t}` as keyof typeof en], t).toBeDefined();
    for (const t of SUGGESTION_KIND) expect(en[`sug.${t}` as keyof typeof en], t).toBeDefined();
    for (const t of REPORT_TYPES) expect(en[`rep.${t}` as keyof typeof en], t).toBeDefined();
    expect(Object.keys(ISSUE_RULES)).toHaveLength(19);
    expect(es["nav.audit"]).not.toBe(en["nav.audit"]);
  });
  it("test helper actors", () => { expect(actor("owner", "u").tenantId).toBe("tenant-one"); });
});
