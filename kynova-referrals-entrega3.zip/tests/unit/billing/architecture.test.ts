import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES, canAccess } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { COLUMNS, TABLE } from "../../../src/modules/billing/columns";
import { POLICIES, can } from "../../../src/modules/billing/access";
import { BILLING_DICTIONARIES } from "../../../src/modules/billing/i18n";
import { ARCHITECTURE_STATUS, notConnectedGateway } from "../../../src/modules/billing/contracts";
import { ENFORCEMENT, METRICS, PROVIDERS, INVOICE_STATUS, CREDIT_TX } from "../../../src/modules/billing/domain";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => { try { return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; }); } catch { return []; } };
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "billing");
const bad = (dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "billing"), join(SRC, "app", "(app)", "app", "billing")];
const strip = (s: string) => s.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");

describe("Billing module boundaries", () => {
  it("never touches Drizzle, database internals, kernel internals or other product modules (CRM only through its public index)", () => {
    expect(bad([MOD], /drizzle-orm|platform\/db|ai-kernel\/|ai-employees\/|platform\/dashboard|components\/dashboard|modules\/(marketing|seo|ai-studio|finance|communications|crm)/)).toEqual([]);
  });
  it("only the store layer knows SQL; no provider host and no network call exist in the module", () => {
    expect(files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f))).toEqual(["store-d1.ts"]);
    expect(files(MOD).filter((f) => /api\.openai\.com|api\.anthropic\.com|api\.stripe\.com|api(-m)?\.paypal\.com|makapay\.(com|io)|coinbase\.com/.test(readFileSync(f, "utf8")))).toEqual([]);
    expect(files(MOD).filter((f) => /(?<![.\w])fetch\(|XMLHttpRequest|new WebSocket|node:https?|node:net/.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
  });
  it("payment providers are contracts: a charge through the default gateway fails and moves no money", async () => {
    expect(await notConnectedGateway.charge({} as never)).toMatchObject({ status: "failed", reason: "gateway_not_connected" });
    expect(Object.values(ARCHITECTURE_STATUS).every((v) => /interface_only|contract_only|manual_confirmation|manual_trigger|advisory_gate/.test(String(v)))).toBe(true);
    expect(PROVIDERS).toEqual(["stripe", "paypal", "bank", "transfer", "crypto", "makapay"]);
  });
  it("UI uses the module's public interface only", () => {
    expect(bad(UI, /platform\/db|drizzle|modules\/billing\/(store|columns|runtime|ai|server)|modules\/(crm|marketing|seo|finance|ai-studio|communications)|components\/(crm|marketing|seo|finance|ai-studio|communications)/)).toEqual([]);
  });
  it("frozen code does not know Billing; it joins through startup registration only", () => {
    const frozen = ["platform/db", "platform/auth", "platform/ai-kernel", "platform/ai-employees", "platform/dashboard", "modules/crm", "modules/marketing", "modules/seo", "modules/ai-studio", "modules/finance", "modules/communications", "components/communications", "components/dashboard", "components/crm", "components/marketing", "components/seo", "components/ai-studio", "components/finance"].map((d) => join(SRC, d));
    expect(bad(frozen, /modules\/billing|components\/billing/)).toEqual([]);
    expect(readFileSync(join(SRC, "instrumentation.ts"), "utf8")).toContain("registerBillingWidget");
  });
  it("registers exactly one widget: billing-overview", () => {
    const w = readFileSync(join(SRC, "components", "billing", "DashboardWidget.tsx"), "utf8");
    expect([...w.matchAll(/registerWidget</g)]).toHaveLength(1); expect(w).toContain('id: "billing-overview"');
  });
  it("client components do not import server-only parts", () => {
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThanOrEqual(5);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/billing$|modules\/billing\/(service|server|http|store|runtime|ai)/.test(i)))).toEqual([]);
  });
  it("adds exactly one product module slug", () => {
    expect(MODULES).toHaveLength(26); expect(MODULES.filter((m) => m.slug === "billing")).toHaveLength(1); expect(MODULES.find((m) => m.slug === "billing")!.roles.sort()).toEqual(["administrator", "ceo", "finance", "owner", "super_admin"]);
    expect(readFileSync(join(MOD, "http.ts"), "utf8")).toContain('BILLING_SLUG = "billing"');
  });
});

describe("API surface: only /api/v1/billing/*", () => {
  const API = join(SRC, "app", "api", "v1", "billing");
  const routes = files(API).filter((f) => f.endsWith("route.ts"));
  it("every handler goes through billingRoute; every mutating verb enables CSRF checks", () => {
    expect(routes.length).toBeGreaterThanOrEqual(50);
    for (const f of routes) {
      const src = readFileSync(f, "utf8");
      for (const m of src.matchAll(/export const (GET|POST|PATCH|PUT|DELETE) = (\w+)/g)) {
        expect(m[2], `${relative(SRC, f)} ${m[1]}`).toBe("billingRoute");
        const decl = src.slice(src.indexOf(m[0])), next = decl.indexOf("\nexport const", 10), block = decl.slice(0, next === -1 ? decl.length : next);
        if (m[1] !== "GET") expect(block, `${relative(SRC, f)} ${m[1]}`).toContain("mutating: true"); else expect(block).not.toContain("mutating");
      }
    }
  });
  it("there is no public, unauthenticated inbound endpoint", () => {
    expect(routes.filter((f) => !readFileSync(f, "utf8").includes("billingRoute"))).toEqual([]);
  });
});

describe("migration 0700_billing.sql", () => {
  const sql = readFileSync(join(process.cwd(), "drizzle/migrations/0700_billing.sql"), "utf8");
  const tables = [...sql.matchAll(/CREATE TABLE `(bill_\w+)` \(([\s\S]*?)\n\);/g)];
  it("creates exactly the 16 bill_* tables and touches nothing else", () => {
    expect(tables).toHaveLength(16);
    expect(Object.values(TABLE).sort()).toEqual(["bill_addons", "bill_coupons", "bill_credit_transactions", "bill_credit_wallet", "bill_discounts", "bill_invoice_items", "bill_invoices", "bill_limits", "bill_notifications", "bill_payment_methods", "bill_payments", "bill_plans", "bill_refunds", "bill_subscriptions", "bill_tax_rates", "bill_usage"]);
    expect(Object.values(TABLE).sort()).toEqual(tables.map((t) => t[1]).sort());
    expect(sql.replace(/^--.*$/gm, "")).not.toMatch(/ALTER TABLE|DROP TABLE|DROP INDEX|REFERENCES `(crm|mkt|seo|ais|fin|com)_|INSERT INTO|DELETE FROM/);
    for (const o of sql.matchAll(/CREATE (?:UNIQUE )?INDEX `(\w+)`/g)) expect(o[1]).toMatch(/^bill_/);
    for (const o of sql.matchAll(/CREATE TRIGGER (\w+)/g)) expect(o[1]).toMatch(/^bill_/);
  });
  it("every table is tenant-owned with cascade and tenant-first indexes", () => {
    for (const [, name, body] of tables) {
      expect(body, name).toContain("`tenant_id` text NOT NULL");
      expect(body, name).toContain("FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`)");
      for (const ix of sql.matchAll(new RegExp(`CREATE (?:UNIQUE )?INDEX \`\\w+\` ON \`${name}\` \\(([^)]*)\\)`, "g"))) expect(ix[1], name).toMatch(/^`tenant_id`/);
    }
  });
  it("the database enforces tenant freezing, append-only ledgers and prepared providers", () => {
    for (const t of Object.values(TABLE)) expect(sql, t).toContain(`${t}_tenant_frozen`);
    expect(sql).toMatch(/_immutable|_no_delete/); expect(sql).toMatch(/'stripe'/); expect(sql).toMatch(/WHERE `deleted_at` IS NULL/);
  });
  it("whitelists cover each kind and carry the tenant column", () => {
    for (const k of Object.keys(TABLE) as (keyof typeof TABLE)[]) { expect(COLUMNS[k]).toContain("id"); expect(COLUMNS[k]).toContain("tenantId"); }
  });
});

describe("permissions and texts", () => {
  it("module access is the outer gate; the policy table only narrows it", () => {
    for (const r of ROLES) {
      const levels = Object.values(POLICIES[r].levels);
      if (!canAccess(r, "billing")) expect(levels.every((l) => l === "none"), r).toBe(true);
      else expect(levels.some((l) => l !== "none"), r).toBe(true);
    }
    expect(can("finance", "plan", "manage")).toBe(false); expect(can("finance", "payment", "manage")).toBe(true); expect(can("ceo", "subscription", "read")).toBe(true); expect(can("ceo", "subscription", "manage")).toBe(false); expect(can("owner", "limit", "manage")).toBe(true); expect(can("sales", "invoice", "read")).toBe(false);
  });
  it("English and Spanish have the same keys, and vocabularies used by the UI have texts", () => {
    const en = BILLING_DICTIONARIES.en as Record<string, string>, es = BILLING_DICTIONARIES.es as Record<string, string>;
    expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort());
    for (const k of METRICS) { expect(en[`metric.${k}`], k).toBeDefined(); }
    for (const k of ENFORCEMENT) expect(en[`enforce.${k}`], k).toBeDefined();
    for (const k of PROVIDERS) expect(en[`provider.${k}`], k).toBeDefined();
    for (const k of INVOICE_STATUS) expect(en[`status.${k}`], k).toBeDefined();
    for (const k of CREDIT_TX) expect(en[`tx.${k}`], k).toBeDefined();
  });
});
