import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES, canAccess } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { COLUMNS, TABLE } from "../../../src/modules/mission-control/columns";
import { MISSION_CONTROL_DICTIONARIES } from "../../../src/modules/mission-control/i18n";
import { ARCHITECTURE_STATUS } from "../../../src/modules/mission-control/contracts";
import { AI_TOPICS, ALERT_STATUS, ANNOUNCEMENT_KINDS, CAPABILITIES, DASHBOARD_CODES, DEFAULT_CAPABILITIES, GOAL_STATUS, HEALTH_STATUS, KPI_CATALOG, NOTIFICATION_CATEGORIES, PRIORITY, REPORT_KINDS, SEVERITY, TASK_STATUS, WIDGET_KINDS } from "../../../src/modules/mission-control/domain";
import { MISSION_CONTROL_BLUEPRINT } from "../../../src/modules/mission-control/employee";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => { try { return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; }); } catch { return []; } };
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "mission-control");
const bad = (dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "mission-control"), join(SRC, "app", "(app)", "app", "mission-control")];
const strip = (s: string) => s.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");

describe("Mission Control module boundaries", () => {
  it("never touches Drizzle, database internals, kernel internals or other product modules", () => {
    expect(bad([MOD], /drizzle-orm|platform\/db|ai-kernel\/|ai-employees\/|platform\/dashboard|components\/dashboard|modules\/(marketing|seo|ai-studio|finance|communications|crm|billing|security|analytics)/)).toEqual([]);
  });
  it("only the store layer knows SQL; no provider host and no network call exist in the module", () => {
    expect(files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f))).toEqual(["store-d1.ts"]);
    expect(files(MOD).filter((f) => /api\.openai\.com|api\.anthropic\.com|smtp\.|sendgrid|mailgun|googleapis\.com|api\.stripe\.com/.test(readFileSync(f, "utf8")))).toEqual([]);
    expect(files(MOD).filter((f) => /(?<![.\w])fetch\(|XMLHttpRequest|new WebSocket|node:https?|node:net/.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
  });
  it("states plainly what it does not do", () => {
    expect(Object.values(ARCHITECTURE_STATUS).length).toBeGreaterThan(0);
  });
  it("UI uses the module's public interface only", () => {
    expect(bad(UI, /platform\/db|drizzle|modules\/mission-control\/(store|columns|runtime|ai|server)|modules\/(crm|marketing|seo|finance|ai-studio|communications|billing|security|analytics)|components\/(crm|marketing|seo|finance|ai-studio|communications|billing|security|analytics)/)).toEqual([]);
  });
  it("frozen code does not know Mission Control; it joins through startup registration only", () => {
    const frozen = ["platform/db", "platform/auth", "platform/ai-kernel", "platform/ai-employees", "platform/dashboard", "modules/crm", "modules/marketing", "modules/seo", "modules/ai-studio", "modules/finance", "modules/communications", "modules/billing", "modules/security"].map((d) => join(SRC, d));
    expect(bad(frozen, /modules\/mission-control|components\/mission-control/)).toEqual([]);
    const ins = readFileSync(join(SRC, "instrumentation.ts"), "utf8"); expect(ins).toContain("registerMissionControlWidget"); expect(ins).toContain("registerMissionControlEmployee");
  });
  it("registers exactly one widget: mission-control-overview", () => {
    const w = readFileSync(join(SRC, "components", "mission-control", "DashboardWidget.tsx"), "utf8");
    expect([...w.matchAll(/registerWidget</g)]).toHaveLength(1); expect(w).toContain('id: "mission-control-overview"');
  });
  it("client components do not import server-only parts", () => {
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThanOrEqual(5);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/mission-control$|modules\/mission-control\/(service|server|http|store|runtime|ai)/.test(i)))).toEqual([]);
  });
  it("adds exactly one product module slug, open to staff", () => {
    expect(MODULES).toHaveLength(26); expect(MODULES.filter((m) => m.slug === "mission-control")).toHaveLength(1);
    expect(readFileSync(join(MOD, "http.ts"), "utf8")).toContain('MISSION_CONTROL_SLUG = "mission-control"');
    expect(canAccess("owner", "mission-control")).toBe(true); expect(canAccess("employee", "mission-control")).toBe(true); expect(canAccess("guest", "mission-control")).toBe(false);
  });
  it("the Mission Control Advisor never executes actions: its blueprint is read only", () => {
    expect(MISSION_CONTROL_BLUEPRINT.maxAutonomy).toBe(1); expect(MISSION_CONTROL_BLUEPRINT.defaultInstructions).toMatch(/never execute/i);
    expect(MISSION_CONTROL_BLUEPRINT.name).toBe("Mission Control Advisor AI"); expect(AI_TOPICS).toHaveLength(8);
    expect(DEFAULT_CAPABILITIES.guest).toHaveLength(0);
    for (const c of MISSION_CONTROL_BLUEPRINT.capabilities) expect(c).toMatch(/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/);
    expect(MISSION_CONTROL_BLUEPRINT.key).toMatch(/^[a-z][a-z0-9_]*$/);
  });
});

describe("API surface: only /api/v1/mission-control/*", () => {
  const API = join(SRC, "app", "api", "v1", "mission-control");
  const routes = files(API).filter((f) => f.endsWith("route.ts"));
  it("every handler goes through missionControlRoute; every mutating verb enables CSRF checks", () => {
    expect(routes.length).toBeGreaterThanOrEqual(40);
    for (const f of routes) {
      const src = readFileSync(f, "utf8");
      for (const m of src.matchAll(/export const (GET|POST|PATCH|PUT|DELETE) = (\w+)/g)) {
        expect(m[2], `${relative(SRC, f)} ${m[1]}`).toBe("missionControlRoute");
        const decl = src.slice(src.indexOf(m[0])), next = decl.indexOf("\nexport const", 10), block = decl.slice(0, next === -1 ? decl.length : next);
        if (m[1] !== "GET") expect(block, `${relative(SRC, f)} ${m[1]}`).toContain("mutating: true"); else expect(block).not.toContain("mutating");
      }
    }
  });
  it("there is no public inbound endpoint and no outbound call", () => {
    expect(routes.filter((f) => !readFileSync(f, "utf8").includes("missionControlRoute"))).toEqual([]);
    expect(routes.filter((f) => /fetch\(/.test(readFileSync(f, "utf8")))).toEqual([]);
  });
  it("covers every section and action", () => {
    const rel = new Set(routes.map((f) => relative(API, f).replace(/\/?route\.ts$/, "")));
    for (const p of ["setup", "summary", "overview", "permissions/mine", "dashboards", "dashboards/[id]/view", "widgets/[id]", "kpis", "kpis/[id]/record", "goals", "goals/evaluate", "tasks", "alerts", "alerts/[id]/acknowledge", "alerts/[id]/resolve", "alerts/[id]/dismiss", "notifications", "notifications/read-all", "notifications/unread", "announcements", "activity", "activity/verify", "health", "health/history", "favorites", "recent", "shortcuts", "reports", "reports/[id]/download", "settings", "ai/recommendations", "ai/[id]"]) expect(rel.has(p), p).toBe(true);
  });
});

describe("pages", () => {
  it("has the 16 views", () => {
    const base = join(SRC, "app", "(app)", "app", "mission-control"), pages = new Set(files(base).filter((f) => f.endsWith("page.tsx")).map((f) => relative(base, f).replace(/\/?page\.tsx$/, "")));
    expect([...pages].sort()).toEqual(["", "activity", "alerts", "announcements", "favorites", "goals", "health", "kpis", "notifications", "recent", "recommendations", "reports", "reports/[id]", "settings", "shortcuts", "tasks", "widgets"]);
  });
});

describe("migration 0900_mission_control.sql", () => {
  const sql = readFileSync(join(process.cwd(), "drizzle/migrations/0900_mission_control.sql"), "utf8");
  const tables = [...sql.matchAll(/CREATE TABLE `(mc_\w+)` \(([\s\S]*?)\n\);/g)];
  it("creates exactly the 16 mc_* tables and touches nothing else", () => {
    expect(tables).toHaveLength(16);
    expect(Object.values(TABLE).sort()).toEqual(tables.map((t) => t[1]).sort());
    for (const n of ["dashboards", "widgets", "notifications", "alerts", "announcements", "kpis", "goals", "tasks", "activity", "ai_recommendations", "favorites", "recent_items", "shortcuts", "reports", "health", "settings"]) expect(Object.values(TABLE)).toContain(`mc_${n}`);
    expect(sql.replace(/^--.*$/gm, "")).not.toMatch(/ALTER TABLE|DROP TABLE|DROP INDEX|INSERT INTO|DELETE FROM/);
    for (const o of sql.matchAll(/CREATE (?:UNIQUE )?INDEX `(\w+)`/g)) expect(o[1]).toMatch(/^mc_/);
    for (const o of sql.matchAll(/CREATE TRIGGER (\w+)/g)) expect(o[1]).toMatch(/^mc_/);
  });
  it("every table is tenant-owned with cascade and tenant-first indexes", () => {
    for (const [, name, body] of tables) {
      expect(body, name).toContain("`tenant_id` text NOT NULL");
      expect(body, name).toContain("FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`)");
      for (const ix of sql.matchAll(new RegExp(`CREATE (?:UNIQUE )?INDEX \`\\w+\` ON \`${name}\` \\(([^)]*)\\)`, "g"))) expect(ix[1], name).toMatch(/^`tenant_id`/);
    }
  });
  it("the database enforces tenant freezing and append-only ledgers", () => {
    for (const t of Object.values(TABLE)) expect(sql, t).toContain(`${t}_tenant_frozen`);
    for (const t of ["activity", "reports", "health"]) { expect(sql).toContain(`mc_${t}_immutable`); expect(sql).toContain(`mc_${t}_no_delete`); }
  });
  it("whitelists cover each kind and carry the tenant column", () => {
    for (const k of Object.keys(TABLE) as (keyof typeof TABLE)[]) { expect(COLUMNS[k]).toContain("id"); expect(COLUMNS[k]).toContain("tenantId"); }
  });
});

describe("catalog, capabilities and texts", () => {
  it("the catalog covers the specified sections", () => {
    expect(DASHBOARD_CODES).toHaveLength(2); expect(WIDGET_KINDS).toHaveLength(14); expect(KPI_CATALOG.length).toBe(17); expect(REPORT_KINDS).toHaveLength(4); expect(CAPABILITIES).toHaveLength(11);
  });
  it("module access is the outer gate; default capabilities only narrow it", () => {
    for (const r of ROLES) { if (!canAccess(r, "mission-control")) expect(DEFAULT_CAPABILITIES[r].length, r).toBe(0); else expect(DEFAULT_CAPABILITIES[r].includes("view"), r).toBe(true); }
    expect(DEFAULT_CAPABILITIES.owner).toHaveLength(CAPABILITIES.length);
  });
  it("English and Spanish have the same keys, and every vocabulary used by the UI has texts", () => {
    const en = MISSION_CONTROL_DICTIONARIES.en as Record<string, string>, es = MISSION_CONTROL_DICTIONARIES.es as Record<string, string>;
    expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort());
    const groups: [string, readonly string[]][] = [["sev", SEVERITY], ["ast", ALERT_STATUS], ["nc", NOTIFICATION_CATEGORIES], ["ann", ANNOUNCEMENT_KINDS], ["prio", PRIORITY], ["ts", TASK_STATUS], ["gs", GOAL_STATUS], ["hs", HEALTH_STATUS], ["rk", REPORT_KINDS], ["wk", WIDGET_KINDS], ["topic", AI_TOPICS], ["cap", CAPABILITIES], ["dashname", DASHBOARD_CODES], ["role", ROLES], ["kpi", KPI_CATALOG.map((k) => k.code)]];
    for (const [p, list] of groups) for (const k of list) expect(en[`${p}.${k}`], `${p}.${k}`).toBeDefined();
    for (const [k, v] of Object.entries(es)) expect(v.trim(), k).not.toBe("");
  });
});
