import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES, canAccess } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { COLUMNS, TABLE } from "../../../src/modules/communications/columns";
import { POLICIES, can } from "../../../src/modules/communications/access";
import { COMMS_DICTIONARIES } from "../../../src/modules/communications/i18n";
import { ARCHITECTURE_STATUS, notConnectedSender } from "../../../src/modules/communications/contracts";
import { CHANNEL_KINDS, INTENTS, SENTIMENTS, WEBHOOK_EVENTS } from "../../../src/modules/communications/domain";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => { try { return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; }); } catch { return []; } };
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "communications");
const bad = (dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "communications"), join(SRC, "app", "(app)", "app", "communications")];
const strip = (s: string) => s.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");

describe("Communications module boundaries", () => {
  it("never touches Drizzle, database internals, kernel internals or other product modules (CRM only through its public index)", () => {
    expect(bad([MOD], /drizzle-orm|platform\/db|ai-kernel\/|ai-employees\/|platform\/dashboard|components\/dashboard|modules\/(marketing|seo|ai-studio|finance)/)).toEqual([]);
    expect(files(MOD).flatMap((f) => imports(f).filter((i) => /modules\/crm\//.test(i)))).toEqual([]);
  });
  it("only the store layer knows SQL; no provider host and no network call exist in the module", () => {
    expect(files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f))).toEqual(["store-d1.ts"]);
    expect(files(MOD).filter((f) => /api\.openai\.com|api\.anthropic\.com|graph\.facebook\.com|api\.telegram\.org|slack\.com\/api/.test(readFileSync(f, "utf8")))).toEqual([]);
    expect(files(MOD).filter((f) => /(?<![.\w])fetch\(|XMLHttpRequest|new WebSocket|node:https?|node:net/.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
  });
  it("channel connectors are contracts that report 'not connected'", async () => {
    expect(await notConnectedSender.send({} as never, {} as never)).toMatchObject({ status: "queued", reason: "channel_not_connected" });
    expect(Object.values(ARCHITECTURE_STATUS).every((v) => /interface_only|contract_only|prepared/.test(String(v)))).toBe(true);
  });
  it("UI uses the module's public interface only", () => {
    expect(bad(UI, /platform\/db|drizzle|modules\/communications\/(store|columns|runtime|ai|server)|modules\/(crm|marketing|seo|finance|ai-studio)|components\/(crm|marketing|seo|finance|ai-studio)/)).toEqual([]);
  });
  it("frozen code does not know Communications; it joins through startup registration only", () => {
    const frozen = ["platform/db", "platform/auth", "platform/ai-kernel", "platform/ai-employees", "platform/dashboard", "modules/crm", "modules/marketing", "modules/seo", "modules/ai-studio", "modules/finance", "components/dashboard", "components/crm", "components/marketing", "components/seo", "components/ai-studio", "components/finance"].map((d) => join(SRC, d));
    expect(bad(frozen, /modules\/communications|components\/communications/)).toEqual([]);
    expect(readFileSync(join(SRC, "instrumentation.ts"), "utf8")).toContain("registerCommsWidget");
  });
  it("registers exactly one widget: communications-overview", () => {
    const w = readFileSync(join(SRC, "components", "communications", "DashboardWidget.tsx"), "utf8");
    expect([...w.matchAll(/registerWidget</g)]).toHaveLength(1); expect(w).toContain('id: "communications-overview"');
  });
  it("client components do not import server-only parts", () => {
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThanOrEqual(8);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/communications$|modules\/communications\/(service|server|http|store|runtime|ai)/.test(i)))).toEqual([]);
  });
  it("adds exactly one product module slug", () => {
    expect(MODULES).toHaveLength(26); expect(MODULES.filter((m) => m.slug === "communications")).toHaveLength(1);
    expect(readFileSync(join(MOD, "http.ts"), "utf8")).toContain('COMMS_SLUG = "communications"');
  });
});

describe("API surface: only /api/v1/communications/*", () => {
  const API = join(SRC, "app", "api", "v1", "communications");
  const routes = files(API).filter((f) => f.endsWith("route.ts"));
  it("every handler goes through commsRoute; every mutating verb enables CSRF checks", () => {
    expect(routes.length).toBeGreaterThanOrEqual(30);
    for (const f of routes) {
      const src = readFileSync(f, "utf8");
      for (const m of src.matchAll(/export const (GET|POST|PATCH|PUT|DELETE) = (\w+)/g)) {
        expect(m[2], `${relative(SRC, f)} ${m[1]}`).toBe("commsRoute");
        const decl = src.slice(src.indexOf(m[0])), next = decl.indexOf("\nexport const", 10), block = decl.slice(0, next === -1 ? decl.length : next);
        if (m[1] !== "GET") expect(block, `${relative(SRC, f)} ${m[1]}`).toContain("mutating: true"); else expect(block).not.toContain("mutating");
      }
    }
  });
  it("there is no public, unauthenticated inbound endpoint", () => {
    expect(routes.filter((f) => !readFileSync(f, "utf8").includes("commsRoute"))).toEqual([]);
  });
});

describe("migration 0600_communications.sql", () => {
  const sql = readFileSync(join(process.cwd(), "drizzle/migrations/0600_communications.sql"), "utf8");
  const tables = [...sql.matchAll(/CREATE TABLE `(com_\w+)` \(([\s\S]*?)\n\);/g)];
  it("creates exactly the 12 com_* tables and touches nothing else", () => {
    expect(tables).toHaveLength(12);
    expect(Object.values(TABLE).sort()).toEqual(["com_accounts", "com_ai_sessions", "com_assignments", "com_attachments", "com_channels", "com_conversations", "com_events", "com_labels", "com_messages", "com_participants", "com_templates", "com_webhooks"]);
    expect(Object.values(TABLE).sort()).toEqual(tables.map((t) => t[1]).sort());
    expect(sql.replace(/^--.*$/gm, "")).not.toMatch(/ALTER TABLE|DROP |REFERENCES `(crm|mkt|seo|ais|fin)_|INSERT |DELETE FROM/);
    for (const o of sql.matchAll(/CREATE (?:UNIQUE )?INDEX `(\w+)`/g)) expect(o[1]).toMatch(/^com_/);
    for (const o of sql.matchAll(/CREATE TRIGGER (\w+)/g)) expect(o[1]).toMatch(/^com_/);
  });
  it("every table is tenant-owned with cascade and tenant-first indexes", () => {
    for (const [, name, body] of tables) {
      expect(body, name).toContain("`tenant_id` text NOT NULL");
      expect(body, name).toContain("FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`)");
      for (const ix of sql.matchAll(new RegExp(`CREATE (?:UNIQUE )?INDEX \`\\w+\` ON \`${name}\` \\(([^)]*)\\)`, "g"))) expect(ix[1], name).toMatch(/^`tenant_id`/);
    }
  });
  it("the database enforces tenant freezing, append-only history and prepared channels", () => {
    for (const t of Object.values(TABLE)) expect(sql, t).toContain(`${t}_tenant_frozen`);
    expect(sql).toMatch(/telegram.*slack.*teams|'telegram'/s); expect(sql).toMatch(/WHERE `deleted_at` IS NULL/);
  });
  it("whitelists cover each kind and carry the tenant column", () => {
    for (const k of Object.keys(TABLE) as (keyof typeof TABLE)[]) { expect(COLUMNS[k]).toContain("id"); expect(COLUMNS[k]).toContain("tenantId"); }
  });
});

describe("permissions and texts", () => {
  it("module access is the outer gate; the policy table only narrows it", () => {
    for (const r of ROLES) {
      const levels = Object.values(POLICIES[r].levels);
      if (!canAccess(r, "communications")) expect(levels.every((l) => l === "none"), r).toBe(true);
      else expect(levels.some((l) => l !== "none"), r).toBe(true);
    }
    expect(can("sales", "channel", "manage")).toBe(false); expect(can("sales", "conversation", "write")).toBe(true);
    expect(can("owner", "automation", "manage")).toBe(true); expect(can("sales", "automation", "manage")).toBe(false); expect(can("guest", "conversation", "read")).toBe(false);
  });
  it("English and Spanish have the same keys, and vocabularies used by the UI have texts", () => {
    const en = COMMS_DICTIONARIES.en as Record<string, string>, es = COMMS_DICTIONARIES.es as Record<string, string>;
    expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort());
    for (const k of CHANNEL_KINDS) expect(en[`kind.${k}`], k).toBeDefined();
    for (const k of SENTIMENTS) expect(en[`sent.${k}`], k).toBeDefined();
    for (const k of INTENTS) expect(en[`intent.${k}`], k).toBeDefined();
    expect(WEBHOOK_EVENTS.length).toBeGreaterThan(0);
  });
});
