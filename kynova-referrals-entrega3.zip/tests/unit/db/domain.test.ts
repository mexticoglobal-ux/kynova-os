import { describe, expect, it } from "vitest";
import { ROLES, type Role } from "@/config/roles";
import { canGrant, canManageMembers } from "@/platform/db/catalog/roles";
import { DomainError, isDomainError, mapDbError } from "@/platform/db/errors";
import { slugify } from "@/platform/db/slug";
import { PLAN_DEFS, businessModuleSlugs } from "@/platform/db/catalog/plans";
import { MODULES } from "@/config/modules";

describe("grant hierarchy (docs/08 4.1)", () => {
  it("Owner grants any tenant role but never super_admin", () => {
    for (const r of ROLES.filter((r) => r !== "super_admin")) expect(canGrant("owner", r)).toBe(true);
    expect(canGrant("owner", "super_admin")).toBe(false);
  });
  it("Administrator grants Manager and below only", () => {
    for (const r of ["manager", "marketing", "sales", "finance", "hr", "support", "employee", "guest"] as Role[]) expect(canGrant("administrator", r)).toBe(true);
    for (const r of ["owner", "ceo", "administrator", "super_admin"] as Role[]) expect(canGrant("administrator", r)).toBe(false);
  });
  it("only Owner, Administrator and Super Admin manage members", () => {
    expect(ROLES.filter(canManageMembers).sort()).toEqual(["administrator", "owner", "super_admin"]);
    for (const r of ["ceo", "manager", "marketing", "sales", "finance", "hr", "support", "employee", "guest"] as Role[]) expect(canGrant(r, "guest")).toBe(false);
  });
});

describe("error mapping", () => {
  const nested = (msg: string) => Object.assign(new Error("Failed query"), { cause: Object.assign(new Error(`D1_ERROR: ${msg}: SQLITE_CONSTRAINT`), {}) });
  it("maps SQLite and trigger messages, including nested causes, to typed codes", () => {
    expect(mapDbError(nested("UNIQUE constraint failed: companies.slug"))?.code).toBe("slug_taken");
    expect(mapDbError(nested("UNIQUE constraint failed: users.email"))?.code).toBe("email_taken");
    expect(mapDbError(nested("a company must keep at least one active owner"))?.code).toBe("last_owner");
    expect(mapDbError(nested("role does not belong to this company"))?.code).toBe("role_not_in_company");
    expect(mapDbError(nested("audit_logs is append-only"))?.code).toBe("append_only");
    expect(mapDbError(nested("FOREIGN KEY constraint failed"))?.code).toBe("conflict");
    expect(mapDbError(new Error("something else"))).toBeNull();
  });
  it("recognizes domain errors by brand, not instanceof", () => {
    expect(isDomainError(new DomainError("not_found", "x"))).toBe(true);
    expect(isDomainError({ __kynovaDomainError: true })).toBe(true);
    expect(isDomainError(new Error("x"))).toBe(false);
  });
});

describe("catalog definitions", () => {
  it("slugify is safe and bounded", () => {
    expect(slugify("Café Niño & Co.")).toBe("cafe-nino-co");
    expect(slugify("!!!")).toBe("company");
    expect(slugify("x".repeat(100)).length).toBeLessThanOrEqual(40);
  });
  it("plans only reference registered business modules and grow monotonically", () => {
    const business = new Set(businessModuleSlugs());
    for (const p of PLAN_DEFS) for (const m of p.modules) expect(business.has(m), `${p.code} -> ${m}`).toBe(true);
    const size = (c: string) => PLAN_DEFS.find((p) => p.code === c)!.modules.length;
    expect(size("starter")).toBeLessThan(size("professional"));
    expect(size("professional")).toBeLessThan(size("business"));
    expect(MODULES.length).toBe(26);
  });
});
