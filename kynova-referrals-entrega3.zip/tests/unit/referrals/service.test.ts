import { describe, expect, it } from "vitest";
import { AGENT, EMP, FIN, GUEST, MKT, OTHER, OWNER, Q, SALES, code, converted, link, ready, setup } from "./helpers";

describe("setup and access", () => {
  it("sets up once and refuses a second run", async () => {
    const h = setup(); expect((await h.svc.setup.status(OWNER)).initialized).toBe(false); await h.svc.setup.initialize(OWNER);
    expect(await code(h.svc.setup.initialize(OWNER))).toBe("invalid_state");
  });
  it("roles and AI employees are limited; tenants never see each other", async () => {
    const h = await ready(setup());
    expect(await code(h.svc.links.create(MKT, { slug: "mk-link", referrerName: "Mk" }))).toBe("ok");
    expect(await code(h.svc.links.create(SALES, { slug: "sl-link", referrerName: "Sl" }))).toBe("forbidden");
    expect(await code(h.svc.links.create(GUEST, { slug: "gs-link", referrerName: "Gs" }))).toBe("forbidden");
    expect(await code(h.svc.links.create({ ...OWNER, agentId: "agent-1" }, { slug: "ag-link", referrerName: "Ag" }))).toBe("forbidden");
    expect(await code(h.svc.rewards.list(MKT, Q()))).toBe("forbidden"); expect(await code(h.svc.rewards.list(EMP, Q()))).toBe("forbidden");
    expect((await h.svc.links.list(AGENT, Q())).items.length).toBe(1);
    expect((await h.svc.links.list(OTHER, Q())).items).toEqual([]);
  });
  it("rejects a bad body with validation_failed and a duplicate code with a field error", async () => {
    const h = await ready(setup()); expect(await code(h.svc.links.create(OWNER, { slug: "A B", referrerName: "" }))).toBe("validation_failed");
    await link(h, "same-code"); expect(await code(link(h, "same-code"))).toBe("validation_failed");
  });
});

describe("referrals", () => {
  it("a person can be referred only once, whatever the case of the email, and cannot refer themselves", async () => {
    const h = await ready(setup()), l1 = await link(h, "one", OWNER, { referrerEmail: "boss@x.test" }), l2 = await link(h, "two");
    await h.svc.referrals.submit(OWNER, { linkId: l1.id, referredName: "Ana", referredEmail: "ana@x.test" });
    expect(await code(h.svc.referrals.submit(OWNER, { linkId: l2.id, referredName: "Ana B", referredEmail: " ANA@x.test " }))).toBe("invalid_state");
    expect(await code(h.svc.referrals.submit(OWNER, { linkId: l1.id, referredName: "Boss", referredEmail: "Boss@x.test" }))).toBe("validation_failed");
  });
  it("a rejected referral frees the person; a converted one keeps them reserved", async () => {
    const h = await ready(setup()), l = await link(h, "free"), r = await h.svc.referrals.submit(OWNER, { linkId: l.id, referredName: "Bea", referredEmail: "bea@x.test" });
    await h.svc.referrals.reject(OWNER, r.id, { reason: "spam" }); expect(await code(h.svc.referrals.submit(OWNER, { linkId: l.id, referredName: "Bea", referredEmail: "bea@x.test" }))).toBe("ok");
    const c = await converted(h, "kept", "cy@x.test"); expect(await code(h.svc.referrals.submit(OWNER, { linkId: c.link.id, referredName: "Cy", referredEmail: "cy@x.test" }))).toBe("invalid_state");
  });
  it("only an active link receives referrals; stages move forward only", async () => {
    const h = await ready(setup()), l = await link(h, "paused-one"); await h.svc.links.pause(OWNER, l.id);
    expect(await code(h.svc.referrals.submit(OWNER, { linkId: l.id, referredName: "Di", referredEmail: "di@x.test" }))).toBe("invalid_state");
    await h.svc.links.resume(OWNER, l.id); const r = await h.svc.referrals.submit(OWNER, { linkId: l.id, referredName: "Di", referredEmail: "di@x.test" });
    await h.svc.referrals.qualify(OWNER, r.id); expect(await code(h.svc.referrals.qualify(OWNER, r.id))).toBe("invalid_state");
    await h.svc.referrals.convert(OWNER, r.id); expect(await code(h.svc.referrals.reject(OWNER, r.id))).toBe("invalid_state"); expect(await code(h.svc.referrals.convert(OWNER, r.id))).toBe("invalid_state");
  });
});

describe("rewards", () => {
  it("converting creates exactly one pending reward with the configured amount", async () => {
    const h = await ready(setup()), c = await converted(h, "rw-a", "rw@x.test", 100_000);
    expect([c.reward.amountCents, c.reward.status, c.reward.mode]).toEqual([5000, "pending", "not_connected"]);
    await h.svc.settings.update(OWNER, { rewardKind: "percent", rewardBps: 1500 }); const d = await converted(h, "rw-b", "rw2@x.test", 100_000); expect(d.reward.amountCents).toBe(15_000);
  });
  it("approve → pay is simulated and moves no money; paid rewards cannot be reversed", async () => {
    const h = await ready(setup()), c = await converted(h, "pay", "pay@x.test");
    expect(await code(h.svc.rewards.pay(OWNER, c.reward.id))).toBe("invalid_state");
    await h.svc.rewards.approve(OWNER, c.reward.id); const p = await h.svc.rewards.pay(OWNER, c.reward.id); expect([p.status, p.mode]).toEqual(["paid", "simulated"]);
    expect(await code(h.svc.rewards.reverse(OWNER, c.reward.id))).toBe("invalid_state");
    const d = await converted(h, "rv-a", "rv@x.test"); expect((await h.svc.rewards.reverse(OWNER, d.reward.id)).status).toBe("reversed");
  });
  it("finance approves; marketing cannot see money", async () => {
    const h = await ready(setup()), c = await converted(h, "fin", "fin@x.test");
    expect(await code(h.svc.rewards.approve(FIN, c.reward.id))).toBe("ok"); expect(await code(h.svc.rewards.approve(MKT, c.reward.id))).toBe("forbidden");
    expect((await h.svc.summary(MKT)).pendingCents).toBeNull(); expect((await h.svc.summary(FIN)).approvedCents).toBe(5000);
  });
  it("summary counts stages and the conversion rate", async () => {
    const h = await ready(setup()); await converted(h, "s1-a", "s1@x.test"); const l = await link(h, "s2-a"), r = await h.svc.referrals.submit(OWNER, { linkId: l.id, referredName: "Nu", referredEmail: "n@x.test" }); await h.svc.referrals.reject(OWNER, r.id);
    const s = await h.svc.summary(OWNER); expect([s.converted, s.rejected, s.conversionRate]).toEqual([1, 1, 50]);
  });
});

describe("activity evidence", () => {
  it("important mutations leave events without sensitive data", async () => {
    const h = await ready(setup()), c = await converted(h, "evi", "evi@x.test"); await h.svc.rewards.approve(OWNER, c.reward.id);
    expect(h.events.map((e) => e.action)).toEqual(expect.arrayContaining(["referrals.program.initialized", "referrals.link.created", "referrals.referral.submitted", "referrals.referral.converted", "referrals.reward.approved"]));
    expect(JSON.stringify(h.events)).not.toContain("evi@x.test");
  });
});
