import { describe, expect, it } from "vitest";
import { emailKey, rewardAmount } from "../../../src/modules/referrals/compute";

describe("referrals compute", () => {
  it("fixed rewards ignore the value; percentage rewards round half up in cents", () => {
    const fixed = { rewardKind: "fixed", rewardFixedCents: 5000, rewardBps: 1000 } as const, pct = { rewardKind: "percent", rewardFixedCents: 0, rewardBps: 1500 } as const;
    expect(rewardAmount(fixed, 0)).toBe(5000); expect(rewardAmount(fixed, 999_999)).toBe(5000);
    expect(rewardAmount(pct, 100_000)).toBe(15_000); expect(rewardAmount(pct, 999)).toBe(150); expect(rewardAmount(pct, 0)).toBe(0);
  });
  it("normalizes emails", () => { expect(emailKey("  Ana@Example.COM ")).toBe("ana@example.com"); });
});
