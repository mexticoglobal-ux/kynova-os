import { describe, expect, it } from "vitest";
import { createActivityService } from "../../../src/platform/activity/service";
import { createMemoryActivityStore } from "../../../src/platform/activity/store-memory";
import { registerReferralsReverters } from "../../../src/modules/referrals/reverters";
import { OWNER, START, converted, link, ready, setup } from "./helpers";

describe("Referrals undo through the Activity Engine", () => {
  it("resumes a paused link and returns an approved reward to pending", async () => {
    const h = await ready(setup()); registerReferralsReverters(async () => h.svc);
    let n = 0; const act = createActivityService({ store: createMemoryActivityStore(), newId: () => `ev${++n}`, now: () => START });
    const log = (action: string, hint: Record<string, unknown>) => act.record(OWNER, { module: "referrals", action, summary: action, reversible: true, revertHint: hint });
    const l = await link(h, "undo"); await h.svc.links.pause(OWNER, l.id); const e1 = await log("referrals.link.paused", { linkId: l.id }); await act.revert(OWNER, e1.event.id);
    expect((await h.svc.links.get(OWNER, l.id)).link.status).toBe("active");
    const c = await converted(h, "undo2", "u@x.test"); await h.svc.rewards.approve(OWNER, c.reward.id); const e2 = await log("referrals.reward.approved", { rewardId: c.reward.id }); await act.revert(OWNER, e2.event.id);
    expect((await h.svc.rewards.get(OWNER, c.reward.id)).status).toBe("pending");
  });
});
