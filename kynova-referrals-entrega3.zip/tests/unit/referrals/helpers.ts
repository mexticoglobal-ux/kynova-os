import type { Role } from "@/config/roles";
import { createMemoryReferralsStore } from "../../../src/modules/referrals/store-memory";
import type { ReferralsStore } from "../../../src/modules/referrals/store";
import { createReferralsService, type Actor, type ReferralsService } from "../../../src/modules/referrals/service";
import type { ActivitySink, SinkEvent } from "../../../src/platform/activity";

export const T1 = "tenant-one", T2 = "tenant-two";
export const DAY = 86_400_000;
export const START = Date.UTC(2026, 9, 20, 12);
export const actor = (role: Role, userId: string, tenantId = T1): Actor => ({ tenantId, userId, role });
export const Q = (o: Record<string, unknown> = {}) => ({ limit: 25, ...o }) as never;
export const code = async (p: Promise<unknown>) => { try { await p; return "ok"; } catch (e) { return (e as { code?: string }).code ?? `other:${(e as Error).message}`; } };
export const OWNER = actor("owner", "owner-1"), SALES = actor("sales", "sales-1"), FIN = actor("finance", "fin-1"), MKT = actor("marketing", "mkt-1"), EMP = actor("employee", "emp-1"), GUEST = actor("guest", "guest-1"), OTHER = actor("owner", "owner-2", T2);
export const AGENT: Actor = { ...OWNER, agentId: "agent-1" };

export function memorySink() {
  const events: SinkEvent[] = [];
  const sink: ActivitySink = {
    async record(_c, e) { events.push(e); return { ok: true, duplicate: false, event: {} as never }; },
    async recordStrict(_c, e) { events.push(e); return { duplicate: false, event: {} as never }; },
  };
  return { sink, events };
}
export interface Harness { svc: ReferralsService; clock: { t: number }; store: ReferralsStore; events: SinkEvent[] }
export function setup(o: { store?: ReferralsStore } = {}): Harness {
  const clock = { t: START }, m = memorySink(), salt = crypto.randomUUID().slice(0, 8); let n = 0;
  const store = o.store ?? createMemoryReferralsStore();
  const svc = createReferralsService({ store, newId: () => `id${salt}${String(++n).padStart(6, "0")}`, now: () => clock.t, activity: m.sink });
  return { svc, clock, store, events: m.events };
}
export async function ready(h: Harness, a: Actor = OWNER) { await h.svc.setup.initialize(a); return h; }
export async function link(h: Harness, slug: string, a: Actor = OWNER, over: Record<string, unknown> = {}) { return h.svc.links.create(a, { slug, referrerName: `Referrer ${slug}`, ...over }); }
/** A converted referral (and its pending reward). */
export async function converted(h: Harness, slug: string, email: string, valueCents = 100_000, a: Actor = OWNER) {
  const l = await link(h, slug, a), r = await h.svc.referrals.submit(a, { linkId: l.id, referredName: `Person ${slug}`, referredEmail: email, valueCents });
  return { link: l, ...(await h.svc.referrals.convert(a, r.id)) };
}
