import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { COLUMNS, TABLE } from "../../../src/modules/referrals/columns";
import { createD1ReferralsStore } from "../../../src/modules/referrals/store-d1";
import type { ReferralsStore } from "../../../src/modules/referrals/store";
import type { Actor } from "../../../src/modules/referrals/service";
import { createTestDb, newCompany, newUser } from "../db/helpers";
import { Q, code, converted, link, ready, setup } from "../../unit/referrals/helpers";

let t: Awaited<ReturnType<typeof createTestDb>>;
let store: ReferralsStore, A: Actor, B: Actor;
const fresh = async (): Promise<Actor> => { const u = await newUser(t.db), c = await newCompany(t.db, u.id); return { tenantId: c.companyId, userId: u.id, role: "owner" }; };
const h = () => setup({ store });
const snake = (s: string) => s.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
const refused = async (p: Promise<unknown>) => { try { await p; return "no error"; } catch { return "refused"; } };

beforeAll(async () => {
  t = await createTestDb(); store = createD1ReferralsStore(t.d1);
  const [o, ob] = [await newUser(t.db), await newUser(t.db)];
  const a = await newCompany(t.db, o.id), b = await newCompany(t.db, ob.id);
  A = { tenantId: a.companyId, userId: o.id, role: "owner" }; B = { tenantId: b.companyId, userId: ob.id, role: "owner" };
}, 60_000);
afterAll(async () => { await t.dispose(); });

describe("schema contract", () => {
  it("every whitelisted column exists in the migration, and every column is whitelisted", async () => {
    for (const [kind, table] of Object.entries(TABLE)) {
      const info = (await t.d1.prepare(`PRAGMA table_info(${table})`).all<{ name: string }>()).results.map((c) => c.name).sort();
      expect(COLUMNS[kind as keyof typeof COLUMNS].map(snake).sort(), table).toEqual(info);
    }
  });
});

describe("the service on D1", () => {
  it("runs the whole flow with real constraints: link, refer, protect, convert, approve, pay (simulated)", async () => {
    const A = await fresh(), x = h(); await ready(x, A);
    const l = await link(x, "d1-link", A), l2 = await link(x, "d1-link-two", A);
    const r = await x.svc.referrals.submit(A, { linkId: l.id, referredName: "Grupo Arya", referredEmail: "arya@x.test", valueCents: 100_000 });
    expect(await code(x.svc.referrals.submit(A, { linkId: l2.id, referredName: "Otra", referredEmail: "ARYA@x.test" }))).toBe("invalid_state");
    const c = await x.svc.referrals.convert(A, r.id); expect([c.reward.amountCents, c.reward.status]).toEqual([5000, "pending"]);
    await x.svc.rewards.approve(A, c.reward.id); const paid = await x.svc.rewards.pay(A, c.reward.id); expect([paid.status, paid.mode]).toEqual(["paid", "simulated"]);
    expect((await x.svc.summary(A)).paidCents).toBe(5000);
  });
  it("the database refuses what the service would never do", async () => {
    const A = await fresh(), B = await fresh(), x = h(); await ready(x, A); const c = await converted(x, "d1-guard", "g@x.test", 10_000, A);
    expect(await refused(t.d1.prepare("UPDATE rf_rewards SET amount_cents = 1 WHERE id = ?").bind(c.reward.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE rf_rewards SET tenant_id = ? WHERE id = ?").bind(B.tenantId, c.reward.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("DELETE FROM rf_links WHERE id = ?").bind(c.link.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE rf_rewards SET status = 'paid' WHERE id = ?").bind(c.reward.id).run())).toBe("refused");
  });
  it("two tenants never see each other's data", async () => {
    const A = await fresh(), B = await fresh(), x = h(); await ready(x, A); const l = await link(x, "d1-iso", A); await x.svc.setup.initialize(B);
    expect((await x.svc.links.list(B, Q())).items).toEqual([]); expect(await code(x.svc.links.get(B, l.id))).toBe("not_found");
  });
});
