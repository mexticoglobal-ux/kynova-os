# ADR 021 · Referidos

**Estado**: aceptado.
1. Patrón de Marketplace/Partners; sin reanalizar la arquitectura.
2. Reglas críticas en la BD: una recompensa por referido (único), persona reservada (índice parcial), monto congelado (trigger), paid ⇔ simulated (CHECK).
3. Evidencia vía `ActivitySink`; módulo funciona sin sink; módulos congelados intactos.
4. Recompensas simuladas hasta que exista proveedor de pagos.
5. Alcance pequeño: sin IA ni widget; página pública y seguimiento de clics quedan para el Portal.
6. Cambios aditivos de configuración: `modules.ts`, `plans.ts` (BUSINESS), `instrumentation.ts`.
