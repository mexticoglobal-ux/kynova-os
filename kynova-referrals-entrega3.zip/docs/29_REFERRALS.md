# 29 · Referidos (Entrega 3, Bloque Comercial)

Módulo de referidos: quién refiere (enlace/código), a quién refiere, y la recompensa que se debe. Mismo patrón que Marketplace y Partners.

## Qué hace
- **Enlaces**: código único por referente (`active` ↔ `paused` → `closed`). Solo un enlace activo recibe referidos.
- **Referidos**: submitted → qualified → converted / rejected. Una persona (email normalizado) solo puede ser referida una vez mientras su referido esté abierto o convertido (índice único parcial en la BD). Rechazar libera a la persona. Nadie puede referirse a sí mismo.
- **Recompensas**: convertir crea **exactamente una** recompensa pendiente en el mismo lote (monto fijo o porcentaje en bps, half-up en centavos). Pendiente → aprobada → pagada (**simulada**). Monto e identidad quedan congelados por trigger.
- **Ajustes**: tipo de recompensa, monto fijo, porcentaje y moneda.

## Activity Engine
Cada mutación deja evidencia (`getActivitySink("referrals")`) sin correos ni datos personales en el resumen. Reversibles: pausar un enlace y aprobar una recompensa (`reverters.ts`, idempotentes).

## Estado honesto (`ARCHITECTURE_STATUS`)
rewards simulated_only · payout_provider not_connected · public_referral_page not_built · click_tracking not_built · referral_delivery not_connected · attribution_to_customer_accounts not_implemented. Sin empleado IA ni widget en esta entrega.

## Escala (10 000 empresas)
Índices con `tenant_id` primero, paginación por cursor, unicidad y congelado en la BD.

## Datos
Migración `1500_referrals.sql`: 4 tablas `rf_*`.
