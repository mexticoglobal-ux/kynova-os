-- Referrals (Entrega 3). Owned by src/modules/referrals. Prepared architecture: rewards are simulated (no payout provider), no public referral page, no click tracking, no delivery.
-- Every table is tenant-owned: tenant_id references companies, composite FKs keep references inside the same company, every index leads with tenant_id.
-- Nothing is deleted: links are closed, referrals rejected, rewards reversed. The money and identity columns of a reward never change (trigger).
-- Nothing here reads other modules' tables.

CREATE TABLE `rf_links` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`slug` text NOT NULL,
	`referrer_name` text NOT NULL,
	`referrer_email` text,
	`status` text DEFAULT 'active' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`created_by` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`status` IN ('active', 'paused', 'closed'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `rf_links_tenant_id_uq` ON `rf_links` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `rf_links_slug_uq` ON `rf_links` (`tenant_id`,`slug`);--> statement-breakpoint
CREATE INDEX `rf_links_status_idx` ON `rf_links` (`tenant_id`,`status`,`created_at`);--> statement-breakpoint
CREATE TRIGGER rf_links_tenant_frozen BEFORE UPDATE OF tenant_id ON rf_links BEGIN SELECT RAISE(ABORT, 'referrals tenant cannot change'); END;
--> statement-breakpoint
CREATE TABLE `rf_referrals` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`link_id` text NOT NULL,
	`referred_name` text NOT NULL,
	`referred_email` text NOT NULL,
	`email_key` text NOT NULL,
	`status` text DEFAULT 'submitted' NOT NULL,
	`value_cents` integer DEFAULT 0 NOT NULL,
	`currency` text DEFAULT 'USD' NOT NULL,
	`reject_reason` text DEFAULT '' NOT NULL,
	`converted_at` integer,
	`closed_at` integer,
	`created_by` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`tenant_id`,`link_id`) REFERENCES `rf_links`(`tenant_id`,`id`) ON UPDATE no action ON DELETE no action,
	CHECK (`status` IN ('submitted', 'qualified', 'converted', 'rejected')),
	CHECK (`value_cents` >= 0),
	CHECK (`currency` IN ('USD','EUR','GBP','CRC','MXN','COP','BRL','CAD'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `rf_referrals_tenant_id_uq` ON `rf_referrals` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `rf_referrals_live_uq` ON `rf_referrals` (`tenant_id`,`email_key`) WHERE `status` IN ('submitted','qualified','converted');--> statement-breakpoint
CREATE INDEX `rf_referrals_link_idx` ON `rf_referrals` (`tenant_id`,`link_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `rf_referrals_status_idx` ON `rf_referrals` (`tenant_id`,`status`,`created_at`);--> statement-breakpoint
CREATE TRIGGER rf_referrals_tenant_frozen BEFORE UPDATE OF tenant_id ON rf_referrals BEGIN SELECT RAISE(ABORT, 'referrals tenant cannot change'); END;
--> statement-breakpoint
CREATE TABLE `rf_rewards` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`referral_id` text NOT NULL,
	`link_id` text NOT NULL,
	`amount_cents` integer NOT NULL,
	`currency` text DEFAULT 'USD' NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`mode` text DEFAULT 'not_connected' NOT NULL,
	`approved_at` integer,
	`paid_at` integer,
	`reversed_at` integer,
	`created_by` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`tenant_id`,`referral_id`) REFERENCES `rf_referrals`(`tenant_id`,`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`tenant_id`,`link_id`) REFERENCES `rf_links`(`tenant_id`,`id`) ON UPDATE no action ON DELETE no action,
	CHECK (`amount_cents` >= 0),
	CHECK (`status` IN ('pending', 'approved', 'paid', 'reversed')),
	CHECK (`mode` IN ('not_connected', 'simulated')),
	CHECK (`currency` IN ('USD','EUR','GBP','CRC','MXN','COP','BRL','CAD')),
	CHECK ((`status` = 'paid') = (`mode` = 'simulated'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `rf_rewards_tenant_id_uq` ON `rf_rewards` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `rf_rewards_referral_uq` ON `rf_rewards` (`tenant_id`,`referral_id`);--> statement-breakpoint
CREATE INDEX `rf_rewards_status_idx` ON `rf_rewards` (`tenant_id`,`status`,`created_at`);--> statement-breakpoint
CREATE INDEX `rf_rewards_link_idx` ON `rf_rewards` (`tenant_id`,`link_id`,`created_at`);--> statement-breakpoint
CREATE TRIGGER rf_rewards_tenant_frozen BEFORE UPDATE OF tenant_id ON rf_rewards BEGIN SELECT RAISE(ABORT, 'referrals tenant cannot change'); END;
--> statement-breakpoint
CREATE TABLE `rf_settings` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`reward_kind` text DEFAULT 'fixed' NOT NULL,
	`reward_fixed_cents` integer DEFAULT 5000 NOT NULL,
	`reward_bps` integer DEFAULT 1000 NOT NULL,
	`currency` text DEFAULT 'USD' NOT NULL,
	`updated_by` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`reward_kind` IN ('fixed', 'percent')),
	CHECK (`reward_fixed_cents` >= 0),
	CHECK (`reward_bps` BETWEEN 0 AND 5000),
	CHECK (`currency` IN ('USD','EUR','GBP','CRC','MXN','COP','BRL','CAD'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `rf_settings_tenant_id_uq` ON `rf_settings` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `rf_settings_tenant_uq` ON `rf_settings` (`tenant_id`);--> statement-breakpoint
CREATE TRIGGER rf_settings_tenant_frozen BEFORE UPDATE OF tenant_id ON rf_settings BEGIN SELECT RAISE(ABORT, 'referrals tenant cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER rf_rewards_frozen BEFORE UPDATE OF referral_id, link_id, amount_cents, currency ON rf_rewards
BEGIN SELECT RAISE(ABORT, 'reward money and identity cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER rf_links_no_delete BEFORE DELETE ON rf_links
BEGIN SELECT RAISE(ABORT, 'rf_links rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER rf_referrals_no_delete BEFORE DELETE ON rf_referrals
BEGIN SELECT RAISE(ABORT, 'rf_referrals rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER rf_rewards_no_delete BEFORE DELETE ON rf_rewards
BEGIN SELECT RAISE(ABORT, 'rf_rewards rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER rf_settings_no_delete BEFORE DELETE ON rf_settings
BEGIN SELECT RAISE(ABORT, 'rf_settings rows cannot be deleted'); END;
