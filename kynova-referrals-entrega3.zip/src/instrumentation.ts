/** Next.js startup hook (supported by OpenNext on Cloudflare). Registers the production stores of the platform modules. */
export async function register(): Promise<void> {
  if (process.env.NEXT_RUNTIME === "edge") return;
  const { registerAiPersistence } = await import("@/platform/db/register-ai");
  registerAiPersistence();
  const { registerEmployeePersistence } = await import("@/platform/db/register-employees");
  registerEmployeePersistence();
  // Sprint 8: the SEO module contributes its AI employee and its dashboard panel through the public registration APIs of those systems.
  const { registerSeoEmployee, getSeoService } = await import("@/modules/seo");
  registerSeoEmployee(getSeoService);
  const { registerSeoWidget } = await import("@/components/seo/DashboardWidget");
  registerSeoWidget();
  // Sprint 9: AI Studio contributes its single dashboard panel through the same public registration API.
  const { registerStudioWidget } = await import("@/components/ai-studio/DashboardWidget");
  registerStudioWidget();
  // Sprint 10: Finance contributes its AI employee (Finance Analyst) and its dashboard panel through the same public registration APIs.
  const { registerFinanceEmployee, getFinanceService } = await import("@/modules/finance");
  registerFinanceEmployee(getFinanceService);
  const { registerFinanceWidget } = await import("@/components/finance/DashboardWidget");
  registerFinanceWidget();
  // Sprint 11: Communications contributes its single dashboard panel through the same public registration API.
  const { registerCommsWidget } = await import("@/components/communications/DashboardWidget");
  registerCommsWidget();
  // Sprint 12: Billing contributes its AI employee (Billing Advisor AI) and its single dashboard panel through the same public registration APIs.
  const { registerBillingEmployee, getBillingService } = await import("@/modules/billing");
  registerBillingEmployee(getBillingService);
  const { registerBillingWidget } = await import("@/components/billing/DashboardWidget");
  registerBillingWidget();
  // Sprint 13: Security contributes its AI employee (Security Advisor AI) and its single dashboard panel through the same public registration APIs.
  const { registerSecurityEmployee, getSecurityService } = await import("@/modules/security");
  registerSecurityEmployee(getSecurityService);
  const { registerSecurityWidget } = await import("@/components/security/DashboardWidget");
  registerSecurityWidget();
  // Sprint 14: Analytics contributes its AI employee (Executive Advisor) and its single dashboard panel through the same public registration APIs.
  const { registerAnalyticsEmployee, getAnalyticsService } = await import("@/modules/analytics");
  registerAnalyticsEmployee(getAnalyticsService);
  const { registerAnalyticsWidget } = await import("@/components/analytics/DashboardWidget");
  registerAnalyticsWidget();

  // Sprint 15: Mission Control contributes its AI employee (Mission Control Advisor) and its single dashboard panel through the same public registration APIs.
  const { registerMissionControlEmployee, getMissionControlService } = await import("@/modules/mission-control");
  registerMissionControlEmployee(getMissionControlService);
  const { registerMissionControlWidget } = await import("@/components/mission-control/DashboardWidget");
  registerMissionControlWidget();

  // Sprint 16: Analytics (BI) contributes its AI employee (Analytics Advisor) and its single dashboard panel through the same public registration APIs.
  const { registerAnalyticsBiEmployee, getAnalyticsBiService } = await import("@/modules/analytics-bi");
  registerAnalyticsBiEmployee(getAnalyticsBiService);
  const { registerAnalyticsBiWidget } = await import("@/components/analytics-bi/DashboardWidget");
  registerAnalyticsBiWidget();

  // Sprint 17: Integrations Hub contributes its AI employee (Integrations Advisor) and its single dashboard panel through the same public registration APIs.
  const { registerIntegrationsEmployee, getIntegrationsService } = await import("@/modules/integrations");
  registerIntegrationsEmployee(getIntegrationsService);
  const { registerIntegrationsWidget } = await import("@/components/integrations/DashboardWidget");
  registerIntegrationsWidget();

  // Sprint 18: Marketplace contributes its AI employee (Marketplace Advisor) and its single dashboard panel through the same public registration APIs.
  const { registerMarketplaceEmployee, getMarketplaceService } = await import("@/modules/marketplace");
  registerMarketplaceEmployee(getMarketplaceService);
  const { registerMarketplaceWidget } = await import("@/components/marketplace/DashboardWidget");
  registerMarketplaceWidget();

  // Entrega 2: Partners contributes its AI employee (Partner Manager), its dashboard panel and its undo handlers for the Activity Engine.
  const { registerPartnersEmployee, getPartnersService, registerPartnersReverters } = await import("@/modules/partners");
  registerPartnersEmployee(getPartnersService);
  registerPartnersReverters(getPartnersService);
  const { registerPartnersWidget } = await import("@/components/partners/DashboardWidget");
  registerPartnersWidget();

  // Entrega 3: Referrals contributes its undo handlers for the Activity Engine.
  const { registerReferralsReverters, getReferralsService } = await import("@/modules/referrals");
  registerReferralsReverters(getReferralsService);
}
