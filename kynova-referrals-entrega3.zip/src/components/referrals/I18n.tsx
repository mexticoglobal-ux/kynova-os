"use client";
import { createContext, useCallback, useContext, type ReactNode } from "react";
import type { ReferralsKey } from "@/modules/referrals/i18n";

type Dict = Record<ReferralsKey, string>;
const Ctx = createContext<{ dict: Dict; locale: string } | null>(null);
/** The server picks the locale's dictionary once; client components read it from here instead of bundling every language. */
export function ReferralsI18n({ dict, locale, children }: { dict: Dict; locale: string; children: ReactNode }) { return <Ctx.Provider value={{ dict, locale }}>{children}</Ctx.Provider>; }
export function useT() {
  const c = useContext(Ctx);
  const t = useCallback((key: ReferralsKey, vars: Record<string, string | number> = {}) => (c?.dict[key] ?? key).replace(/\{(\w+)\}/g, (_m, k: string) => String(vars[k] ?? "")), [c]);
  return { t, locale: c?.locale ?? "en" };
}
