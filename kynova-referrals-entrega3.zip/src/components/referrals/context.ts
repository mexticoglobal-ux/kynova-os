import { redirect } from "next/navigation";
import { requireModuleAccess } from "@/platform/auth/session";
import { getReferralsService, referralsLocale, tr, type Actor, type Capability, type ReferralsKey } from "@/modules/referrals";

/** Server-side context of every Referrals page: verified session, actor, service, translator and the capabilities of the role. The tenant always comes from the session. */
export async function referralsContext() {
  const s = await requireModuleAccess("referrals");
  if (!s.tenantId) redirect("/app/profile");
  const actor: Actor = { tenantId: s.tenantId, userId: s.user.id, role: s.role };
  const locale = referralsLocale(s.user.locale), svc = await getReferralsService(), mine = await svc.permissions.mine(actor).catch(() => ({ role: s.role, capabilities: [] as Capability[] }));
  const caps = new Set<string>(mine.capabilities);
  return {
    actor, locale, svc, role: s.role,
    t: (k: ReferralsKey, v?: Record<string, string | number>) => tr(locale, k, v),
    can: (p: Capability) => caps.has(p),
  };
}
export type ReferralsContext = Awaited<ReturnType<typeof referralsContext>>;
