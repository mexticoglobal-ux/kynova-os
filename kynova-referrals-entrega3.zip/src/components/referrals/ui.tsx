import Link from "next/link";
import type { ReactNode } from "react";
import type { ReferralsKey } from "@/modules/referrals/i18n";

export type T = (k: ReferralsKey, v?: Record<string, string | number>) => string;
export const Card = ({ title, action, children, className = "" }: { title?: string; action?: ReactNode; children: ReactNode; className?: string }) => (
  <section className={`min-w-0 rounded-2xl border border-line bg-surface p-4 sm:p-5 ${className}`}>
    {(title || action) && <header className="mb-3 flex items-center justify-between gap-3">{title && <h2 className="text-sm font-semibold tracking-tight">{title}</h2>}{action}</header>}
    {children}
  </section>
);
export const Stat = ({ label, value, sub }: { label: string; value: string | number; sub?: string }) => (
  <div className="min-w-0 rounded-xl border border-line px-3.5 py-3"><dt className="truncate text-xs text-muted">{label}</dt><dd className="mt-0.5 truncate text-xl font-bold tabular-nums">{value}</dd>{sub && <dd className="truncate text-xs text-muted">{sub}</dd>}</div>
);
const TONES = { info: "bg-ac2/10 text-ac2", success: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300", warning: "bg-amber-500/10 text-amber-700 dark:text-amber-300", danger: "bg-rose-500/10 text-rose-700 dark:text-rose-300" } as const;
export const Pill = ({ tone = "info", children }: { tone?: keyof typeof TONES; children: ReactNode }) => <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${TONES[tone]}`}>{children}</span>;
export const Empty = ({ children }: { children: ReactNode }) => <p className="rounded-xl border border-dashed border-line px-4 py-8 text-center text-sm text-muted">{children}</p>;

export function PageHeader({ title, actions, back }: { title: string; actions?: ReactNode; back?: { href: string; label: string } }) {
  return (
    <header className="mb-5 flex flex-wrap items-start justify-between gap-3">
      <div className="min-w-0">{back && <Link href={back.href} className="text-xs text-muted hover:underline">← {back.label}</Link>}<h1 className="truncate text-xl font-bold tracking-tight sm:text-2xl">{title}</h1></div>
      {actions}
    </header>
  );
}
export const fmtDate = (ms: number, locale: string, time = false) => new Intl.DateTimeFormat(locale, { dateStyle: "medium", ...(time ? { timeStyle: "short" as const } : {}), timeZone: "UTC" }).format(ms);

/** GET filter form: works without JavaScript and keeps the URL shareable. */
export function FilterForm({ t, params, q = true, hidden = {}, selects }: { t: T; params: Record<string, string | undefined>; q?: boolean; hidden?: Record<string, string | undefined>; selects: { name: string; label: string; options: { value: string; label: string }[] }[] }) {
  const field = "rounded-lg border border-line bg-transparent px-2.5 py-1.5 text-sm focus-visible:outline-2 focus-visible:outline-ac2";
  return (
    <form method="get" role="search" className="mb-4 flex flex-wrap items-end gap-2.5">
      {Object.entries(hidden).map(([k, v]) => (v ? <input key={k} type="hidden" name={k} value={v} /> : null))}
      {q && <label className="grid gap-1 text-xs text-muted">{t("common.search")}<input name="q" type="search" defaultValue={params.q ?? ""} maxLength={100} className={`${field} w-48`} /></label>}
      {selects.map((s) => (
        <label key={s.name} className="grid gap-1 text-xs text-muted">{s.label}
          <select name={s.name} defaultValue={params[s.name] ?? ""} className={field}><option value="">{t("common.all")}</option>{s.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select>
        </label>
      ))}
      <button className="rounded-lg border border-line px-3 py-1.5 text-sm hover:bg-ac/10 focus-visible:outline-2 focus-visible:outline-ac2">{t("common.filter")}</button>
      <Link href="?" className="px-1 py-1.5 text-sm text-muted hover:underline">{t("common.clear")}</Link>
    </form>
  );
}
export function Pager({ t, base, params, next }: { t: T; base: string; params: Record<string, string | undefined>; next: string | null }) {
  if (!next) return null;
  const qs = new URLSearchParams(Object.entries({ ...params, cursor: next }).filter((e): e is [string, string] => !!e[1]));
  return <div className="mt-4 text-center"><Link href={`${base}?${qs}`} className="rounded-lg border border-line px-4 py-2 text-sm hover:bg-ac/10">{t("common.next")}</Link></div>;
}
/** Responsive list: rows are cards on mobile and a table-like grid from md up. */
export function DataList({ cols, rows, t }: { cols: { label: string; className?: string }[]; rows: { key: string; href: string; cells: ReactNode[] }[]; t: T }) {
  if (rows.length === 0) return <Empty>{t("common.noResults")}</Empty>;
  const grid = { gridTemplateColumns: cols.map((c) => c.className ?? "minmax(0,1fr)").join(" ") };
  return (
    <div className="overflow-hidden rounded-2xl border border-line bg-surface">
      <div className="hidden gap-3 border-b border-line px-4 py-2 text-xs text-muted md:grid" style={grid} role="presentation">{cols.map((c) => <span key={c.label}>{c.label}</span>)}</div>
      <ul>
        {rows.map((r) => (
          <li key={r.key} className="border-b border-line last:border-0">
            <Link href={r.href} className="block px-4 py-3 hover:bg-ac/5 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-ac2">
              <div className="grid gap-1 md:items-center md:gap-3" style={undefined}>
                <div className="hidden md:grid md:items-center md:gap-3" style={grid}>{r.cells.map((c, i) => <div key={i} className="min-w-0 truncate">{c}</div>)}</div>
                <div className="grid gap-1 md:hidden">{r.cells.map((c, i) => (c ? <div key={i} className={i === 0 ? "font-medium" : "flex items-center gap-2 text-sm text-muted"}>{i > 0 && <span className="w-24 shrink-0 text-xs">{cols[i]?.label}</span>}<span className="min-w-0 truncate text-fg">{c}</span></div> : null))}</div>
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
export const sp1 = (v: string | string[] | undefined): string | undefined => (Array.isArray(v) ? v[0] : v) || undefined;
export const num = (n: number | null, locale: string): string => (n === null ? "—" : new Intl.NumberFormat(locale).format(n));
export const PRIORITY_TONE = { critical: "danger", high: "warning", medium: "info", low: "success" } as const;
export const scoreTone = (s: number | null): keyof typeof TONES => (s === null ? "info" : s >= 80 ? "success" : s >= 55 ? "warning" : "danger");
