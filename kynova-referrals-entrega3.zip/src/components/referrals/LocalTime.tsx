"use client";
import { useEffect, useState } from "react";

/** Shows a moment in the viewer's own time zone. The server renders UTC first so the markup matches, then the browser swaps in local time. */
export default function LocalTime({ ms, locale, withTime = true }: { ms: number; locale: string; withTime?: boolean }) {
  const fmt = (tz?: string) => new Intl.DateTimeFormat(locale, { dateStyle: "medium", ...(withTime ? { timeStyle: "short" as const } : {}), timeZone: tz }).format(ms);
  const [text, setText] = useState(() => `${fmt("UTC")}${withTime ? " UTC" : ""}`);
  useEffect(() => { setText(fmt()); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [ms, locale, withTime]);
  return <time dateTime={new Date(ms).toISOString()}>{text}</time>;
}
