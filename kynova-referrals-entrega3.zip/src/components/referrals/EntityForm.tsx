"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useT } from "./I18n";
import { Err, primary, useRun } from "./Actions";
import { Check, Labeled, input } from "./Form";
import { referralsCall } from "./api";
import type { ReferralsKey } from "@/modules/referrals/i18n";

export interface FieldSpec { name: string; label: ReferralsKey; kind?: "text" | "number" | "money" | "percent" | "date" | "select" | "check" | "textarea" | "list" | "multi"; options?: { value: string; label: string }[]; required?: boolean; def?: string | boolean; max?: number }
/** One generic create/edit form for the simple masters (accounts, customers, vendors, taxes, cost centers, currencies, periods, payments, expenses...). */
export default function EntityForm({ path, method = "POST", fields, submit, goto, fixed, className = "" }: { path: string; method?: "POST" | "PATCH" | "PUT"; fields: FieldSpec[]; submit?: ReferralsKey; goto?: string; fixed?: Record<string, unknown>; className?: string }) {
  const { t } = useT(), router = useRouter(), { busy, err, run } = useRun();
  const init = () => Object.fromEntries(fields.map((f) => [f.name, f.def ?? (f.kind === "check" ? false : "")])) as Record<string, string | boolean>;
  const [v, setV] = useState(init), [bad, setBad] = useState<string | null>(null);
  function body() {
    const o: Record<string, unknown> = { ...fixed };
    for (const f of fields) {
      const x = v[f.name];
      if (f.kind === "check") { o[f.name] = Boolean(x); continue; }
      const s = String(x ?? "").trim(); if (s === "") continue;
      if (f.kind === "list" || f.kind === "multi") o[f.name] = s.split(",").map((x) => x.trim()).filter(Boolean);
      else if (f.kind === "money" || f.kind === "percent") { const n = Number(s.replace(",", ".")); if (!Number.isFinite(n) || n < 0) { setBad(t(f.label)); return null; } o[f.name] = Math.round(n * 100); }
      else if (f.kind === "number") { const n = Number(s); if (!Number.isFinite(n)) { setBad(t(f.label)); return null; } o[f.name] = n; }
      else if (f.kind === "date") { const ms = Date.parse(`${s}T00:00:00Z`); if (!Number.isFinite(ms)) { setBad(t(f.label)); return null; } o[f.name] = ms; }
      else o[f.name] = s;
    }
    return o;
  }
  return (
    <form className={`grid gap-3 sm:grid-cols-2 ${className}`} onSubmit={(e) => {
      e.preventDefault(); setBad(null); const b = body(); if (!b) return;
      void (async () => {
        let out: { id?: string } | undefined;
        const ok = await run(async () => { const r = await referralsCall<{ id?: string }>(method, path, b); out = r.data; return r; }, () => { setV(init()); if (goto && out?.id) router.push(`${goto}${out.id}`); else router.refresh(); });
        void ok;
      })();
    }}>
      {fields.map((f) => (
        <Labeled key={f.name} label={t(f.label)} className={f.kind === "textarea" ? "sm:col-span-2" : ""}>
          {(id) => f.kind === "check" ? <Check label={t(f.label)} checked={Boolean(v[f.name])} onChange={(c) => setV({ ...v, [f.name]: c })} />
            : f.kind === "select" ? <select id={id} className={input} required={f.required} value={String(v[f.name])} onChange={(e) => setV({ ...v, [f.name]: e.target.value })}><option value="">—</option>{f.options?.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select>
            : f.kind === "multi" ? <select id={id} multiple size={Math.min(6, Math.max(3, f.options?.length ?? 3))} className={input} value={String(v[f.name]).split(",").filter(Boolean)} onChange={(e) => setV({ ...v, [f.name]: Array.from(e.target.selectedOptions).map((o) => o.value).join(",") })}>{f.options?.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select>
            : f.kind === "textarea" ? <textarea id={id} className={input} rows={3} maxLength={f.max} value={String(v[f.name])} onChange={(e) => setV({ ...v, [f.name]: e.target.value })} />
            : <input id={id} className={input} required={f.required} maxLength={f.max} type={f.kind === "date" ? "date" : "text"} inputMode={f.kind === "number" ? "numeric" : f.kind === "money" || f.kind === "percent" ? "decimal" : undefined} value={String(v[f.name])} onChange={(e) => setV({ ...v, [f.name]: e.target.value })} />}
        </Labeled>
      ))}
      <div className="flex items-center gap-3 sm:col-span-2"><button className={primary} disabled={busy}>{busy ? t("common.saving") : t(submit ?? "common.create")}</button><Err err={bad ? `${t("common.invalidField")}: ${bad}` : err} /></div>
    </form>
  );
}
