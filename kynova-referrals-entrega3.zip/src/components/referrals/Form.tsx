"use client";
import { useId, type ReactNode } from "react";

export const input = "w-full rounded-lg border border-line bg-transparent px-3 py-2 text-sm focus-visible:outline-2 focus-visible:outline-ac2";
/** Label + control with a stable id so the label is always associated (keyboard and screen readers). */
export function Labeled({ label, hint, children, className = "" }: { label: string; hint?: string; children: (id: string) => ReactNode; className?: string }) {
  const id = useId();
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1 block text-xs text-muted">{label}</label>
      {children(id)}
      {hint && <p className="mt-1 text-xs text-muted">{hint}</p>}
    </div>
  );
}
export function Check({ label, checked, onChange, disabled }: { label: string; checked: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} className="size-4 accent-[var(--ac)]" />{label}</label>;
}
export const numOrNull = (s: string): number | null => { const n = Number(s); return s.trim() === "" || !Number.isFinite(n) ? null : Math.trunc(n); };
export function Group({ title, children }: { title: string; children: ReactNode }) {
  return <fieldset className="rounded-2xl border border-line p-4"><legend className="px-1 text-sm font-semibold">{title}</legend><div className="mt-2 grid gap-3 sm:grid-cols-2">{children}</div></fieldset>;
}
