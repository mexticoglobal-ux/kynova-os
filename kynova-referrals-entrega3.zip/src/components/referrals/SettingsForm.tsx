"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useT } from "./I18n";
import { Err, primary, useRun } from "./Actions";
import { Labeled, input } from "./Form";
import { referralsCall } from "./api";

interface S { rewardKind: string; rewardFixedCents: number; rewardBps: number; currency: string }
export default function SettingsForm({ initial, currencies }: { initial: S; currencies: readonly string[] }) {
  const { t } = useT(), router = useRouter(), { busy, err, run } = useRun(), [v, setV] = useState(initial), [fixed, setFixed] = useState(String(initial.rewardFixedCents / 100)), [pct, setPct] = useState(String(initial.rewardBps / 100)), [saved, setSaved] = useState(false);
  return (
    <form className="grid gap-3 sm:grid-cols-2" onSubmit={(e) => {
      e.preventDefault(); setSaved(false); const f = Number(fixed.replace(",", ".")), p = Number(pct.replace(",", "."));
      if (!Number.isFinite(f) || f < 0 || !Number.isFinite(p) || p < 0 || p > 50) return;
      void run(() => referralsCall("PATCH", "/settings", { ...v, rewardFixedCents: Math.round(f * 100), rewardBps: Math.round(p * 100) }), () => { setSaved(true); router.refresh(); });
    }}>
      <Labeled label={t("set.kind")}>{(id) => <select id={id} className={input} value={v.rewardKind} onChange={(e) => setV({ ...v, rewardKind: e.target.value })}><option value="fixed">{t("rk.fixed")}</option><option value="percent">{t("rk.percent")}</option></select>}</Labeled>
      <Labeled label={t("set.currency")}>{(id) => <select id={id} className={input} value={v.currency} onChange={(e) => setV({ ...v, currency: e.target.value })}>{currencies.map((c) => <option key={c} value={c}>{c}</option>)}</select>}</Labeled>
      <Labeled label={t("set.fixed")} hint={t("set.fixedHint")}>{(id) => <input id={id} inputMode="decimal" className={input} value={fixed} onChange={(e) => setFixed(e.target.value)} />}</Labeled>
      <Labeled label={t("set.percent")} hint={t("set.percentHint")}>{(id) => <input id={id} inputMode="decimal" className={input} value={pct} onChange={(e) => setPct(e.target.value)} />}</Labeled>
      <div className="flex items-center gap-3 sm:col-span-2"><button className={primary} disabled={busy}>{busy ? t("common.saving") : t("common.save")}</button>{saved && <span role="status" className="text-xs text-muted">{t("common.saved")}</span>}<Err err={err} /></div>
    </form>
  );
}
