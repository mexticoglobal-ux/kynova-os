import { createMemoryReferralsStore } from "./store-memory";
import type { ReferralsStore } from "./store";

let override: ReferralsStore | null = null;
/** Tests and tooling can inject a store. */
export const setReferralsStore = (s: ReferralsStore | null): void => { override = s; };
const g = globalThis as unknown as { __kynovaReferralsDevStore?: ReferralsStore };
const isDevLike = (): boolean => process.env.APP_ENV === "local" || process.env.NODE_ENV === "test" || process.env.NODE_ENV === "development";

/**
 * Resolves the store for the current request. In the Worker the D1 binding is only known per request, so it is read lazily.
 * Without a binding (a laptop running `next dev`) an in-memory store keeps the module usable; elsewhere a missing binding fails closed.
 */
export async function getReferralsStore(): Promise<ReferralsStore> {
  if (override) return override;
  try {
    const { getCloudflareContext } = await import("@opennextjs/cloudflare");
    const d1 = getCloudflareContext().env.DB;
    if (d1) { const { createD1ReferralsStore } = await import("./store-d1"); return createD1ReferralsStore(d1); }
  } catch { /* no Cloudflare context */ }
  if (!isDevLike()) {
    const { ReferralsError } = await import("./errors");
    throw new ReferralsError("unavailable", "The Referrals database is not available. Check the D1 binding.");
  }
  return (g.__kynovaReferralsDevStore ??= createMemoryReferralsStore());
}
