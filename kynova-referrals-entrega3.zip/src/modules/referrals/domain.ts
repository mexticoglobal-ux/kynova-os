import { z } from "zod";
import { ROLES } from "@/config/roles";

/* ------------------------------------------------------------------ vocabulary */
export const LINK_STATUS = ["active", "paused", "closed"] as const;
export const REFERRAL_STATUS = ["submitted", "qualified", "converted", "rejected"] as const;
/** A referred person/company is reserved while the referral is in one of these stages (and after it converted). */
export const LIVE_STAGES = ["submitted", "qualified", "converted"] as const;
export const REWARD_STATUS = ["pending", "approved", "paid", "reversed"] as const;
export const REWARD_MODES = ["not_connected", "simulated"] as const;
export const REWARD_KINDS = ["fixed", "percent"] as const;
export const CURRENCIES = ["USD", "EUR", "GBP", "CRC", "MXN", "COP", "BRL", "CAD"] as const;
export const CAPABILITIES = ["view", "manage_links", "manage_referrals", "view_rewards", "approve_rewards", "manage_settings"] as const;
export type Capability = (typeof CAPABILITIES)[number];
const ALL = [...CAPABILITIES] as Capability[];
export const DEFAULT_CAPABILITIES: Record<(typeof ROLES)[number], readonly Capability[]> = {
  super_admin: ALL, owner: ALL, administrator: ALL, ceo: ALL.filter((c) => c !== "manage_settings"),
  manager: ["view", "manage_links", "manage_referrals", "view_rewards"],
  marketing: ["view", "manage_links", "manage_referrals"], sales: ["view", "manage_referrals"], finance: ["view", "view_rewards", "approve_rewards"],
  support: [], hr: [], employee: [], guest: [],
};

/* ------------------------------------------------------------------ helpers */
const text = (max: number) => z.string().trim().max(max);
const id = z.string().trim().min(1).max(64);
const slug = z.string().trim().toLowerCase().regex(/^[a-z0-9][a-z0-9-]*$/, "Use lowercase letters, numbers or -.").min(3).max(40);
const int = (min: number, max: number) => z.number().int().min(min).max(max);
const email = z.string().trim().email().max(120);

/* ------------------------------------------------------------------ inputs */
export const linkInput = z.object({ slug, referrerName: text(100).min(2), referrerEmail: email.optional(), notes: text(500).default("") }).strict();
export const linkPatch = z.object({ referrerName: text(100).min(2).optional(), referrerEmail: email.nullable().optional(), notes: text(500).optional() }).strict();
export const referralInput = z.object({ linkId: id, referredName: text(120).min(2), referredEmail: email, valueCents: int(0, 1_000_000_000).default(0) }).strict();
export const rejectInput = z.object({ reason: text(200).default("") }).strict();
export const convertInput = z.object({ valueCents: int(0, 1_000_000_000).optional() }).strict();
export const settingsPatch = z.object({ rewardKind: z.enum(REWARD_KINDS).optional(), rewardFixedCents: int(0, 100_000_000).optional(), rewardBps: int(0, 5000).optional(), currency: z.enum(CURRENCIES).optional() }).strict();
export const listQuery = z.object({
  q: text(100).optional(), status: text(20).optional(), linkId: id.optional(), referralId: id.optional(), cursor: text(300).optional(), limit: z.coerce.number().int().min(1).max(100).default(25),
}).strict();
export type ListQuery = z.output<typeof listQuery>;

/* ------------------------------------------------------------------ records */
type V<T extends readonly string[]> = T[number];
export interface LinkRecord { id: string; tenantId: string; slug: string; referrerName: string; referrerEmail: string | null; status: V<typeof LINK_STATUS>; notes: string; createdBy: string; createdAt: number; updatedAt: number }
export interface ReferralRecord { id: string; tenantId: string; linkId: string; referredName: string; referredEmail: string; emailKey: string; status: V<typeof REFERRAL_STATUS>; valueCents: number; currency: V<typeof CURRENCIES>; rejectReason: string; convertedAt: number | null; closedAt: number | null; createdBy: string; createdAt: number; updatedAt: number }
export interface RewardRecord { id: string; tenantId: string; referralId: string; linkId: string; amountCents: number; currency: V<typeof CURRENCIES>; status: V<typeof REWARD_STATUS>; mode: V<typeof REWARD_MODES>; approvedAt: number | null; paidAt: number | null; reversedAt: number | null; createdBy: string; createdAt: number; updatedAt: number }
export interface SettingRecord { id: string; tenantId: string; rewardKind: V<typeof REWARD_KINDS>; rewardFixedCents: number; rewardBps: number; currency: V<typeof CURRENCIES>; updatedBy: string; createdAt: number; updatedAt: number }
