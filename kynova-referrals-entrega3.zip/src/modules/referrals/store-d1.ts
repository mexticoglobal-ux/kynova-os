import type { D1Database, D1PreparedStatement } from "@cloudflare/workers-types";
import { BOOLEAN_COLS, COLUMNS, JSON_COLS, REMOVABLE, SOFT_DELETE, TABLE, camel, snake } from "./columns";
import { ReferralsError } from "./errors";
import type { Cond, Kind, KindMap, QuerySpec, ReferralsStore, WriteOp } from "./store";

type Row = Record<string, unknown>;
type Bind = string | number | null;
const MAX_IN = 90; // D1 allows 100 bound parameters per statement.
const likeEscape = (s: string) => s.replace(/[\\%_]/g, (m) => `\\${m}`);

function mapError(e: unknown): never {
  const m = e instanceof Error ? `${e.message} ${(e.cause as Error | undefined)?.message ?? ""}` : String(e);
  if (/UNIQUE constraint failed/i.test(m)) throw new ReferralsError("duplicate", "A record with the same unique value already exists.");
  if (/FOREIGN KEY constraint failed/i.test(m)) throw new ReferralsError("validation_failed", "A referenced record does not exist.");
  if (/CHECK constraint failed/i.test(m)) throw new ReferralsError("validation_failed", "A value is not allowed.");
  if (/append-only|cannot change|immutable/i.test(m)) throw new ReferralsError("invalid_state", "That change is not allowed.");
  throw e;
}
const parseJson = (v: unknown): unknown => { if (typeof v !== "string") return v ?? null; try { return JSON.parse(v) as unknown; } catch { return null; } };

/**
 * Cloudflare D1 store written in plain parameterized SQL. It lives in the Referrals module (the Database module is not modified) and only
 * touches the int_* tables created by drizzle/migrations/1100_referrals.sql. Every statement is scoped by tenant_id; identifiers come from a
 * fixed whitelist (columns.ts), never from request input; values are always bound.
 */
export function createD1ReferralsStore(d1: D1Database): ReferralsStore {
  const allowed = (kind: Kind, col: string): string => { if (!COLUMNS[kind].includes(col)) throw new Error(`Unknown column ${kind}.${col}`); return snake(col); };
  const enc = (col: string, v: unknown): Bind => (v === undefined || v === null ? null : JSON_COLS.has(col) ? JSON.stringify(v) : BOOLEAN_COLS.has(col) ? (v ? 1 : 0) : (v as string | number));
  const dec = <K extends Kind>(r: Row): KindMap[K] => {
    const o: Row = {};
    for (const [k, v] of Object.entries(r)) { const c = camel(k); o[c] = JSON_COLS.has(c) ? parseJson(v) : BOOLEAN_COLS.has(c) ? v === 1 : v ?? null; }
    return o as unknown as KindMap[K];
  };
  function whereSql(kind: Kind, conds: readonly Cond<Kind>[] = []): { sql: string[]; binds: Bind[] } {
    const sql: string[] = [], binds: Bind[] = [];
    for (const c of conds) {
      const col = allowed(kind, c.col);
      switch (c.op) {
        case "eq": sql.push(`${col} = ?`); binds.push(enc(c.col, c.value)); break;
        case "ne": sql.push(`${col} IS NOT ?`); binds.push(enc(c.col, c.value)); break;
        case "gte": sql.push(`${col} >= ?`); binds.push(c.value); break;
        case "lte": sql.push(`${col} <= ?`); binds.push(c.value); break;
        case "null": sql.push(`${col} IS NULL`); break;
        case "notnull": sql.push(`${col} IS NOT NULL`); break;
        case "in":
          if (c.value.length > MAX_IN) throw new ReferralsError("validation_failed", "Too many values in a filter.");
          if (c.value.length === 0) sql.push("0 = 1"); else { sql.push(`${col} IN (${c.value.map(() => "?").join(",")})`); binds.push(...c.value); }
      }
    }
    return { sql, binds };
  }
  function insertStmt(kind: Kind, row: KindMap[Kind]): D1PreparedStatement {
    const r = row as unknown as Row, cols = COLUMNS[kind].filter((c) => c in r);
    return d1.prepare(`INSERT INTO ${TABLE[kind]} (${cols.map((c) => snake(c)).join(", ")}) VALUES (${cols.map(() => "?").join(", ")})`).bind(...cols.map((c) => enc(c, r[c])));
  }
  function updateStmt(kind: Kind, tenantId: string, id: string, patch: Row): D1PreparedStatement | null {
    const cols = Object.keys(patch).filter((c) => c !== "id" && c !== "tenantId" && patch[c] !== undefined);
    if (cols.length === 0) return null;
    return d1.prepare(`UPDATE ${TABLE[kind]} SET ${cols.map((c) => `${allowed(kind, c)} = ?`).join(", ")} WHERE tenant_id = ? AND id = ?`).bind(...cols.map((c) => enc(c, patch[c])), tenantId, id);
  }
  async function get<K extends Kind>(kind: K, tenantId: string, id: string): Promise<KindMap[K] | null> {
    const r = await d1.prepare(`SELECT * FROM ${TABLE[kind]} WHERE tenant_id = ? AND id = ?${SOFT_DELETE.has(kind) ? " AND deleted_at IS NULL" : ""}`).bind(tenantId, id).first<Row>();
    return r ? dec<K>(r) : null;
  }
  const baseWhere = (kind: Kind, tenantId: string, conds?: readonly Cond<Kind>[]) => {
    const where = ["tenant_id = ?"], binds: Bind[] = [tenantId];
    if (SOFT_DELETE.has(kind)) where.push("deleted_at IS NULL");
    const w = whereSql(kind, conds); where.push(...w.sql); binds.push(...w.binds);
    return { where, binds };
  };

  return {
    async insert(kind, row) { try { await insertStmt(kind, row).run(); } catch (e) { mapError(e); } },
    get,
    async update(kind, tenantId, id, patch) {
      try { const st = updateStmt(kind, tenantId, id, patch as Row); if (st) await st.run(); } catch (e) { mapError(e); }
      return get(kind, tenantId, id);
    },
    async query(kind, tenantId, spec: QuerySpec<Kind>) {
      const { where, binds } = baseWhere(kind, tenantId, spec.where);
      const needle = spec.search?.text.trim();
      if (needle && spec.search) { where.push(`(${spec.search.cols.map((c) => `${allowed(kind, c)} LIKE ? ESCAPE '\\'`).join(" OR ")})`); for (let i = 0; i < spec.search.cols.length; i++) binds.push(`%${likeEscape(needle)}%`); }
      const col = allowed(kind, spec.orderBy?.col ?? "createdAt"), dir = spec.orderBy?.dir ?? "desc";
      if (spec.after) { where.push(`(${col} ${dir === "desc" ? "<" : ">"} ? OR (${col} = ? AND id ${dir === "desc" ? "<" : ">"} ?))`); binds.push(spec.after.value, spec.after.value, spec.after.id); }
      const rows = await d1.prepare(`SELECT * FROM ${TABLE[kind]} WHERE ${where.join(" AND ")} ORDER BY ${col} ${dir}, id ${dir} LIMIT ?`).bind(...binds, Math.min(500, Math.max(1, spec.limit))).all<Row>();
      return rows.results.map((r) => dec<typeof kind>(r));
    },
    async count(kind, tenantId, conds) {
      const { where, binds } = baseWhere(kind, tenantId, conds as readonly Cond<Kind>[] | undefined);
      const r = await d1.prepare(`SELECT COUNT(*) AS n FROM ${TABLE[kind]} WHERE ${where.join(" AND ")}`).bind(...binds).first<{ n: number }>();
      return Number(r?.n ?? 0);
    },
    async remove(kind, tenantId, id) {
      if (!REMOVABLE.has(kind)) throw new ReferralsError("invalid_state", "That record cannot be deleted.");
      try { const r = await d1.prepare(`DELETE FROM ${TABLE[kind]} WHERE tenant_id = ? AND id = ?`).bind(tenantId, id).run(); return (r.meta?.changes ?? 0) > 0; } catch (e) { mapError(e); }
    },
    async batch(ops: readonly WriteOp[]) {
      const stmts = ops.map((o) => (o.op === "insert" ? insertStmt(o.kind, o.row) : updateStmt(o.kind, o.tenantId, o.id, o.patch as Row))).filter((s): s is D1PreparedStatement => s !== null);
      try { if (stmts.length) await d1.batch(stmts); } catch (e) { mapError(e); }
    },
  };
}
