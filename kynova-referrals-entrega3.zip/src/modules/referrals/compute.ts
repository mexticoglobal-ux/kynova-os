/** Reward = fixed amount, or a percentage (basis points) of the referral value rounded half up in integer cents. */
export const rewardAmount = (s: { rewardKind: "fixed" | "percent"; rewardFixedCents: number; rewardBps: number }, valueCents: number): number =>
  s.rewardKind === "fixed" ? s.rewardFixedCents : Math.floor((valueCents * s.rewardBps + 5000) / 10_000);
/** Normalized email used to recognise the same referred person. */
export const emailKey = (e: string): string => e.trim().toLowerCase();
export const dayStart = (t: number): number => Math.floor(t / 86_400_000) * 86_400_000;
