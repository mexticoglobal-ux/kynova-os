import { registerReverter } from "@/platform/activity";
import type { ReferralsService } from "./service";

const flag = globalThis as unknown as { __kynovaReferralsReverters?: boolean };
/** How Referrals undoes its own reversible activity (the Activity Engine only coordinates). Handlers are idempotent. Registered once at startup. */
export function registerReferralsReverters(getService: () => Promise<ReferralsService>): void {
  if (flag.__kynovaReferralsReverters) return;
  flag.__kynovaReferralsReverters = true;
  registerReverter("referrals", async (event, actor) => {
    const svc = await getService(), h = (event.revertHint ?? {}) as { linkId?: string; rewardId?: string };
    switch (event.action) {
      case "referrals.link.paused": {
        const d = await svc.links.get(actor, String(h.linkId));
        if (d.link.status === "paused") await svc.links.resume(actor, d.link.id);
        return { summary: `Referral link resumed: ${d.link.referrerName}` };
      }
      case "referrals.reward.approved": {
        const r = await svc.rewards.get(actor, String(h.rewardId));
        if (r.status === "approved") await svc.rewards.unapprove(actor, r.id);
        return { summary: "Reward back to pending" };
      }
      default: throw new Error("This activity cannot be undone.");
    }
  });
}
