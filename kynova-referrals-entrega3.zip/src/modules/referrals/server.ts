import { getActivitySink } from "@/platform/activity";
import { getReferralsStore } from "./runtime";
import { createReferralsService, type ReferralsService } from "./service";

/** Composition root: the store is resolved per request (the D1 binding only exists inside a request), everything else is stateless. Evidence goes to the Activity Engine through its sink. */
export async function getReferralsService(): Promise<ReferralsService> {
  return createReferralsService({ store: await getReferralsStore(), newId: () => crypto.randomUUID().replace(/-/g, ""), activity: await getActivitySink("referrals") });
}
