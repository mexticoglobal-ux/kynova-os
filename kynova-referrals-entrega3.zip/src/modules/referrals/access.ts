import type { Role } from "@/config/roles";
import { DEFAULT_CAPABILITIES, type Capability } from "./domain";

/** Capabilities INSIDE Referrals. Whether a role may open /app/referrals at all is decided only by src/config/modules.ts; this table never grants module access. */
export const allows = (role: Role, c: Capability): boolean => DEFAULT_CAPABILITIES[role].includes(c);
