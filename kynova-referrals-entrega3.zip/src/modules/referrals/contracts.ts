/** Honest status of every part that is not fully working yet; the UI and the docs read it. */
export const ARCHITECTURE_STATUS = {
  rewards: "simulated_only", payout_provider: "not_connected", public_referral_page: "not_built", click_tracking: "not_built", referral_delivery: "not_connected", attribution_to_customer_accounts: "not_implemented", ai_actions: "not_applicable",
} as const;
