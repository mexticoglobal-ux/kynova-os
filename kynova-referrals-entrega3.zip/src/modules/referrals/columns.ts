import type { Kind } from "./store";

export const TABLE: Record<Kind, string> = { link: "rf_links", referral: "rf_referrals", reward: "rf_rewards", setting: "rf_settings" };
export const KIND_LIST = Object.keys(TABLE) as Kind[];
/** Nothing in Referrals is deleted: links are closed, referrals rejected, rewards reversed. */
export const SOFT_DELETE: ReadonlySet<Kind> = new Set<Kind>();
export const REMOVABLE: ReadonlySet<Kind> = new Set<Kind>();
export const IMMUTABLE_KINDS: ReadonlySet<Kind> = new Set<Kind>();
/** Columns that never change after insert (money and identity of a reward). The migration enforces the same with a trigger. */
export const FROZEN_COLS: Partial<Record<Kind, readonly string[]>> = { reward: ["referralId", "linkId", "amountCents", "currency"] };
export const BOOLEAN_COLS: ReadonlySet<string> = new Set();
export const JSON_COLS: ReadonlySet<string> = new Set();
const AUDIT = ["createdBy", "createdAt", "updatedAt"] as const;
/** The only columns the D1 store will ever write or filter on (property names; snake_case in SQL). Verified against the migration by a test. */
export const COLUMNS: Record<Kind, readonly string[]> = {
  link: ["id", "tenantId", "slug", "referrerName", "referrerEmail", "status", "notes", ...AUDIT],
  referral: ["id", "tenantId", "linkId", "referredName", "referredEmail", "emailKey", "status", "valueCents", "currency", "rejectReason", "convertedAt", "closedAt", ...AUDIT],
  reward: ["id", "tenantId", "referralId", "linkId", "amountCents", "currency", "status", "mode", "approvedAt", "paidAt", "reversedAt", ...AUDIT],
  setting: ["id", "tenantId", "rewardKind", "rewardFixedCents", "rewardBps", "currency", "updatedBy", "createdAt", "updatedAt"],
};
/** Unique constraints (property names), mirrored by the memory store. */
export const UNIQUE: Partial<Record<Kind, readonly (readonly string[])[]>> = { link: [["slug"]], reward: [["referralId"]], setting: [["tenantId"]] };
/** Partial unique: a referred person is reserved while their referral is live (or converted). */
export const UNIQUE_WHEN: Partial<Record<Kind, readonly { cols: readonly string[]; col: string; in: readonly string[] }[]>> = {
  referral: [{ cols: ["emailKey"], col: "status", in: ["submitted", "qualified", "converted"] }],
};
export const snake = (k: string) => k.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
export const camel = (k: string) => k.replace(/_([a-z0-9])/g, (_m, c: string) => c.toUpperCase());
