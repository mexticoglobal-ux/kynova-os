export type ReferralsErrorCode = "forbidden" | "not_found" | "validation_failed" | "conflict" | "duplicate" | "invalid_state" | "limit_exceeded" | "unavailable" | "ai_unavailable";
const STATUS: Record<ReferralsErrorCode, number> = { forbidden: 403, not_found: 404, validation_failed: 422, conflict: 409, duplicate: 409, invalid_state: 409, limit_exceeded: 403, unavailable: 503, ai_unavailable: 503 };
export class ReferralsError extends Error {
  readonly status: number;
  constructor(readonly code: ReferralsErrorCode, message: string, readonly details?: Record<string, unknown>) { super(message); this.name = "ReferralsError"; this.status = STATUS[code]; }
}
export const isReferralsError = (e: unknown): e is ReferralsError => e instanceof ReferralsError || (typeof e === "object" && e !== null && (e as { name?: string }).name === "ReferralsError");
