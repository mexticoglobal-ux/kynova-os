import type { z } from "zod";
import { canAccess } from "@/config/modules";
import type { Role } from "@/config/roles";
import type { ActivitySink, SinkEvent } from "@/platform/activity";
import { allows } from "./access";
import { emailKey, rewardAmount } from "./compute";
import {
  CAPABILITIES, convertInput, linkInput, linkPatch, listQuery, referralInput, rejectInput, settingsPatch,
  type Capability, type LinkRecord, type ListQuery, type ReferralRecord, type RewardRecord, type SettingRecord,
} from "./domain";
import { ReferralsError } from "./errors";
import type { Cond, Kind, KindMap, ReferralsStore } from "./store";

export interface Actor { tenantId: string; userId: string; role: Role; requestId?: string; agentId?: string }
export interface Page<T> { items: T[]; nextCursor: string | null }
export interface ReferralsDeps { store: ReferralsStore; newId: () => string; now?: () => number; /** Evidence for the Activity Engine; optional so the module also runs without it. */ activity?: ActivitySink }

const enc = (v: string | number, id: string): string => btoa(JSON.stringify({ v, id })).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
function dec(c: string | undefined): { value: string | number; id: string } | undefined {
  if (!c) return undefined;
  try { const o = JSON.parse(atob(c.replace(/-/g, "+").replace(/_/g, "/"))) as { v?: unknown; id?: unknown }; if ((typeof o.v === "string" || typeof o.v === "number") && typeof o.id === "string") return { value: o.v, id: o.id }; } catch { /* falls through */ }
  throw new ReferralsError("validation_failed", "Invalid cursor.");
}
const SEARCH = { link: ["referrerName", "slug", "referrerEmail"], referral: ["referredName", "referredEmail"] } as const;
export const eq = <K extends Kind>(col: keyof KindMap[K] & string, value: string | number | boolean): Cond<K> => ({ col, op: "eq", value });
const SCAN_MAX = 5000, LIMITS = { link: 5000, referral: 50_000 } as const;
const DEFAULTS = { rewardKind: "fixed", rewardFixedCents: 5000, rewardBps: 1000, currency: "USD" } as const;

export function createReferralsService(deps: ReferralsDeps) {
  const { store } = deps;
  const now = deps.now ?? Date.now;
  const parse = <S extends z.ZodType>(schema: S, input: unknown): z.output<S> => {
    const r = schema.safeParse(input);
    if (!r.success) throw new ReferralsError("validation_failed", "One or more fields are invalid.", { fields: r.error.issues.map((i) => ({ field: i.path.join(".") || "_", message: i.message })) });
    return r.data;
  };
  const invalid = (field: string, message: string): never => { throw new ReferralsError("validation_failed", message, { fields: [{ field, message }] }); };
  const state = (message: string, details?: Record<string, unknown>): never => { throw new ReferralsError("invalid_state", message, details); };
  const one = async <K extends Kind>(kind: K, a: Actor, id: string, what: string): Promise<KindMap[K]> => (await store.get(kind, a.tenantId, id)) ?? ((): never => { throw new ReferralsError("not_found", `${what} not found.`); })();
  const can = (a: Actor, c: Capability): boolean => canAccess(a.role, "referrals") && allows(a.role, c) && (!a.agentId || c === "view");
  function need(a: Actor, c: Capability): void {
    if (can(a, c)) return;
    throw new ReferralsError("forbidden", a.agentId && c !== "view" ? "AI employees cannot change referrals." : `Your role cannot do this in Referrals (${c}).`);
  }
  /** Leaves evidence in the Activity Engine. Never fails the operation. */
  async function rec(a: Actor, e: SinkEvent): Promise<void> {
    if (!deps.activity) return;
    await deps.activity.record({ tenantId: a.tenantId, requestId: a.requestId }, { actorKind: a.agentId ? "employee" : "user", actorId: a.userId, ...e });
  }
  async function listPage<K extends Kind>(kind: K, a: Actor, q: ListQuery, where: Cond<K>[]): Promise<Page<KindMap[K]>> {
    const cols = (SEARCH as Record<string, readonly string[]>)[kind];
    const rows = await store.query(kind, a.tenantId, { where, search: q.q && cols ? { cols: cols as never, text: q.q } : undefined, limit: q.limit + 1, after: dec(q.cursor) });
    const page = rows.slice(0, q.limit), last = page.at(-1) as Record<string, unknown> | undefined;
    return { items: page, nextCursor: rows.length > q.limit && last ? enc(last.createdAt as number, last.id as string) : null };
  }
  async function scan<K extends Kind>(kind: K, a: Actor, where: Cond<K>[], max = SCAN_MAX): Promise<KindMap[K][]> {
    const out: KindMap[K][] = [];
    let after: { value: string; id: string } | undefined;
    for (;;) {
      const rows = await store.query(kind, a.tenantId, { where, orderBy: { col: "id" as never, dir: "asc" }, limit: 500, after });
      out.push(...rows);
      if (out.length > max) throw new ReferralsError("invalid_state", "There are too many records. Narrow the filters.");
      if (rows.length < 500) return out;
      const last = rows.at(-1) as { id: string }; after = { value: last.id, id: last.id };
    }
  }
  const w = <K extends Kind>(...c: (Cond<K> | false | undefined | "" | null)[]): Cond<K>[] => c.filter(Boolean) as Cond<K>[];
  const guardLimit = async (kind: Kind, a: Actor, max: number, what: string) => { if ((await store.count(kind, a.tenantId)) >= max) throw new ReferralsError("limit_exceeded", `You reached the limit of ${max} ${what}.`); };
  const cfg = async (a: Actor): Promise<SettingRecord> => (await store.query("setting", a.tenantId, { limit: 1 }))[0] ?? { id: "", tenantId: a.tenantId, ...DEFAULTS, updatedBy: "", createdAt: 0, updatedAt: 0 };
  const dupAs = async (field: string, msg: string, fn: () => Promise<void>): Promise<void> => { try { await fn(); } catch (e) { if ((e as { code?: string } | null)?.code === "duplicate") invalid(field, msg); throw e; } };
  const linkOf = (a: Actor, id: string) => one("link", a, id, "Link");
  const referralOf = (a: Actor, id: string) => one("referral", a, id, "Referral");

  /* ---------------- setup ---------------- */
  const setup = {
    async status(a: Actor) { need(a, "view"); return { initialized: (await store.count("setting", a.tenantId)) > 0 }; },
    async initialize(a: Actor) {
      need(a, "manage_settings");
      if ((await store.count("setting", a.tenantId)) > 0) throw new ReferralsError("invalid_state", "Referrals is already set up.");
      const t = now();
      await store.batch([{ op: "insert", kind: "setting", row: { id: deps.newId(), tenantId: a.tenantId, ...DEFAULTS, updatedBy: a.userId, createdAt: t, updatedAt: t } }]);
      await rec(a, { action: "referrals.program.initialized", summary: "Referral program set up" });
      return { initialized: true };
    },
  };

  /* ---------------- links ---------------- */
  async function setLink(a: Actor, id: string, to: LinkRecord["status"], from: readonly LinkRecord["status"][], label: string): Promise<LinkRecord> {
    need(a, "manage_links"); const l = await linkOf(a, id);
    if (!from.includes(l.status)) state(`A ${l.status} link cannot be ${label}.`, { reason: "invalid_transition", status: l.status });
    return (await store.update("link", a.tenantId, id, { status: to, updatedAt: now() })) as LinkRecord;
  }
  const links = {
    async list(a: Actor, q: unknown = {}) { need(a, "view"); const p = parse(listQuery, q); return listPage("link", a, p, w<"link">(p.status && eq<"link">("status", p.status))); },
    async get(a: Actor, id: string) {
      need(a, "view"); const l = await linkOf(a, id), rs = await scan("referral", a, [eq<"referral">("linkId", id)], LIMITS.referral);
      const rw = can(a, "view_rewards") ? await scan("reward", a, [eq<"reward">("linkId", id)], LIMITS.referral) : null, sum = (st: string) => (rw ?? []).filter((r) => r.status === st).reduce((s, r) => s + r.amountCents, 0);
      const count = (st: string) => rs.filter((r) => r.status === st).length;
      return { link: l, referrals: { submitted: count("submitted"), qualified: count("qualified"), converted: count("converted"), rejected: count("rejected") }, rewards: rw ? { pendingCents: sum("pending"), approvedCents: sum("approved"), paidCents: sum("paid") } : null };
    },
    async create(a: Actor, input: unknown) {
      need(a, "manage_links"); const i = parse(linkInput, input); await guardLimit("link", a, LIMITS.link, "links"); const t = now();
      const row: LinkRecord = { id: deps.newId(), tenantId: a.tenantId, slug: i.slug, referrerName: i.referrerName, referrerEmail: i.referrerEmail ?? null, status: "active", notes: i.notes, createdBy: a.userId, createdAt: t, updatedAt: t };
      await dupAs("slug", "That code is already used.", () => store.insert("link", row));
      await rec(a, { action: "referrals.link.created", summary: `Referral link created: ${row.referrerName}`, subjectKind: "link", subjectId: row.id });
      return row;
    },
    async update(a: Actor, id: string, input: unknown) { need(a, "manage_links"); const i = parse(linkPatch, input); await linkOf(a, id); return (await store.update("link", a.tenantId, id, { ...i, updatedAt: now() })) as LinkRecord; },
    async pause(a: Actor, id: string) {
      const l = await setLink(a, id, "paused", ["active"], "paused");
      await rec(a, { action: "referrals.link.paused", summary: `Referral link paused: ${l.referrerName}`, subjectKind: "link", subjectId: id, reversible: true, revertHint: { linkId: id } }); return l;
    },
    async resume(a: Actor, id: string) { const l = await setLink(a, id, "active", ["paused"], "resumed"); await rec(a, { action: "referrals.link.resumed", summary: `Referral link resumed: ${l.referrerName}`, subjectKind: "link", subjectId: id }); return l; },
    async close(a: Actor, id: string) { const l = await setLink(a, id, "closed", ["active", "paused"], "closed"); await rec(a, { action: "referrals.link.closed", summary: `Referral link closed: ${l.referrerName}`, subjectKind: "link", subjectId: id }); return l; },
  };

  /* ---------------- referrals ---------------- */
  const referrals = {
    async list(a: Actor, q: unknown = {}) { need(a, "view"); const p = parse(listQuery, q); return listPage("referral", a, p, w<"referral">(p.status && eq<"referral">("status", p.status), p.linkId && eq<"referral">("linkId", p.linkId))); },
    async get(a: Actor, id: string) {
      need(a, "view"); const r = await referralOf(a, id);
      return { referral: r, link: await store.get("link", a.tenantId, r.linkId), reward: can(a, "view_rewards") ? (await store.query("reward", a.tenantId, { where: [eq<"reward">("referralId", id)], limit: 1 }))[0] ?? null : null };
    },
    /** A person records a referral that arrived (the public referral page is not built yet). The referred person is reserved once. */
    async submit(a: Actor, input: unknown) {
      need(a, "manage_referrals"); const i = parse(referralInput, input), l = await linkOf(a, i.linkId);
      if (l.status !== "active") state("Only an active link can receive referrals.", { reason: "link_not_active", status: l.status });
      await guardLimit("referral", a, LIMITS.referral, "referrals"); const t = now(), key = emailKey(i.referredEmail), s = await cfg(a);
      if (l.referrerEmail && emailKey(l.referrerEmail) === key) invalid("referredEmail", "A person cannot refer themselves.");
      const row: ReferralRecord = { id: deps.newId(), tenantId: a.tenantId, linkId: l.id, referredName: i.referredName, referredEmail: i.referredEmail, emailKey: key, status: "submitted", valueCents: i.valueCents, currency: s.currency, rejectReason: "", convertedAt: null, closedAt: null, createdBy: a.userId, createdAt: t, updatedAt: t };
      try { await store.insert("referral", row); } catch (e) { if ((e as { code?: string } | null)?.code === "duplicate") state("This person was already referred.", { reason: "already_referred" }); throw e; }
      await rec(a, { action: "referrals.referral.submitted", summary: `Referral received: ${row.referredName} (via ${l.referrerName})`, subjectKind: "referral", subjectId: row.id });
      return row;
    },
    async qualify(a: Actor, id: string) {
      need(a, "manage_referrals"); const r = await referralOf(a, id); if (r.status !== "submitted") state("Only a submitted referral can be qualified.", { reason: "invalid_transition", status: r.status });
      const row = (await store.update("referral", a.tenantId, id, { status: "qualified", updatedAt: now() })) as ReferralRecord;
      await rec(a, { action: "referrals.referral.qualified", summary: `Referral qualified: ${r.referredName}`, subjectKind: "referral", subjectId: id }); return row;
    },
    /** Converting creates exactly one pending reward in the same batch (the database allows one reward per referral). */
    async convert(a: Actor, id: string, input: unknown = {}) {
      need(a, "manage_referrals"); const i = parse(convertInput, input), r = await referralOf(a, id), l = await linkOf(a, r.linkId);
      if (r.status !== "submitted" && r.status !== "qualified") state("Only an open referral can be converted.", { reason: "invalid_transition", status: r.status });
      const t = now(), s = await cfg(a), value = i.valueCents ?? r.valueCents;
      const reward: RewardRecord = { id: deps.newId(), tenantId: a.tenantId, referralId: id, linkId: l.id, amountCents: rewardAmount(s, value), currency: r.currency, status: "pending", mode: "not_connected", approvedAt: null, paidAt: null, reversedAt: null, createdBy: a.userId, createdAt: t, updatedAt: t };
      await store.batch([{ op: "update", kind: "referral", tenantId: a.tenantId, id, patch: { status: "converted", valueCents: value, convertedAt: t, closedAt: t, updatedAt: t } }, { op: "insert", kind: "reward", row: reward }]);
      await rec(a, { action: "referrals.referral.converted", summary: `Referral converted: ${r.referredName} (${(reward.amountCents / 100).toFixed(2)} ${reward.currency} reward)`, subjectKind: "referral", subjectId: id });
      return { referral: await referralOf(a, id), reward };
    },
    async reject(a: Actor, id: string, input: unknown = {}) {
      need(a, "manage_referrals"); const i = parse(rejectInput, input), r = await referralOf(a, id);
      if (r.status !== "submitted" && r.status !== "qualified") state("Only an open referral can be rejected.", { reason: "invalid_transition", status: r.status });
      const t = now(), row = (await store.update("referral", a.tenantId, id, { status: "rejected", rejectReason: i.reason, closedAt: t, updatedAt: t })) as ReferralRecord;
      await rec(a, { action: "referrals.referral.rejected", summary: `Referral rejected: ${r.referredName}`, subjectKind: "referral", subjectId: id }); return row;
    },
  };

  /* ---------------- rewards (simulated: nothing is paid for real) ---------------- */
  const rewards = {
    async get(a: Actor, id: string) { need(a, "view_rewards"); return one("reward", a, id, "Reward"); },
    async list(a: Actor, q: unknown = {}) { need(a, "view_rewards"); const p = parse(listQuery, q); return listPage("reward", a, p, w<"reward">(p.status && eq<"reward">("status", p.status), p.linkId && eq<"reward">("linkId", p.linkId), p.referralId && eq<"reward">("referralId", p.referralId))); },
    async approve(a: Actor, id: string) {
      need(a, "approve_rewards"); const r = await one("reward", a, id, "Reward"); if (r.status !== "pending") state("Only a pending reward can be approved.", { reason: "invalid_transition", status: r.status });
      const t = now(), row = (await store.update("reward", a.tenantId, id, { status: "approved", approvedAt: t, updatedAt: t })) as RewardRecord;
      await rec(a, { action: "referrals.reward.approved", summary: `Reward approved (${(r.amountCents / 100).toFixed(2)} ${r.currency})`, subjectKind: "reward", subjectId: id, reversible: true, revertHint: { rewardId: id } }); return row;
    },
    async unapprove(a: Actor, id: string) {
      need(a, "approve_rewards"); const r = await one("reward", a, id, "Reward"); if (r.status !== "approved") state("Only an approved reward can be unapproved.", { reason: "invalid_transition", status: r.status });
      return (await store.update("reward", a.tenantId, id, { status: "pending", approvedAt: null, updatedAt: now() })) as RewardRecord;
    },
    /** Marks the reward paid. Simulated: no provider is contacted and no money moves. */
    async pay(a: Actor, id: string) {
      need(a, "approve_rewards"); const r = await one("reward", a, id, "Reward"); if (r.status !== "approved") state("Only an approved reward can be marked paid.", { reason: "invalid_transition", status: r.status });
      const t = now(), row = (await store.update("reward", a.tenantId, id, { status: "paid", mode: "simulated", paidAt: t, updatedAt: t })) as RewardRecord;
      await rec(a, { action: "referrals.reward.paid", summary: `Reward marked paid (simulated, ${(r.amountCents / 100).toFixed(2)} ${r.currency})`, subjectKind: "reward", subjectId: id, mode: "simulation" }); return row;
    },
    async reverse(a: Actor, id: string) {
      need(a, "approve_rewards"); const r = await one("reward", a, id, "Reward"); if (r.status === "paid" || r.status === "reversed") state("A paid or reversed reward cannot be reversed.", { reason: "invalid_transition", status: r.status });
      const t = now(), row = (await store.update("reward", a.tenantId, id, { status: "reversed", reversedAt: t, updatedAt: t })) as RewardRecord;
      await rec(a, { action: "referrals.reward.reversed", summary: "Reward reversed", subjectKind: "reward", subjectId: id }); return row;
    },
  };

  /* ---------------- settings ---------------- */
  const settingsApi = {
    async get(a: Actor) { need(a, "view"); return cfg(a); },
    async update(a: Actor, input: unknown) {
      need(a, "manage_settings"); const i = parse(settingsPatch, input), cur = await cfg(a);
      if (!cur.id) throw new ReferralsError("invalid_state", "Set up Referrals first.");
      const row = (await store.update("setting", a.tenantId, cur.id, { ...i, updatedBy: a.userId, updatedAt: now() })) as SettingRecord;
      await rec(a, { action: "referrals.settings.updated", summary: "Referral reward settings updated" }); return row;
    },
  };

  /* ---------------- summary ---------------- */
  async function summary(a: Actor) {
    need(a, "view"); const initialized = (await store.count("setting", a.tenantId)) > 0;
    if (!initialized) return { initialized, links: 0, activeLinks: 0, submitted: 0, qualified: 0, converted: 0, rejected: 0, conversionRate: null, pendingCents: null, approvedCents: null, paidCents: null };
    const lc = (st: string) => store.count("link", a.tenantId, [eq<"link">("status", st)]), rc = (st: string) => store.count("referral", a.tenantId, [eq<"referral">("status", st)]);
    const [links_, active, submitted, qualified, converted, rejected] = await Promise.all([store.count("link", a.tenantId), lc("active"), rc("submitted"), rc("qualified"), rc("converted"), rc("rejected")]);
    const money = can(a, "view_rewards"), sum = async (st: string) => (await scan("reward", a, [eq<"reward">("status", st)], LIMITS.referral)).reduce((s, r) => s + r.amountCents, 0), closed = converted + rejected;
    return {
      initialized, links: links_, activeLinks: active, submitted, qualified, converted, rejected, conversionRate: closed ? Math.round((converted / closed) * 1000) / 10 : null,
      pendingCents: money ? await sum("pending") : null, approvedCents: money ? await sum("approved") : null, paidCents: money ? await sum("paid") : null,
    };
  }

  const permissions = { async mine(a: Actor) { return { role: a.role, capabilities: CAPABILITIES.filter((c) => can(a, c)) }; } };
  return { setup, summary, permissions, links, referrals, rewards, settings: settingsApi };
}
export type ReferralsService = ReturnType<typeof createReferralsService>;
