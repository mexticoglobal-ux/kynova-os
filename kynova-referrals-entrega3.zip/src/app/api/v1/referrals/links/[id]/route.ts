import { referralsRoute, noContent, parseListQuery, readBody, respond } from "@/modules/referrals/http";

type Ctx = { params: Promise<{ id: string }> };

export const GET = referralsRoute<Ctx>(async (req, c, { actor, svc, rid }) => { const p = await c.params; return respond(await svc.links.get(actor, p.id), rid); });
export const PATCH = referralsRoute<Ctx>(async (req, c, { actor, svc, rid }) => { const p = await c.params; return respond(await svc.links.update(actor, p.id, await readBody(req)), rid); }, { mutating: true });
