import { referralsRoute, noContent, parseListQuery, readBody, respond } from "@/modules/referrals/http";

export const GET = referralsRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.permissions.mine(actor), rid); });
