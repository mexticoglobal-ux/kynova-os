import { referralsRoute, noContent, parseListQuery, readBody, respond } from "@/modules/referrals/http";

export const GET = referralsRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.setup.status(actor), rid); });
export const POST = referralsRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.setup.initialize(actor), rid, 201); }, { mutating: true });
