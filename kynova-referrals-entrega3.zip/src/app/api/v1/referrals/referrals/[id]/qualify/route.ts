import { referralsRoute, noContent, parseListQuery, readBody, respond } from "@/modules/referrals/http";

type Ctx = { params: Promise<{ id: string }> };

export const POST = referralsRoute<Ctx>(async (req, c, { actor, svc, rid }) => { const p = await c.params; return respond(await svc.referrals.qualify(actor, p.id), rid); }, { mutating: true });
