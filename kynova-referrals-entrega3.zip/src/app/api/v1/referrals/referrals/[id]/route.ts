import { referralsRoute, noContent, parseListQuery, readBody, respond } from "@/modules/referrals/http";

type Ctx = { params: Promise<{ id: string }> };

export const GET = referralsRoute<Ctx>(async (req, c, { actor, svc, rid }) => { const p = await c.params; return respond(await svc.referrals.get(actor, p.id), rid); });
