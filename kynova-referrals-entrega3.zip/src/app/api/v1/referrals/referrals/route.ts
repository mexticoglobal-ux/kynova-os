import { referralsRoute, noContent, parseListQuery, readBody, respond } from "@/modules/referrals/http";

export const GET = referralsRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.referrals.list(actor, parseListQuery(req)), rid); });
export const POST = referralsRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.referrals.submit(actor, await readBody(req)), rid, 201); }, { mutating: true });
