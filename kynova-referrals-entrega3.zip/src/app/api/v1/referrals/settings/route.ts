import { referralsRoute, noContent, parseListQuery, readBody, respond } from "@/modules/referrals/http";

export const GET = referralsRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.settings.get(actor), rid); });
export const PATCH = referralsRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.settings.update(actor, await readBody(req)), rid); }, { mutating: true });
