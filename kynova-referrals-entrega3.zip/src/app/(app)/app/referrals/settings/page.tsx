import ActionButton from "@/components/referrals/ActionButton";
import EntityForm from "@/components/referrals/EntityForm";
import LocalTime from "@/components/referrals/LocalTime";
import { referralsContext } from "@/components/referrals/context";
import { K } from "@/components/referrals/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/referrals/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/referrals/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/referrals";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
import SettingsForm from "@/components/referrals/SettingsForm";
import { ROLES } from "@/config/roles";
import { ARCHITECTURE_STATUS, CAPABILITIES, CURRENCIES, DEFAULT_CAPABILITIES } from "@/modules/referrals";
export default async function Page() {
  const { actor, svc, t, can } = await referralsContext();
  const [s, mine] = await Promise.all([svc.settings.get(actor), svc.permissions.mine(actor)]);
  return (
    <>
      <PageHeader title={t("set.title")} />
      <Card title={t("set.reward")}>{can("manage_settings") ? <SettingsForm initial={{ rewardKind: s.rewardKind, rewardFixedCents: s.rewardFixedCents, rewardBps: s.rewardBps, currency: s.currency }} currencies={CURRENCIES} /> : <p className="text-sm text-muted">{t("set.readOnly")}</p>}</Card>
      <Card title={t("set.yourAccess")} className="mt-4"><p className="mb-2 text-sm">{t(K(`role.${mine.role}`))}</p><ul className="flex flex-wrap gap-2">{mine.capabilities.map((c) => <li key={c}><Pill>{t(K(`cap.${c}`))}</Pill></li>)}</ul></Card>
      <Card title={t("set.matrix")} className="mt-4">
        <Table head={[t("set.role"), ...CAPABILITIES.map((c) => t(K(`cap.${c}`)))]} rows={ROLES.map((r) => ({ key: r, cells: [t(K(`role.${r}`)), ...CAPABILITIES.map((c) => (DEFAULT_CAPABILITIES[r].includes(c) ? "✓" : "—"))] }))} />
        <p className="mt-2 text-xs text-muted">{t("set.matrixHint")}</p>
      </Card>
      <Card title={t("arch.title")} className="mt-4"><Table head={[t("arch.part"), t("common.status")]} rows={Object.entries(ARCHITECTURE_STATUS).map(([k, v]) => ({ key: k, cells: [t(K(`arch.${k}`)), <Pill key="v" tone={v === "not_applicable" ? "success" : "warning"}>{t(K(`arch.state.${v}`))}</Pill>] }))} /></Card>
    </>
  );
}
