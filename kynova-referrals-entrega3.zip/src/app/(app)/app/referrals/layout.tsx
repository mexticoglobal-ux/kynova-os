import Link from "next/link";
import { ReferralsI18n } from "@/components/referrals/I18n";
import { referralsContext } from "@/components/referrals/context";
import ActionButton from "@/components/referrals/ActionButton";
import { Card } from "@/components/referrals/ui";
import { REFERRALS_DICTIONARIES } from "@/modules/referrals";

const TABS = [["", "nav.dashboard"], ["links", "nav.links"], ["referrals", "nav.referrals"], ["rewards", "nav.rewards"], ["settings", "nav.settings"]] as const;

export default async function ReferralsLayout({ children }: { children: React.ReactNode }) {
  const { t, locale, can, svc, actor } = await referralsContext();
  const ready = (await svc.setup.status(actor).catch(() => ({ initialized: false }))).initialized;
  return (
    <ReferralsI18n dict={REFERRALS_DICTIONARIES[locale]} locale={locale}>
      <div className="mx-auto w-full max-w-[96rem] p-4 sm:p-6 lg:p-8">
        <nav aria-label={t("title")} className="-mx-1 mb-5 flex gap-1 overflow-x-auto border-b border-line px-1 pb-2">
          {TABS.map(([x, k]) => <Link key={x} href={`/app/referrals${x ? `/${x}` : ""}`} className="shrink-0 rounded-lg px-3 py-1.5 text-sm hover:bg-ac/10 focus-visible:outline-2 focus-visible:outline-ac2">{t(k)}</Link>)}
        </nav>
        {ready ? children : (
          <Card title={t("setup.title")}>
            {can("manage_settings") ? <div className="grid max-w-xl gap-3"><p className="text-sm text-muted">{t("setup.intro")}</p><div><ActionButton path="/setup" label="setup.start" tone="primary" /></div></div> : <p className="text-sm text-muted">{t("setup.notReady")}</p>}
          </Card>
        )}
      </div>
    </ReferralsI18n>
  );
}
