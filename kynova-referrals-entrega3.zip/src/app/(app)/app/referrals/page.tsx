import ActionButton from "@/components/referrals/ActionButton";
import EntityForm from "@/components/referrals/EntityForm";
import LocalTime from "@/components/referrals/LocalTime";
import { referralsContext } from "@/components/referrals/context";
import { K } from "@/components/referrals/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/referrals/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/referrals/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/referrals";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
import Link from "next/link";
import { ARCHITECTURE_STATUS } from "@/modules/referrals";
export default async function Page() {
  const { actor, svc, t, locale, can } = await referralsContext();
  const [s, st, recent] = await Promise.all([svc.summary(actor), svc.settings.get(actor), svc.referrals.list(actor, { limit: 8 })]);
  const money = (c: number) => fmtMoney(c, st.currency, locale), names = new Map((await svc.links.list(actor, { limit: 100 })).items.map((l) => [l.id, l.referrerName]));
  return (
    <>
      <PageHeader title={t("title")} />
      <p role="note" className="mb-4 rounded-xl border border-line px-3 py-2 text-xs text-muted">{t("arch.notice")}</p>
      <dl className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label={t("dash.links")} value={s.activeLinks} sub={t("dash.of", { n: s.links })} /><Stat label={t("dash.submitted")} value={s.submitted} /><Stat label={t("dash.qualified")} value={s.qualified} /><Stat label={t("dash.converted")} value={s.converted} />
        <Stat label={t("dash.rejected")} value={s.rejected} /><Stat label={t("dash.rate")} value={s.conversionRate === null ? "—" : `${s.conversionRate}%`} />
        {s.pendingCents !== null && <><Stat label={t("dash.pending")} value={money(s.pendingCents)} /><Stat label={t("dash.approved")} value={money(s.approvedCents ?? 0)} /><Stat label={t("dash.paid")} value={money(s.paidCents ?? 0)} /></>}
      </dl>
      <Card title={t("dash.recent")}>{recent.items.length === 0 ? <Empty>{t("common.noResults")}</Empty> : <Table head={[t("ref.referred"), t("ref.link"), t("common.status")]} rows={recent.items.map((r) => ({ key: r.id, cells: [<Link key="n" className="hover:underline" href={`${B}/referrals`}>{r.referredName}</Link>, names.get(r.linkId) ?? "—", <StatusPill key="s" status={r.status} label={t(K(`rst.${r.status}`))} />] }))} />}</Card>
      <h2 className="mb-2 mt-6 text-sm font-semibold">{t("arch.title")}</h2>
      <Table head={[t("arch.part"), t("common.status")]} rows={Object.entries(ARCHITECTURE_STATUS).map(([k, v]) => ({ key: k, cells: [t(K(`arch.${k}`)), <Pill key="v" tone={v === "not_applicable" ? "success" : "warning"}>{t(K(`arch.state.${v}`))}</Pill>] }))} />
    </>
  );
}
