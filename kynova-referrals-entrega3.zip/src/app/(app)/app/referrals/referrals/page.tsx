import ActionButton from "@/components/referrals/ActionButton";
import EntityForm from "@/components/referrals/EntityForm";
import LocalTime from "@/components/referrals/LocalTime";
import { referralsContext } from "@/components/referrals/context";
import { K } from "@/components/referrals/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/referrals/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/referrals/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/referrals";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
import { REFERRAL_STATUS } from "@/modules/referrals";
export default async function Page({ searchParams }: SP) {
  const { actor, svc, t, locale, can } = await referralsContext(), q = await cur(searchParams, ["q", "status", "linkId"]), p = await searchParams;
  const [r, ls, st] = await Promise.all([svc.referrals.list(actor, q), svc.links.list(actor, { limit: 100 }), svc.settings.get(actor)]);
  const ln = new Map(ls.items.map((x) => [x.id, x.referrerName])), params = { q: sp1(p.q), status: sp1(p.status), linkId: sp1(p.linkId) }, mg = can("manage_referrals");
  return (
    <>
      <PageHeader title={t("nav.referrals")} />
      <FilterForm t={t} params={params} selects={[{ name: "status", label: t("common.status"), options: REFERRAL_STATUS.map((x) => ({ value: x, label: t(K(`rst.${x}`)) })) }, { name: "linkId", label: t("ref.link"), options: ls.items.map((x) => ({ value: x.id, label: x.referrerName })) }]} />
      {r.items.length === 0 ? <Empty>{t("common.noResults")}</Empty> : (
        <Table right={[3]} head={[t("ref.referred"), t("ref.link"), t("common.email"), t("ref.value"), t("common.status"), ...(mg ? [t("common.actions")] : [])]} rows={r.items.map((x) => ({ key: x.id, cells: [x.referredName, ln.get(x.linkId) ?? "—", x.referredEmail, fmtMoney(x.valueCents, x.currency, locale), <StatusPill key="s" status={x.status} label={t(K(`rst.${x.status}`))} />,
          ...(mg ? [<span key="a" className="flex flex-wrap gap-2">{x.status === "submitted" && <ActionButton path={`/referrals/${x.id}/qualify`} label="ref.qualify" />}{(x.status === "submitted" || x.status === "qualified") && <><ActionButton path={`/referrals/${x.id}/convert`} label="ref.convert" tone="primary" confirm /><ActionButton path={`/referrals/${x.id}/reject`} label="ref.reject" tone="danger" ask={{ field: "reason", label: "ref.reason" }} /></>}</span>] : [])] }))} />
      )}
      <Pager t={t} base={`${B}/referrals`} params={params} next={r.nextCursor} />
      {mg && ls.items.some((x) => x.status === "active") && (
        <Card title={t("ref.new")} className="mt-5">
          <EntityForm path="/referrals" fields={[{ name: "linkId", label: "ref.link", kind: "select", required: true, options: ls.items.filter((x) => x.status === "active").map((x) => ({ value: x.id, label: x.referrerName })) }, { name: "referredName", label: "ref.referred", required: true, max: 120 }, { name: "referredEmail", label: "common.email", required: true, max: 120 }, { name: "valueCents", label: "ref.value", kind: "money" }]} />
          <p className="mt-2 text-xs text-muted">{t("ref.hint", { c: st.currency })}</p>
        </Card>
      )}
    </>
  );
}
