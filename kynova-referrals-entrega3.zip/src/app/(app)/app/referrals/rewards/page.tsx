import ActionButton from "@/components/referrals/ActionButton";
import EntityForm from "@/components/referrals/EntityForm";
import LocalTime from "@/components/referrals/LocalTime";
import { referralsContext } from "@/components/referrals/context";
import { K } from "@/components/referrals/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/referrals/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/referrals/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/referrals";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
import { REWARD_STATUS } from "@/modules/referrals";
export default async function Page({ searchParams }: SP) {
  const { actor, svc, t, locale, can } = await referralsContext(), q = await cur(searchParams, ["status", "linkId"]), p = await searchParams;
  const [r, ls, rf] = await Promise.all([svc.rewards.list(actor, q), svc.links.list(actor, { limit: 100 }), svc.referrals.list(actor, { limit: 100 })]);
  const ln = new Map(ls.items.map((x) => [x.id, x.referrerName])), rn = new Map(rf.items.map((x) => [x.id, x.referredName])), params = { status: sp1(p.status), linkId: sp1(p.linkId) }, ap = can("approve_rewards");
  return (
    <>
      <PageHeader title={t("nav.rewards")} />
      <p role="note" className="mb-4 rounded-xl border border-line px-3 py-2 text-xs text-muted">{t("rw.notice")}</p>
      <FilterForm t={t} q={false} params={params} selects={[{ name: "status", label: t("common.status"), options: REWARD_STATUS.map((x) => ({ value: x, label: t(K(`wst.${x}`)) })) }, { name: "linkId", label: t("ref.link"), options: ls.items.map((x) => ({ value: x.id, label: x.referrerName })) }]} />
      {r.items.length === 0 ? <Empty>{t("common.noResults")}</Empty> : (
        <Table right={[2]} head={[t("lnk.referrer"), t("ref.referred"), t("rw.amount"), t("common.status"), t("rw.mode"), ...(ap ? [t("common.actions")] : [])]} rows={r.items.map((x) => ({ key: x.id, cells: [ln.get(x.linkId) ?? "—", rn.get(x.referralId) ?? "—", fmtMoney(x.amountCents, x.currency, locale), <StatusPill key="s" status={x.status} label={t(K(`wst.${x.status}`))} />, t(K(`wmode.${x.mode}`)),
          ...(ap ? [<span key="a" className="flex flex-wrap gap-2">{x.status === "pending" && <ActionButton path={`/rewards/${x.id}/approve`} label="rw.approve" tone="primary" />}{x.status === "approved" && <><ActionButton path={`/rewards/${x.id}/pay`} label="rw.markPaid" tone="primary" confirm /><ActionButton path={`/rewards/${x.id}/unapprove`} label="rw.unapprove" /></>}{(x.status === "pending" || x.status === "approved") && <ActionButton path={`/rewards/${x.id}/reverse`} label="rw.reverse" tone="danger" confirm />}</span>] : [])] }))} />
      )}
      <Pager t={t} base={`${B}/rewards`} params={params} next={r.nextCursor} />
    </>
  );
}
