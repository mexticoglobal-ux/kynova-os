import ActionButton from "@/components/referrals/ActionButton";
import EntityForm from "@/components/referrals/EntityForm";
import LocalTime from "@/components/referrals/LocalTime";
import { referralsContext } from "@/components/referrals/context";
import { K } from "@/components/referrals/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/referrals/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/referrals/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/referrals";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
import { getActivityService } from "@/platform/activity";
export default async function Page({ params, searchParams }: { params: Promise<{ id: string }> } & SP) {
  const { id } = await params, { actor, svc, t, locale, can } = await referralsContext(), q = await cur(searchParams, []);
  void q;
  const [d, st, rs, activity] = await Promise.all([orNotFound(svc.links.get(actor, id)), svc.settings.get(actor), svc.referrals.list(actor, { linkId: id, limit: 50 }), getActivityService().then((a) => a.timeline(actor, "link", id, { limit: 8 })).catch(() => null)]);
  const l = d.link;
  return (
    <>
      <PageHeader title={l.referrerName} back={{ href: `${B}/links`, label: t("nav.links") }} actions={
        <div className="flex flex-wrap gap-2">
          {l.status === "active" && <ActionButton path={`/links/${id}/pause`} label="lnk.pause" confirm />}
          {l.status === "paused" && <ActionButton path={`/links/${id}/resume`} label="lnk.resume" tone="primary" />}
          {l.status !== "closed" && <ActionButton path={`/links/${id}/close`} label="lnk.close" tone="danger" confirm />}
        </div>} />
      <dl className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label={t("common.status")} value={t(K(`lst.${l.status}`))} /><Stat label={t("lnk.code")} value={l.slug} /><Stat label={t("dash.converted")} value={d.referrals.converted} /><Stat label={t("dash.submitted")} value={d.referrals.submitted + d.referrals.qualified} />
        {d.rewards && <><Stat label={t("dash.pending")} value={fmtMoney(d.rewards.pendingCents, st.currency, locale)} /><Stat label={t("dash.approved")} value={fmtMoney(d.rewards.approvedCents, st.currency, locale)} /><Stat label={t("dash.paid")} value={fmtMoney(d.rewards.paidCents, st.currency, locale)} /></>}
      </dl>
      <Card title={t("nav.referrals")}>{rs.items.length === 0 ? <Empty>{t("common.noResults")}</Empty> : <Table head={[t("ref.referred"), t("common.email"), t("common.status")]} rows={rs.items.map((r) => ({ key: r.id, cells: [r.referredName, r.referredEmail, <StatusPill key="s" status={r.status} label={t(K(`rst.${r.status}`))} />] }))} />}</Card>
      {can("manage_referrals") && l.status === "active" && (
        <Card title={t("ref.new")} className="mt-4"><EntityForm path="/referrals" fixed={{ linkId: id }} fields={[{ name: "referredName", label: "ref.referred", required: true, max: 120 }, { name: "referredEmail", label: "common.email", required: true, max: 120 }, { name: "valueCents", label: "ref.value", kind: "money" }]} /></Card>
      )}
      <Card title={t("lnk.activity")} className="mt-4">{!activity || activity.items.length === 0 ? <Empty>{t("lnk.noActivity")}</Empty> : <ul className="grid gap-1 text-sm">{activity.items.map((e) => <li key={e.id} className="flex justify-between gap-3"><span>{e.summary}</span><LocalTime ms={e.occurredAt} locale={locale} /></li>)}</ul>}<p className="mt-2 text-xs text-muted">{t("lnk.activityNote")}</p></Card>
    </>
  );
}
