import ActionButton from "@/components/referrals/ActionButton";
import EntityForm from "@/components/referrals/EntityForm";
import LocalTime from "@/components/referrals/LocalTime";
import { referralsContext } from "@/components/referrals/context";
import { K } from "@/components/referrals/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/referrals/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/referrals/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/referrals";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
import Link from "next/link";
import { LINK_STATUS } from "@/modules/referrals";
export default async function Page({ searchParams }: SP) {
  const { actor, svc, t, can } = await referralsContext(), q = await cur(searchParams, ["q", "status"]), p = await searchParams;
  const r = await svc.links.list(actor, q), params = { q: sp1(p.q), status: sp1(p.status) };
  return (
    <>
      <PageHeader title={t("nav.links")} />
      <FilterForm t={t} params={params} selects={[{ name: "status", label: t("common.status"), options: LINK_STATUS.map((x) => ({ value: x, label: t(K(`lst.${x}`)) })) }]} />
      {r.items.length === 0 ? <Empty>{t("lnk.none")}</Empty> : (
        <Table head={[t("lnk.referrer"), t("lnk.code"), t("common.email"), t("common.status")]} rows={r.items.map((x) => ({ key: x.id, cells: [<Link key="n" className="hover:underline" href={`${B}/links/${x.id}`}>{x.referrerName}</Link>, x.slug, x.referrerEmail ?? "—", <StatusPill key="s" status={x.status} label={t(K(`lst.${x.status}`))} />] }))} />
      )}
      <Pager t={t} base={`${B}/links`} params={params} next={r.nextCursor} />
      {can("manage_links") && (
        <Card title={t("lnk.new")} className="mt-5">
          <EntityForm path="/links" goto={`${B}/links/`} fields={[{ name: "referrerName", label: "lnk.referrer", required: true, max: 100 }, { name: "slug", label: "lnk.code", required: true, max: 40 }, { name: "referrerEmail", label: "common.email", max: 120 }, { name: "notes", label: "common.notes", kind: "textarea", max: 500 }]} />
          <p className="mt-2 text-xs text-muted">{t("lnk.hint")}</p>
        </Card>
      )}
    </>
  );
}
