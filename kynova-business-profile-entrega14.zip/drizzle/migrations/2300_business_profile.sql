-- Business Profile + Business DNA (Entrega 14). Owned by src/platform/business-profile. One row per company; tenant_id is the primary key.
-- Name, industry, country, language, currency and time zone stay in `companies` (single source of truth).
CREATE TABLE `bp_profiles` (
	`tenant_id` text PRIMARY KEY NOT NULL, `logo_url` text DEFAULT '' NOT NULL, `website` text DEFAULT '' NOT NULL, `socials` text DEFAULT '{}' NOT NULL, `email` text DEFAULT '' NOT NULL, `phone` text DEFAULT '' NOT NULL,
	`location` text DEFAULT '' NOT NULL, `basics_confirmed_at` integer, `updated_by` text DEFAULT '' NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `bp_dna` (
	`tenant_id` text PRIMARY KEY NOT NULL, `objectives` text DEFAULT '[]' NOT NULL, `value_proposition` text DEFAULT '' NOT NULL, `customer_type` text DEFAULT '' NOT NULL, `tone` text DEFAULT '' NOT NULL, `industries` text DEFAULT '[]' NOT NULL,
	`products` text DEFAULT '[]' NOT NULL, `services` text DEFAULT '[]' NOT NULL, `competitors` text DEFAULT '[]' NOT NULL, `keywords` text DEFAULT '[]' NOT NULL, `priorities` text DEFAULT '[]' NOT NULL,
	`updated_by` text DEFAULT '' NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TRIGGER bp_profiles_no_delete BEFORE DELETE ON bp_profiles BEGIN SELECT RAISE(ABORT, 'bp_profiles rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER bp_dna_no_delete BEFORE DELETE ON bp_dna BEGIN SELECT RAISE(ABORT, 'bp_dna rows cannot be deleted'); END;
