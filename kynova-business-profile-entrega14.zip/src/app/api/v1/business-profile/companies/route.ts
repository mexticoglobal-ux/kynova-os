import { createMyCompany, listMyCompanies } from "@/platform/business-profile";
import { bpRoute, readBody, respond } from "@/platform/business-profile/http";
export const GET = bpRoute(async (req, c, { userId, actor, rid }) => { void req; void c; return respond({ current: actor.tenantId, companies: await listMyCompanies(userId) }, rid); });
export const POST = bpRoute(async (req, c, { svc, userId, rid }) => { void c; return respond(await createMyCompany(userId, svc.parseCreateCompany(await readBody(req))), rid, 201); }, { mutating: true });
