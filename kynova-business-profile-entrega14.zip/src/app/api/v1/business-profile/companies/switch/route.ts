import { NextResponse } from "next/server";
import { getAuthService } from "@/platform/auth";
import { getAuthConfig } from "@/platform/auth/http";
import { switchInput } from "@/platform/business-profile";
import { BusinessProfileError } from "@/platform/business-profile";
import { bpRoute, readBody } from "@/platform/business-profile/http";

/** Switches the live session to another company of the same person. The server checks the membership; the client never chooses a role. */
export const POST = bpRoute(async (req, c, { rid }) => {
  void c; const cfg = getAuthConfig(), b = switchInput.safeParse(await readBody(req));
  if (!b.success) throw new BusinessProfileError("validation_failed", "company_id is required.");
  const r = await getAuthService().switchTenant(req.cookies.get(cfg.cookie.session)?.value, b.data.companyId);
  if (!r) throw new BusinessProfileError("forbidden", "You do not belong to that company.");
  const res = NextResponse.json({ data: { company_id: r.tenantId, role: r.role } }, { headers: { "X-Request-Id": rid, "Cache-Control": "no-store" } });
  res.cookies.set(cfg.cookie.ticket, r.ticket, { httpOnly: true, secure: cfg.cookie.secure, sameSite: "lax", path: "/", maxAge: cfg.ttl.ticketSec });
  return res;
}, { mutating: true });
