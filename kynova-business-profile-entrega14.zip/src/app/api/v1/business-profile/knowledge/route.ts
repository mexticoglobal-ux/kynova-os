import { bpRoute, respond } from "@/platform/business-profile/http";
export const GET = bpRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.state(actor), rid); });
