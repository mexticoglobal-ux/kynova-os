import { bpRoute, readBody, respond } from "@/platform/business-profile/http";
export const GET = bpRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.dna(actor), rid); });
export const PUT = bpRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.saveDna(actor, await readBody(req)), rid); }, { mutating: true });
