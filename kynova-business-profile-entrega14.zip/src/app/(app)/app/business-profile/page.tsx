import { redirect } from "next/navigation";
import { Companies, DnaForm, ProfileForm } from "@/components/business-profile/Forms";
import { KnowledgeCard } from "@/components/business-profile/KnowledgeCard";
import { Card } from "@/components/workforce/ui";
import { LOCALES } from "@/config/locales";
import { requireModuleAccess } from "@/platform/auth/session";
import { BUSINESS_PROFILE_DICTIONARIES, PRIORITIES, SOCIALS, businessProfileLocale, getBusinessProfileService, listMyCompanies, tr } from "@/platform/business-profile";

export const metadata = { title: "Business Profile" };
export const dynamic = "force-dynamic";

export default async function BusinessProfilePage() {
  const s = await requireModuleAccess("business-profile");
  if (!s.tenantId) redirect("/app/profile");
  const actor = { tenantId: s.tenantId, userId: s.user.id, role: s.role }, svc = await getBusinessProfileService(), locale = businessProfileLocale(s.user.locale), L = BUSINESS_PROFILE_DICTIONARIES[locale], t = (k: Parameters<typeof tr>[1], v?: Record<string, number | string>) => tr(locale, k, v);
  const [p, dna, state, perm, companies] = await Promise.all([svc.profile(actor), svc.dna(actor), svc.state(actor), svc.permissions(actor), listMyCompanies(s.user.id)]), manage = perm.capabilities.includes("manage"), b = p.basics;
  return (
    <main id="main" className="mx-auto grid w-full max-w-[72rem] gap-5 p-4 sm:p-6 lg:p-8">
      <header><h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{t("title")}</h1><p className="mt-1 text-sm text-muted">{t("sub")}</p></header>
      <KnowledgeCard state={state} t={t} manage={false} />
      <Card title={t("sec.companies")}><Companies companies={companies.map((c) => ({ id: c.id, name: c.name, industry: c.industry }))} current={s.tenantId} L={L} /></Card>
      {manage ? (
        <>
          <Card title={t("sec.profile")}><ProfileForm L={L} locales={[...LOCALES]} socials={[...SOCIALS]} init={{ name: b?.name ?? "", industry: b?.industry ?? "", country: b?.country ?? "", locale: b?.locale ?? "en", currency: b?.currency ?? "USD", timezone: b?.timezone ?? "UTC", website: p.website, logoUrl: p.logoUrl, email: p.email, phone: p.phone, location: p.location, socials: p.socials }} /></Card>
          <Card title={t("sec.dna")}><DnaForm L={L} priorities={[...PRIORITIES]} init={{ objectives: dna.objectives, valueProposition: dna.valueProposition, customerType: dna.customerType, tone: dna.tone, industries: dna.industries, products: dna.products, services: dna.services, competitors: dna.competitors, keywords: dna.keywords, priorities: dna.priorities }} /></Card>
        </>
      ) : null}
    </main>
  );
}
