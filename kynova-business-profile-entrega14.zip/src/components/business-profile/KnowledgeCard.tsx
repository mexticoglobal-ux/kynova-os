import Link from "next/link";
import { Card, Pill } from "@/components/workforce/ui";
import type { BusinessProfileKey, KnowledgeState } from "@/platform/business-profile";

type T = (k: BusinessProfileKey, v?: Record<string, number | string>) => string;
const SHOW = 6;
/** "Conocimiento de tu empresa": percentages and the pending list, computed from what the company has actually registered. */
export function KnowledgeCard({ state, t, manage }: { state: KnowledgeState; t: T; manage: boolean }) {
  const shown = state.pending.slice(0, SHOW), more = state.pending.length - shown.length;
  return (
    <Card title={t("card.title")}>
      <div className="flex flex-wrap items-center gap-2 text-sm"><Pill tone={state.profilePct >= 70 ? "success" : "info"}>{t("card.profile", { n: state.profilePct })}</Pill><Pill tone={state.dnaPct >= 70 ? "success" : "info"}>{t("card.dna", { n: state.dnaPct })}</Pill>
        {!state.hasAnyData && <Pill tone="muted">{t("card.notConfigured")}</Pill>}</div>
      <div className="mt-3 text-sm">
        {state.pending.length === 0 ? <p className="text-muted">{t("card.complete")}</p> : (
          <><p className="text-xs font-medium uppercase tracking-wide text-muted">{t("card.pending")}</p>
            <p className="mt-1">{shown.map((c) => t(c as BusinessProfileKey)).join(" · ")}{more > 0 ? ` · ${t("card.more", { n: more })}` : ""}</p></>)}
      </div>
      {manage && <p className="mt-3"><Link className="text-sm underline" href="/app/business-profile">{t("card.open")}</Link></p>}
    </Card>
  );
}
