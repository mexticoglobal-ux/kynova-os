"use client";
import { useState } from "react";
import { wfCall } from "@/components/workforce/api";

type L = Record<string, string>;
const field = "w-full rounded-lg border border-line bg-transparent px-3 py-2 text-sm focus-visible:outline-2 focus-visible:outline-ac2";
const primary = "rounded-lg bg-ac px-3 py-1.5 text-sm font-medium text-white disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ac2";
const btn = "rounded-lg border border-line px-2.5 py-1 text-xs hover:bg-ac/10 disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-ac2";
function useSave(L: L) {
  const [busy, setBusy] = useState(false), [msg, setMsg] = useState<string | null>(null);
  async function save(method: "PUT" | "POST", path: string, body: unknown, after?: () => void) {
    setBusy(true); setMsg(null); const r = await wfCall(method, path, body); setBusy(false);
    if (!r.ok) { setMsg(r.fields?.map((f) => `${f.field}: ${f.message}`).join(" · ") || r.message || L.error || ""); return false; }
    setMsg(L.saved ?? ""); after?.(); return true;
  }
  return { busy, msg, save };
}
const Lbl = ({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string | undefined }) => <label className="grid gap-1 text-xs text-muted">{label}{children}{hint && <span className="text-[11px]">{hint}</span>}</label>;
const Status = ({ msg }: { msg: string | null }) => <p role="status" aria-live="polite" className="text-xs text-muted">{msg}</p>;

export interface ProfileInit { name: string; industry: string; country: string; locale: string; currency: string; timezone: string; website: string; logoUrl: string; email: string; phone: string; location: string; socials: Record<string, string> }
export function ProfileForm({ init, L, locales, socials }: { init: ProfileInit; L: L; locales: string[]; socials: string[] }) {
  const [v, setV] = useState(init), { busy, msg, save } = useSave(L), set = (k: keyof ProfileInit) => (e: { target: { value: string } }) => setV({ ...v, [k]: e.target.value });
  function body() {
    const { country, socials: so, ...rest } = v; return { ...rest, ...(country ? { country: country.toUpperCase() } : {}), socials: so };
  }
  const txt = (k: keyof ProfileInit, label: string, hint?: string) => <Lbl label={label} hint={hint}><input className={field} value={String(v[k] ?? "")} onChange={set(k)} /></Lbl>;
  return (
    <form className="grid gap-3" onSubmit={(e) => { e.preventDefault(); void save("PUT", "/business-profile", body()); }}>
      <div className="grid gap-3 sm:grid-cols-2">
        {txt("name", L["profile.name"] ?? "")}{txt("industry", L["profile.industry"] ?? "")}{txt("website", L["profile.website"] ?? "")}{txt("logoUrl", L["profile.logo"] ?? "", L["hint.logo"])}
        {txt("email", L["profile.email"] ?? "")}{txt("phone", L["profile.phone"] ?? "")}{txt("location", L["profile.location"] ?? "")}{txt("country", L["profile.country"] ?? "")}
        <Lbl label={L["profile.locale"] ?? ""}><select className={field} value={v.locale} onChange={set("locale")}>{locales.map((l) => <option key={l} value={l}>{l}</option>)}</select></Lbl>
        {txt("currency", L["profile.currency"] ?? "")}{txt("timezone", L["profile.timezone"] ?? "")}
      </div>
      <fieldset className="grid gap-3 sm:grid-cols-2"><legend className="mb-1 text-xs text-muted">{L["profile.socials"]}</legend>
        {socials.map((s) => <Lbl key={s} label={L[`soc.${s}`] ?? s}><input className={field} value={v.socials[s] ?? ""} onChange={(e) => setV({ ...v, socials: { ...v.socials, [s]: e.target.value } })} /></Lbl>)}</fieldset>
      <p className="text-xs text-muted">{L["hint.store"]}</p>
      <div className="flex items-center gap-3"><button className={primary} disabled={busy}>{busy ? L.saving : L.save}</button><Status msg={msg} /></div>
    </form>
  );
}

export interface DnaInit { objectives: string[]; valueProposition: string; customerType: string; tone: string; industries: string[]; products: string[]; services: string[]; competitors: string[]; keywords: string[]; priorities: string[] }
const LISTS = ["objectives", "industries", "products", "services", "competitors", "keywords"] as const;
export function DnaForm({ init, L, priorities }: { init: DnaInit; L: L; priorities: string[] }) {
  const [t, setT] = useState<Record<string, string>>({ ...Object.fromEntries(LISTS.map((k) => [k, init[k].join("\n")])), valueProposition: init.valueProposition, customerType: init.customerType, tone: init.tone });
  const [pri, setPri] = useState<string[]>(init.priorities), { busy, msg, save } = useSave(L);
  const body = () => ({ ...Object.fromEntries(LISTS.map((k) => [k, (t[k] ?? "").split("\n").map((x) => x.trim()).filter(Boolean)])), valueProposition: t.valueProposition ?? "", customerType: t.customerType ?? "", tone: t.tone ?? "", priorities: pri });
  return (
    <form className="grid gap-3" onSubmit={(e) => { e.preventDefault(); void save("PUT", "/business-profile/dna", body()); }}>
      <div className="grid gap-3 sm:grid-cols-2">
        {(["valueProposition", "customerType", "tone"] as const).map((k) => <Lbl key={k} label={L[`dna.${k}`] ?? k}><input className={field} value={t[k] ?? ""} onChange={(e) => setT({ ...t, [k]: e.target.value })} /></Lbl>)}
        {LISTS.map((k) => <Lbl key={k} label={L[`dna.${k}`] ?? k} hint={L["hint.list"]}><textarea className={field} rows={3} value={t[k] ?? ""} onChange={(e) => setT({ ...t, [k]: e.target.value })} /></Lbl>)}
      </div>
      <fieldset className="flex flex-wrap gap-3 text-sm"><legend className="mb-1 text-xs text-muted">{L["dna.priorities"]}</legend>
        {priorities.map((p) => <label key={p} className="flex items-center gap-1.5"><input type="checkbox" checked={pri.includes(p)} onChange={(e) => setPri(e.target.checked ? [...pri, p] : pri.filter((x) => x !== p))} />{L[`pri.${p}`] ?? p}</label>)}</fieldset>
      <p className="text-xs text-muted">{L["hint.store"]}</p>
      <div className="flex items-center gap-3"><button className={primary} disabled={busy}>{busy ? L.saving : L.save}</button><Status msg={msg} /></div>
    </form>
  );
}

export function Companies({ companies, current, L }: { companies: { id: string; name: string; industry: string | null }[]; current: string; L: L }) {
  const { busy, msg, save } = useSave(L), [name, setName] = useState("");
  const go = () => window.location.assign("/app/business-profile");
  return (
    <div className="grid gap-3">
      <p className="text-xs text-muted">{L["co.note"]}</p>
      <ul className="grid gap-2">{companies.map((c) => (
        <li key={c.id} className="flex flex-wrap items-center gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span className="min-w-0 flex-1">{c.name}{c.industry ? <span className="text-xs text-muted"> · {c.industry}</span> : null}</span>
          {c.id === current ? <span className="text-xs text-muted">{L["co.current"]}</span> : <button type="button" className={btn} disabled={busy} onClick={() => void save("POST", "/business-profile/companies/switch", { companyId: c.id }, go)}>{L["co.switch"]}</button>}</li>))}</ul>
      <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); void (async () => { const r = await wfCall<{ id: string }>("POST", "/business-profile/companies", { name }); if (r.ok && r.data) await save("POST", "/business-profile/companies/switch", { companyId: r.data.id }, go); })(); }}>
        <label className="grid min-w-48 flex-1 gap-1 text-xs text-muted">{L["co.name"]}<input required minLength={2} className={field} value={name} onChange={(e) => setName(e.target.value)} /></label>
        <button className={primary} disabled={busy || name.trim().length < 2}>{L["co.create"]}</button></form>
      <Status msg={msg} />
    </div>
  );
}
