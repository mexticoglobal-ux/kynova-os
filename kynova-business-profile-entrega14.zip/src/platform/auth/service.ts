import type { Role } from "@/config/roles";
import { AuthError } from "./errors";
import type { AuthConfig } from "./config";
import { validatePasswordPolicy, type PasswordHasher } from "./password";
import type { AuthStore, BreachChecker, EmailSender, Membership, MembershipDirectory, RateLimiter, SessionRecord, TokenType, UserRecord } from "./store";
import { signTicket } from "./ticket";
import { newId, randomToken, sha256Hex } from "./tokens";
import { accountExistsEmail, passwordChangedEmail, resetEmail, verificationEmail } from "./emails";

export interface AuthDeps {
  store: AuthStore; directory: MembershipDirectory; limiter: RateLimiter; email: EmailSender;
  hasher: PasswordHasher; breach: BreachChecker | null; config: AuthConfig; now?: () => number;
}
export interface RequestMeta { ip: string; userAgent?: string | null }
export interface SignedIn {
  token: string; ticket: string; sessionMaxAgeSec: number; ticketMaxAgeSec: number;
  user: { id: string; email: string; name: string }; role: Role; tenantId: string | null;
}
export interface ResolvedSession { session: SessionRecord; user: UserRecord; role: Role; tenantId: string | null }
export interface OAuthProfileInput { provider: string; providerAccountId: string; email: string | null; emailVerified: boolean; name: string | null }

const PRIVILEGED: ReadonlySet<Role> = new Set<Role>(["super_admin", "owner", "ceo", "administrator", "finance"]);
export const normalizeEmail = (e: string) => e.trim().normalize("NFKC").toLowerCase();

export function createAuthService(d: AuthDeps) {
  const { store, directory, limiter, email, hasher, config: cfg } = d;
  const now = d.now ?? Date.now;
  let dummyHash: Promise<string> | null = null;

  const link = (path: string, token: string) => `${cfg.appUrl}${path}?token=${encodeURIComponent(token)}`;
  const ipKey = async (ip: string) => (await sha256Hex(`${cfg.secret}|${ip}|${new Date(now()).toISOString().slice(0, 10)}`)).slice(0, 32);
  const tooMany = (retryAfterSec: number) => new AuthError("rate_limited", "Too many attempts. Try again later.", { retryAfterSec });

  async function issueToken(userId: string, type: TokenType, ttlSec: number): Promise<string> {
    const raw = randomToken(32);
    await store.tokens.invalidateAll(userId, type, now());
    await store.tokens.create({ id: newId(now()), userId, type, tokenHash: await sha256Hex(raw), expiresAt: now() + ttlSec * 1000, usedAt: null, createdAt: now() });
    return raw;
  }
  async function consumeToken(raw: string, type: TokenType) {
    const t = await store.tokens.findByHash(type, await sha256Hex(raw));
    if (!t || t.usedAt || t.expiresAt <= now()) throw new AuthError("invalid_token", "This link is invalid or has expired.");
    await store.tokens.markUsed(t.id, now());
    const user = await store.users.findById(t.userId);
    if (!user || user.status !== "active") throw new AuthError("invalid_token", "This link is invalid or has expired.");
    return user;
  }
  function checkPolicy(password: string, mail: string) {
    const issues = validatePasswordPolicy(password, { email: mail }, cfg.password.min, cfg.password.max);
    if (issues.length) throw new AuthError("validation_failed", "Password does not meet the policy.", { fields: issues.map((i) => ({ field: "password", code: i, message: i })) });
  }
  async function checkBreach(password: string) {
    if (d.breach && (await d.breach.isBreached(password)))
      throw new AuthError("validation_failed", "This password appeared in a data breach. Choose a different one.", { fields: [{ field: "password", code: "breached", message: "breached" }] });
  }

  async function createSession(user: UserRecord, m: Membership | null, meta: RequestMeta): Promise<SignedIn> {
    const role: Role = m?.role ?? "guest";
    const ttl = PRIVILEGED.has(role) ? cfg.ttl.privileged : cfg.ttl.standard;
    const t = now();
    const token = randomToken(32);
    const session: SessionRecord = {
      id: newId(t), userId: user.id, tenantId: m?.tenantId ?? null, tokenHash: await sha256Hex(token), createdAt: t, lastSeenAt: t,
      idleExpiresAt: t + ttl.idleSec * 1000, absoluteExpiresAt: t + ttl.absoluteSec * 1000,
      ipHash: await ipKey(meta.ip), userAgent: meta.userAgent?.slice(0, 200) ?? null, mfaVerifiedAt: null, revokedAt: null,
    };
    await store.sessions.create(session);
    await store.users.update(user.id, { lastLoginAt: t });
    const rs: ResolvedSession = { session, user, role, tenantId: session.tenantId };
    const { ticket } = await issueTicket(rs);
    return { token, ticket, sessionMaxAgeSec: ttl.absoluteSec, ticketMaxAgeSec: cfg.ttl.ticketSec, user: { id: user.id, email: user.email, name: user.name }, role, tenantId: session.tenantId };
  }

  async function issueTicket(rs: ResolvedSession): Promise<{ ticket: string }> {
    const iat = Math.floor(now() / 1000);
    const ticket = await signTicket(cfg.secret, { sid: rs.session.id, uid: rs.user.id, tid: rs.tenantId, role: rs.role, iat, exp: iat + cfg.ttl.ticketSec });
    return { ticket };
  }

  async function pickMembership(userId: string): Promise<Membership | null> {
    return (await directory.listMemberships(userId))[0] ?? null;
  }

  return {
    normalizeEmail,
    issueTicket,

    /** Moves the live session to another company the person belongs to (never to one they do not). Re-issues the edge ticket. */
    async switchTenant(rawToken: string | undefined, tenantId: string): Promise<{ ticket: string; role: Role; tenantId: string } | null> {
      if (!rawToken) return null;
      const s = await store.sessions.findByTokenHash(await sha256Hex(rawToken)), t = now();
      if (!s || s.revokedAt || s.idleExpiresAt <= t || s.absoluteExpiresAt <= t) return null;
      const m = await directory.getMembership(s.userId, tenantId);
      if (!m) return null;
      await store.sessions.update(s.id, { tenantId });
      const iat = Math.floor(t / 1000);
      return { ticket: await signTicket(cfg.secret, { sid: s.id, uid: s.userId, tid: tenantId, role: m.role, iat, exp: iat + cfg.ttl.ticketSec }), role: m.role, tenantId };
    },

    async register(input: { name: string; email: string; password: string; locale?: string }, meta: RequestMeta): Promise<void> {
      const rl = await limiter.consume(`register:ip:${await ipKey(meta.ip)}`, cfg.limits.registerPerIp, cfg.limits.hourSec);
      if (!rl.allowed) throw tooMany(rl.retryAfterSec);
      const mail = normalizeEmail(input.email);
      checkPolicy(input.password, mail);
      await checkBreach(input.password);
      // Same observable outcome whether or not the email exists (no account enumeration).
      const existing = await store.users.findByEmail(mail);
      if (existing) {
        await email.send(accountExistsEmail(mail, `${cfg.appUrl}/login`, `${cfg.appUrl}/login/forgot-password`));
        return;
      }
      const t = now();
      const user: UserRecord = { id: newId(t), email: mail, name: input.name.trim(), passwordHash: await hasher.hash(input.password), emailVerifiedAt: null, locale: input.locale ?? "en", status: "active", createdAt: t, updatedAt: t, lastLoginAt: null };
      await store.users.create(user);
      await directory.provisionOwner({ id: user.id, email: user.email, name: user.name });
      const raw = await issueToken(user.id, "verify_email", cfg.ttl.verifyTokenSec);
      await email.send(verificationEmail(mail, user.name, link("/register/verify-email", raw)));
    },

    async verifyEmail(rawToken: string): Promise<void> {
      const user = await consumeToken(rawToken, "verify_email");
      if (!user.emailVerifiedAt) await store.users.update(user.id, { emailVerifiedAt: now(), updatedAt: now() });
    },

    async resendVerification(emailInput: string, meta: RequestMeta): Promise<void> {
      const rl = await limiter.consume(`resend:ip:${await ipKey(meta.ip)}`, cfg.limits.resetPerIp, cfg.limits.hourSec);
      if (!rl.allowed) throw tooMany(rl.retryAfterSec);
      const mail = normalizeEmail(emailInput);
      if (!(await limiter.consume(`resend:acct:${mail}`, cfg.limits.resetPerEmail, cfg.limits.hourSec)).allowed) return;
      const user = await store.users.findByEmail(mail);
      if (!user || user.emailVerifiedAt || user.status !== "active") return;
      const raw = await issueToken(user.id, "verify_email", cfg.ttl.verifyTokenSec);
      await email.send(verificationEmail(mail, user.name, link("/register/verify-email", raw)));
    },

    async login(input: { email: string; password: string }, meta: RequestMeta): Promise<SignedIn> {
      const mail = normalizeEmail(input.email);
      const acct = `login:acct:${mail}`, ip = `login:ip:${await ipKey(meta.ip)}`;
      const [a, b] = await Promise.all([limiter.peek(acct, cfg.limits.loginFailures, cfg.limits.loginWindowSec), limiter.peek(ip, cfg.limits.loginIpFailures, cfg.limits.loginWindowSec)]);
      if (!a.allowed || !b.allowed) throw tooMany(Math.max(a.allowed ? 0 : a.retryAfterSec, b.allowed ? 0 : b.retryAfterSec));
      const user = await store.users.findByEmail(mail);
      dummyHash ??= hasher.hash(randomToken(16));
      const ok = await hasher.verify(input.password, user?.passwordHash ?? (await dummyHash)); // equalize timing when user is unknown
      if (!user || !user.passwordHash || !ok || user.status !== "active") {
        await Promise.all([limiter.consume(acct, cfg.limits.loginFailures, cfg.limits.loginWindowSec), limiter.consume(ip, cfg.limits.loginIpFailures, cfg.limits.loginWindowSec)]);
        throw new AuthError("invalid_credentials", "Incorrect email or password.");
      }
      if (!user.emailVerifiedAt) throw new AuthError("email_not_verified", "Confirm your email before signing in.");
      await limiter.reset(acct);
      if (hasher.needsRehash(user.passwordHash)) await store.users.update(user.id, { passwordHash: await hasher.hash(input.password), updatedAt: now() });
      return createSession(user, await pickMembership(user.id), meta);
    },

    async logout(rawToken: string | undefined): Promise<void> {
      if (!rawToken) return;
      const s = await store.sessions.findByTokenHash(await sha256Hex(rawToken));
      if (s) await store.sessions.revoke(s.id, now());
    },

    async requestPasswordReset(emailInput: string, meta: RequestMeta): Promise<void> {
      const rl = await limiter.consume(`reset:ip:${await ipKey(meta.ip)}`, cfg.limits.resetPerIp, cfg.limits.hourSec);
      if (!rl.allowed) throw tooMany(rl.retryAfterSec);
      const mail = normalizeEmail(emailInput);
      if (!(await limiter.consume(`reset:acct:${mail}`, cfg.limits.resetPerEmail, cfg.limits.hourSec)).allowed) return; // silent: no enumeration
      const user = await store.users.findByEmail(mail);
      if (!user || user.status !== "active") return;
      const raw = await issueToken(user.id, "reset_password", cfg.ttl.resetTokenSec);
      await email.send(resetEmail(mail, link("/login/reset-password", raw)));
    },

    async resetPassword(rawToken: string, newPassword: string): Promise<void> {
      const user = await consumeToken(rawToken, "reset_password");
      checkPolicy(newPassword, user.email);
      await checkBreach(newPassword);
      await store.users.update(user.id, { passwordHash: await hasher.hash(newPassword), emailVerifiedAt: user.emailVerifiedAt ?? now(), updatedAt: now() });
      await store.sessions.revokeAllForUser(user.id, now()); // password change signs out everywhere
      await email.send(passwordChangedEmail(user.email));
    },

    /** Authoritative session check (store lookup, expiry, live membership). Slides the idle window. */
    async getSessionByToken(rawToken: string | undefined): Promise<ResolvedSession | null> {
      if (!rawToken) return null;
      const s = await store.sessions.findByTokenHash(await sha256Hex(rawToken));
      const t = now();
      if (!s || s.revokedAt || s.idleExpiresAt <= t || s.absoluteExpiresAt <= t) return null;
      const user = await store.users.findById(s.userId);
      if (!user || user.status !== "active" || !user.emailVerifiedAt) return null;
      let role: Role = "guest";
      if (s.tenantId) {
        const m = await directory.getMembership(s.userId, s.tenantId);
        if (!m) { await store.sessions.revoke(s.id, t); return null; }
        role = m.role;
      }
      if (t - s.lastSeenAt > 60_000) {
        const ttl = PRIVILEGED.has(role) ? cfg.ttl.privileged : cfg.ttl.standard;
        await store.sessions.update(s.id, { lastSeenAt: t, idleExpiresAt: Math.min(t + ttl.idleSec * 1000, s.absoluteExpiresAt) });
      }
      return { session: s, user, role, tenantId: s.tenantId };
    },


    async updateProfile(userId: string, input: { name: string; locale: string }): Promise<UserRecord> {
      await store.users.update(userId, { name: input.name.trim(), locale: input.locale, updatedAt: now() });
      const u = await store.users.findById(userId);
      if (!u) throw new AuthError("unauthenticated", "Account not found.");
      return u;
    },

    async changePassword(rs: ResolvedSession, current: string, next: string): Promise<void> {
      const rl = await limiter.consume(`pwchange:${rs.user.id}`, 5, cfg.limits.loginWindowSec);
      if (!rl.allowed) throw tooMany(rl.retryAfterSec);
      const user = await store.users.findById(rs.user.id);
      if (!user?.passwordHash) throw new AuthError("validation_failed", "This account has no password. Use password reset to set one.");
      if (!(await hasher.verify(current, user.passwordHash))) throw new AuthError("invalid_credentials", "Current password is incorrect.");
      checkPolicy(next, user.email);
      await checkBreach(next);
      await store.users.update(user.id, { passwordHash: await hasher.hash(next), updatedAt: now() });
      await store.sessions.revokeOthers(user.id, rs.session.id, now());
      await email.send(passwordChangedEmail(user.email));
    },

    async listSessions(userId: string, currentId: string) {
      const list = await store.sessions.listActiveForUser(userId, now());
      return list.map((s) => ({ id: s.id, createdAt: s.createdAt, lastSeenAt: s.lastSeenAt, userAgent: s.userAgent, current: s.id === currentId }));
    },

    async revokeSession(userId: string, sessionId: string): Promise<boolean> {
      const s = (await store.sessions.listActiveForUser(userId, now())).find((x) => x.id === sessionId);
      if (!s) return false; // not yours or already gone: indistinguishable on purpose
      await store.sessions.revoke(s.id, now());
      return true;
    },

    async revokeOtherSessions(userId: string, currentId: string): Promise<void> {
      await store.sessions.revokeOthers(userId, currentId, now());
    },

    async signInWithOAuth(p: OAuthProfileInput, meta: RequestMeta): Promise<SignedIn> {
      const linked = await store.oauth.find(p.provider, p.providerAccountId);
      let user: UserRecord | null = linked ? await store.users.findById(linked.userId) : null;
      if (linked && (!user || user.status !== "active")) throw new AuthError("oauth_failed", "Account unavailable.");
      if (!user) {
        if (!p.email || !p.emailVerified) throw new AuthError("oauth_email_unverified", "The provider did not return a verified email.");
        const mail = normalizeEmail(p.email);
        user = await store.users.findByEmail(mail);
        if (user) {
          if (user.status !== "active") throw new AuthError("oauth_failed", "Account unavailable.");
          if (!user.emailVerifiedAt) {
            // Pre-hijack defense: an unverified local account may belong to an attacker. Drop its password.
            await store.users.update(user.id, { passwordHash: null, emailVerifiedAt: now(), updatedAt: now() });
            await store.sessions.revokeAllForUser(user.id, now());
          }
        } else {
          const t = now();
          user = { id: newId(t), email: mail, name: (p.name ?? mail.split("@")[0] ?? "User").slice(0, 100), passwordHash: null, emailVerifiedAt: t, locale: "en", status: "active", createdAt: t, updatedAt: t, lastLoginAt: null };
          await store.users.create(user);
          await directory.provisionOwner({ id: user.id, email: user.email, name: user.name });
        }
        await store.oauth.link({ provider: p.provider, providerAccountId: p.providerAccountId, userId: user.id, email: mail, createdAt: now() });
      }
      return createSession(user, await pickMembership(user.id), meta);
    },
  };
}
export type AuthService = ReturnType<typeof createAuthService>;
