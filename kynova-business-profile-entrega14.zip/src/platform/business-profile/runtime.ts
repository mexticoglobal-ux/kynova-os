import { createMemoryBusinessProfileStore, type BusinessProfileStore } from "./store";

let override: BusinessProfileStore | null = null;
export const setBusinessProfileStore = (s: BusinessProfileStore | null): void => { override = s; };
const g = globalThis as unknown as { __kynovaBpDevStore?: BusinessProfileStore };
const isDevLike = (): boolean => process.env.APP_ENV === "local" || process.env.NODE_ENV === "test" || process.env.NODE_ENV === "development";
export async function getBusinessProfileStore(): Promise<BusinessProfileStore> {
  if (override) return override;
  try {
    const { getCloudflareContext } = await import("@opennextjs/cloudflare");
    const d1 = getCloudflareContext().env.DB;
    if (d1) { const { createD1BusinessProfileStore } = await import("./store-d1"); return createD1BusinessProfileStore(d1); }
  } catch { /* no Cloudflare context */ }
  if (!isDevLike()) throw new Error("The business profile database is not available. Check the D1 binding.");
  return (g.__kynovaBpDevStore ??= createMemoryBusinessProfileStore());
}
