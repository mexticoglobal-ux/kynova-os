import type { Role } from "@/config/roles";
import type { ActivitySink } from "@/platform/activity";
import { z } from "zod";
import { allows, createCompanyInput, dnaInput, profileInput, type Basics, type Capability, type DnaRecord, type ProfileRecord } from "./domain";
import { knowledge, type KnowledgeState } from "./knowledge";
import type { BusinessProfileStore } from "./store";

export interface Actor { tenantId: string; userId: string; role: Role; requestId?: string }
export class BusinessProfileError extends Error {
  readonly status: number;
  constructor(readonly code: "forbidden" | "not_found" | "validation_failed" | "unavailable", message: string, readonly details?: Record<string, unknown>) { super(message); this.name = "BusinessProfileError"; this.status = { forbidden: 403, not_found: 404, validation_failed: 422, unavailable: 503 }[code]; }
}
export const isBusinessProfileError = (e: unknown): e is BusinessProfileError => e instanceof BusinessProfileError || (typeof e === "object" && e !== null && (e as { name?: string }).name === "BusinessProfileError");
/** The company basics live in `companies` (one source of truth). The composition root provides them. */
export interface BusinessProfilePorts {
  basics(tenantId: string): Promise<Basics | null>;
  updateBasics(tenantId: string, patch: Partial<Basics>): Promise<void>;
}
export interface BusinessProfileDeps { store: BusinessProfileStore; ports: BusinessProfilePorts; now?: () => number; activity?: ActivitySink }
export type BusinessProfileService = ReturnType<typeof createBusinessProfileService>;

function parse<T extends z.ZodType>(schema: T, input: unknown): z.output<T> {
  const r = schema.safeParse(input);
  if (!r.success) throw new BusinessProfileError("validation_failed", "The request is not valid.", { fields: r.error.issues.map((i) => ({ field: i.path.join("."), message: i.message })) });
  return r.data;
}
const EMPTY_DNA = (tenantId: string, t: number): DnaRecord => ({ tenantId, objectives: [], valueProposition: "", customerType: "", tone: "", industries: [], products: [], services: [], competitors: [], keywords: [], priorities: [], updatedBy: "", createdAt: t, updatedAt: t });

export function createBusinessProfileService(deps: BusinessProfileDeps) {
  const { store, ports } = deps, now = deps.now ?? Date.now;
  const need = (a: Actor, c: Capability): void => { if (!allows(a.role, c)) throw new BusinessProfileError("forbidden", "Your role cannot do this."); };
  const rec = async (a: Actor, action: string, summary: string, key: string) => { await deps.activity?.record({ tenantId: a.tenantId, ...(a.requestId ? { requestId: a.requestId } : {}) }, { module: "business-profile", source: "business_profile", action, summary, actorKind: "user", actorId: a.userId, mode: "production", idempotencyKey: key }); };
  async function load(a: Actor) { const [basics, profile, dna] = await Promise.all([ports.basics(a.tenantId), store.getProfile(a.tenantId), store.getDna(a.tenantId)]); return { basics, profile, dna }; }

  async function profile(a: Actor) {
    need(a, "view"); const { basics, profile: p } = await load(a);
    return { basics, logoUrl: p?.logoUrl ?? "", website: p?.website ?? "", socials: p?.socials ?? {}, email: p?.email ?? "", phone: p?.phone ?? "", location: p?.location ?? "", basicsConfirmed: Boolean(p?.basicsConfirmedAt), updatedAt: p?.updatedAt ?? null };
  }
  /** Saves what the person typed. Name, industry, country, language, currency and time zone go to the company record; the rest to the profile. Nothing is verified against any API. */
  async function saveProfile(a: Actor, input: unknown) {
    need(a, "manage"); const i = parse(profileInput, input), t = now(), cur = await store.getProfile(a.tenantId);
    const basics: Partial<Basics> = {}; for (const k of ["name", "industry", "country", "locale", "currency", "timezone"] as const) if (i[k] !== undefined) (basics as Record<string, unknown>)[k] = k === "industry" && i[k] === "" ? null : i[k];
    if (Object.keys(basics).length) await ports.updateBasics(a.tenantId, basics);
    const confirmedNow = ["name", "locale", "currency", "timezone"].every((k) => (i as Record<string, unknown>)[k] !== undefined);
    const row: ProfileRecord = {
      tenantId: a.tenantId, logoUrl: i.logoUrl ?? cur?.logoUrl ?? "", website: i.website ?? cur?.website ?? "", email: i.email ?? cur?.email ?? "", phone: i.phone ?? cur?.phone ?? "", location: i.location ?? cur?.location ?? "",
      socials: i.socials ? { ...(cur?.socials ?? {}), ...Object.fromEntries(Object.entries(i.socials).filter(([, v]) => v !== "")), ...Object.fromEntries(Object.entries(i.socials).filter(([, v]) => v === "").map(([k]) => [k, ""])) } : cur?.socials ?? {},
      basicsConfirmedAt: cur?.basicsConfirmedAt ?? (confirmedNow ? t : null), updatedBy: a.userId, createdAt: cur?.createdAt ?? t, updatedAt: t,
    };
    row.socials = Object.fromEntries(Object.entries(row.socials).filter(([, v]) => v !== ""));
    await store.putProfile(row); await rec(a, "business_profile.profile.updated", "Business profile updated", `bp-profile:${a.tenantId}:${t}`);
    return profile(a);
  }
  async function dna(a: Actor): Promise<DnaRecord> { need(a, "view"); return (await store.getDna(a.tenantId)) ?? EMPTY_DNA(a.tenantId, 0); }
  async function saveDna(a: Actor, input: unknown): Promise<DnaRecord> {
    need(a, "manage"); const i = parse(dnaInput, input), t = now(), cur = (await store.getDna(a.tenantId)) ?? EMPTY_DNA(a.tenantId, t);
    const row: DnaRecord = { ...cur, ...i, tenantId: a.tenantId, updatedBy: a.userId, updatedAt: t };
    await store.putDna(row); await rec(a, "business_profile.dna.updated", "Business DNA updated", `bp-dna:${a.tenantId}:${t}`); return row;
  }
  /** Percentages and the pending list, computed from what is stored. */
  async function state(a: Actor): Promise<KnowledgeState> { need(a, "view"); const { basics, profile: p, dna: d } = await load(a); return knowledge(basics, p, d); }
  async function permissions(a: Actor) { return { role: a.role, capabilities: (["view", "manage"] as const).filter((c) => allows(a.role, c)) }; }
  return { profile, saveProfile, dna, saveDna, state, permissions, parseCreateCompany: (input: unknown) => parse(createCompanyInput, input) };
}
