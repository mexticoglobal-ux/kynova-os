import { companiesRepo, getDb, provisionCompany, userMembershipsRepo } from "@/platform/db";
import type { Basics } from "./domain";
import { getActivitySink } from "@/platform/activity";
import { getBusinessProfileStore } from "./runtime";
import { createBusinessProfileService, type BusinessProfilePorts, type BusinessProfileService } from "./service";

/** Composition root: the only file that meets the database. Name, industry, country, language, currency and time zone live in `companies`. */
type Dev = { basics: Map<string, Basics>; names: Map<string, string> };
const dg = globalThis as unknown as { __kynovaBpDev?: Dev; __kynovaAuthMemory?: { directory: { listMemberships(u: string): Promise<{ tenantId: string; role: string }[]>; provisionOwner(u: { id: string; email: string; name: string }): Promise<{ tenantId: string }> } } };
const dev = (): Dev => (dg.__kynovaBpDev ??= { basics: new Map(), names: new Map() });
/** Without a D1 binding (a laptop running `next dev`) companies live in the in-memory auth directory; production never takes this path. */
async function maybeDb() {
  try { return await getDb(); } catch (e) { if (process.env.APP_ENV === "local" || process.env.NODE_ENV === "development" || process.env.NODE_ENV === "test") return null; throw e; }
}
const defaults = (name: string): Basics => ({ name, industry: null, country: null, locale: "en", currency: "USD", timezone: "UTC" });
const ports: BusinessProfilePorts = {
  async basics(tenantId) {
    if (!(await maybeDb())) return dev().basics.get(tenantId) ?? defaults(dev().names.get(tenantId) ?? "My workspace");
 const c = await companiesRepo((await maybeDb())!).findById(tenantId); return c ? { name: c.name, industry: c.industry, country: c.country, locale: c.defaultLocale, currency: c.defaultCurrency, timezone: c.timezone } : null; },
  async updateBasics(tenantId, p) {
    if (!(await maybeDb())) { const d = dev(); d.basics.set(tenantId, { ...(d.basics.get(tenantId) ?? defaults("My workspace")), ...(p as Partial<Basics>) } as Basics); return; }
    const patch: Parameters<ReturnType<typeof companiesRepo>["update"]>[1] = { updatedAt: Date.now() };
    if (p.name !== undefined) patch.name = p.name; if (p.industry !== undefined) patch.industry = p.industry; if (p.country !== undefined) patch.country = p.country;
    if (p.locale !== undefined) patch.defaultLocale = p.locale; if (p.currency !== undefined) patch.defaultCurrency = p.currency; if (p.timezone !== undefined) patch.timezone = p.timezone;
    await companiesRepo((await maybeDb())!).update(tenantId, patch);
  },
};
export async function getBusinessProfileService(): Promise<BusinessProfileService> {
  return createBusinessProfileService({ store: await getBusinessProfileStore(), ports, activity: await getActivitySink("business-profile", "business_profile") });
}
/** The companies this person belongs to (their own memberships only). */
export async function listMyCompanies(userId: string) {
  if (!(await maybeDb())) return (await dg.__kynovaAuthMemory?.directory.listMemberships(userId) ?? []).map((m) => ({ id: m.tenantId, name: dev().basics.get(m.tenantId)?.name ?? dev().names.get(m.tenantId) ?? "My workspace", industry: dev().basics.get(m.tenantId)?.industry ?? null, role: m.role }));
  return (await userMembershipsRepo((await maybeDb())!).listForUser(userId)).map((r) => ({ id: r.company.id, name: r.company.name, industry: r.company.industry, role: r.role.id }));
}
/** Registers a real company owned by this person, exactly like the one created at sign-up. Nothing is pre-filled. */
export async function createMyCompany(userId: string, input: { name: string; industry?: string | undefined; country?: string | undefined; locale?: string | undefined; currency?: string | undefined; timezone?: string | undefined }) {
  if (!(await maybeDb())) {
    const dir = dg.__kynovaAuthMemory?.directory; if (!dir) throw new Error("No directory available.");
    const m = await dir.provisionOwner({ id: userId, email: "", name: input.name }); dev().basics.set(m.tenantId, { ...defaults(input.name), industry: input.industry ?? null, country: input.country ?? null });
    return { id: m.tenantId, name: input.name };
  }
  const { companyId } = await provisionCompany((await maybeDb())!, { ownerUserId: userId, name: input.name, ...(input.industry ? { industry: input.industry } : {}), ...(input.country ? { country: input.country } : {}), ...(input.locale ? { locale: input.locale as never } : {}), ...(input.currency ? { currency: input.currency } : {}), ...(input.timezone ? { timezone: input.timezone } : {}) });
  return { id: companyId, name: input.name };
}
