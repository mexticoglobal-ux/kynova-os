import { z } from "zod";
import { LOCALES } from "@/config/locales";
import type { Role } from "@/config/roles";

/**
 * Business Profile: the single source of truth about a company, reusable by every AI Business System (Marketing, SEO, CRM, Marketplace, YouTube,
 * Ecommerce, Finance...). Basics (name, industry, country, language, currency, time zone) stay in `companies`; this module stores the rest and
 * never duplicates them. It only PERSISTS what the person writes: no API is called and no AI is used.
 */
export const SOCIALS = ["facebook", "instagram", "linkedin", "x", "youtube", "tiktok"] as const;
/** Generic strategic priorities (valid for any business). Systems map them to their own work. */
export const PRIORITIES = ["acquisition", "sales", "retention", "brand", "growth", "efficiency", "quality", "expansion"] as const;
export const PROFILE_ITEMS = ["name", "logo", "industry", "website", "socials", "email", "phone", "location", "locale", "currency", "timezone"] as const;
export const DNA_ITEMS = ["objectives", "valueProposition", "customerType", "tone", "industries", "products", "services", "competitors", "keywords", "priorities"] as const;
export type ProfileItem = (typeof PROFILE_ITEMS)[number];
export type DnaItem = (typeof DNA_ITEMS)[number];
export type Capability = "view" | "manage";
const MANAGE: ReadonlySet<Role> = new Set<Role>(["super_admin", "owner", "ceo", "administrator", "manager", "marketing"]);
const VIEW: ReadonlySet<Role> = new Set<Role>([...MANAGE, "sales", "finance"]);
export const allows = (role: Role, c: Capability): boolean => (c === "manage" ? MANAGE : VIEW).has(role);

export interface Basics { name: string; industry: string | null; country: string | null; locale: string; currency: string; timezone: string }
export interface ProfileRecord { tenantId: string; logoUrl: string; website: string; socials: Record<string, string>; email: string; phone: string; location: string; basicsConfirmedAt: number | null; updatedBy: string; createdAt: number; updatedAt: number }
export interface DnaRecord { tenantId: string; objectives: string[]; valueProposition: string; customerType: string; tone: string; industries: string[]; products: string[]; services: string[]; competitors: string[]; keywords: string[]; priorities: string[]; updatedBy: string; createdAt: number; updatedAt: number }

const txt = (n: number) => z.string().trim().max(n);
const url = z.union([z.literal(""), z.string().trim().max(300).refine((v) => /^https?:\/\/[^\s]+\.[^\s]+$/i.test(v), "Must be an http(s) address")]);
const list = (n = 20, len = 120) => z.array(z.string().trim().min(1).max(len)).max(n).transform((a) => [...new Set(a)]);
const tz = z.string().trim().min(1).max(64).refine((v) => { try { new Intl.DateTimeFormat("en", { timeZone: v }); return true; } catch { return false; } }, "Unknown time zone");
export const profileInput = z.object({
  name: txt(120).min(2), industry: txt(80), country: z.string().regex(/^[A-Z]{2}$/), locale: z.enum(LOCALES), currency: z.string().regex(/^[A-Z]{3}$/), timezone: tz,
  logoUrl: url, website: url, email: z.union([z.literal(""), z.string().trim().email().max(160)]), phone: z.union([z.literal(""), z.string().trim().regex(/^[+()\-.\s\d]{5,30}$/)]), location: txt(160),
  socials: z.partialRecord(z.enum(SOCIALS), txt(200)),
}).partial().strict();
export const dnaInput = z.object({
  objectives: list(), valueProposition: txt(500), customerType: txt(300), tone: txt(80), industries: list(), products: list(40), services: list(40), competitors: list(), keywords: list(40, 80), priorities: z.array(z.enum(PRIORITIES)).max(PRIORITIES.length).transform((a) => [...new Set(a)]),
}).partial().strict();
export const createCompanyInput = z.object({ name: txt(120).min(2), industry: txt(80).optional(), country: z.string().regex(/^[A-Z]{2}$/).optional(), locale: z.enum(LOCALES).optional(), currency: z.string().regex(/^[A-Z]{3}$/).optional(), timezone: tz.optional() }).strict();
export const switchInput = z.object({ companyId: z.string().min(1).max(64) }).strict();
