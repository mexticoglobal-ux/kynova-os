import type { DnaRecord, ProfileRecord } from "./domain";

/** Persistence port. EVERY method takes the tenant id; a company can only ever read or write its own row. */
export interface BusinessProfileStore {
  getProfile(tenantId: string): Promise<ProfileRecord | null>;
  putProfile(row: ProfileRecord): Promise<void>;
  getDna(tenantId: string): Promise<DnaRecord | null>;
  putDna(row: DnaRecord): Promise<void>;
}
export function createMemoryBusinessProfileStore(): BusinessProfileStore {
  const p = new Map<string, ProfileRecord>(), d = new Map<string, DnaRecord>();
  return { async getProfile(t) { const r = p.get(t); return r ? structuredClone(r) : null; }, async putProfile(r) { p.set(r.tenantId, structuredClone(r)); }, async getDna(t) { const r = d.get(t); return r ? structuredClone(r) : null; }, async putDna(r) { d.set(r.tenantId, structuredClone(r)); } };
}
