/** Business Profile texts. One entry = [key, Spanish, English]. */
const E = [
  ["title", "Perfil de empresa", "Company profile"], ["sub", "La fuente única de verdad de tu empresa. Todos los AI Employees la consultan antes de recomendar.", "Your company's single source of truth. Every AI Employee reads it before recommending."],
  ["card.title", "Conocimiento de tu empresa", "What we know about your company"], ["card.profile", "Perfil completado: {n}%", "Profile completed: {n}%"], ["card.dna", "Business DNA: {n}%", "Business DNA: {n}%"], ["card.pending", "Información pendiente", "Pending information"],
  ["card.complete", "No falta información.", "Nothing is missing."], ["card.more", "y {n} más", "and {n} more"], ["card.open", "Completar perfil", "Complete profile"], ["card.notConfigured", "No configurado", "Not configured"],
  ["insufficient", "Todavía no hay suficiente información para generar recomendaciones.", "There is not enough information yet to generate recommendations."],
  ["needs", "Para recomendar mejor necesito: {list}.", "To recommend better I need: {list}."], ["soon", "Disponible próximamente", "Coming soon"], ["pending", "Pendiente", "Pending"],
  ["sec.profile", "Datos de la empresa", "Company details"], ["sec.dna", "Business DNA", "Business DNA"], ["sec.companies", "Tus empresas", "Your companies"], ["sec.new", "Registrar una empresa", "Register a company"],
  ["profile.name", "Nombre", "Name"], ["profile.logo", "Logo", "Logo"], ["profile.industry", "Industria", "Industry"], ["profile.website", "Sitio web", "Website"], ["profile.socials", "Redes sociales", "Social networks"], ["profile.email", "Correo", "Email"],
  ["profile.phone", "Teléfono", "Phone"], ["profile.location", "Ubicación", "Location"], ["profile.locale", "Idioma", "Language"], ["profile.currency", "Moneda", "Currency"], ["profile.timezone", "Zona horaria", "Time zone"], ["profile.country", "País (código, ej. CR)", "Country (code, e.g. CR)"],
  ["dna.objectives", "Objetivos", "Objectives"], ["dna.valueProposition", "Propuesta de valor", "Value proposition"], ["dna.customerType", "Tipo de cliente", "Customer type"], ["dna.tone", "Tono de comunicación", "Communication tone"], ["dna.industries", "Industrias", "Industries"],
  ["dna.products", "Productos", "Products"], ["dna.services", "Servicios", "Services"], ["dna.competitors", "Competidores", "Competitors"], ["dna.keywords", "Palabras clave", "Keywords"], ["dna.priorities", "Prioridades", "Priorities"],
  ["pri.acquisition", "Captar clientes", "Win new customers"], ["pri.sales", "Vender más", "Sell more"], ["pri.retention", "Retener y dar seguimiento", "Retain and follow up"], ["pri.brand", "Marca", "Brand"], ["pri.growth", "Crecer", "Grow"], ["pri.efficiency", "Eficiencia", "Efficiency"], ["pri.quality", "Calidad", "Quality"], ["pri.expansion", "Expansión", "Expansion"],
  ["soc.facebook", "Facebook", "Facebook"], ["soc.instagram", "Instagram", "Instagram"], ["soc.linkedin", "LinkedIn", "LinkedIn"], ["soc.x", "X", "X"], ["soc.youtube", "YouTube", "YouTube"], ["soc.tiktok", "TikTok", "TikTok"],
  ["hint.list", "Uno por línea", "One per line"], ["hint.logo", "Dirección https de tu logo. Subir archivos: disponible próximamente.", "https address of your logo. File upload: coming soon."], ["hint.store", "Solo guardamos lo que escribes. No se conecta ninguna API ni se usa IA.", "We only store what you type. No API is connected and no AI is used."],
  ["save", "Guardar", "Save"], ["saving", "Guardando…", "Saving…"], ["saved", "Guardado", "Saved"], ["error", "Algo salió mal. Inténtalo de nuevo.", "Something went wrong. Try again."],
  ["co.current", "Actual", "Current"], ["co.switch", "Cambiar a esta empresa", "Switch to this company"], ["co.create", "Crear empresa", "Create company"], ["co.name", "Nombre de la empresa", "Company name"], ["co.note", "Cada empresa tiene sus propios datos, aislados de las demás.", "Each company has its own data, isolated from the others."],
] as const;
type Entry = (typeof E)[number];
export type BusinessProfileKey = Entry[0];
export type BusinessProfileLocale = "en" | "es";
const build = (i: 1 | 2): Record<BusinessProfileKey, string> => Object.fromEntries(E.map((e) => [e[0], e[i]])) as Record<BusinessProfileKey, string>;
export const BUSINESS_PROFILE_DICTIONARIES: Record<BusinessProfileLocale, Record<BusinessProfileKey, string>> = { es: build(1), en: build(2) };
export const businessProfileLocale = (l: string | null | undefined): BusinessProfileLocale => (l?.toLowerCase().startsWith("es") ? "es" : "en");
export const tr = (locale: BusinessProfileLocale, key: BusinessProfileKey, vars: Record<string, string | number> = {}): string => (BUSINESS_PROFILE_DICTIONARIES[locale][key] ?? String(key)).replace(/\{(\w+)\}/g, (_m, k: string) => String(vars[k] ?? ""));
