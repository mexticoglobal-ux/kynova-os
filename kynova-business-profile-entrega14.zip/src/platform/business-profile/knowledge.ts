import { DNA_ITEMS, PROFILE_ITEMS, type Basics, type DnaItem, type DnaRecord, type ProfileItem, type ProfileRecord } from "./domain";

/** What the platform knows about a company. Pure: the percentages are computed, never stored. */
export interface KnowledgeState {
  profilePct: number; dnaPct: number; basicsConfirmed: boolean;
  profile: Record<ProfileItem, boolean>; dna: Record<DnaItem, boolean>;
  /** Missing items, profile first then DNA, as "profile.logo" / "dna.competitors". */
  pending: string[]; priorities: string[]; industry: string | null; hasAnyData: boolean;
}
const has = (s: string | null | undefined) => typeof s === "string" && s.trim() !== "";
/** Name, language, currency and time zone always have a value (company defaults), so they only count once the person has confirmed them. */
export function knowledge(basics: Basics | null, p: ProfileRecord | null, d: DnaRecord | null): KnowledgeState {
  const confirmed = Boolean(p?.basicsConfirmedAt);
  const profile: Record<ProfileItem, boolean> = {
    name: confirmed && has(basics?.name), logo: has(p?.logoUrl), industry: has(basics?.industry), website: has(p?.website), socials: Object.values(p?.socials ?? {}).some(has), email: has(p?.email), phone: has(p?.phone), location: has(p?.location),
    locale: confirmed && has(basics?.locale), currency: confirmed && has(basics?.currency), timezone: confirmed && has(basics?.timezone),
  };
  const dna: Record<DnaItem, boolean> = {
    objectives: (d?.objectives.length ?? 0) > 0, valueProposition: has(d?.valueProposition), customerType: has(d?.customerType), tone: has(d?.tone), industries: (d?.industries.length ?? 0) > 0,
    products: (d?.products.length ?? 0) > 0, services: (d?.services.length ?? 0) > 0, competitors: (d?.competitors.length ?? 0) > 0, keywords: (d?.keywords.length ?? 0) > 0, priorities: (d?.priorities.length ?? 0) > 0,
  };
  const pct = (r: Record<string, boolean>) => { const v = Object.values(r); return Math.round((v.filter(Boolean).length / v.length) * 100); };
  return {
    profilePct: pct(profile), dnaPct: pct(dna), basicsConfirmed: confirmed, profile, dna, priorities: d?.priorities ?? [], industry: has(basics?.industry) ? (basics?.industry as string) : null,
    pending: [...PROFILE_ITEMS.filter((k) => !profile[k]).map((k) => `profile.${k}`), ...DNA_ITEMS.filter((k) => !dna[k]).map((k) => `dna.${k}`)],
    hasAnyData: Object.values(profile).some(Boolean) || Object.values(dna).some(Boolean),
  };
}
/**
 * The contract every AI Employee follows before it recommends: ask the profile, and if something it needs is missing, say EXACTLY what (never invent it).
 * `needs` are item codes such as "dna.tone" or "profile.website". With no profile at all (null) everything is missing.
 */
export function requirements(state: KnowledgeState | null, needs: readonly string[]): { ready: boolean; missing: string[] } {
  const missing = needs.filter((n) => { const [k, i] = n.split("."); return !state || !(k === "profile" ? state.profile[i as ProfileItem] : state.dna[i as DnaItem]); });
  return { ready: missing.length === 0, missing };
}
