import type { D1Database } from "@cloudflare/workers-types";
import type { DnaRecord, ProfileRecord } from "./domain";
import type { BusinessProfileStore } from "./store";

type Row = Record<string, unknown>;
const J = <T,>(v: unknown, d: T): T => { try { const x = JSON.parse(String(v)) as T; return x ?? d; } catch { return d; } };
const S = (v: unknown) => (typeof v === "string" ? v : "");
/** Plain parameterized SQL, every statement scoped by tenant_id (the primary key). */
export function createD1BusinessProfileStore(d1: D1Database): BusinessProfileStore {
  return {
    async getProfile(t) {
      const r = await d1.prepare("SELECT * FROM bp_profiles WHERE tenant_id = ?").bind(t).first<Row>();
      return r ? { tenantId: t, logoUrl: S(r.logo_url), website: S(r.website), socials: J<Record<string, string>>(r.socials, {}), email: S(r.email), phone: S(r.phone), location: S(r.location), basicsConfirmedAt: (r.basics_confirmed_at as number | null) ?? null, updatedBy: S(r.updated_by), createdAt: r.created_at as number, updatedAt: r.updated_at as number } : null;
    },
    async putProfile(r) {
      await d1.prepare("INSERT INTO bp_profiles (tenant_id, logo_url, website, socials, email, phone, location, basics_confirmed_at, updated_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id) DO UPDATE SET logo_url=excluded.logo_url, website=excluded.website, socials=excluded.socials, email=excluded.email, phone=excluded.phone, location=excluded.location, basics_confirmed_at=excluded.basics_confirmed_at, updated_by=excluded.updated_by, updated_at=excluded.updated_at")
        .bind(r.tenantId, r.logoUrl, r.website, JSON.stringify(r.socials), r.email, r.phone, r.location, r.basicsConfirmedAt, r.updatedBy, r.createdAt, r.updatedAt).run();
    },
    async getDna(t) {
      const r = await d1.prepare("SELECT * FROM bp_dna WHERE tenant_id = ?").bind(t).first<Row>();
      return r ? { tenantId: t, objectives: J(r.objectives, []), valueProposition: S(r.value_proposition), customerType: S(r.customer_type), tone: S(r.tone), industries: J(r.industries, []), products: J(r.products, []), services: J(r.services, []), competitors: J(r.competitors, []), keywords: J(r.keywords, []), priorities: J(r.priorities, []), updatedBy: S(r.updated_by), createdAt: r.created_at as number, updatedAt: r.updated_at as number } : null;
    },
    async putDna(r) {
      await d1.prepare("INSERT INTO bp_dna (tenant_id, objectives, value_proposition, customer_type, tone, industries, products, services, competitors, keywords, priorities, updated_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id) DO UPDATE SET objectives=excluded.objectives, value_proposition=excluded.value_proposition, customer_type=excluded.customer_type, tone=excluded.tone, industries=excluded.industries, products=excluded.products, services=excluded.services, competitors=excluded.competitors, keywords=excluded.keywords, priorities=excluded.priorities, updated_by=excluded.updated_by, updated_at=excluded.updated_at")
        .bind(r.tenantId, JSON.stringify(r.objectives), r.valueProposition, r.customerType, r.tone, JSON.stringify(r.industries), JSON.stringify(r.products), JSON.stringify(r.services), JSON.stringify(r.competitors), JSON.stringify(r.keywords), JSON.stringify(r.priorities), r.updatedBy, r.createdAt, r.updatedAt).run();
    },
  };
}
