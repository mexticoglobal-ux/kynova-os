import { NextResponse, type NextRequest } from "next/server";
import { canAccess } from "@/config/modules";
import { assertSameOrigin, getAuthConfig, ok, problem, route } from "@/platform/auth/http";
import { requireApiSession } from "@/platform/auth/session";
import { BusinessProfileError, isBusinessProfileError, type Actor, type BusinessProfileService } from "./service";
import { getBusinessProfileService } from "./server";
import { fromWire, toWire } from "./wire";

export const BUSINESS_PROFILE_SLUG = "business-profile";
export interface BpRouteContext { actor: Actor; rid: string; svc: BusinessProfileService; userId: string }
/** Verified session, module access for the role, an active company, CSRF checks on mutations, and domain errors as problem+json. */
export function bpRoute<C = unknown>(fn: (req: NextRequest, ctx: C, a: BpRouteContext) => Promise<NextResponse>, opts: { mutating?: boolean } = {}) {
  return route<C>(async (req, ctx, rid) => {
    try {
      if (opts.mutating) assertSameOrigin(req, getAuthConfig());
      const s = await requireApiSession();
      if (!s.tenantId) throw new BusinessProfileError("forbidden", "Select or create a company first.");
      if (!canAccess(s.role, BUSINESS_PROFILE_SLUG)) throw new BusinessProfileError("forbidden", "Your role cannot use the company profile.");
      return await fn(req, ctx, { actor: { tenantId: s.tenantId, userId: s.user.id, role: s.role, requestId: rid }, rid, svc: await getBusinessProfileService(), userId: s.user.id });
    } catch (e) {
      if (isBusinessProfileError(e)) return problem(e.code, e.status, e.message, rid, e.details?.fields ? { errors: e.details.fields } : {});
      throw e;
    }
  });
}
export async function readBody(req: NextRequest): Promise<unknown> {
  if (!req.headers.get("content-type")?.toLowerCase().startsWith("application/json")) throw new BusinessProfileError("validation_failed", "Content-Type must be application/json.");
  const text = await req.text(); if (!text.trim()) return {};
  try { const b = JSON.parse(text) as unknown; if (b === null || typeof b !== "object" || Array.isArray(b)) throw 0; return fromWire(b); } catch { throw new BusinessProfileError("validation_failed", "The body must be a JSON object."); }
}
export const respond = (data: unknown, rid: string, status = 200) => ok(toWire(data), rid, status);
