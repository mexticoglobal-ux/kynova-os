# ADR 031 · Business Profile como capa de plataforma

**Estado**: aceptada (Entrega 14).

## Contexto
Cada AI Employee necesita conocer la empresa. Sin una fuente única, cada módulo (Marketing, SEO, CRM, Real Estate…) duplicaría esos datos.

## Decisión
1. `platform/business-profile` es genérico e independiente de cualquier módulo; solo la composición (`server.ts`) conoce otros sistemas.
2. Los datos básicos permanecen en `companies` (una sola fuente); el resto en `bp_profiles` y `bp_dna`, una fila por `tenant_id`.
3. Completitud calculada, nunca almacenada; los valores por defecto no confirmados no cuentan.
4. El DNA se persiste, no se interpreta. Los empleados consultan `requirements()` y declaran lo que falta.
5. Cambio aditivo en Core: `AuthService.switchTenant` para operar varias empresas con una sesión.
6. Los nombres de empresa son datos, no código.

## Escala (10.000 empresas)
Sin estado global; acceso por clave primaria `tenant_id`; sin jobs ni barridos; la completitud se calcula bajo demanda sobre dos filas. No requiere rediseño.

## Consecuencias
Solo el CEO AI de Real Estate consume el perfil hoy; el resto debe llamar a `requirements()`. Sin IA real, integraciones ni cron.
