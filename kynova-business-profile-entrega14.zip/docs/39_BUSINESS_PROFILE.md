# 39 · Business Profile y Business DNA (Entrega 14)

KYNOVA como primer cliente: las empresas reales (KYNOVA, Nova Marketing Studio, PSI, Jeffrey Real Estate) se registran por la UI/API como cualquier otra. Ningún nombre está en el código.

## Qué es
`src/platform/business-profile/` — fuente única de verdad sobre una empresa, reutilizable por cualquier AI Business System. No importa módulos de negocio ni usa red/IA.

- **Perfil**: nombre, logo (URL https), industria, sitio web, redes sociales, email, teléfono, ubicación, idioma, moneda, zona horaria. Solo se guarda.
- **Business DNA v1**: objetivos, propuesta de valor, tipo de cliente, tono, industrias, productos, servicios, competidores, palabras clave, prioridades. Solo se guarda; no se interpreta.
- Los básicos (nombre, industria, país, idioma, moneda, zona) viven en `companies`; no se duplican.

## Honestidad
- Los porcentajes se **calculan**, nunca se guardan.
- Los valores por defecto (nombre, idioma, moneda, zona) no cuentan hasta que la persona los confirma (los cuatro en un mismo guardado).
- Sin datos: «Todavía no hay suficiente información para generar recomendaciones.»

## Contrato para AI Employees
`requirements(state, needs)` → `{ ready, missing }`. Cada empleado declara qué necesita (`dna.tone`, `profile.website`…) y lista exactamente lo que falta; nunca lo inventa. El CEO AI de Real Estate es el primer adoptante: usa el perfil como contexto por reglas (refuerza el trabajo que sirve a las prioridades del DNA, avisa `profile_incomplete`). Los demás empleados adoptan la misma llamada.

## Mission Control
Tarjeta «Conocimiento de tu empresa»: perfil %, DNA %, información pendiente.

## API (`/api/v1/business-profile`)
`GET/PUT /`, `GET/PUT /dna`, `GET /knowledge`, `GET/POST /companies`, `POST /companies/switch`. CSRF en mutaciones; ver = cualquier rol con acceso, gestionar = roles de gestión.

## Multiempresa
`createMyCompany` crea otra empresa para el usuario; `switchTenant` (cambio aditivo en Auth) mueve la sesión a otra membresía propia y re-firma el ticket. Una fila por `tenant_id` (tablas `bp_profiles`, `bp_dna`, migración 2300, sin DELETE).

## Límites
Logo por URL (subida: próximamente). Sin verificación de datos con APIs externas, sin IA conversacional, sin cron ni integraciones.
