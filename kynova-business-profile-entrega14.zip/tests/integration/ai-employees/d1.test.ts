import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { addMember, createD1EmployeeStores, createLazyD1EmployeeStores, tenantDb } from "@/platform/db";
import { isEmployeeError, type Actor } from "@/platform/ai-employees";
import { ProviderError } from "@/platform/ai-kernel/errors";
import { createTestDb, newCompany, newUser, expectDomain } from "../db/helpers";
import { hire, reply, setup } from "../../unit/ai-employees/helpers";

let t: Awaited<ReturnType<typeof createTestDb>>;
let A: Actor, MK: Actor, SUP: Actor, B: Actor;
beforeAll(async () => {
  t = await createTestDb();
  const [oa, ob, mk, sup] = [await newUser(t.db), await newUser(t.db), await newUser(t.db), await newUser(t.db)];
  const a = await newCompany(t.db, oa.id), b = await newCompany(t.db, ob.id);
  await addMember(t.db, { tenantId: a.companyId, actorUserId: oa.id, userId: mk.id, roleId: "marketing" });
  await addMember(t.db, { tenantId: a.companyId, actorUserId: oa.id, userId: sup.id, roleId: "support" });
  A = { tenantId: a.companyId, userId: oa.id, role: "owner" };
  MK = { tenantId: a.companyId, userId: mk.id, role: "marketing" };
  SUP = { tenantId: a.companyId, userId: sup.id, role: "support" };
  B = { tenantId: b.companyId, userId: ob.id, role: "owner" };
});
afterAll(async () => { await t.dispose(); });

const env = (o: Parameters<typeof setup>[0] = {}) => setup({ ...o, stores: createD1EmployeeStores(t.db) });
const code = async (p: Promise<unknown>) => { try { await p; return "none"; } catch (e) { return isEmployeeError(e) ? e.code : `other:${(e as { code?: string }).code ?? (e as Error).message}`; } };
const fresh = async (): Promise<Actor> => { const o = await newUser(t.db); return { tenantId: (await newCompany(t.db, o.id)).companyId, userId: o.id, role: "owner" }; };
let n = 0;
const nm = () => `Emp ${++n} ${Math.random().toString(36).slice(2, 6)}`;

describe("framework on a real D1", () => {
  it("hires, runs through the kernel and records usage, cost, audit and company profile", async () => {
    const e = env({ alpha: [reply({ reply: "Hello", actions: [{ capability: "crm.note", input: { contact: "c", text: "x" } }] }, 1000, 500)] });
    const emp = await hire(e, { name: nm(), goal: "Help", autonomy: 3 }, A);
    expect(emp).toMatchObject({ tenantId: A.tenantId, ownerUserId: A.userId, ownerRole: "owner" });
    const task = await e.fw.tasks.enqueue(MK, emp.id, { title: "Greet", input: "hi", mode: "now" });
    expect(task).toMatchObject({ status: "succeeded", provider: "alpha", costMicros: 2000, inputTokens: 1000, outputTokens: 500, attempts: 1, byok: false, requestedBy: MK.userId, requestedRole: "marketing" });
    expect(task.result!.actions[0]!.status).toBe("executed");
    expect(e.alpha.seen[0]!.system).toContain("Test Co"); // company name comes from the companies table
    const audit = await tenantDb(t.db, { tenantId: A.tenantId }).audit.list({ limit: 50 });
    expect(audit.items.map((r) => r.action)).toEqual(expect.arrayContaining(["ai.employee.created", "ai.employee.task_enqueued", "ai.employee.action_executed", "ai.employee.task_completed"]));
    expect(audit.items.find((r) => r.action === "ai.employee.task_completed")).toMatchObject({ actorType: "agent", actorId: `agent:${emp.id}` });
    const [rec] = await e.kernel.listUsage(A.tenantId, { limit: 1 });
    expect(rec).toMatchObject({ module: "employee:custom", userId: `agent:${emp.id}` });
    expect((await e.fw.employees.usage(A, emp.id)).today).toMatchObject({ runs: 1, costMicros: 2000, inputTokens: 1000, outputTokens: 500 });
  });

  it("isolates companies at the database level", async () => {
    const e = env({ alphaRepeat: reply() });
    const emp = await hire(e, { name: nm() }, A);
    const task = await e.fw.tasks.enqueue(A, emp.id, { title: "x" });
    await e.fw.memory.remember(A, emp.id, { content: "secret of A" });
    expect(await code(e.fw.employees.get(B, emp.id))).toBe("not_found");
    expect(await code(e.fw.tasks.get(B, task.id))).toBe("not_found");
    expect(await code(e.fw.tasks.enqueue(B, emp.id, { title: "x" }))).toBe("not_found");
    expect(await code(e.fw.memory.recall(B, emp.id))).toBe("not_found");
    expect(await e.stores.tasks.claim(B.tenantId, { id: task.id, now: Date.now() + 1e9, leaseMs: 1000 })).toBeNull();
    expect(await e.stores.memory.list(B.tenantId, emp.id, { limit: 10, now: 0 })).toEqual([]);
    expect((await e.fw.employees.list(B)).map((x) => x.id)).not.toContain(emp.id);
  });

  it("composite foreign keys refuse a task or memory that points at another company's employee", async () => {
    const e = env();
    const emp = await hire(e, { name: nm() }, A);
    const base = { id: "x".repeat(32), employeeId: emp.id, title: "t", input: "", status: "queued" as const, priority: 5, attempts: 0, maxAttempts: 3, runAfter: 0, leaseUntil: null, requestedBy: B.userId, requestedRole: "owner" as const, source: "manual" as const, idempotencyKey: null, result: null, errorCode: null, errorMessage: null, provider: null, model: null, byok: false, promptId: null, promptVersion: null, inputTokens: 0, outputTokens: 0, costMicros: 0, decidedBy: null, decidedAt: null, startedAt: null, finishedAt: null, createdAt: 1, updatedAt: 1 };
    expect(await expectDomain(e.stores.tasks.insert({ ...base, tenantId: B.tenantId }))).toBe("conflict");
    expect(await expectDomain(e.stores.memory.insert({ id: "m".repeat(32), tenantId: B.tenantId, employeeId: emp.id, kind: "note", content: "x", importance: 3, source: "user", createdBy: null, expiresAt: null, createdAt: 1 }))).toBe("conflict");
  });

  it("employee names are unique per company, case-insensitively, but may repeat across companies", async () => {
    const e = env();
    const name = nm();
    await hire(e, { name }, A);
    expect(await code(hire(e, { name: name.toUpperCase() }, A))).toBe("conflict");
    await hire(e, { name }, B);
  });

  it("claim is atomic: racing workers execute a task once", async () => {
    const e = env({ alpha: [reply(), reply(), reply()] });
    const emp = await hire(e, { name: nm() }, A);
    const task = await e.fw.tasks.enqueue(A, emp.id, { title: "x" });
    await Promise.all([e.fw.run.runTask(A.tenantId, task.id), e.fw.run.runTask(A.tenantId, task.id), e.fw.run.runTask(A.tenantId, task.id)]);
    expect(e.alpha.seen).toHaveLength(1);
    expect((await e.fw.tasks.get(A, task.id))).toMatchObject({ status: "succeeded", attempts: 1 });
  });

  it("drain takes tasks by priority, then age, and skips tasks that are not due yet", async () => {
    const e = env({ alphaRepeat: reply() });
    const C = await fresh(); // a fresh company: the queue of A holds tasks left by other tests
    const emp = await hire(e, { name: nm() }, C);
    const due = Date.now() - 1000;
    const low = await e.fw.tasks.enqueue(C, emp.id, { title: "low", priority: 9, runAfter: due });
    const high = await e.fw.tasks.enqueue(C, emp.id, { title: "high", priority: 0, runAfter: due });
    const later = await e.fw.tasks.enqueue(C, emp.id, { title: "later", priority: 0, runAfter: Date.now() + 10 * 365 * 86_400_000 });
    // The scripted clock is in the past; drain by claiming with the real clock through the store the way a worker would.
    const first = await e.stores.tasks.claim(C.tenantId, { now: Date.now(), leaseMs: 1000 });
    const second = await e.stores.tasks.claim(C.tenantId, { now: Date.now(), leaseMs: 1000 });
    const third = await e.stores.tasks.claim(C.tenantId, { now: Date.now(), leaseMs: 1000 });
    expect([first?.id, second?.id]).toEqual([high.id, low.id]);
    expect(third).toBeNull(); // "later" is not due
  });

  it("retries a transient failure with backoff then fails; an expired lease is reclaimed or failed", async () => {
    const e = env({ alphaRepeat: new ProviderError("unavailable", "down") });
    const A = await fresh();
    const emp = await hire(e, { name: nm(), budget: { maxAttempts: 2 } }, A);
    const task = await e.fw.tasks.enqueue(A, emp.id, { title: "x" });
    const r1 = (await e.fw.run.runTask(A.tenantId, task.id))!;
    expect(r1).toMatchObject({ status: "queued", attempts: 1, errorCode: "all_providers_failed" });
    e.tick(10 * 60_000);
    const r2 = (await e.fw.run.drain(A.tenantId)).tasks[0]!;
    expect(r2).toMatchObject({ id: task.id, status: "failed", attempts: 2 });
    // crashed worker with attempts exhausted
    const emp2 = await hire(e, { name: nm(), budget: { maxAttempts: 1 } }, A);
    const t2 = await e.fw.tasks.enqueue(A, emp2.id, { title: "y" });
    await e.stores.tasks.claim(A.tenantId, { id: t2.id, now: e.now(), leaseMs: 1000 });
    e.tick(5000);
    expect((await e.fw.run.drain(A.tenantId)).failedExpired).toBe(1);
    expect(await e.fw.tasks.get(A, t2.id)).toMatchObject({ status: "failed", errorCode: "lease_expired" });
  });

  it("L2 approval flow persists pending actions, one reviewer wins, and the ledger is final afterwards", async () => {
    const e = env({ alpha: [reply({ actions: [{ capability: "crm.note", input: { contact: "c", text: "t" } }] })] });
    const emp = await hire(e, { name: nm(), autonomy: 2 }, A);
    const task = await e.fw.tasks.enqueue(MK, emp.id, { title: "x", mode: "now" });
    expect(task.status).toBe("awaiting_approval");
    expect(task.result!.actions[0]!.status).toBe("pending");
    const [a, b] = await Promise.allSettled([e.fw.tasks.decide(A, task.id, "approve"), e.fw.tasks.decide(A, task.id, "approve")]);
    expect([a.status, b.status].sort()).toEqual(["fulfilled", "rejected"]);
    expect(e.handled).toHaveLength(1);
    const done = await e.fw.tasks.get(A, task.id);
    expect(done).toMatchObject({ status: "succeeded", decidedBy: A.userId });
    expect(done.result!.actions[0]!.status).toBe("executed");
    expect(await expectDomain(e.stores.tasks.transition(A.tenantId, task.id, { from: ["succeeded"], set: { status: "queued", finishedAt: null }, now: 1 }))).toBe("conflict");
  });

  it("re-checks live memberships: a removed requester or a changed role takes effect at execution time", async () => {
    const e = env({ alphaRepeat: reply() });
    const emp = await hire(e, { name: nm(), allowedRoles: ["marketing", "support"] }, A);
    const ok = await e.fw.tasks.enqueue(SUP, emp.id, { title: "ok", mode: "now" });
    expect(ok.status).toBe("succeeded");
    // the requester is queued, then disabled before the worker picks the task up
    const queued = await e.fw.tasks.enqueue(SUP, emp.id, { title: "later" });
    const { setMemberStatus } = await import("@/platform/db");
    await setMemberStatus(t.db, { tenantId: A.tenantId, actorUserId: A.userId, userId: SUP.userId, status: "suspended" } as never);
    expect(await e.fw.run.runTask(A.tenantId, queued.id)).toMatchObject({ status: "failed", errorCode: "actor_inactive" });
  });

  it("database rules: retired employees are final, only active employees take tasks, tasks keep their identity", async () => {
    const e = env();
    const emp = await hire(e, { name: nm() }, A);
    const task = await e.fw.tasks.enqueue(A, emp.id, { title: "x" });
    await e.fw.employees.update(A, emp.id, { status: "paused" });
    expect(await code(e.fw.tasks.enqueue(A, emp.id, { title: "y" }))).toBe("forbidden"); // service guard
    expect(await expectDomain(e.stores.tasks.insert({ ...task, id: "q".repeat(32), idempotencyKey: null }))).toBe("conflict"); // trigger guard
    expect(await expectDomain(e.stores.tasks.transition(A.tenantId, task.id, { from: ["queued"], set: { requestedBy: "someone-else" }, now: 1 }))).toBe("forbidden");
    await e.fw.employees.update(A, emp.id, { status: "retired" });
    expect(await expectDomain(e.stores.employees.update(A.tenantId, emp.id, { name: "Back to life" }, 1))).toBe("conflict");
  });

  it("CHECK constraints reject impossible rows (NULL-safe)", async () => {
    const e = env();
    const emp = await hire(e, { name: nm() }, A);
    const bad = async (patch: object) => expectDomain(e.stores.tasks.insert({ id: Math.random().toString(16).slice(2).padEnd(32, "0"), tenantId: A.tenantId, employeeId: emp.id, title: "t", input: "", status: "queued", priority: 5, attempts: 0, maxAttempts: 3, runAfter: 0, leaseUntil: null, requestedBy: A.userId, requestedRole: "owner", source: "manual", idempotencyKey: null, result: null, errorCode: null, errorMessage: null, provider: null, model: null, byok: false, promptId: null, promptVersion: null, inputTokens: 0, outputTokens: 0, costMicros: 0, decidedBy: null, decidedAt: null, startedAt: null, finishedAt: null, createdAt: 1, updatedAt: 1, ...patch } as never));
    expect(await bad({ priority: 12 })).toBe("validation_failed");
    expect(await bad({ attempts: 4 })).toBe("validation_failed");
    expect(await bad({ status: "running", leaseUntil: null })).toBe("validation_failed");
    expect(await bad({ status: "failed", finishedAt: null })).toBe("validation_failed");
    expect(await bad({ costMicros: -1 })).toBe("validation_failed");
    expect(await bad({ requestedRole: "root" })).toBe("validation_failed");
  });

  it("the lazy registration resolves the binding per call and fails closed without one", async () => {
    const lazy = createLazyD1EmployeeStores(async () => t.db);
    const emp = await hire(env(), { name: nm() }, A);
    expect((await lazy.employees.get(A.tenantId, emp.id))?.id).toBe(emp.id);
    const prev = process.env.APP_ENV;
    process.env.APP_ENV = "production";
    try {
      const broken = createLazyD1EmployeeStores(async () => { throw new Error("no binding"); });
      await expect(broken.employees.get(A.tenantId, emp.id)).rejects.toMatchObject({ name: "AiConfigError" });
    } finally { process.env.APP_ENV = prev; }
  });
});
