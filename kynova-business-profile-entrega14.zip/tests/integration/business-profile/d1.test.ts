import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { companiesRepo } from "../../../src/platform/db";
import { createD1BusinessProfileStore } from "../../../src/platform/business-profile/store-d1";
import { createBusinessProfileService, type Actor } from "../../../src/platform/business-profile";
import { createTestDb, newCompany, newUser } from "../db/helpers";

let t: Awaited<ReturnType<typeof createTestDb>>;
beforeAll(async () => { t = await createTestDb(); }, 60_000);
afterAll(async () => { await t.dispose(); });
const fresh = async (): Promise<Actor> => { const u = await newUser(t.db), c = await newCompany(t.db, u.id); return { tenantId: c.companyId, userId: u.id, role: "owner" }; };
const svc = () => createBusinessProfileService({
  store: createD1BusinessProfileStore(t.d1),
  ports: {
    async basics(id) { const c = await companiesRepo(t.db).findById(id); return c ? { name: c.name, industry: c.industry, country: c.country, locale: c.defaultLocale, currency: c.defaultCurrency, timezone: c.timezone } : null; },
    async updateBasics(id, p) { await companiesRepo(t.db).update(id, { ...(p.name ? { name: p.name } : {}), ...(p.industry !== undefined ? { industry: p.industry } : {}), updatedAt: Date.now() }); },
  },
});

describe("Business Profile on D1", () => {
  it("round-trips profile and DNA, and keeps basics in the company row", async () => {
    const a = await fresh(), s = svc();
    await s.saveProfile(a, { name: "KYNOVA", industry: "technology", locale: "es", currency: "USD", timezone: "UTC", website: "https://kynova.example", socials: { x: "@k" } });
    await s.saveDna(a, { objectives: ["Crecer"], priorities: ["sales"], keywords: ["ia", "ia"] });
    const k = await s.state(a), c = await companiesRepo(t.db).findById(a.tenantId);
    expect(c?.name).toBe("KYNOVA"); expect(k.profile).toMatchObject({ name: true, website: true, socials: true }); expect(k.priorities).toEqual(["sales"]);
    expect((await s.dna(a)).keywords).toEqual(["ia"]);
  });
  it("two companies never see each other's data", async () => {
    const a = await fresh(), b = await fresh(), s = svc();
    await s.saveProfile(a, { website: "https://a.example" }); await s.saveDna(a, { tone: "formal" });
    expect((await s.profile(b)).website).toBe(""); expect((await s.dna(b)).tone).toBe(""); expect((await s.state(b)).hasAnyData).toBe(false);
  });
  it("rows cannot be deleted", async () => {
    const a = await fresh(); await svc().saveProfile(a, { website: "https://a.example" }); await svc().saveDna(a, { tone: "x" });
    await expect(t.d1.prepare("DELETE FROM bp_profiles WHERE tenant_id = ?").bind(a.tenantId).run()).rejects.toThrow();
    await expect(t.d1.prepare("DELETE FROM bp_dna WHERE tenant_id = ?").bind(a.tenantId).run()).rejects.toThrow();
  });
  it("refuses a row for a company that does not exist", async () => {
    await expect(t.d1.prepare("INSERT INTO bp_dna (tenant_id, created_at, updated_at, updated_by) VALUES ('ghost', 1, 1, 'u')").run()).rejects.toThrow();
  });
});
