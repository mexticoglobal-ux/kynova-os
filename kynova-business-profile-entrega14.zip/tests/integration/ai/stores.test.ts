import { afterAll, afterEach, beforeAll, describe, expect, it } from "vitest";
import { z } from "zod";
import { addAiPromptVersion, createD1AiStores, createLazyD1AiStores, registerAiPersistence, setAiCompanyCaps, setAiProviderStatus, tenantDb, upsertAiModel } from "@/platform/db";
import { getAiKernel } from "@/platform/ai-kernel";
import { createCatalogSync } from "@/platform/ai-kernel/catalog-sync";
import { getAiConfig } from "@/platform/ai-kernel/config";
import { createCredentialService } from "@/platform/ai-kernel/credentials";
import { isAiError, ProviderError } from "@/platform/ai-kernel/errors";
import { createAiKernel } from "@/platform/ai-kernel/kernel";
import { windowKeys } from "@/platform/ai-kernel/limits";
import { createModelRegistry } from "@/platform/ai-kernel/registry/models";
import { createPromptRegistry } from "@/platform/ai-kernel/registry/prompts";
import { createProviderRegistry } from "@/platform/ai-kernel/registry/providers";
import { createSecretBox } from "@/platform/ai-kernel/secrets";
import type { StoredCredential } from "@/platform/ai-kernel/ports";
import type { AdapterRequest, AdapterResponse, ModelDef, ProviderAdapter, UsageRecord } from "@/platform/ai-kernel/types";
import { createTestDb, newCompany, newUser } from "../db/helpers";

let t: Awaited<ReturnType<typeof createTestDb>>;
let A: string, B: string;
beforeAll(async () => {
  t = await createTestDb();
  A = (await newCompany(t.db, (await newUser(t.db)).id)).companyId;
  B = (await newCompany(t.db, (await newUser(t.db)).id)).companyId;
});
afterAll(async () => { await t.dispose(); });

const actions = async (tenantId: string) => (await tenantDb(t.db, { tenantId }).audit.list({ limit: 100 })).items.filter((a) => a.action.startsWith("ai.")).map((a) => a.action).sort();
const cred = (tenantId: string, over: Partial<StoredCredential> = {}): StoredCredential => ({ tenantId, provider: "openai", ciphertext: "v1.k1.iv.SECRETCIPHERTEXT", keyId: "k1", last4: "9876", status: "active", createdAt: 1, updatedAt: 2, createdBy: "u1", ...over });
let seq = 0;
const rec = (tenantId: string, over: Partial<UsageRecord> = {}): UsageRecord => ({
  id: `r${Date.now()}${++seq}`, tenantId, userId: "u1", module: "growth", taskClass: "draft", promptId: "growth.caption", promptVersion: 1, provider: "alpha", model: "alpha:m", source: "platform", byok: false,
  inputTokens: 100, outputTokens: 50, costMicros: 200, latencyMs: 12, status: "success", errorCode: null, attempts: [{ model: "alpha:m", provider: "alpha", source: "platform", attempt: 1, outcome: "success", latencyMs: 12 }], degraded: false, requestId: "req-1", createdAt: Date.now(), ...over,
});

describe("D1 credential store (BYOK)", () => {
  it("round-trips, upserts, and is isolated per company", async () => {
    const st = createD1AiStores(t.db).credentials;
    await st.put(cred(A));
    await st.put(cred(B, { last4: "1111" }));
    expect((await st.get(A, "openai"))!.last4).toBe("9876");
    expect((await st.get(B, "openai"))!.last4).toBe("1111");
    await st.put(cred(A, { last4: "2222", ciphertext: "v1.k1.iv.NEW" }));
    expect((await st.list(A)).map((c) => [c.provider, c.last4])).toEqual([["openai", "2222"]]);
    expect(await st.get(A, "anthropic")).toBeNull();
  });
  it("audits set, rotated, invalidated and removed with the actor, and never records the key", async () => {
    const st = createD1AiStores(t.db).credentials;
    await st.put(cred(B, { provider: "google", last4: "5555", createdBy: "admin-9" }));
    await st.put(cred(B, { provider: "google", last4: "5555", keyId: "k2", ciphertext: "v1.k2.iv.ROTATED", createdBy: "admin-9" }));
    await st.put(cred(B, { provider: "google", last4: "5555", keyId: "k2", ciphertext: "v1.k2.iv.ROTATED", status: "invalid", createdBy: "admin-9" }));
    expect(await st.delete(B, "google", "admin-9")).toBe(true);
    expect(await st.delete(B, "google", "admin-9")).toBe(false);
    const log = (await tenantDb(t.db, { tenantId: B }).audit.list({ limit: 100 })).items.filter((a) => a.resourceId === "google");
    expect(log.map((a) => a.action).sort()).toEqual(["ai.credential.invalidated", "ai.credential.removed", "ai.credential.rotated", "ai.credential.set"]);
    expect(log.find((a) => a.action === "ai.credential.removed")).toMatchObject({ actorType: "user", actorId: "admin-9" });
    expect(log.find((a) => a.action === "ai.credential.rotated")!.actorType).toBe("system");
    expect(JSON.stringify(log)).not.toMatch(/ROTATED|SECRETCIPHERTEXT|ciphertext/);
  });
  it("the sealed key stored in D1 is bound to its company and provider", async () => {
    const providers = createProviderRegistry({ includeMock: false });
    const box = createSecretBox({ activeKeyId: "k", keys: { k: new Uint8Array(32).fill(5) } });
    const svc = createCredentialService({ store: createD1AiStores(t.db).credentials, box, providers });
    await svc.set(A, "xai", "xai-live-abcdef123456", "owner-1");
    expect(await svc.reveal(A, "xai")).toBe("xai-live-abcdef123456");
    const raw = await t.d1.prepare("select ciphertext from ai_providers where tenant_id = ? and provider = 'xai'").bind(A).first<{ ciphertext: string }>();
    expect(raw!.ciphertext).not.toContain("abcdef");
    await t.d1.prepare("update ai_providers set ciphertext = ? where tenant_id = ? and provider = 'xai'").bind(raw!.ciphertext, A).run();
    // copy the ciphertext into another company's row: it must not decrypt there
    await svc.set(B, "xai", "xai-other-zzzzzzzz9999", "owner-2");
    await t.d1.prepare("update ai_providers set ciphertext = ? where tenant_id = ? and provider = 'xai'").bind(raw!.ciphertext, B).run();
    await expect(svc.reveal(B, "xai")).rejects.toThrow();
  });
});

describe("D1 settings store", () => {
  it("round-trips every field, audits before/after, and never touches the platform caps", async () => {
    const st = createD1AiStores(t.db);
    expect(await st.settings.get(A)).toBeNull();
    await setAiCompanyCaps(t.db, A, { daily: { requests: 50 } }, "admin-1");
    const settings = { enabled: false, routing: { preferred: ["anthropic:claude-haiku-5-5"], denyProviders: ["xai"], maxCostPerRequestMicros: 5000, maxLatencyClass: "standard" as const }, limits: { daily: { tokens: 1000, requests: 10 }, monthly: { costMicros: 9_000_000 } }, byok: { mode: "required" as const }, redactSecrets: false };
    await st.settings.put(A, settings, "owner-1");
    expect(await st.settings.get(A)).toEqual(settings);
    expect((await st.caps(A)).daily.requests).toBe(50);
    await st.settings.put(A, { ...settings, enabled: true }, "owner-1");
    expect((await st.settings.get(A))!.enabled).toBe(true);
    const entries = (await tenantDb(t.db, { tenantId: A }).audit.list({ action: "ai.settings.updated" })).items;
    expect(entries).toHaveLength(2);
    const last = entries[0]!; // newest first
    expect(JSON.parse(last.beforeJson!).enabled).toBe(false);
    expect(JSON.parse(last.afterJson!).enabled).toBe(true);
    expect(last).toMatchObject({ actorType: "user", actorId: "owner-1" });
  });
  it("is isolated per company", async () => {
    const st = createD1AiStores(t.db).settings;
    expect(await st.get(B)).toBeNull();
  });
});

describe("D1 usage store and window counters", () => {
  it("round-trips a record and lists newest first with a cursor", async () => {
    const us = createD1AiStores(t.db).usage;
    const base = Date.now() - 10_000;
    for (let i = 0; i < 4; i++) await us.append(rec(B, { createdAt: base + i * 100, requestId: `r${i}` }));
    const page = await us.list(B, { limit: 3 });
    expect(page.map((r) => r.requestId)).toEqual(["r3", "r2", "r1"]);
    expect(page[0]).toMatchObject({ tenantId: B, module: "growth", byok: false, degraded: false, inputTokens: 100, attempts: [{ outcome: "success" }] });
    expect((await us.list(B, { limit: 10, before: page.at(-1)!.createdAt })).map((r) => r.requestId)).toEqual(["r0"]);
    expect(await us.list(A, { limit: 10 })).toEqual([]);
  });
  it("counts only successful platform-key calls, per UTC day and month, per company", async () => {
    const us = createD1AiStores(t.db).usage;
    const C = (await newCompany(t.db, (await newUser(t.db)).id)).companyId;
    const now = Date.UTC(2026, 5, 15, 12);
    const keys = windowKeys(now);
    const dayStart = Date.parse("2026-06-15T00:00:00Z"), monthStart = Date.parse("2026-06-01T00:00:00Z");
    await us.append(rec(C, { createdAt: now }));                                                                    // today: counts
    await us.append(rec(C, { createdAt: now + 1, inputTokens: 10, outputTokens: 5, costMicros: 7 }));                  // today: counts
    await us.append(rec(C, { createdAt: dayStart - 1 }));                                                              // yesterday: month only
    await us.append(rec(C, { createdAt: monthStart - 1 }));                                                            // last month: neither
    await us.append(rec(C, { createdAt: now + 2, source: "tenant", byok: true }));                                     // own key: exempt
    await us.append(rec(C, { createdAt: now + 3, status: "error", errorCode: "all_providers_failed", provider: null, model: null, source: null, inputTokens: 40, outputTokens: 0, costMicros: 0 })); // failed: not counted
    await us.append(rec(B, { createdAt: now + 4 }));                                                                   // another company
    expect(await us.counters(C, keys)).toEqual({ day: { tokens: 165, costMicros: 207, requests: 2 }, month: { tokens: 315, costMicros: 407, requests: 3 } });
    expect(await us.counters("nobody", keys)).toEqual({ day: { tokens: 0, costMicros: 0, requests: 0 }, month: { tokens: 0, costMicros: 0, requests: 0 } });
    await expect(us.incrementCounters("x", keys, { tokens: 1, costMicros: 1, requests: 1 })).resolves.toBeUndefined(); // derived, so a no-op
  });
  it("counters are exact under concurrent appends", async () => {
    const us = createD1AiStores(t.db).usage;
    const D = (await newCompany(t.db, (await newUser(t.db)).id)).companyId;
    const now = Date.now();
    await Promise.all(Array.from({ length: 25 }, () => us.append(rec(D, { createdAt: now, inputTokens: 3, outputTokens: 2, costMicros: 1 }))));
    expect((await us.counters(D, windowKeys(now))).day).toEqual({ tokens: 125, costMicros: 25, requests: 25 });
  });
});

describe("AI Kernel running on the D1 stores", () => {
  const ok = (text: string): AdapterResponse => ({ text, inputTokens: 1000, outputTokens: 500 });
  function boot(steps: (() => AdapterResponse | ProviderError)[] = []) {
    const seen: { req: AdapterRequest; apiKey: string }[] = [];
    const adapter: ProviderAdapter = { id: "alpha", async generate(req, o) { seen.push({ req, apiKey: o.apiKey }); const s = steps.shift()?.() ?? ok("hello from alpha"); if (s instanceof ProviderError) throw s; return s; } };
    const providers = createProviderRegistry({ includeMock: false, defs: [] });
    providers.register({ id: "alpha", label: "Alpha", protocol: "mock", baseUrl: "mock://alpha", envKey: "TEST_ALPHA_KEY", maxTokensParam: "max_tokens", jsonMode: true, status: "active" }, adapter);
    // In code the model is UNPRICED: only the stored catalog can make it routable.
    const unpriced: ModelDef = { id: "alpha:m", provider: "alpha", ref: "m", label: "Alpha M", capabilities: ["text", "structured"], contextWindow: 100_000, maxOutputTokens: 4096, pricing: null, latency: "fast", quality: "standard", status: "active" };
    const models = createModelRegistry([unpriced]);
    const prompts = createPromptRegistry();
    const stores = createD1AiStores(t.db);
    const credentials = createCredentialService({ store: stores.credentials, box: createSecretBox({ activeKeyId: "k", keys: { k: new Uint8Array(32).fill(7) } }), providers });
    const sync = createCatalogSync({ store: stores.catalog, models, providers, prompts, ttlMs: 0 });
    const config = { ...getAiConfig(), retry: { maxAttemptsPerModel: 1, baseDelayMs: 1, maxDelayMs: 1 }, defaultCaps: { daily: {}, monthly: {} } };
    const kernel = createAiKernel({ config, providers, models, prompts, settings: stores.settings, credentials, usage: stores.usage, caps: stores.caps, sync, fetch });
    return { kernel, seen, credentials };
  }
  const ctxFor = (tenantId: string) => ({ tenantId, module: "growth", userId: "u1", requestId: "e2e" });
  const call = (k: ReturnType<typeof boot>["kernel"], tenantId: string) => k.generate({ ctx: ctxFor(tenantId), task: "draft", input: { prompt: { id: "e2e.caption", vars: { topic: "shoes" } } } });
  let T: string;
  beforeAll(async () => {
    process.env.TEST_ALPHA_KEY = "platform-alpha-key";
    T = (await newCompany(t.db, (await newUser(t.db)).id)).companyId;
    await upsertAiModel(t.db, { id: "alpha:m", provider: "alpha", ref: "m", label: "Alpha M", capabilities: ["text", "structured"], contextWindow: 100_000, maxOutputTokens: 4096, pricing: { inputPerMTokMicros: 1_000_000, outputPerMTokMicros: 2_000_000 }, latency: "fast", quality: "standard", status: "active" }, "admin-1");
    await addAiPromptVersion(t.db, { id: "e2e.caption", version: 1, owner: "growth", task: "draft", template: "Caption for {{topic}}", variables: [{ name: "topic" }] }, "admin-1");
  });
  afterAll(() => { delete process.env.TEST_ALPHA_KEY; });

  it("routes using the stored prices and the stored prompt, and persists the usage record", async () => {
    const { kernel, seen } = boot();
    const r = await call(kernel, T);
    expect(r).toMatchObject({ provider: "alpha", model: "alpha:m", source: "platform", promptId: "e2e.caption", promptVersion: 1, text: "hello from alpha" });
    expect(r.usage).toEqual({ inputTokens: 1000, outputTokens: 500, costMicros: 2000 }); // 1000*1 + 500*2 micros, from the stored prices
    expect(seen[0]!.req.messages[0]!.content).toBe("Caption for shoes");
    const [row] = await t.d1.prepare("select * from ai_usage where tenant_id = ?").bind(T).all<Record<string, unknown>>().then((x) => x.results);
    expect(row).toMatchObject({ tenant_id: T, module: "growth", task_class: "draft", prompt_id: "e2e.caption", provider: "alpha", model: "alpha:m", source: "platform", byok: 0, input_tokens: 1000, output_tokens: 500, cost_micros: 2000, status: "success", request_id: "e2e" });
  });
  it("enforces the per-company daily limit from persisted counters, across kernel restarts", async () => {
    const E = (await newCompany(t.db, (await newUser(t.db)).id)).companyId;
    await setAiCompanyCaps(t.db, E, { daily: { requests: 2 } }, "admin-1");
    await call(boot().kernel, E);
    await call(boot().kernel, E); // a brand new kernel instance: the counters live in D1, not in memory
    const e = await call(boot().kernel, E).catch((x) => x);
    expect(isAiError(e) && e.code).toBe("quota_exceeded");
    expect(e.details).toMatchObject({ window: "daily", dimension: "requests", limit: 2, used: 2 });
    expect((await createD1AiStores(t.db).usage.list(E, { limit: 10 })).map((r) => r.status).sort()).toEqual(["error", "success", "success"]);
  });
  it("a company can lower its limit through the kernel but never exceed the platform cap", async () => {
    const F = (await newCompany(t.db, (await newUser(t.db)).id)).companyId;
    const { kernel } = boot();
    await setAiCompanyCaps(t.db, F, { daily: { requests: 3 } });
    await kernel.saveSettings(F, { limits: { daily: { requests: 1 } } }, "owner-1");
    await call(kernel, F);
    await expect(call(kernel, F)).rejects.toMatchObject({ code: "quota_exceeded" });
    const G = (await newCompany(t.db, (await newUser(t.db)).id)).companyId;
    await setAiCompanyCaps(t.db, G, { daily: { requests: 1 } });
    await kernel.saveSettings(G, { limits: { daily: { requests: 999 } } }, "owner-2");
    expect((await kernel.getSettings(G)).caps.daily.requests).toBe(1);
  });
  it("uses the company's own sealed key from D1 and exempts it from platform caps", async () => {
    const H = (await newCompany(t.db, (await newUser(t.db)).id)).companyId;
    await setAiCompanyCaps(t.db, H, { daily: { requests: 1 } });
    const { kernel, seen, credentials } = boot();
    await credentials.set(H, "alpha", "tenant-own-key-123456", "owner-3");
    for (let i = 0; i < 3; i++) expect((await call(kernel, H)).source).toBe("tenant");
    expect(seen.every((s) => s.apiKey === "tenant-own-key-123456")).toBe(true);
    expect((await kernel.getUsageSummary(H)).totals.day.requests).toBe(0);
    expect((await createD1AiStores(t.db).usage.list(H, { limit: 5 })).every((r) => r.byok)).toBe(true);
  });
  it("the operator can switch a provider off for everyone without a deploy, and back on", async () => {
    const J = (await newCompany(t.db, (await newUser(t.db)).id)).companyId;
    const { kernel } = boot();
    await setAiProviderStatus(t.db, "alpha", "disabled", "admin-1");
    await expect(call(kernel, J)).rejects.toMatchObject({ code: "no_route" });
    await setAiProviderStatus(t.db, "alpha", "active", "admin-1");
    await expect(call(kernel, J)).resolves.toMatchObject({ provider: "alpha" });
  });
  it("a new active prompt version takes effect and the old one can be rolled back to", async () => {
    const K = (await newCompany(t.db, (await newUser(t.db)).id)).companyId;
    const { kernel, seen } = boot();
    await addAiPromptVersion(t.db, { id: "e2e.caption", version: 2, owner: "growth", task: "draft", template: "V2 caption for {{topic}}", variables: [{ name: "topic" }] }, "admin-1");
    expect((await call(kernel, K)).promptVersion).toBe(2);
    expect(seen.at(-1)!.req.messages[0]!.content).toBe("V2 caption for shoes");
    const { activateAiPromptVersion } = await import("@/platform/db");
    await activateAiPromptVersion(t.db, "e2e.caption", 1, "admin-1");
    expect((await call(kernel, K)).promptVersion).toBe(1);
  });
  it("structured output works end to end", async () => {
    const L = (await newCompany(t.db, (await newUser(t.db)).id)).companyId;
    const { kernel } = boot([() => ok("nope"), () => ok('{"title":"ok"}')]);
    const r = await kernel.generate({ ctx: ctxFor(L), task: "draft", input: { prompt: { id: "e2e.caption", vars: { topic: "x" } } }, schema: z.object({ title: z.string() }) });
    expect(r.data).toEqual({ title: "ok" });
  });
});

describe("registration with the Cloudflare D1 binding", () => {
  const saved = { ...process.env };
  afterEach(() => { process.env = { ...saved }; });

  it("lazy stores resolve the binding per call and talk to D1", async () => {
    const lazy = createLazyD1AiStores(async () => t.db);
    const M = (await newCompany(t.db, (await newUser(t.db)).id)).companyId;
    await lazy.credentials.put(cred(M, { provider: "openrouter" }));
    expect((await createD1AiStores(t.db).credentials.list(M)).map((c) => c.provider)).toEqual(["openrouter"]);
    expect(await lazy.caps(M)).toEqual({ daily: {}, monthly: {} });
  });
  it("without a D1 binding: local and test fall back to memory, production fails closed", async () => {
    const down = async (): Promise<never> => { throw new Error("no binding"); };
    process.env.APP_ENV = "test";
    const dev = createLazyD1AiStores(down);
    await dev.credentials.put(cred("t-dev"));
    expect((await dev.credentials.list("t-dev")).length).toBe(1);
    expect(await dev.catalog.models()).toEqual([]);
    process.env.APP_ENV = "production";
    const prod = createLazyD1AiStores(down);
    await expect(prod.credentials.list("t1")).rejects.toMatchObject({ name: "AiConfigError" });
    await expect(prod.caps("t1")).rejects.toMatchObject({ name: "AiConfigError" });
    await expect(prod.usage.counters("t1", windowKeys(Date.now()))).rejects.toMatchObject({ name: "AiConfigError" });
  });
  it("registerAiPersistence makes getAiKernel work in production on D1 (no longer fail-closed)", async () => {
    process.env.APP_ENV = "production";
    process.env.FIELD_ENCRYPTION_KEYS = JSON.stringify({ k1: Buffer.from(new Uint8Array(32).fill(3)).toString("base64url") });
    registerAiPersistence(async () => t.db);
    registerAiPersistence(async () => { throw new Error("second registration must be ignored"); });
    const kernel = getAiKernel();
    const N = (await newCompany(t.db, (await newUser(t.db)).id)).companyId;
    await kernel.credentials.set(N, "anthropic", "sk-ant-live-abcdef123456", "owner-9");
    expect((await createD1AiStores(t.db).credentials.get(N, "anthropic"))!.last4).toBe("3456");
    await kernel.saveSettings(N, { limits: { daily: { requests: 4 } } }, "owner-9");
    expect((await createD1AiStores(t.db).settings.get(N))!.limits.daily.requests).toBe(4);
    await kernel.ready(); // loads the (empty) shared catalog from D1 without error
    expect(kernel.models.list().some((m) => m.id === "anthropic:claude-haiku-5-5")).toBe(true);
    expect(await actions(N)).toEqual(["ai.credential.set", "ai.settings.updated"]);
    expect(kernel.providers.get("mock")).toBeNull(); // production has no mock provider
  });
});
