import { z } from "zod";
import { getAiConfig } from "@/platform/ai-kernel/config";
import { createCredentialService } from "@/platform/ai-kernel/credentials";
import { ProviderError } from "@/platform/ai-kernel/errors";
import { createAiKernel } from "@/platform/ai-kernel/kernel";
import { createMemoryAiStores } from "@/platform/ai-kernel/memory";
import { createModelRegistry } from "@/platform/ai-kernel/registry/models";
import { createPromptRegistry } from "@/platform/ai-kernel/registry/prompts";
import { createProviderRegistry } from "@/platform/ai-kernel/registry/providers";
import { createSecretBox } from "@/platform/ai-kernel/secrets";
import type { AdapterRequest, AdapterResponse, ModelDef, ProviderAdapter, ProviderDef } from "@/platform/ai-kernel/types";
import { createEmployeeFramework, createEmployeeRegistry, createMemoryEmployeeStores, type Actor, type EmployeeEvent, type EmployeeStores } from "@/platform/ai-employees";

export type Step = AdapterResponse | ProviderError | ((req: AdapterRequest) => AdapterResponse);
export const reply = (o: { reply?: string; actions?: { capability: string; input?: object; rationale?: string }[]; memory?: { kind: "fact" | "note"; content: string }[] } = {}, i = 200, out = 80): AdapterResponse =>
  ({ text: JSON.stringify({ reply: o.reply ?? "done", actions: o.actions ?? [], memory: o.memory ?? [] }), inputTokens: i, outputTokens: out });

const def = (id: string): ProviderDef => ({ id, label: id, protocol: "mock", baseUrl: `mock://${id}`, envKey: `TEST_${id.toUpperCase()}_KEY`, maxTokensParam: "max_tokens", jsonMode: true, status: "active" });
const model = (provider: string, p: Partial<ModelDef> = {}): ModelDef => ({ id: `${provider}:m`, provider, ref: "m", label: provider, capabilities: ["text", "structured"], contextWindow: 100_000, maxOutputTokens: 4096, pricing: { inputPerMTokMicros: 1_000_000, outputPerMTokMicros: 2_000_000 }, latency: "fast", quality: "standard", status: "active", ...p });

export function script(steps: Step[], repeat?: Step) {
  const seen: AdapterRequest[] = [];
  const adapter = (id: string): ProviderAdapter => ({ id, async generate(req) {
    seen.push(req);
    const s = steps.shift() ?? repeat;
    if (!s) throw new ProviderError("unavailable", "script exhausted");
    if (s instanceof ProviderError) throw s;
    return typeof s === "function" ? s(req) : s;
  } });
  return { seen, adapter };
}

export const OWNER: Actor = { tenantId: "t1", userId: "u-owner", role: "owner" };
export const MANAGER: Actor = { tenantId: "t1", userId: "u-mgr", role: "manager" };
export const MARKETING: Actor = { tenantId: "t1", userId: "u-mkt", role: "marketing" };
export const SUPPORT: Actor = { tenantId: "t1", userId: "u-sup", role: "support" };
export const GUEST: Actor = { tenantId: "t1", userId: "u-guest", role: "guest" };
export const OTHER_TENANT: Actor = { tenantId: "t2", userId: "u-other", role: "owner" };

export function setup(o: { alpha?: Step[]; beta?: Step[]; alphaRepeat?: Step; stores?: EmployeeStores; actors?: Record<string, "drop" | string>; limits?: Parameters<typeof createEmployeeFramework>[0]["limits"] } = {}) {
  process.env.TEST_ALPHA_KEY = "platform-alpha-key"; process.env.TEST_BETA_KEY = "platform-beta-key";
  const alpha = script(o.alpha ?? [], o.alphaRepeat);
  const beta = script(o.beta ?? []);
  const providers = createProviderRegistry({ includeMock: false, defs: [] });
  providers.register(def("alpha"), alpha.adapter("alpha"));
  providers.register(def("beta"), beta.adapter("beta"));
  const models = createModelRegistry([model("alpha"), model("beta", { quality: "economy" })]);
  const aiStores = createMemoryAiStores();
  let clock = Date.UTC(2026, 5, 15, 12);
  const tick = (ms: number) => { clock += ms; };
  const config = { ...getAiConfig(), retry: { maxAttemptsPerModel: 1, baseDelayMs: 1, maxDelayMs: 2 }, defaultCaps: { daily: {}, monthly: {} } };
  const kernel = createAiKernel({
    config, providers, models, prompts: createPromptRegistry(), settings: aiStores.settings, usage: aiStores.usage,
    credentials: createCredentialService({ store: aiStores.credentials, box: createSecretBox({ activeKeyId: "k", keys: { k: new Uint8Array(32).fill(9) } }), providers }),
    fetch, now: () => clock, sleep: async () => undefined, random: () => 1,
  });
  const stores = o.stores ?? createMemoryEmployeeStores();
  const audit: { tenantId: string; action: string; actorId?: string }[] = [];
  if (!o.stores) { // the D1 integration tests keep the real audit sink and company profiles
    stores.audit = { async record(tenantId, e) { audit.push({ tenantId, action: e.action, actorId: e.actorId }); } };
    stores.profiles = { async get(t) { return { name: t === "t1" ? "Acme Co" : "Other Co" }; } };
  }
  if (o.actors) { const dir = o.actors; stores.actors = { async roleOf(_t, userId, _snapshot) { const r = dir[userId]; return r === "drop" ? null : ((r as never) ?? null); } }; }
  const registry = createEmployeeRegistry();
  const events: EmployeeEvent[] = [];
  const handled: { key: string; input: unknown; ctx: unknown }[] = [];
  const handler = (key: string) => async (ctx: unknown, input: unknown) => { handled.push({ key, input, ctx }); return { ok: true, key }; };
  registry.defineCapability({ key: "crm.note", description: "Add a note to a contact.", risk: "draft", roles: ["owner", "ceo", "administrator", "manager", "marketing", "sales", "support"], input: z.object({ contact: z.string(), text: z.string().max(200) }), handler: handler("crm.note") });
  registry.defineCapability({ key: "social.publish", description: "Publish a post.", risk: "external", roles: ["owner", "ceo", "administrator", "manager", "marketing"], input: z.object({ text: z.string() }), handler: handler("social.publish") });
  registry.defineCapability({ key: "billing.refund", description: "Refund an invoice.", risk: "financial", roles: ["owner", "finance"], input: z.object({ invoice: z.string() }), handler: handler("billing.refund") });
  registry.defineCapability({ key: "crm.delete", description: "Delete a contact.", risk: "irreversible", roles: ["owner", "administrator"], input: z.object({ id: z.string() }), handler: async () => { throw new Error("boom"); } });
  const fw = createEmployeeFramework({ stores, registry, kernel: () => kernel, devLike: true, now: () => clock, onEvent: (e) => events.push(e), limits: o.limits });
  return { fw, kernel, stores, alpha, beta, audit, events, handled, tick, aiStores, registry, now: () => clock };
}
export type Env = ReturnType<typeof setup>;

export async function hire(env: Env, over: Record<string, unknown> = {}, actor: Actor = OWNER) {
  return env.fw.employees.hire(actor, { blueprint: "custom", name: `Employee ${Math.random().toString(36).slice(2, 7)}`, goal: "Help the team", capabilities: ["crm.note"], autonomy: 3, ...over } as never);
}
