import { readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import type { Role } from "@/config/roles";
import { BUSINESS_PROFILE_DICTIONARIES, DNA_ITEMS, PROFILE_ITEMS, createBusinessProfileService, createMemoryBusinessProfileStore, knowledge, requirements, type Actor, type Basics } from "@/platform/business-profile";
import { getAuthConfig } from "@/platform/auth/config";
import { setup, GOOD, meta } from "../auth/helpers";

const actor = (role: Role, tenantId = "t1"): Actor => ({ tenantId, userId: `${role}-1`, role });
const OWNER = actor("owner"), SALES = actor("sales"), SUPPORT = actor("support"), OTHER = actor("owner", "t2");
const code = async (p: Promise<unknown>) => { try { await p; return "ok"; } catch (e) { return (e as { code?: string }).code ?? `other:${(e as Error).message}`; } };
function harness() {
  const companies = new Map<string, Basics>(), calls: string[] = [];
  const seed = (t: string) => companies.set(t, { name: "Ana's workspace", industry: null, country: null, locale: "en", currency: "USD", timezone: "UTC" });
  seed("t1"); seed("t2"); let n = 0;
  const events: string[] = [];
  const svc = createBusinessProfileService({
    store: createMemoryBusinessProfileStore(), now: () => 1_000 + ++n,
    ports: { async basics(t) { return companies.get(t) ?? null; }, async updateBasics(t, p) { calls.push(t); companies.set(t, { ...(companies.get(t) as Basics), ...p }); } },
    activity: { async record(_c, e) { events.push(e.action); return { ok: false, error: { code: "x", message: "captured" } }; }, async recordStrict() { throw new Error("x"); } },
  });
  return { svc, companies, calls, events };
}
const ALL = { name: "Jeffrey Real Estate", industry: "real_estate", country: "CR", locale: "es", currency: "CRC", timezone: "America/Costa_Rica", website: "https://example-co.cr", logoUrl: "https://example-co.cr/logo.png", email: "hola@example-co.cr", phone: "+506 8888 8888", location: "Escazú, San José", socials: { facebook: "https://facebook.com/x" } };
const FULL_DNA = { objectives: ["Captar 10 propiedades"], valueProposition: "Asesoría cercana", customerType: "Familias", tone: "cercano", industries: ["bienes raíces"], products: ["Casas"], services: ["Venta"], competitors: ["Otra inmobiliaria"], keywords: ["casas escazú"], priorities: ["sales", "acquisition"] };

describe("completeness (computed, never stored)", () => {
  it("an empty company is 0% and everything is pending, profile first then DNA", () => {
    const k = knowledge({ name: "Ana's workspace", industry: null, country: null, locale: "en", currency: "USD", timezone: "UTC" }, null, null);
    expect(k).toMatchObject({ profilePct: 0, dnaPct: 0, basicsConfirmed: false, hasAnyData: false }); expect(k.pending).toHaveLength(PROFILE_ITEMS.length + DNA_ITEMS.length); expect(k.pending[0]).toBe("profile.name"); expect(k.pending.at(-1)).toBe("dna.priorities");
  });
  it("default name, language, currency and time zone do not count until the person confirms them", async () => {
    const h = harness(); await h.svc.saveProfile(OWNER, { website: "https://a.co" });
    const k = await h.svc.state(OWNER); expect(k.profile).toMatchObject({ website: true, name: false, locale: false, currency: false, timezone: false }); expect(k.profilePct).toBe(Math.round((1 / 11) * 100));
    await h.svc.saveProfile(OWNER, { name: "NOVA", locale: "es", currency: "CRC", timezone: "America/Costa_Rica" }); expect((await h.svc.state(OWNER)).profile).toMatchObject({ name: true, locale: true, currency: true, timezone: true });
  });
  it("a complete company is 100% / 100% with nothing pending", async () => {
    const h = harness(); await h.svc.saveProfile(OWNER, ALL); await h.svc.saveDna(OWNER, FULL_DNA);
    expect(await h.svc.state(OWNER)).toMatchObject({ profilePct: 100, dnaPct: 100, pending: [], industry: "real_estate", priorities: ["sales", "acquisition"] });
  });
  it("a partial company shows exactly what is missing (e.g. logo, social networks, competitors, products)", async () => {
    const h = harness(); const { logoUrl, socials, ...rest } = ALL; void logoUrl; void socials; await h.svc.saveProfile(OWNER, rest); const { competitors, products, ...dna } = FULL_DNA; void competitors; void products; await h.svc.saveDna(OWNER, dna);
    const k = await h.svc.state(OWNER); expect(k.pending).toEqual(["profile.logo", "profile.socials", "dna.products", "dna.competitors"]); expect(k.profilePct).toBe(82); expect(k.dnaPct).toBe(80);
  });
  it("requirements() says exactly what is missing and never invents it", () => {
    expect(requirements(null, ["dna.tone", "profile.website"])).toEqual({ ready: false, missing: ["dna.tone", "profile.website"] });
    const k = knowledge(null, null, null); expect(requirements(k, [])).toEqual({ ready: true, missing: [] }); expect(requirements(k, ["dna.keywords"]).missing).toEqual(["dna.keywords"]);
  });
});

describe("the service", () => {
  it("stores the basics in the company record (one source of truth) and the rest in the profile", async () => {
    const h = harness(); await h.svc.saveProfile(OWNER, ALL); const p = await h.svc.profile(OWNER);
    expect(h.companies.get("t1")).toMatchObject({ name: "Jeffrey Real Estate", industry: "real_estate", country: "CR", locale: "es", currency: "CRC", timezone: "America/Costa_Rica" }); expect(h.calls).toEqual(["t1"]);
    expect(p).toMatchObject({ website: ALL.website, email: ALL.email, location: ALL.location, basicsConfirmed: true }); expect(p.socials).toEqual({ facebook: "https://facebook.com/x" });
  });
  it("saving a part never wipes the rest, and a social network can be removed", async () => {
    const h = harness(); await h.svc.saveProfile(OWNER, ALL); await h.svc.saveProfile(OWNER, { phone: "+506 2222 2222", socials: { instagram: "@x" } });
    let p = await h.svc.profile(OWNER); expect(p).toMatchObject({ website: ALL.website, phone: "+506 2222 2222" }); expect(p.socials).toEqual({ facebook: "https://facebook.com/x", instagram: "@x" });
    await h.svc.saveProfile(OWNER, { socials: { facebook: "" } }); p = await h.svc.profile(OWNER); expect(p.socials).toEqual({ instagram: "@x" });
    await h.svc.saveDna(OWNER, FULL_DNA); await h.svc.saveDna(OWNER, { tone: "formal" }); expect(await h.svc.dna(OWNER)).toMatchObject({ tone: "formal", valueProposition: "Asesoría cercana", keywords: ["casas escazú"] });
  });
  it("validates every boundary", async () => {
    const h = harness();
    for (const bad of [{ email: "nope" }, { website: "javascript:alert(1)" }, { logoUrl: "ftp://x.co/a.png" }, { timezone: "Mars/Base" }, { currency: "usd" }, { locale: "xx" }, { phone: "abc" }, { unknown: 1 }, { socials: { myspace: "x" } }]) expect(await code(h.svc.saveProfile(OWNER, bad)), JSON.stringify(bad)).toBe("validation_failed");
    expect(await code(h.svc.saveDna(OWNER, { priorities: ["world_domination"] }))).toBe("validation_failed"); expect(await code(h.svc.saveDna(OWNER, { keywords: Array.from({ length: 41 }, (_, i) => `k${i}`) }))).toBe("validation_failed");
    expect((await h.svc.saveDna(OWNER, { keywords: ["a", "a", " b "] })).keywords).toEqual(["a", "b"]);
  });
  it("is isolated by company: nobody reads or writes another company's data", async () => {
    const h = harness(); await h.svc.saveProfile(OWNER, ALL); await h.svc.saveDna(OWNER, FULL_DNA);
    expect((await h.svc.state(OTHER))).toMatchObject({ profilePct: 0, dnaPct: 0, hasAnyData: false }); expect(await h.svc.dna(OTHER)).toMatchObject({ valueProposition: "", keywords: [] }); expect((await h.svc.profile(OTHER)).website).toBe("");
    await h.svc.saveProfile(OTHER, { website: "https://other.co" }); expect((await h.svc.profile(OWNER)).website).toBe(ALL.website); expect(h.companies.get("t2")?.name).toBe("Ana's workspace");
  });
  it("respects roles: viewers read, managers write, others nothing", async () => {
    const h = harness(); expect(await code(h.svc.state(SALES))).toBe("ok"); expect(await code(h.svc.saveProfile(SALES, { phone: "+506 1111 1111" }))).toBe("forbidden"); expect(await code(h.svc.saveDna(SALES, { tone: "x" }))).toBe("forbidden");
    expect(await code(h.svc.state(SUPPORT))).toBe("forbidden"); expect(await code(h.svc.saveDna(actor("marketing"), { tone: "x" }))).toBe("ok");
  });
  it("leaves evidence in the Activity Engine", async () => { const h = harness(); await h.svc.saveProfile(OWNER, { phone: "+506 1111 1111" }); await h.svc.saveDna(OWNER, { tone: "x" }); expect(h.events).toEqual(["business_profile.profile.updated", "business_profile.dna.updated"]); });
});

describe("company switching (Auth, additive)", () => {
  it("a session moves only between companies the person belongs to, and the ticket changes", async () => {
    const { svc, store, directory, registerVerified } = setup(); await registerVerified();
    const s = await svc.login({ email: "ana@example.com", password: GOOD }, meta), user = (await store.users.findByEmail("ana@example.com"))!, second = await directory.provisionOwner({ id: user.id, email: user.email, name: user.name });
    const r = await svc.switchTenant(s.token, second.tenantId); expect(r).toMatchObject({ tenantId: second.tenantId, role: "owner" }); expect((await svc.getSessionByToken(s.token))?.tenantId).toBe(second.tenantId);
    expect(await svc.switchTenant(s.token, "someone-elses-company")).toBeNull(); expect(await svc.switchTenant(undefined, second.tenantId)).toBeNull(); expect(await svc.switchTenant("garbage", second.tenantId)).toBeNull();
    expect(getAuthConfig()).toBeTruthy();
  });
});

describe("architecture and honesty", () => {
  const files = (d: string): string[] => readdirSync(d).flatMap((f) => { const p = join(d, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; });
  const BP = files("src/platform/business-profile"), strip = (s: string) => s.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");
  it("is generic: depends on no business module and no AI or network client", () => {
    const src = BP.map((f) => strip(readFileSync(f, "utf8"))).join("\n");
    expect(src).not.toMatch(/@\/modules\//); expect(src.toLowerCase()).not.toMatch(/real.?estate|\bseo\b|blueprint/); expect(src).not.toMatch(/\bfetch\(|ai-kernel|@anthropic|openai|gemini|twilio|stripe/i);
    expect(BP.some((f) => /cron|schedule/i.test(strip(readFileSync(f, "utf8"))))).toBe(false);
  });
  it("Spanish and English have the same keys and no empty text", () => { const { es, en } = BUSINESS_PROFILE_DICTIONARIES; expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort()); for (const k of Object.keys(es)) { expect(es[k as keyof typeof es], k).toBeTruthy(); expect(en[k as keyof typeof en], k).toBeTruthy(); } for (const i of PROFILE_ITEMS) expect(es[`profile.${i}` as keyof typeof es] ?? es[`profile.${i}` as keyof typeof es]).toBeTruthy(); for (const i of DNA_ITEMS) expect(es[`dna.${i}` as keyof typeof es]).toBeTruthy(); });
  it("Mission Control and the systems it shows contain no demo, example or fake content", () => {
    const dirs = ["src/modules/mission-control", "src/components/mission-control", "src/app/(app)/app/mission-control", "src/modules/realestate", "src/components/realestate", "src/components/business-profile", "src/platform/business-profile"];
    const hits = dirs.flatMap((d) => files(d)).flatMap((f) => [...strip(readFileSync(f, "utf8")).matchAll(/test company|sample property|fake buyer|mock activity|\bdemo (company|data|property|buyer)|empresa de (ejemplo|prueba)|datos de (ejemplo|demostración)/gi)].map((m) => `${f}: ${m[0]}`));
    expect(hits).toEqual([]);
  });
  it("the honest 'not enough information' sentence exists in both languages", () => { expect(BUSINESS_PROFILE_DICTIONARIES.es.insufficient).toBe("Todavía no hay suficiente información para generar recomendaciones."); expect(BUSINESS_PROFILE_DICTIONARIES.en.insufficient).toMatch(/not enough information/); });
});
