# ADR 028 – Real Estate AI Business System

**Estado:** aceptado.
**Decisión:** Foundation como módulo aislado `realestate`, tablas `re_*` con tenant primero, puertos a Team/Marketing solo en `server.ts`. El Blueprint real_estate sube a 1.1.0 (cambio aditivo en `catalog.ts`).
**Honestidad:** matching por reglas, KPIs solo de hechos, publicaciones nunca automáticas, integraciones declaradas sin conectar.
**Cambios fuera del módulo (aditivos):** roster/entitlements/i18n de Team (+6 empleados), `config/modules.ts`, `plans.ts` STARTER, tarjeta en layout de Mission Control, conteos de tests.
**¿Escala a 10.000 empresas?** Sí: todo tenant-scoped con índices tenant-first, sin estado global, matching calculado por petición sobre datos del tenant; el `Matcher` se puede sustituir por un servicio indexado sin rediseño.
