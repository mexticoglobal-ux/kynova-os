# 36 – Real Estate AI Business System (V1 · Foundation)

Se instala solo al elegir el Blueprint **Inmobiliaria** (v1.1.0). Módulo `realestate`, API `/api/v1/realestate`.

## Alcance (Entrega 11 = Foundation)
- Equipo de 11 AI Employees (Document Manager: "próximamente").
- Propiedades (venta/alquiler/reservada/vendida, archivar), captación de propietarios con próxima acción, compradores (intereses, presupuesto, zonas).
- Matching por reglas (`rulesMatcher`, puntaje mínimo 60). Firma `Matcher` intercambiable; sin IA.
- Publicaciones (Facebook, Instagram, LinkedIn, WhatsApp, Email): briefs desde datos reales; siempre aprobación humana. Aprobar en FB/IG/LinkedIn crea un borrador en Marketing; WhatsApp/Email quedan "preparadas". Nada se publica.
- Agenda: visitas, open house, llamadas, seguimientos, recordatorios.
- KPIs solo desde hechos registrados (null sin datos). Conversión = compradores ganados / compradores; Ingresos = comisiones cerradas; Comisiones esperadas = reservadas.
- Digest "Mientras estabas fuera..." en Mission Control (solo datos reales).
- Integraciones (MLS, Google Maps, WhatsApp, Google Calendar, email): solo arquitectura, estado "Disponible próximamente".
- Bootstrap: captación, contenido, SEO, Google Business, redes; sin anuncios pagados.

## Fases
11 Foundation · 12 Automation (seguimientos, matching inteligente, campañas, WhatsApp, emails) · 13 Intelligence (IA real, predicción, valoración, forecast).

## Reutilización
Patrón de sistema: `SystemDef` en el catálogo de Blueprints + módulo con store/service/server + equipo declarado + digest. Otro sistema (YouTube, Ecommerce…) repite el patrón sin tocar el framework.

## Migración de instalaciones existentes
Empresas Inmobiliaria en 1.0.0 reciben el sistema con upgrade menor (aditivo, sin `confirm`).
