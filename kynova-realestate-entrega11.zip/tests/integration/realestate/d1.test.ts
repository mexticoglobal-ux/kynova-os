import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { COLUMNS, TABLE } from "../../../src/modules/realestate/columns";
import { createD1RealEstateStore } from "../../../src/modules/realestate/store-d1";
import type { RealEstateStore } from "../../../src/modules/realestate/store";
import { createRealEstateService, type Actor, type RealEstatePorts } from "../../../src/modules/realestate/service";
import { createTestDb, newCompany, newUser } from "../db/helpers";

let t: Awaited<ReturnType<typeof createTestDb>>;
let store: RealEstateStore;
const snake = (s: string) => s.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
const refused = async (p: Promise<unknown>) => { try { await p; return "no error"; } catch { return "refused"; } };
const code = async (p: Promise<unknown>) => { try { await p; return "ok"; } catch (e) { return (e as { code?: string }).code ?? "other"; } };
const fresh = async (): Promise<Actor> => { const u = await newUser(t.db), c = await newCompany(t.db, u.id); return { tenantId: c.companyId, userId: u.id, role: "owner" }; };
const drafts: unknown[] = [];
const ports: RealEstatePorts = { member: async (_a, key) => ({ key, name: key, entitled: true, active: true, activityKey: key }), async createDraft(_a, d) { drafts.push(d); return { id: `p${drafts.length}` }; } };
beforeAll(async () => { t = await createTestDb(); store = createD1RealEstateStore(t.d1); }, 60_000);
afterAll(async () => { await t.dispose(); });
const svcFor = () => createRealEstateService({ store, ports, newId: () => crypto.randomUUID().replace(/-/g, "") });

describe("schema contract", () => {
  it("every whitelisted column exists in the migration, and every column is whitelisted", async () => {
    for (const [kind, table] of Object.entries(TABLE)) {
      const info = (await t.d1.prepare(`PRAGMA table_info(${table})`).all<{ name: string }>()).results.map((c) => c.name).sort();
      expect(COLUMNS[kind as keyof typeof COLUMNS].map(snake).sort(), table).toEqual(info);
    }
  });
});
describe("the service on D1", () => {
  it("runs the whole flow: owner, property, buyer, match, visit, publication draft, closing, KPIs and digest", async () => {
    const A = await fresh(), svc = svcFor(), o = await svc.createOwner(A, { name: "Luis" });
    const p = await svc.createProperty(A, { title: "Casa", operation: "sale", priceMinor: 20_000_000, zone: "Escazú", bedrooms: 3, ownerId: o.id });
    const b = await svc.createBuyer(A, { name: "Ana", budgetMaxMinor: 25_000_000, zones: ["Escazú"] });
    expect((await svc.matchesOfBuyer(A, b.id)).map((m) => m.propertyId)).toEqual([p.id]);
    await svc.createActivity(A, { kind: "visit", title: "Visita", whenAt: Date.now() + 3600_000, propertyId: p.id, buyerId: b.id, ownerId: o.id });
    const [pub] = await svc.prepare(A, { propertyId: p.id, channels: ["instagram"] }); expect((await svc.decide(A, pub!.id, { approve: true })).outcome).toBe("draft_created");
    await svc.updateProperty(A, p.id, { status: "sold", closedPriceMinor: 19_000_000 });
    const k = await svc.kpis(A, { from: 0, to: Date.now() + 1000 }); expect(k).toMatchObject({ soldProperties: 1, incomeMinor: { USD: 570_000 } });
    expect((await svc.digest(A)).items.map((i) => i.key)).toContain("buyers_registered");
    expect(await code(svc.updateProperty(A, p.id, { status: "active" }))).toBe("invalid_state");
  });
  it("the database refuses what the service would never do", async () => {
    const A = await fresh(), B = await fresh(), svc = svcFor(), p = await svc.createProperty(A, { title: "Casa", operation: "sale", priceMinor: 1000 });
    const [pub] = await svc.prepare(A, { propertyId: p.id, channels: ["facebook"] }); await svc.decide(A, pub!.id, { approve: false });
    expect(await refused(t.d1.prepare("DELETE FROM re_properties WHERE id = ?").bind(p.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE re_properties SET tenant_id = ? WHERE id = ?").bind(B.tenantId, p.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE re_properties SET status = 'sold' WHERE id = ?").bind(p.id).run())).toBe("refused"); // sold without a closing date
    expect(await refused(t.d1.prepare("UPDATE re_publications SET status = 'approved' WHERE id = ?").bind(pub!.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE re_publications SET channel = 'email' WHERE id = ?").bind(pub!.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("INSERT INTO re_buyers (id, tenant_id, name, budget_min_minor, budget_max_minor, created_by, created_at, updated_at) VALUES ('b1', ?, 'x', 100, 50, 'u', 1, 1)").bind(A.tenantId).run())).toBe("refused");
    expect(await refused(t.d1.prepare("INSERT INTO re_properties (id, tenant_id, title, operation, price_minor, owner_id, listed_at, created_by, created_at, updated_at) VALUES ('p9', ?, 'x', 'sale', 1, 'ghost', 1, 'u', 1, 1)").bind(A.tenantId).run())).toBe("refused"); // owner must exist
  });
  it("companies never see each other's data", async () => {
    const A = await fresh(), B = await fresh(), svc = svcFor(); await svc.createProperty(A, { title: "Casa", operation: "sale", priceMinor: 1000 });
    expect(await svc.listProperties(B)).toEqual([]); expect((await svc.overview(B)).state).toBe("empty");
  });
});
