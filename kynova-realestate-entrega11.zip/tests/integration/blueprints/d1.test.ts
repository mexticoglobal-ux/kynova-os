import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { COLUMNS, TABLE } from "../../../src/modules/blueprints/columns";
import { createD1BlueprintsStore } from "../../../src/modules/blueprints/store-d1";
import type { BlueprintsStore } from "../../../src/modules/blueprints/store";
import { createBlueprintsService, type Actor, type BlueprintsPorts } from "../../../src/modules/blueprints/service";
import { createTestDb, newCompany, newUser } from "../db/helpers";

let t: Awaited<ReturnType<typeof createTestDb>>;
let store: BlueprintsStore;
const snake = (s: string) => s.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
const refused = async (p: Promise<unknown>) => { try { await p; return "no error"; } catch { return "refused"; } };
const code = async (p: Promise<unknown>) => { try { await p; return "ok"; } catch (e) { return (e as { code?: string }).code ?? "other"; } };
const fresh = async (): Promise<Actor> => { const u = await newUser(t.db), c = await newCompany(t.db, u.id); return { tenantId: c.companyId, userId: u.id, role: "owner" }; };
let n = 0;
const ports: BlueprintsPorts = {
  activate: async () => "applied", enableSkill: async () => {}, createObjective: async () => ({ id: `o${++n}` }), createAgenda: async () => ({ id: `a${++n}` }), growthPlan: async () => {},
  plan: async () => "business", activeEmployees: async () => [], employeeName: (k) => k,
};
beforeAll(async () => { t = await createTestDb(); store = createD1BlueprintsStore(t.d1); }, 60_000);
afterAll(async () => { await t.dispose(); });
const svcFor = () => createBlueprintsService({ store, ports, newId: () => crypto.randomUUID().replace(/-/g, "") });

describe("schema contract", () => {
  it("every whitelisted column exists in the migration, and every column is whitelisted", async () => {
    for (const [kind, table] of Object.entries(TABLE)) {
      const info = (await t.d1.prepare(`PRAGMA table_info(${table})`).all<{ name: string }>()).results.map((c) => c.name).sort();
      expect(COLUMNS[kind as keyof typeof COLUMNS].map(snake).sort(), table).toEqual(info);
    }
  });
});
describe("the service on D1", () => {
  it("installs once per company, keeps the applied list as JSON and reads it back", async () => {
    const A = await fresh(), svc = svcFor();
    const cur = (await svc.install(A, { blueprintId: "real_estate", bootstrap: true, locale: "es" }))!;
    expect(cur.version).toBe("1.1.0"); expect(cur.items.length).toBeGreaterThan(20); expect(cur.bootstrap).toBe(true);
    expect(await code(svc.install(A, { blueprintId: "clinic" }))).toBe("conflict");
    expect((await svc.current(A))?.items.length).toBe(cur.items.length);
  });
  it("the database refuses what the service would never do", async () => {
    const A = await fresh(), B = await fresh(), svc = svcFor(); await svc.install(A, { blueprintId: "restaurant" });
    const row = await t.d1.prepare("SELECT id FROM bp_installs WHERE tenant_id = ?").bind(A.tenantId).first<{ id: string }>();
    expect(await refused(t.d1.prepare("DELETE FROM bp_installs WHERE id = ?").bind(row!.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE bp_installs SET blueprint_id = 'clinic' WHERE id = ?").bind(row!.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE bp_installs SET tenant_id = ? WHERE id = ?").bind(B.tenantId, row!.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE bp_installs SET version = 'x' WHERE id = ?").bind(row!.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("INSERT INTO bp_installs (id, tenant_id, blueprint_id, version, installed_by, created_at, updated_at) VALUES ('dup', ?, 'clinic', '1.0.0', 'u', 1, 1)").bind(A.tenantId).run())).toBe("refused");
  });
  it("companies never see each other's install", async () => {
    const A = await fresh(), B = await fresh(), svc = svcFor(); await svc.install(A, { blueprintId: "restaurant" });
    expect(await svc.current(B)).toBeNull();
  });
});
