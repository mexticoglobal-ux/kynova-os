import { describe, expect, it } from "vitest";
import { computeKpis, matchesForBuyer, rulesMatcher } from "../../../src/modules/realestate/engine";
import { REAL_ESTATE_TEAM } from "../../../src/modules/realestate/team";
import { DAY, FINANCE, OTHER, OWNER, SALES, SUPPORT, code, harness, house } from "./helpers";

describe("team", () => {
  it("has the eleven requested roles; the Document Manager is honestly 'soon'", () => {
    expect(REAL_ESTATE_TEAM.map((m) => m.key)).toEqual(["real_estate_director", "property_manager", "listing_manager", "buyer_specialist", "seller_specialist", "marketing_manager", "crm_manager", "follow_up_manager", "appointment_manager", "document_manager", "analytics_manager"]);
    expect(REAL_ESTATE_TEAM.filter((m) => m.soon).map((m) => m.key)).toEqual(["document_manager"]);
  });
});
describe("properties", () => {
  it("registers, edits and archives; sold/rented need the real closing price and the matching operation", async () => {
    const h = harness(), p = await h.svc.createProperty(OWNER, house());
    expect(p.status).toBe("active"); expect((await h.svc.updateProperty(OWNER, p.id, { priceMinor: 24_000_000 })).priceMinor).toBe(24_000_000);
    expect(await code(h.svc.updateProperty(OWNER, p.id, { status: "sold" }))).toBe("validation_failed"); // no closing price
    expect(await code(h.svc.updateProperty(OWNER, p.id, { status: "rented", closedPriceMinor: 1 }))).toBe("invalid_state"); // a sale cannot be rented
    h.clock.t += 40 * DAY;
    const sold = await h.svc.updateProperty(OWNER, p.id, { status: "sold", closedPriceMinor: 23_000_000 });
    expect(sold).toMatchObject({ status: "sold", closedPriceMinor: 23_000_000, commissionMinor: 690_000 }); // 3% default
    expect(await code(h.svc.updateProperty(OWNER, p.id, { status: "active" }))).toBe("invalid_state");
    expect((await h.svc.updateProperty(OWNER, p.id, { status: "archived" })).status).toBe("archived");
  });
  it("a PATCH never overwrites fields it did not send (properties and owners)", async () => {
    const h = harness(), p = await h.svc.createProperty(OWNER, house({ description: "Vista", bedrooms: 4 })), o = await h.svc.createOwner(OWNER, { name: "Luis", phone: "88", notes: "n" });
    expect(await h.svc.updateProperty(OWNER, p.id, { priceMinor: 1 })).toMatchObject({ zone: "Escazú", bedrooms: 4, description: "Vista", commissionBp: 300 });
    expect(await h.svc.updateOwner(OWNER, o.id, { stage: "contacted" })).toMatchObject({ phone: "88", notes: "n", name: "Luis" });
  });
  it("archive is reversible for an open property", async () => {
    const h = harness(), p = await h.svc.createProperty(OWNER, house());
    await h.svc.updateProperty(OWNER, p.id, { status: "archived" }); expect((await h.svc.updateProperty(OWNER, p.id, { status: "active" })).status).toBe("active");
  });
  it("rejects a missing owner and keeps companies apart", async () => {
    const h = harness(); expect(await code(h.svc.createProperty(OWNER, house({ ownerId: "nope" })))).toBe("not_found");
    const p = await h.svc.createProperty(OWNER, house()); expect(await code(h.svc.getProperty(OTHER, p.id))).toBe("not_found"); expect(await h.svc.listProperties(OTHER)).toEqual([]);
  });
});
describe("access", () => {
  it("sales manages but cannot approve; finance only reads; support is out", async () => {
    const h = harness(); await h.svc.createProperty(SALES, house());
    expect(await code(h.svc.decide(SALES, "x", { approve: true }))).toBe("forbidden"); expect(await code(h.svc.createProperty(FINANCE, house()))).toBe("forbidden");
    expect((await h.svc.kpis(FINANCE)).activeProperties).toBe(1); expect(await code(h.svc.overview(SUPPORT))).toBe("forbidden");
  });
});
describe("matching (rules, no AI)", () => {
  it("needs the same operation, currency and a price inside the budget; scores zone, kind and bedrooms", async () => {
    const h = harness(), p = await h.svc.createProperty(OWNER, house());
    const ok = await h.svc.createBuyer(OWNER, { name: "Ana", intent: "sale", budgetMaxMinor: 30_000_000, zones: ["escazú"], kinds: ["house"], bedroomsMin: 3 });
    const far = await h.svc.createBuyer(OWNER, { name: "Beto", intent: "sale", budgetMaxMinor: 10_000_000 }), rent = await h.svc.createBuyer(OWNER, { name: "Cleo", intent: "rent" }), zone = await h.svc.createBuyer(OWNER, { name: "Dan", zones: ["Heredia"] });
    expect((await h.svc.matchesOfBuyer(OWNER, ok.id))[0]).toMatchObject({ propertyId: p.id, score: 100, engine: "rules" });
    for (const b of [far, rent, zone]) expect(await h.svc.matchesOfBuyer(OWNER, b.id)).toEqual([]);
    expect((await h.svc.matchesOfProperty(OWNER, p.id)).map((m) => m.buyerId)).toEqual([ok.id]);
  });
  it("is a swappable function: a different matcher plugs into the same signature", async () => {
    const b = { id: "b", stage: "new", intent: "sale", currency: "USD", budgetMinMinor: 0, budgetMaxMinor: 0, zones: [], kinds: [], bedroomsMin: 0 } as never;
    expect(matchesForBuyer(b, [{ id: "p", status: "active", operation: "sale", currency: "USD", priceMinor: 1, zone: "", kind: "house", bedrooms: 0 } as never], () => null)).toEqual([]);
    expect(rulesMatcher).toBeTypeOf("function");
  });
});
describe("KPIs come only from recorded facts", () => {
  it("is empty and honest with no data, then counts sold, rented, days, clients, conversion and income", async () => {
    const h = harness(); expect(await h.svc.kpis(OWNER)).toMatchObject({ activeProperties: 0, avgDaysToSell: null, conversionPct: null, incomeMinor: {} });
    const s = await h.svc.createProperty(OWNER, house()), r = await h.svc.createProperty(OWNER, house({ title: "Apto", operation: "rent", priceMinor: 100_000 })), b = await h.svc.createBuyer(OWNER, { name: "Ana" }); await h.svc.createOwner(OWNER, { name: "Luis" });
    h.clock.t += 10 * DAY; await h.svc.updateProperty(OWNER, s.id, { status: "sold", closedPriceMinor: 20_000_000 }); await h.svc.updateProperty(OWNER, r.id, { status: "rented", closedPriceMinor: 100_000, commissionMinor: 100_000 }); await h.svc.updateBuyer(OWNER, b.id, { stage: "won" });
    expect(await h.svc.kpis(OWNER)).toMatchObject({ soldProperties: 1, rentedProperties: 1, avgDaysToSell: 10, avgDaysToRent: 10, newClients: 2, conversionPct: 100, incomeMinor: { USD: 700_000 } });
    expect(computeKpis([], [], [], 0, 1).newClients).toBe(0);
  });
});
describe("agenda", () => {
  it("schedules visits, open houses, calls and reminders linked to real records, and marks them done", async () => {
    const h = harness(), p = await h.svc.createProperty(OWNER, house());
    expect(await code(h.svc.createActivity(OWNER, { kind: "visit", title: "Visita", whenAt: h.clock.t + 1000, propertyId: "ghost" }))).toBe("not_found");
    const a = await h.svc.createActivity(OWNER, { kind: "visit", title: "Visita", whenAt: h.clock.t + 1000, propertyId: p.id }); expect((await h.svc.updateActivity(OWNER, a.id, { status: "done" })).status).toBe("done");
  });
});
describe("publications always need human approval", () => {
  it("prepares briefs from real facts (idempotent), social approval creates a Marketing DRAFT, whatsapp/email are only prepared, and rejecting creates nothing", async () => {
    const h = harness(), p = await h.svc.createProperty(OWNER, house());
    const first = await h.svc.prepare(OWNER, { propertyId: p.id, channels: ["facebook", "whatsapp", "email", "instagram"] }); expect(first).toHaveLength(4);
    expect((await h.svc.prepare(OWNER, { propertyId: p.id, channels: ["facebook"] })).map((x) => x.id)).toEqual([first[0]!.id]); expect(await h.svc.listPublications(OWNER)).toHaveLength(4);
    expect(first[0]!.body).toContain("Escazú"); expect(h.drafts).toHaveLength(0); // nothing before approval
    expect((await h.svc.decide(OWNER, first[0]!.id, { approve: true })).outcome).toBe("draft_created"); expect(h.drafts).toHaveLength(1);
    expect((await h.svc.decide(OWNER, first[1]!.id, { approve: true })).outcome).toBe("prepared"); expect(h.drafts).toHaveLength(1);
    expect((await h.svc.decide(OWNER, first[3]!.id, { approve: false })).status).toBe("rejected"); expect(h.drafts).toHaveLength(1);
    expect(await code(h.svc.decide(OWNER, first[0]!.id, { approve: false }))).toBe("invalid_state");
  });
  it("does not promote an archived property", async () => {
    const h = harness(), p = await h.svc.createProperty(OWNER, house()); await h.svc.updateProperty(OWNER, p.id, { status: "archived" });
    expect(await code(h.svc.prepare(OWNER, { propertyId: p.id, channels: ["facebook"] }))).toBe("invalid_state");
  });
});
describe("Mientras estabas fuera…", () => {
  it("is empty with no data and never invents a line", async () => { expect((await harness().svc.digest(OWNER)).items).toEqual([]); });
  it("reports only what the data shows, attributed to the right AI Employee", async () => {
    const h = harness(), p = await h.svc.createProperty(OWNER, house()); await h.svc.createBuyer(OWNER, { name: "Ana", budgetMaxMinor: 30_000_000, nextActionAt: h.clock.t - 1000 }); await h.svc.createBuyer(OWNER, { name: "Beto" }); await h.svc.createOwner(OWNER, { name: "Luis" });
    for (let i = 0; i < 3; i++) { const a = await h.svc.createActivity(OWNER, { kind: "visit", title: `v${i}`, whenAt: h.clock.t + 1000, propertyId: p.id }); await h.svc.updateActivity(OWNER, a.id, { status: "done" }); }
    await h.svc.createActivity(OWNER, { kind: "call", title: "Llamar", whenAt: h.clock.t + 3600_000 }); await h.svc.prepare(OWNER, { propertyId: p.id, channels: ["facebook"] });
    const by = Object.fromEntries((await h.svc.digest(OWNER)).items.map((i) => [i.key, i.count]));
    expect(by).toMatchObject({ buyers_registered: 2, owners_registered: 1, properties_with_potential: 1, clients_need_follow_up: 1, property_many_visits: 1, publication_ready: 1, appointments_soon: 1 });
    expect((await h.svc.digest(OWNER, { since: h.clock.t + 1 })).items.find((i) => i.key === "buyers_registered")).toBeUndefined();
  });
});
describe("overview and evidence", () => {
  it("states the Bootstrap focus without paid ads, integrations as coming soon and matching as rules", async () => {
    const o = await harness().svc.overview(OWNER);
    expect(o).toMatchObject({ state: "empty", paidAds: false, matching: { engine: "rules", ai: false } }); expect(o.focus).toEqual(["captation", "content", "seo", "google_business", "social"]);
    expect(o.integrations.map((i) => i.id)).toEqual(["mls", "google_maps", "whatsapp", "google_calendar", "email"]); expect(o.integrations.every((i) => i.status === "coming_soon")).toBe(true);
  });
  it("records evidence; the marketing preparation is attributed to the AI Employee in simulation, approvals to the person", async () => {
    const h = harness(), p = await h.svc.createProperty(OWNER, house()), [pub] = await h.svc.prepare(OWNER, { propertyId: p.id, channels: ["facebook"] }); await h.svc.decide(OWNER, pub!.id, { approve: true });
    expect(h.events.map((e) => e.action)).toEqual(["realestate.property.created", "realestate.publication.prepared", "realestate.publication.approved"]);
    expect(h.events[1]).toMatchObject({ actorKind: "employee", mode: "simulation" }); expect(h.events[2]).toMatchObject({ mode: "production" });
  });
});
