import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES, canAccess } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { COLUMNS, TABLE } from "../../../src/modules/ai-studio/columns";
import { POLICIES, can, mayApprove } from "../../../src/modules/ai-studio/access";
import { STUDIO_DICTIONARIES } from "../../../src/modules/ai-studio/i18n";
import { fromWire, queryObject, toWire } from "../../../src/modules/ai-studio/wire";
import { ARCHITECTURE_STATUS, notConnectedKnowledgeIndexer, notAvailableMarketplacePublisher, notConnectedToolExecutor, notConnectedWorkflowRunner } from "../../../src/modules/ai-studio/contracts";
import { TEMPLATES, templateByKey } from "../../../src/modules/ai-studio/templates";
import { DEPARTMENTS, KNOWLEDGE_TYPES, TOOL_KINDS, RISKS } from "../../../src/modules/ai-studio/domain";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => { try { return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; }); } catch { return []; } };
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "ai-studio");
const bad = (dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "ai-studio"), join(SRC, "app", "(app)", "app", "ai-studio")];
const strip = (s: string) => s.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");

describe("AI Studio module boundaries (docs/05 section 3)", () => {
  it("never touches Drizzle, the database internals, the kernel/employee internals, the dashboard or other product modules", () => {
    expect(bad([MOD], /drizzle-orm|platform\/db|ai-kernel\/|ai-employees\/|platform\/dashboard|components\/dashboard|modules\/(crm|marketing|seo)/)).toEqual([]);
  });
  it("reaches the platform only through public entry points", () => {
    const platform = new Set(files(MOD).flatMap((f) => imports(f).filter((i) => i.startsWith("@/platform"))));
    expect([...platform].filter((p) => !["@/platform/ai-kernel", "@/platform/ai-employees", "@/platform/auth/errors", "@/platform/auth/http", "@/platform/auth/session"].includes(p))).toEqual([]);
  });
  it("only the store layer knows SQL; no provider host appears; no code in the module performs network calls", () => {
    const sqlFiles = files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f));
    expect(sqlFiles).toEqual(["store-d1.ts"]);
    expect(files(MOD).filter((f) => /api\.openai\.com|api\.anthropic\.com|generativelanguage\.googleapis\.com/.test(readFileSync(f, "utf8")))).toEqual([]);
    expect(files(MOD).filter((f) => /(?<![.\w])fetch\(|XMLHttpRequest|new WebSocket|node:https?|node:net/.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
  });
  it("architecture-only parts are contracts that report 'not connected' and do nothing", async () => {
    expect(await notConnectedKnowledgeIndexer.ingest({} as never)).toMatchObject({ status: "failed" });
    expect(await notConnectedKnowledgeIndexer.search("t", "e", "q", 3)).toEqual([]);
    await expect(notConnectedToolExecutor.execute({} as never, {}, {} as never)).resolves.toMatchObject({ ok: false });
    await expect(notConnectedWorkflowRunner.start({} as never, {} as never)).rejects.toThrow(/not available/);
    expect(ARCHITECTURE_STATUS).toEqual({ knowledgeIndexing: "not_connected", toolExecution: "contract_only", workflowRuns: "prepared", marketplacePublishing: "not_available" });
    expect(notAvailableMarketplacePublisher).toBeDefined();
  });
  it("UI uses the module's public interface, never its stores or other product modules", () => {
    expect(bad(UI, /platform\/db|drizzle|modules\/ai-studio\/(store|columns|runtime|ai|catalog)|modules\/(crm|marketing|seo)|components\/(crm|marketing|seo)/)).toEqual([]);
  });
  it("platform, CRM, Marketing, SEO, Dashboard and Landing code do not know AI Studio (it joins through startup registration only)", () => {
    const frozen = ["platform/db", "platform/auth", "platform/ai-kernel", "platform/ai-employees", "platform/dashboard", "modules/crm", "modules/marketing", "modules/seo", "components/dashboard", "components/crm", "components/marketing", "components/seo", "components/landing", "app/(marketing)", "app/(app)/app/dashboard", "app/(app)/app/crm", "app/(app)/app/seo", "app/api/v1/crm", "app/api/v1/marketing", "app/api/v1/seo"].map((d) => join(SRC, d));
    expect(bad(frozen, /modules\/ai-studio|components\/ai-studio/)).toEqual([]);
    const startup = readFileSync(join(SRC, "instrumentation.ts"), "utf8");
    expect(startup).toContain("registerStudioWidget"); expect(startup).toContain("registerSeoWidget");
  });
  it("client components do not import server-only parts of the module", () => {
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThanOrEqual(8);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/ai-studio$|modules\/ai-studio\/(service|server|http|store|runtime|catalog|ai)/.test(i)))).toEqual([]);
  });
  it("does not add a product module: AI Studio uses the existing slug and roles", () => {
    expect(MODULES).toHaveLength(32);
    expect(MODULES.filter((m) => m.slug === "ai-studio")).toHaveLength(1);
    expect(readFileSync(join(MOD, "http.ts"), "utf8")).toContain('STUDIO_SLUG = "ai-studio"');
  });
});

describe("API surface: only /api/v1/ai-studio/*", () => {
  const API = join(SRC, "app", "api", "v1", "ai-studio");
  const routes = files(API).filter((f) => f.endsWith("route.ts"));
  it("every handler goes through studioRoute; every mutating verb enables CSRF checks", () => {
    expect(routes.length).toBeGreaterThanOrEqual(40);
    for (const f of routes) {
      const src = readFileSync(f, "utf8");
      for (const m of src.matchAll(/export const (GET|POST|PATCH|PUT|DELETE) = (\w+)/g)) {
        expect(m[2], `${relative(SRC, f)} ${m[1]}`).toBe("studioRoute");
        const decl = src.slice(src.indexOf(m[0])), next = decl.indexOf("\nexport const", 10), block = decl.slice(0, next === -1 ? decl.length : next);
        if (m[1] !== "GET") expect(block, `${relative(SRC, f)} ${m[1]}`).toContain("mutating: true"); else expect(block).not.toContain("mutating");
      }
    }
  });
  it("is the only API this module adds", () => {
    expect(files(join(SRC, "app", "api")).filter((f) => /modules\/ai-studio/.test(readFileSync(f, "utf8"))).filter((f) => !f.startsWith(API))).toEqual([]);
  });
});

describe("migration 0400_ai_studio.sql", () => {
  const sql = readFileSync(join(process.cwd(), "drizzle/migrations/0400_ai_studio.sql"), "utf8");
  const tables = [...sql.matchAll(/CREATE TABLE `(ais_\w+)` \(([\s\S]*?)\n\);/g)];
  it("is independent: it only creates ais_* objects and touches nothing else", () => {
    expect(tables).toHaveLength(11);
    expect(Object.values(TABLE).sort()).toEqual(tables.map((t) => t[1]).sort());
    expect(sql).not.toMatch(/ALTER TABLE|DROP |seo_|mkt_|crm_|INSERT |DELETE FROM/);
    for (const o of sql.matchAll(/CREATE (?:UNIQUE )?INDEX `(\w+)`/g)) expect(o[1]).toMatch(/^ais_/);
    for (const o of sql.matchAll(/CREATE TRIGGER (\w+)/g)) expect(o[1]).toMatch(/^ais_/);
  });
  it("every table is tenant-owned with cascade and tenant-first indexes", () => {
    for (const [, name, body] of tables) {
      expect(body, name).toContain("`tenant_id` text NOT NULL");
      expect(body, name).toContain("FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`)");
      for (const ix of sql.matchAll(new RegExp(`CREATE (?:UNIQUE )?INDEX \`\\w+\` ON \`${name}\` \\(([^)]*)\\)`, "g"))) expect(ix[1], name).toMatch(/^`tenant_id`/);
    }
  });
  it("immutability, append-only audit and tenant freezing are enforced by the database", () => {
    expect(sql).toContain("ais_activity_append_only"); expect(sql).toContain("ais_versions_immutable"); expect(sql).toContain("ais_prompt_versions_immutable");
    for (const t of Object.values(TABLE)) expect(sql, t).toContain(`${t}_tenant_frozen`);
    expect(sql).toMatch(/WHERE `deleted_at` IS NULL/);
  });
  it("whitelists cover each kind and carry the tenant column", () => {
    for (const k of Object.keys(TABLE) as (keyof typeof TABLE)[]) { expect(COLUMNS[k]).toContain("id"); expect(COLUMNS[k]).toContain("tenantId"); }
  });
});

describe("permissions", () => {
  it("module access is the outer gate; the policy table only narrows it", () => {
    for (const r of ROLES) {
      const levels = Object.values(POLICIES[r].levels);
      if (!canAccess(r, "ai-studio")) expect(levels.every((l) => l === "none"), r).toBe(true);
      else expect(levels.some((l) => l !== "none"), r).toBe(true);
    }
    expect(can("marketing", "employee", "write")).toBe(true); expect(can("marketing", "employee", "manage")).toBe(false); expect(can("marketing", "approval", "manage")).toBe(false);
    expect(can("manager", "employee", "manage")).toBe(true); expect(can("guest", "employee", "read")).toBe(false);
  });
  it("four-eyes approval rule", () => {
    expect(mayApprove("manager", "u1", "u1")).toBe(false); expect(mayApprove("manager", "u1", "u2")).toBe(true);
    expect(mayApprove("owner", "u1", "u1")).toBe(true); expect(mayApprove("marketing", "u1", "u2")).toBe(false);
  });
});

describe("templates are blueprints", () => {
  it("the eight required templates exist, bilingual, with no capability that can leave the company", () => {
    expect(TEMPLATES.map((t) => t.key).sort()).toEqual(["crm_specialist", "finance_assistant", "general_assistant", "hr_assistant", "marketing_specialist", "sales_assistant", "seo_specialist", "support_agent"]);
    for (const t of TEMPLATES) {
      expect(templateByKey(t.key)).toBe(t);
      for (const l of ["es", "en"] as const) { expect(t.texts[l].name.length).toBeGreaterThan(1); expect(t.texts[l].promptBody.length).toBeGreaterThan(40); }
      expect(t.autonomy).toBeLessThanOrEqual(2);
    }
  });
  it("vocabularies used by the UI have texts in both languages", () => {
    const en = STUDIO_DICTIONARIES.en as Record<string, string>;
    for (const d of DEPARTMENTS) expect(en[`dep.${d}`], d).toBeDefined();
    for (const k of KNOWLEDGE_TYPES) expect(en[`kt.${k}`], k).toBeDefined();
    for (const k of TOOL_KINDS) expect(en[`kind.${k}`], k).toBeDefined();
    for (const k of RISKS) expect(en[`risk.${k}`], k).toBeDefined();
    for (const n of [0, 1, 2, 3, 4]) expect(en[`aut.${n}`], String(n)).toBeDefined();
  });
});

describe("wire format and texts", () => {
  it("snake_case and ISO dates on the way out, the reverse on the way in, tenant hidden", () => {
    expect(toWire({ tenantId: "t", employeeId: "s", createdAt: 0, nested: [{ updatedAt: 86_400_000, publishedVersion: 3 }] })).toEqual({ employee_id: "s", created_at: "1970-01-01T00:00:00.000Z", nested: [{ updated_at: "1970-01-02T00:00:00.000Z", published_version: 3 }] });
    expect(fromWire({ employee_id: "s", created_at: "1970-01-01T00:00:00.000Z" })).toEqual({ employeeId: "s", createdAt: 0 });
    expect(() => queryObject(new URLSearchParams("a=1&a=2"))).toThrow();
  });
  it("Spanish and English have the same keys, no empty texts", () => {
    const en = STUDIO_DICTIONARIES.en, es = STUDIO_DICTIONARIES.es;
    expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort());
    for (const v of [...Object.values(en), ...Object.values(es)]) expect(v.length).toBeGreaterThan(0);
    expect(es["nav.employees"]).not.toBe(en["nav.employees"]);
  });
});
