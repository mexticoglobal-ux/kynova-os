import { realestateRoute, readBody, respond } from "@/modules/realestate/http";
export const GET = realestateRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.listPublications(actor, { status: req.nextUrl.searchParams.get("status") ?? undefined }), rid); });
