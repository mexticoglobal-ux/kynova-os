import { realestateRoute, readBody, respond } from "@/modules/realestate/http";
type Ctx = { params: Promise<{ id: string }> };
export const POST = realestateRoute<Ctx>(async (req, c, { actor, svc, rid }) => respond(await svc.decide(actor, (await c.params).id, await readBody(req)), rid), { mutating: true });
