import { realestateRoute, readBody, respond } from "@/modules/realestate/http";
export const POST = realestateRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.prepare(actor, await readBody(req)), rid, 201); }, { mutating: true });
