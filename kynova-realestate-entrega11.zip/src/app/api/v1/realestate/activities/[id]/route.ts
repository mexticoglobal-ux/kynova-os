import { realestateRoute, readBody, respond } from "@/modules/realestate/http";
type Ctx = { params: Promise<{ id: string }> };
export const PATCH = realestateRoute<Ctx>(async (req, c, { actor, svc, rid }) => respond(await svc.updateActivity(actor, (await c.params).id, await readBody(req)), rid), { mutating: true });
