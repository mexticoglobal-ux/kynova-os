import { realestateRoute, readBody, respond } from "@/modules/realestate/http";
export const GET = realestateRoute(async (req, c, { actor, svc, rid }) => { void c; const n = (k: string) => { const v = req.nextUrl.searchParams.get(k); return v ? Number(v) : undefined; }; return respond(await svc.kpis(actor, { from: n("from"), to: n("to") }), rid); });
