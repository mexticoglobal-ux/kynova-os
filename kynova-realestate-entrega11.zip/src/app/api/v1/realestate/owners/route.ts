import { realestateRoute, readBody, respond } from "@/modules/realestate/http";
export const GET = realestateRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.listOwners(actor), rid); });
export const POST = realestateRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.createOwner(actor, await readBody(req)), rid, 201); }, { mutating: true });
