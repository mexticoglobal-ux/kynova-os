import { realestateRoute, readBody, respond } from "@/modules/realestate/http";
export const GET = realestateRoute(async (req, c, { actor, svc, rid }) => { void c; const v = req.nextUrl.searchParams.get("since"); return respond(await svc.digest(actor, v ? { since: Number(v) } : {}), rid); });
