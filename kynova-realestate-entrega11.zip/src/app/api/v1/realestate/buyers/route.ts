import { realestateRoute, readBody, respond } from "@/modules/realestate/http";
export const GET = realestateRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.listBuyers(actor), rid); });
export const POST = realestateRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.createBuyer(actor, await readBody(req)), rid, 201); }, { mutating: true });
