import { realestateRoute, readBody, respond } from "@/modules/realestate/http";
type Ctx = { params: Promise<{ id: string }> };
export const GET = realestateRoute<Ctx>(async (req, c, { actor, svc, rid }) => { void req; return respond(await svc.matchesOfProperty(actor, (await c.params).id), rid); });
