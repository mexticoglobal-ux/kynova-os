import { realestateRoute, readBody, respond } from "@/modules/realestate/http";
type Ctx = { params: Promise<{ id: string }> };
export const GET = realestateRoute<Ctx>(async (req, c, { actor, svc, rid }) => { void req; return respond(await svc.getProperty(actor, (await c.params).id), rid); });
export const PATCH = realestateRoute<Ctx>(async (req, c, { actor, svc, rid }) => respond(await svc.updateProperty(actor, (await c.params).id, await readBody(req)), rid), { mutating: true });
