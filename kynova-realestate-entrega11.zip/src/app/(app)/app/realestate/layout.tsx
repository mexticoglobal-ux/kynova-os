import type { ReactNode } from "react";
import { RealEstateI18n } from "@/components/realestate/I18n";
import { realestateContext } from "@/components/realestate/context";
import { REALESTATE_DICTIONARIES } from "@/modules/realestate";

export default async function RealEstateLayout({ children }: { children: ReactNode }) {
  const { locale } = await realestateContext();
  return <RealEstateI18n dict={REALESTATE_DICTIONARIES[locale]} locale={locale}><main id="main" className="mx-auto w-full max-w-[96rem] p-4 sm:p-6 lg:p-8">{children}</main></RealEstateI18n>;
}
