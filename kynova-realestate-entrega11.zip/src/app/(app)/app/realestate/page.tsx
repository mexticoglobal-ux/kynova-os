import { realestateContext } from "@/components/realestate/context";
import { RealEstateDigest } from "@/components/realestate/DigestCard";
import { ActionButton, PrepareForm, QuickForm, type FieldSpec } from "@/components/realestate/Panels";
import { Card, Empty, Notice, Pill, Stat } from "@/components/workforce/ui";
import { ARCHITECTURE_STATUS, BUYER_STAGES, CHANNELS, KINDS, OPERATIONS, OWNER_STAGES, type RealEstateKey } from "@/modules/realestate";

export const metadata = { title: "Real Estate" };
export const dynamic = "force-dynamic";
const k = (s: string) => s as RealEstateKey;
const ST = (v: string) => (v.startsWith("built") ? "built" : v.startsWith("declared") ? "declared" : "not_built");
const fmtMoney = (minor: number, cur: string, locale: string) => new Intl.NumberFormat(locale, { style: "currency", currency: cur, maximumFractionDigits: 0 }).format(minor / 100);

export default async function RealEstatePage() {
  const { t, locale, svc, actor } = await realestateContext(), now = Date.now();
  const [ov, perm, kp, dg, props, owners, buyers, acts, pubs] = await Promise.all([svc.overview(actor), svc.permissions(actor), svc.kpis(actor), svc.digest(actor), svc.listProperties(actor), svc.listOwners(actor), svc.listBuyers(actor), svc.listActivities(actor, { from: now - 86_400_000 }), svc.listPublications(actor)]);
  const manage = perm.capabilities.includes("manage"), approve = perm.capabilities.includes("approve"), names = Object.fromEntries(ov.team.map((m) => [m.key, m.name]));
  const matches = await Promise.all(buyers.filter((b) => b.stage !== "won" && b.stage !== "lost").slice(0, 8).map(async (b) => [b.id, await svc.matchesOfBuyer(actor, b.id)] as const)), matchOf = new Map(matches), title = new Map(props.map((p) => [p.id, p.title]));
  const opts = (xs: readonly string[], pre: string) => xs.map((value) => ({ value, label: t(k(`${pre}.${value}`)) }));
  const cur = (m: Record<string, number>) => Object.entries(m).map(([c, n]) => fmtMoney(n, c, locale)).join(" · ") || t("kpi.na");
  const propFields: FieldSpec[] = [{ name: "title", label: "prop.name", type: "text", required: true }, { name: "operation", label: "op.sale", type: "select", options: opts(OPERATIONS, "op") }, { name: "kind", label: "kind.house", type: "select", options: opts(KINDS, "kind") }, { name: "priceMinor", label: "prop.price", type: "money", required: true }, { name: "zone", label: "prop.zone", type: "text" }, { name: "bedrooms", label: "prop.beds", type: "number" }];
  const ownerFields: FieldSpec[] = [{ name: "name", label: "owner.name", type: "text", required: true }, { name: "phone", label: "Tel", type: "text" }, { name: "nextAction", label: "owner.next", type: "text" }, { name: "nextActionAt", label: "owner.when", type: "datetime" }];
  const buyerFields: FieldSpec[] = [{ name: "name", label: "buyer.name", type: "text", required: true }, { name: "intent", label: "op.sale", type: "select", options: opts(OPERATIONS, "op") }, { name: "budgetMaxMinor", label: "buyer.max", type: "money" }, { name: "zones", label: "buyer.zones", type: "list" }, { name: "nextActionAt", label: "owner.when", type: "datetime" }];
  const actFields: FieldSpec[] = [{ name: "kind", label: "ak.visit", type: "select", options: opts(["visit", "open_house", "call", "follow_up", "reminder"], "ak") }, { name: "title", label: "ag.name", type: "text", required: true }, { name: "whenAt", label: "ag.when", type: "datetime", required: true }];
  const row = "flex flex-wrap items-center gap-2 rounded-lg border border-line px-3 py-2 text-sm";
  return (
    <div className="grid gap-5">
      <header><h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{t("title")}</h1><p className="mt-1 text-sm text-muted">{t("sub")}</p></header>
      <RealEstateDigest digest={dg} t={t} names={names} />
      <Notice><strong>{t("boot.title")}.</strong> {t("boot.text")}</Notice>
      <Card title={t("kpi.title")}>
        <dl className="grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-5">
          <Stat label={t("kpi.active")} value={kp.activeProperties} /><Stat label={t("kpi.sold")} value={kp.soldProperties} /><Stat label={t("kpi.rented")} value={kp.rentedProperties} />
          <Stat label={t("kpi.daysSell")} value={kp.avgDaysToSell === null ? t("kpi.na") : t("kpi.days", { n: kp.avgDaysToSell })} /><Stat label={t("kpi.daysRent")} value={kp.avgDaysToRent === null ? t("kpi.na") : t("kpi.days", { n: kp.avgDaysToRent })} />
          <Stat label={t("kpi.clients")} value={kp.newClients} /><Stat label={t("kpi.conversion")} value={kp.conversionPct === null ? t("kpi.na") : `${kp.conversionPct}%`} /><Stat label={t("kpi.income")} value={cur(kp.incomeMinor)} /><Stat label={t("kpi.expected")} value={cur(kp.expectedCommissionMinor)} />
        </dl>
      </Card>
      <Card title={t("team.title")}>
        <ul className="grid gap-2 md:grid-cols-2 xl:grid-cols-3">{ov.team.map((m) => (
          <li key={m.key} className="grid gap-1 rounded-xl border border-line px-3 py-2 text-sm"><div className="flex items-center justify-between gap-2"><span className="font-medium">{m.name}</span>
            {m.soon ? <Pill tone="muted">{t("soon")}</Pill> : !m.entitled ? <Pill tone="muted">{t("team.plan")}</Pill> : m.active ? <Pill tone="success">{t("team.ready")}</Pill> : <Pill tone="muted">{t("team.notActive")}</Pill>}</div><p className="text-xs text-muted">{t(k(`m.${m.key}`))}</p></li>))}</ul>
      </Card>
      <Card title={t("prop.title")}>
        {props.length === 0 ? <Empty>{t("common.none")}</Empty> : <ul className="mb-3 grid gap-2">{props.map((p) => (
          <li key={p.id} className={row}><span className="min-w-0 flex-1">{p.title} <span className="text-xs text-muted">· {t(k(`op.${p.operation}`))} · {fmtMoney(p.priceMinor, p.currency, locale)}{p.zone ? ` · ${p.zone}` : ""}</span></span><Pill tone={p.status === "active" ? "success" : p.status === "archived" ? "muted" : "info"}>{t(k(`ps.${p.status}`))}</Pill>
            {manage && p.status === "active" && <><ActionButton path={`/realestate/properties/${p.id}`} body={{ status: "reserved" }} label={t("act.reserve")} /><ActionButton path={`/realestate/properties/${p.id}`} body={{ status: p.operation === "sale" ? "sold" : "rented" }} label={t("act.close", { what: t(p.operation === "sale" ? "ps.sold" : "ps.rented") })} ask="act.closePrice" /></>}
            {manage && p.status === "reserved" && <><ActionButton path={`/realestate/properties/${p.id}`} body={{ status: "active" }} label={t("act.restore")} /><ActionButton path={`/realestate/properties/${p.id}`} body={{ status: p.operation === "sale" ? "sold" : "rented" }} label={t("act.close", { what: t(p.operation === "sale" ? "ps.sold" : "ps.rented") })} ask="act.closePrice" /></>}
            {manage && (p.status === "active" || p.status === "reserved") && <ActionButton path={`/realestate/properties/${p.id}`} body={{ status: "archived" }} label={t("act.archive")} />}
            {manage && p.status === "archived" && <ActionButton path={`/realestate/properties/${p.id}`} body={{ status: "active" }} label={t("act.restore")} />}</li>))}</ul>}
        {manage && <QuickForm path="/realestate/properties" fields={propFields} />}
      </Card>
      <div className="grid gap-5 lg:grid-cols-2">
        <Card title={t("owner.title")}>
          {owners.length === 0 ? <Empty>{t("common.none")}</Empty> : <ul className="mb-3 grid gap-2">{owners.map((o) => (
            <li key={o.id} className={row}><span className="min-w-0 flex-1">{o.name}{o.nextAction && <span className="text-xs text-muted"> · {o.nextAction}{o.nextActionAt ? ` · ${new Date(o.nextActionAt).toISOString().slice(0, 10)}` : ""}</span>}</span><Pill>{t(k(`os.${o.stage}`))}</Pill>
              {manage && OWNER_STAGES.filter((s) => s !== o.stage).slice(0, 4).map((s) => <ActionButton key={s} path={`/realestate/owners/${o.id}`} body={{ stage: s }} label={t(k(`os.${s}`))} />)}</li>))}</ul>}
          {manage && <QuickForm path="/realestate/owners" fields={ownerFields} />}
        </Card>
        <Card title={t("buyer.title")}>
          {buyers.length === 0 ? <Empty>{t("common.none")}</Empty> : <ul className="mb-3 grid gap-2">{buyers.map((b) => { const m = matchOf.get(b.id) ?? []; return (
            <li key={b.id} className={`${row} items-start`}><span className="min-w-0 flex-1">{b.name} <span className="text-xs text-muted">· {t(k(`op.${b.intent}`))}{b.budgetMaxMinor ? ` · ≤ ${fmtMoney(b.budgetMaxMinor, b.currency, locale)}` : ""}{b.zones.length ? ` · ${b.zones.join(", ")}` : ""}</span>
              {b.stage !== "won" && b.stage !== "lost" && <span className="block text-xs text-muted">{t("buyer.matches")}: {m.length ? m.map((x) => `${title.get(x.propertyId) ?? x.propertyId} (${x.score})`).join(", ") : t("buyer.noMatches")}</span>}</span>
              <Pill>{t(k(`bs.${b.stage}`))}</Pill>{manage && BUYER_STAGES.filter((s) => s !== b.stage && s !== "new").slice(0, 3).map((s) => <ActionButton key={s} path={`/realestate/buyers/${b.id}`} body={{ stage: s }} label={t(k(`bs.${s}`))} />)}</li>); })}</ul>}
          {manage && <QuickForm path="/realestate/buyers" fields={buyerFields} />}
        </Card>
      </div>
      <Card title={t("ag.title")}>
        {acts.length === 0 ? <Empty>{t("common.none")}</Empty> : <ul className="mb-3 grid gap-2">{acts.map((a) => (
          <li key={a.id} className={row}><Pill tone="info">{t(k(`ak.${a.kind}`))}</Pill><span className="min-w-0 flex-1">{a.title} <time className="text-xs text-muted" dateTime={new Date(a.whenAt).toISOString()}>· {new Date(a.whenAt).toISOString().slice(0, 16).replace("T", " ")} UTC</time></span>
            {a.status === "planned" && manage ? <><ActionButton path={`/realestate/activities/${a.id}`} body={{ status: "done" }} label={t("ag.done")} /><ActionButton path={`/realestate/activities/${a.id}`} body={{ status: "cancelled" }} label={t("ag.cancel")} /></> : <Pill tone="muted">{a.status}</Pill>}</li>))}</ul>}
        {manage && <QuickForm path="/realestate/activities" fields={actFields} />}
      </Card>
      <Card title={t("pub.title")}>
        <p className="mb-3 text-xs text-muted">{t("pub.note")}</p>
        {pubs.length === 0 ? <Empty>{t("pub.none")}</Empty> : <ul className="mb-3 grid gap-2">{pubs.map((p) => (
          <li key={p.id} className="grid gap-1 rounded-lg border border-line px-3 py-2 text-sm"><div className="flex flex-wrap items-center gap-2"><Pill tone="info">{t(k(`ch.${p.channel}`))}</Pill><span className="min-w-0 flex-1">{title.get(p.propertyId) ?? p.title}</span><Pill tone={p.status === "approved" ? "success" : p.status === "rejected" ? "muted" : "warning"}>{t(k(`st.${p.status}`))}</Pill></div>
            <p className="whitespace-pre-line text-xs text-muted">{p.body}</p>{p.outcome && <p className="text-xs text-muted">{t(k(`out.${p.outcome}`))}</p>}
            {p.status === "proposed" && approve && <div className="flex gap-2"><ActionButton method="POST" path={`/realestate/publications/${p.id}/decision`} body={{ approve: true }} label={t("approve")} /><ActionButton method="POST" path={`/realestate/publications/${p.id}/decision`} body={{ approve: false }} label={t("reject")} /></div>}</li>))}</ul>}
        {manage && props.some((p) => p.status === "active" || p.status === "reserved") && <PrepareForm locale={locale} properties={props.filter((p) => p.status === "active" || p.status === "reserved").map((p) => ({ id: p.id, title: p.title }))} channels={CHANNELS.map((c) => ({ value: c, label: t(k(`ch.${c}`)) }))} />}
      </Card>
      <Card title={t("int.title")}>
        <ul className="grid gap-2 sm:grid-cols-3 xl:grid-cols-5">{ov.integrations.map((i) => <li key={i.id} className="flex items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span>{t(k(`int.${i.id}`))}</span><Pill tone="muted">{t("soon")}</Pill></li>)}</ul>
      </Card>
      <Card title={t("arch.title")}><p className="mb-3 text-xs text-muted">{t("arch.notice")}</p>
        <ul className="grid gap-2 sm:grid-cols-2">{Object.entries(ARCHITECTURE_STATUS).map(([key, v]) => <li key={key} className="flex items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span>{t(k(`a.${key}`))}</span><Pill tone={ST(v) === "built" ? "success" : "muted"}>{t(k(`s.${ST(v)}`))}</Pill></li>)}</ul></Card>
    </div>
  );
}
