/** The official AI Employees of Blueprint doc 03 section 21, by department. Names are the Blueprint's own role names. A registered blueprint with the same key makes the entry activatable; `real` marks the ones that already have tools wired to a platform capability. */
export const DEPARTMENTS = ["direction", "marketing", "seo", "sales", "finance", "customers", "marketplace", "partners", "operations", "technology", "intelligence", "communication", "real_estate"] as const;
export type Department = (typeof DEPARTMENTS)[number];
/** How far a member really is: `ready` = tools wired to the platform; `preparing` = can reason and talk, no tools yet; `soon` = nothing behind it yet. Never shown as working unless `ready`. */
export const STAGES = ["ready", "preparing", "soon"] as const;
export type Stage = (typeof STAGES)[number];
/** Members with nothing behind them yet (no module, no data to work from). Edit this list as capabilities land. */
export const SOON_KEYS: ReadonlySet<string> = new Set(["hr_manager", "legal_assistant", "contract_manager", "document_manager", "training_manager", "tax_assistant", "product_reviewer", "license_manager", "ai_research_manager", "brand_manager", "developer_assistant", "qa_manager", "release_manager"]);
export interface RosterEntry { key: string; name: string; department: Department; /** Key of an already-registered blueprint that does this job today. */ blueprint?: string }
const d = (department: Department, names: readonly string[], map: Record<string, string> = {}): RosterEntry[] =>
  names.map((name) => { const key = name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, ""); return { key, name, department, ...(map[key] ? { blueprint: map[key] } : {}) }; });
export const ROSTER: readonly RosterEntry[] = [
  ...d("direction", ["CEO AI", "Chief of Staff AI", "Mission Control AI"], { ceo_ai: "executive_advisor", mission_control_ai: "mission_control_advisor" }),
  ...d("marketing", ["Marketing Manager", "Content Creator", "Social Media Manager", "Ads Manager", "Email Marketing Manager", "Brand Manager", "Content Manager"]),
  ...d("seo", ["Technical SEO", "Local SEO", "Content SEO", "Link Building Advisor", "SEO Auditor", "SEO Manager"]),
  ...d("sales", ["Sales Manager", "CRM Manager", "Lead Manager", "Proposal Manager", "Follow-up Manager"]),
  ...d("finance", ["Finance Manager", "Accounting Manager", "Billing Manager", "Collections Manager", "Tax Assistant"], { finance_manager: "finance_analyst", billing_manager: "billing_advisor" }),
  ...d("customers", ["Customer Success Manager", "Support Manager", "Onboarding Specialist", "Training Manager"]),
  ...d("marketplace", ["Marketplace Manager", "Product Reviewer", "License Manager"], { marketplace_manager: "marketplace_advisor" }),
  ...d("partners", ["Partner Manager", "Referral Manager", "Commission Manager"], { partner_manager: "partner_manager" }),
  ...d("operations", ["HR Manager", "Legal Assistant", "Contract Manager", "Document Manager"]),
  ...d("technology", ["Developer Assistant", "QA Manager", "Release Manager", "Security Officer", "Integration Manager"], { integration_manager: "integrations_advisor" }),
  ...d("intelligence", ["Analytics Advisor", "Forecast Manager", "Automation Manager", "AI Research Manager", "Analytics Manager"], { analytics_advisor: "analytics_advisor" }),
  ...d("communication", ["Communication Manager", "WhatsApp Manager", "Email Manager", "Social Messaging Manager"]),
  ...d("real_estate", ["Real Estate Director", "Property Manager", "Listing Manager", "Buyer Specialist", "Seller Specialist", "Appointment Manager"]),
];
export const stageOf = (r: RosterEntry): Stage => (r.blueprint ? "ready" : SOON_KEYS.has(r.key) ? "soon" : "preparing");
export const ROSTER_BY_KEY = new Map(ROSTER.map((r) => [r.key, r]));
/** The blueprint a hire of this entry uses: the existing one when it has one, otherwise the generic one registered under the roster key. */
export const blueprintOf = (r: RosterEntry): string => r.blueprint ?? r.key;
/** Activity Engine key for a activated employee: stable, one per employee record, never a person's data. */
export const employeeKeyOf = (employeeId: string): string => `emp_${employeeId.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 40)}`;

/** What a freshly activated member is asked to do until the company sets its own goal. */
export const DEPARTMENT_GOALS: Record<Department, string> = {
  direction: "Keep the whole company moving toward its goals and tell the owner what matters.", marketing: "Plan and improve the company's marketing from the evidence available.", seo: "Find and prioritise what will improve the company's search visibility.",
  sales: "Help the company win and follow up customers.", finance: "Keep the company's money clear and flag what needs attention.", customers: "Keep customers supported, onboarded and successful.",
  marketplace: "Keep the marketplace healthy and recommend what fits the company.", partners: "Grow and look after partners, referrals and commissions.", operations: "Keep people, contracts and documents in order.",
  technology: "Keep the platform secure, tested and connected.", real_estate: "Run the real estate business: properties, owners, buyers, visits and publications.", communication: "Talk with customers and prospects through the right channel, follow up and keep every conversation on record.", intelligence: "Turn the company's own data into forecasts and clear recommendations.",
};
