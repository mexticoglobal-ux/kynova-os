import type { Role } from "@/config/roles";
import { DEFAULT_CAPABILITIES, type Capability } from "./domain";

/** Capabilities INSIDE RealEstate. Whether a role may open /app/realestate at all is decided only by src/config/modules.ts. */
export const allows = (role: Role, c: Capability): boolean => DEFAULT_CAPABILITIES[role].includes(c);
