import type { Kind } from "./store";

export const TABLE: Record<Kind, string> = { property: "re_properties", owner: "re_owners", buyer: "re_buyers", activity: "re_activities", publication: "re_publications" };
export const KIND_LIST = Object.keys(TABLE) as Kind[];
/** Nothing is deleted: a property is archived, an owner or buyer is marked lost, an activity is cancelled. */
export const SOFT_DELETE: ReadonlySet<Kind> = new Set<Kind>();
export const REMOVABLE: ReadonlySet<Kind> = new Set<Kind>();
export const IMMUTABLE_KINDS: ReadonlySet<Kind> = new Set<Kind>();
export const FROZEN_COLS: Partial<Record<Kind, readonly string[]>> = { publication: ["propertyId", "channel"] };
export const BOOLEAN_COLS: ReadonlySet<string> = new Set<string>();
export const JSON_COLS: ReadonlySet<string> = new Set(["zones", "kinds"]);
export const COLUMNS: Record<Kind, readonly string[]> = {
  property: ["id", "tenantId", "title", "operation", "kind", "status", "priceMinor", "currency", "zone", "address", "bedrooms", "bathrooms", "areaM2", "description", "ownerId", "commissionBp", "listedAt", "closedAt", "closedPriceMinor", "commissionMinor", "createdBy", "createdAt", "updatedAt"],
  owner: ["id", "tenantId", "name", "phone", "email", "source", "stage", "nextAction", "nextActionAt", "notes", "createdBy", "createdAt", "updatedAt"],
  buyer: ["id", "tenantId", "name", "phone", "email", "intent", "budgetMinMinor", "budgetMaxMinor", "currency", "zones", "kinds", "bedroomsMin", "stage", "nextAction", "nextActionAt", "notes", "createdBy", "createdAt", "updatedAt"],
  activity: ["id", "tenantId", "kind", "title", "whenAt", "status", "propertyId", "buyerId", "ownerId", "notes", "createdBy", "createdAt", "updatedAt"],
  publication: ["id", "tenantId", "propertyId", "channel", "title", "body", "status", "outcome", "refId", "preparedBy", "decidedBy", "decidedAt", "createdAt", "updatedAt"],
};
export const UNIQUE: Partial<Record<Kind, readonly (readonly string[])[]>> = { publication: [["propertyId", "channel"]] };
export const UNIQUE_WHEN: Partial<Record<Kind, readonly { cols: readonly string[]; col: string; in: readonly string[] }[]>> = {};
export const snake = (k: string) => k.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
export const camel = (k: string) => k.replace(/_([a-z0-9])/g, (_m, c: string) => c.toUpperCase());
