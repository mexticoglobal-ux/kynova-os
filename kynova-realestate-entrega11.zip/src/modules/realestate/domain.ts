import { z } from "zod";
import { ROLES } from "@/config/roles";

/** Capabilities INSIDE Real Estate. Whether a role may open /app/realestate at all is decided only by src/config/modules.ts. */
export const CAPABILITIES = ["view", "manage", "approve"] as const;
export type Capability = (typeof CAPABILITIES)[number];
export const DEFAULT_CAPABILITIES: Record<(typeof ROLES)[number], readonly Capability[]> = {
  super_admin: [...CAPABILITIES], owner: [...CAPABILITIES], administrator: [...CAPABILITIES], ceo: [...CAPABILITIES], manager: ["view", "manage"],
  marketing: ["view", "manage"], sales: ["view", "manage"], finance: ["view"], support: [], hr: [], employee: [], guest: [],
};
export const OPERATIONS = ["sale", "rent"] as const;
export const KINDS = ["house", "apartment", "land", "commercial", "other"] as const;
export const PROPERTY_STATUS = ["active", "reserved", "sold", "rented", "archived"] as const;
export const OWNER_STAGES = ["new", "contacted", "meeting", "mandate", "lost"] as const;
export const BUYER_STAGES = ["new", "contacted", "searching", "visiting", "negotiating", "won", "lost"] as const;
export const ACTIVITY_KINDS = ["visit", "open_house", "call", "follow_up", "reminder"] as const;
export const ACTIVITY_STATUS = ["planned", "done", "cancelled"] as const;
export const CHANNELS = ["facebook", "instagram", "linkedin", "whatsapp", "email"] as const;
export const PUB_STATUS = ["proposed", "approved", "rejected"] as const;
export const PUB_OUTCOMES = ["", "draft_created", "prepared"] as const;
type V<T extends readonly string[]> = T[number];
export type PropertyStatus = V<typeof PROPERTY_STATUS>;

export interface PropertyRecord { id: string; tenantId: string; title: string; operation: V<typeof OPERATIONS>; kind: V<typeof KINDS>; status: PropertyStatus; priceMinor: number; currency: string; zone: string; address: string; bedrooms: number; bathrooms: number; areaM2: number; description: string; ownerId: string | null; commissionBp: number; listedAt: number; closedAt: number | null; closedPriceMinor: number | null; commissionMinor: number | null; createdBy: string; createdAt: number; updatedAt: number }
export interface OwnerRecord { id: string; tenantId: string; name: string; phone: string; email: string; source: string; stage: V<typeof OWNER_STAGES>; nextAction: string; nextActionAt: number | null; notes: string; createdBy: string; createdAt: number; updatedAt: number }
export interface BuyerRecord { id: string; tenantId: string; name: string; phone: string; email: string; intent: V<typeof OPERATIONS>; budgetMinMinor: number; budgetMaxMinor: number; currency: string; zones: string[]; kinds: string[]; bedroomsMin: number; stage: V<typeof BUYER_STAGES>; nextAction: string; nextActionAt: number | null; notes: string; createdBy: string; createdAt: number; updatedAt: number }
export interface ActivityRecord { id: string; tenantId: string; kind: V<typeof ACTIVITY_KINDS>; title: string; whenAt: number; status: V<typeof ACTIVITY_STATUS>; propertyId: string | null; buyerId: string | null; ownerId: string | null; notes: string; createdBy: string; createdAt: number; updatedAt: number }
export interface PublicationRecord { id: string; tenantId: string; propertyId: string; channel: V<typeof CHANNELS>; title: string; body: string; status: V<typeof PUB_STATUS>; outcome: V<typeof PUB_OUTCOMES>; refId: string | null; preparedBy: string; decidedBy: string | null; decidedAt: number | null; createdAt: number; updatedAt: number }

const text = (max: number) => z.string().trim().max(max);
const money = z.number().int().min(0).max(100_000_000_000_00);
const id = z.string().trim().min(1).max(64);
const ts = z.number().int().positive();
/** A PATCH body: every field optional and WITHOUT its create-time default, so an update never overwrites a field the person did not send. */
function patchOf<S extends z.ZodObject<z.ZodRawShape>, X extends z.ZodRawShape>(base: S, extra: X): z.ZodType<Partial<z.output<S>> & Partial<z.output<z.ZodObject<X>>>> {
  const own = Object.fromEntries(Object.entries(base.shape).map(([k, v]) => [k, ((v instanceof z.ZodDefault ? v.removeDefault() : v) as z.ZodType).optional()]));
  return z.object({ ...own, ...extra }).strict() as unknown as z.ZodType<Partial<z.output<S>> & Partial<z.output<z.ZodObject<X>>>>;
}
const cur = z.string().trim().toUpperCase().regex(/^[A-Z]{3}$/).default("USD");
export const propertyInput = z.object({
  title: text(140).min(1), operation: z.enum(OPERATIONS), kind: z.enum(KINDS).default("house"), priceMinor: money, currency: cur, zone: text(80).default(""), address: text(200).default(""),
  bedrooms: z.number().int().min(0).max(50).default(0), bathrooms: z.number().int().min(0).max(50).default(0), areaM2: z.number().int().min(0).max(1_000_000).default(0),
  description: text(2000).default(""), ownerId: id.nullable().default(null), commissionBp: z.number().int().min(0).max(10_000).default(300),
}).strict();
/** Closing a property (sold / rented) needs the real closing price; the commission is the agency's income and is computed from it unless the person types the real figure. */
export const propertyPatch = patchOf(propertyInput, { status: z.enum(PROPERTY_STATUS).optional(), closedPriceMinor: money.optional(), commissionMinor: money.optional() });
export const ownerInput = z.object({ name: text(120).min(1), phone: text(40).default(""), email: text(160).default(""), source: text(80).default(""), nextAction: text(200).default(""), nextActionAt: ts.nullable().default(null), notes: text(1000).default("") }).strict();
export const ownerPatch = patchOf(ownerInput, { stage: z.enum(OWNER_STAGES).optional() });
export const buyerInput = z.object({
  name: text(120).min(1), phone: text(40).default(""), email: text(160).default(""), intent: z.enum(OPERATIONS).default("sale"), budgetMinMinor: money.default(0), budgetMaxMinor: money.default(0), currency: cur,
  zones: z.array(text(80)).max(20).default([]), kinds: z.array(z.enum(KINDS)).max(5).default([]), bedroomsMin: z.number().int().min(0).max(50).default(0), nextAction: text(200).default(""), nextActionAt: ts.nullable().default(null), notes: text(1000).default(""),
}).strict().refine((v) => v.budgetMaxMinor === 0 || v.budgetMaxMinor >= v.budgetMinMinor, { path: ["budgetMaxMinor"], message: "Maximum budget must be at least the minimum." });
export const buyerPatch = z.object({ name: text(120).min(1), phone: text(40), email: text(160), intent: z.enum(OPERATIONS), budgetMinMinor: money, budgetMaxMinor: money, zones: z.array(text(80)).max(20), kinds: z.array(z.enum(KINDS)).max(5), bedroomsMin: z.number().int().min(0).max(50), nextAction: text(200), nextActionAt: ts.nullable(), notes: text(1000), stage: z.enum(BUYER_STAGES) }).partial().strict();
export const activityInput = z.object({ kind: z.enum(ACTIVITY_KINDS), title: text(140).min(1), whenAt: ts, propertyId: id.nullable().default(null), buyerId: id.nullable().default(null), ownerId: id.nullable().default(null), notes: text(500).default("") }).strict();
export const activityPatch = z.object({ title: text(140).min(1), whenAt: ts, status: z.enum(ACTIVITY_STATUS), notes: text(500) }).partial().strict();
export const prepareInput = z.object({ propertyId: id, channels: z.array(z.enum(CHANNELS)).min(1).max(5), locale: z.enum(["es", "en"]).default("es") }).strict();
export const decisionInput = z.object({ approve: z.boolean() }).strict();
export const digestQuery = z.object({ since: ts.optional() }).strict();
