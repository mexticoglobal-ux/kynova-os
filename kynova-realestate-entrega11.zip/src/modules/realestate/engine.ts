import type { BuyerRecord, PropertyRecord } from "./domain";

/**
 * Matching engine (V1): deterministic rules, no AI. It is a pure function so Entrega 12 can add automation and Entrega 13 can add a model behind the
 * same `Matcher` signature without touching callers. A match needs the same operation and currency and a price inside the budget.
 */
export interface Match { propertyId: string; buyerId: string; score: number; reasons: string[]; engine: "rules" }
export type Matcher = (buyer: BuyerRecord, property: PropertyRecord) => Match | null;
export const MIN_SCORE = 60;
const norm = (s: string) => s.trim().toLowerCase();
export const rulesMatcher: Matcher = (b, p) => {
  if (p.status !== "active" || p.operation !== b.intent || p.currency !== b.currency) return null;
  if (b.budgetMaxMinor > 0 && p.priceMinor > b.budgetMaxMinor) return null;
  if (p.priceMinor < b.budgetMinMinor) return null;
  const reasons: string[] = ["operation", "budget"]; let score = 40;
  if (b.zones.length === 0) score += 12; else if (b.zones.some((z) => norm(p.zone).includes(norm(z)) || norm(z).includes(norm(p.zone)))) { score += 25; reasons.push("zone"); } else return null; // the buyer named zones and this property is outside them
  if (b.kinds.length === 0) score += 7; else if (b.kinds.includes(p.kind)) { score += 15; reasons.push("kind"); } else score -= 10;
  if (b.bedroomsMin === 0 || p.bedrooms >= b.bedroomsMin) { score += 20; if (b.bedroomsMin > 0) reasons.push("bedrooms"); } else score -= 10;
  return score >= MIN_SCORE ? { propertyId: p.id, buyerId: b.id, score: Math.min(100, score), reasons, engine: "rules" } : null;
};
export function matchesForBuyer(b: BuyerRecord, props: readonly PropertyRecord[], m: Matcher = rulesMatcher): Match[] { return props.flatMap((p) => m(b, p) ?? []).sort((x, y) => y.score - x.score); }
export function matchesForProperty(p: PropertyRecord, buyers: readonly BuyerRecord[], m: Matcher = rulesMatcher): Match[] { return buyers.flatMap((b) => (b.stage === "won" || b.stage === "lost" ? [] : m(b, p) ?? [])).sort((x, y) => y.score - x.score); }

/** KPIs from recorded facts only. Anything with nothing behind it is null, never zero-filled into a fake result. */
export interface Kpis {
  activeProperties: number; reservedProperties: number; soldProperties: number; rentedProperties: number; avgDaysToSell: number | null; avgDaysToRent: number | null;
  newClients: number; conversionPct: number | null; incomeMinor: Record<string, number>; expectedCommissionMinor: Record<string, number>;
}
const DAY = 86_400_000;
export function computeKpis(props: readonly PropertyRecord[], owners: readonly { createdAt: number }[], buyers: readonly (BuyerRecord)[], from: number, to: number): Kpis {
  const inRange = (t: number) => t >= from && t <= to, closed = props.filter((p) => p.closedAt !== null && inRange(p.closedAt));
  const days = (st: string) => { const r = closed.filter((p) => p.status === st); return r.length ? Math.round(r.reduce((n, p) => n + ((p.closedAt as number) - p.listedAt) / DAY, 0) / r.length) : null; };
  const sum = (rows: readonly PropertyRecord[], f: (p: PropertyRecord) => number) => rows.reduce<Record<string, number>>((o, p) => { o[p.currency] = (o[p.currency] ?? 0) + f(p); return o; }, {});
  return {
    activeProperties: props.filter((p) => p.status === "active").length, reservedProperties: props.filter((p) => p.status === "reserved").length,
    soldProperties: closed.filter((p) => p.status === "sold").length, rentedProperties: closed.filter((p) => p.status === "rented").length, avgDaysToSell: days("sold"), avgDaysToRent: days("rented"),
    newClients: owners.filter((o) => inRange(o.createdAt)).length + buyers.filter((b) => inRange(b.createdAt)).length,
    conversionPct: buyers.length ? Math.round((buyers.filter((b) => b.stage === "won").length / buyers.length) * 1000) / 10 : null,
    incomeMinor: sum(closed, (p) => p.commissionMinor ?? 0), expectedCommissionMinor: sum(props.filter((p) => p.status === "reserved"), (p) => Math.round((p.priceMinor * p.commissionBp) / 10_000)),
  };
}
