/**
 * The Real Estate AI Business System is a team, not a CRM. Each member owns one slice of the work and the screen shows what they found.
 * `soon` = nothing behind it yet: shown as "Disponible próximamente", never as working.
 */
export interface REMember { key: string; role: "director" | "specialist"; soon?: boolean }
export const REAL_ESTATE_TEAM: readonly REMember[] = [
  { key: "real_estate_director", role: "director" }, { key: "property_manager", role: "specialist" }, { key: "listing_manager", role: "specialist" }, { key: "buyer_specialist", role: "specialist" },
  { key: "seller_specialist", role: "specialist" }, { key: "marketing_manager", role: "specialist" }, { key: "crm_manager", role: "specialist" }, { key: "follow_up_manager", role: "specialist" },
  { key: "appointment_manager", role: "specialist" }, { key: "document_manager", role: "specialist", soon: true }, { key: "analytics_manager", role: "specialist" },
];
export const REAL_ESTATE_KEYS: readonly string[] = REAL_ESTATE_TEAM.map((m) => m.key);
/** Bootstrap focus: what a starting agency works on first. Paid advertising is never part of it. */
export const BOOTSTRAP_FOCUS = ["captation", "content", "seo", "google_business", "social"] as const;
/** External systems the architecture is prepared for. Nothing is connected: every one is "coming soon". */
export const INTEGRATIONS = ["mls", "google_maps", "whatsapp", "google_calendar", "email"] as const;
