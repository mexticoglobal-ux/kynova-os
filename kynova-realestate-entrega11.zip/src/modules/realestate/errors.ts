export type RealEstateErrorCode = "forbidden" | "not_found" | "validation_failed" | "conflict" | "duplicate" | "invalid_state" | "limit_exceeded" | "unavailable" | "ai_unavailable" | "plan_required";
const STATUS: Record<RealEstateErrorCode, number> = { forbidden: 403, not_found: 404, validation_failed: 422, conflict: 409, duplicate: 409, invalid_state: 409, limit_exceeded: 403, unavailable: 503, ai_unavailable: 503, plan_required: 403 };
export class RealEstateError extends Error {
  readonly status: number;
  constructor(readonly code: RealEstateErrorCode, message: string, readonly details?: Record<string, unknown>) { super(message); this.name = "RealEstateError"; this.status = STATUS[code]; }
}
export const isRealEstateError = (e: unknown): e is RealEstateError => e instanceof RealEstateError || (typeof e === "object" && e !== null && (e as { name?: string }).name === "RealEstateError");
