/**
 * The Blueprint catalog. A Blueprint is a declarative definition (data, never code): which AI Business Systems it installs plus its own industry items.
 * Every item says in which version it appeared (`since`); upgrades only ADD what is new, so existing companies are never broken.
 * Marketplace items (integrations) are only declared here: the Marketplace installs them later. Nothing here calls a provider.
 */
export interface L { es: string; en: string }
export type Tier = "starter" | "business" | "enterprise";
interface Base { id: string; since?: string; paid?: boolean }
export interface ObjDef extends Base { employee: string; title: L; priority: number; metric?: string }
export interface AgendaDef extends Base { employee: string; objective?: string; title: L; instruction: L; everyDays: number; priority?: number }
export interface KpiDef extends Base { name: L; unit: "count" | "currency" | "percent"; target?: number }
export interface IntDef extends Base { name: L }
export interface RecDef extends Base { text: L }
export interface SkillDef2 extends Base { employee: string; skill: string }
export interface Content { employees: string[]; skills: SkillDef2[]; objectives: ObjDef[]; agenda: AgendaDef[]; kpis: KpiDef[]; integrations: IntDef[]; recommendations: RecDef[] }
export interface SystemDef extends Content { id: string; name: L; description: L; status: "available" | "planned" }
export interface HistoryEntry { version: string; breaking: boolean; notes: L }
export interface BlueprintDef extends Partial<Content> {
  id: string; name: L; industry: string; description: L; version: string; author: string; status: "official" | "beta"; tier: Tier;
  systems: { id: string; since?: string }[]; dependencies: string[]; growthObjective: "first_clients" | "sell_more" | "brand_awareness" | "leads" | "social_growth" | "youtube" | "other"; history: HistoryEntry[];
}
const l = (es: string, en: string): L => ({ es, en });
const empty: Content = { employees: [], skills: [], objectives: [], agenda: [], kpis: [], integrations: [], recommendations: [] };

/** Marketing & Growth (Entrega 9). The only AI Business System that exists today; the rest are declared so Blueprints can reference them and receive them through an upgrade once built. */
const MARKETING: SystemDef = {
  id: "marketing_growth", name: l("Marketing & Growth", "Marketing & Growth"), status: "available",
  description: l("Equipo que prepara el crecimiento: estrategia, contenido, SEO, comunicación y medición. Orgánico primero.", "Team that prepares growth: strategy, content, SEO, communication and measurement. Organic first."),
  employees: ["marketing_manager", "content_manager", "social_media_manager", "seo_manager", "analytics_manager", "communication_manager", "whatsapp_manager", "email_manager", "social_messaging_manager", "follow_up_manager"],
  skills: [{ id: "s1", employee: "seo_manager", skill: "seo" }, { id: "s2", employee: "email_manager", skill: "email_marketing" }, { id: "s3", employee: "analytics_manager", skill: "analytics" }, { id: "s4", employee: "marketing_manager", skill: "meta_ads", paid: true }, { id: "s5", employee: "marketing_manager", skill: "google_ads", paid: true }],
  objectives: [
    { id: "o1", employee: "marketing_manager", title: l("Conseguir los primeros clientes de forma orgánica", "Win the first customers organically"), priority: 1, metric: "customers" },
    { id: "o2", employee: "marketing_manager", title: l("Evaluar una inversión publicitaria pequeña con resultados reales", "Assess a small advertising investment with real results"), priority: 4, paid: true },
  ],
  agenda: [
    { id: "a1", employee: "content_manager", objective: "o1", title: l("Preparar el calendario de contenido", "Prepare the content calendar"), instruction: l("Prepara el calendario de contenido de las próximas 4 semanas con los canales prioritarios del plan.", "Prepare the next 4 weeks of content for the plan's priority channels."), everyDays: 28 },
    { id: "a2", employee: "analytics_manager", title: l("Revisión mensual de resultados", "Monthly results review"), instruction: l("Resume la inversión, ventas, leads y clientes del mes y recomienda el siguiente paso.", "Summarise the month's investment, sales, leads and customers and recommend the next step."), everyDays: 30 },
    { id: "a3", employee: "follow_up_manager", title: l("Seguimiento de contactos nuevos", "Follow up new contacts"), instruction: l("Prepara el seguimiento de los contactos nuevos de la semana.", "Prepare follow-up for this week's new contacts."), everyDays: 7 },
  ],
  kpis: [{ id: "k1", name: l("Clientes nuevos", "New customers"), unit: "count" }, { id: "k2", name: l("Leads", "Leads"), unit: "count" }, { id: "k3", name: l("ROI", "ROI"), unit: "count" }, { id: "k4", name: l("Costo por lead", "Cost per lead"), unit: "currency", paid: true }],
  integrations: [{ id: "i1", name: l("WhatsApp Business", "WhatsApp Business") }, { id: "i2", name: l("Google Business Profile", "Google Business Profile") }, { id: "i3", name: l("Meta Ads", "Meta Ads"), paid: true }, { id: "i4", name: l("Google Ads", "Google Ads"), paid: true }],
  recommendations: [{ id: "r1", text: l("Elige tu objetivo e inversión (puede ser $0) en Marketing & Growth.", "Choose your goal and investment (it can be $0) in Marketing & Growth.") }, { id: "r2", text: l("Registra los resultados del mes para medir tu ROI.", "Record this month's results to measure your ROI.") }],
};
/** Real Estate (Entrega 11). A team of AI Employees plus the system's own data; the module is src/modules/realestate. Organic first: nothing here needs paid advertising. */
const REAL_ESTATE: SystemDef = {
  id: "real_estate", name: l("Real Estate", "Real Estate"), status: "available",
  description: l("Propiedades, propietarios, compradores, agenda y publicaciones con un equipo especializado en bienes raíces.", "Properties, owners, buyers, agenda and publications run by a real estate specialist team."),
  employees: ["real_estate_director", "property_manager", "listing_manager", "buyer_specialist", "seller_specialist", "crm_manager", "follow_up_manager", "appointment_manager", "document_manager", "analytics_manager"],
  skills: [{ id: "s1", employee: "seller_specialist", skill: "prospecting" }, { id: "s2", employee: "crm_manager", skill: "pipeline_review" }, { id: "s3", employee: "analytics_manager", skill: "analytics" }],
  objectives: [
    { id: "o1", employee: "real_estate_director", title: l("Captar las primeras propiedades", "Win the first listings"), priority: 1, metric: "listings" },
    { id: "o2", employee: "buyer_specialist", title: l("Registrar y calificar compradores", "Register and qualify buyers"), priority: 2, metric: "buyers" },
  ],
  agenda: [
    { id: "a1", employee: "follow_up_manager", objective: "o2", title: l("Revisar clientes que necesitan seguimiento", "Review clients who need follow-up"), instruction: l("Lista los propietarios y compradores con próxima acción vencida.", "List owners and buyers whose next action is overdue."), everyDays: 3 },
    { id: "a2", employee: "listing_manager", title: l("Revisar propiedades sin actividad", "Review properties with no activity"), instruction: l("Señala las propiedades activas sin visitas ni compradores compatibles.", "Flag active properties with no visits or compatible buyers."), everyDays: 14 },
    { id: "a3", employee: "analytics_manager", title: l("Revisión mensual de indicadores", "Monthly KPI review"), instruction: l("Resume propiedades vendidas y alquiladas, tiempos de cierre, clientes nuevos e ingresos.", "Summarise properties sold and rented, closing times, new clients and income."), everyDays: 30 },
  ],
  kpis: [
    { id: "k1", name: l("Propiedades activas", "Active properties"), unit: "count" }, { id: "k2", name: l("Propiedades vendidas", "Properties sold"), unit: "count" }, { id: "k3", name: l("Propiedades alquiladas", "Properties rented"), unit: "count" },
    { id: "k4", name: l("Tiempo promedio de venta", "Average time to sell"), unit: "count" }, { id: "k5", name: l("Tiempo promedio de alquiler", "Average time to rent"), unit: "count" }, { id: "k6", name: l("Clientes nuevos", "New clients"), unit: "count" },
    { id: "k7", name: l("Conversión", "Conversion"), unit: "percent" }, { id: "k8", name: l("Ingresos", "Income"), unit: "currency" }, { id: "k9", name: l("Comisiones", "Commissions"), unit: "currency" },
  ],
  integrations: [{ id: "i1", name: l("MLS", "MLS") }, { id: "i2", name: l("Google Maps", "Google Maps") }, { id: "i3", name: l("WhatsApp", "WhatsApp") }, { id: "i4", name: l("Google Calendar", "Google Calendar") }, { id: "i5", name: l("Correo", "Email") }],
  recommendations: [{ id: "r1", text: l("Registra tu primera propiedad y tu primer propietario en Inmobiliaria.", "Register your first property and owner in Real Estate.") }, { id: "r2", text: l("Para empezar, enfócate en captación, contenido, SEO, Google Business y redes: sin publicidad pagada.", "To start, focus on prospecting, content, SEO, Google Business and social media: no paid advertising.") }],
};

const planned = (id: string, es: string, en: string): SystemDef => ({ ...empty, id, name: l(es, en), description: l("AI Business System independiente. Aún no construido: se instalará con una actualización.", "Independent AI Business System. Not built yet: it will arrive through an upgrade."), status: "planned" });
export const SYSTEMS: readonly SystemDef[] = [
  MARKETING, REAL_ESTATE, planned("youtube", "YouTube", "YouTube"), planned("ecommerce", "Ecommerce", "Ecommerce"), planned("sales_crm", "CRM & Ventas", "CRM & Sales"),
  planned("academy", "Academy", "Academy"), planned("marketplace_system", "Marketplace", "Marketplace"), planned("finance_system", "Finanzas", "Finance"), planned("hr_system", "Recursos Humanos", "Human Resources"),
];

interface Ind { id: string; es: string; en: string; des: string; den: string; tier?: Tier; obj: SalesObjective; employees?: string[]; goal: [string, string]; kpis: [string, string, "count" | "currency" | "percent"][]; ints: [string, string][]; rec: [string, string]; systems?: string[] }
type SalesObjective = BlueprintDef["growthObjective"];
const ind = (i: Ind): BlueprintDef => ({
  id: i.id, name: l(i.es, i.en), industry: i.id, description: l(i.des, i.den), version: "1.0.0", author: "KYNOVA", status: "official", tier: i.tier ?? "starter",
  systems: ["marketing_growth", ...(i.systems ?? [])].map((id) => ({ id })), dependencies: [], growthObjective: i.obj,
  employees: i.employees ?? [], skills: [], objectives: [{ id: "g1", employee: "marketing_manager", title: l(i.goal[0], i.goal[1]), priority: 2, metric: "customers" }],
  agenda: [], kpis: i.kpis.map(([es, en, unit], n) => ({ id: `k${n + 1}`, name: l(es, en), unit })), integrations: i.ints.map(([es, en], n) => ({ id: `i${n + 1}`, name: l(es, en) })), recommendations: [{ id: "r1", text: l(i.rec[0], i.rec[1]) }],
  history: [{ version: "1.0.0", breaking: false, notes: l("Primera versión.", "First version.") }],
});
export const BLUEPRINTS: readonly BlueprintDef[] = ([
  ind({ id: "kynova", es: "KYNOVA", en: "KYNOVA", des: "El Blueprint oficial con el que se opera KYNOVA.", den: "The official Blueprint KYNOVA itself runs on.", tier: "starter", obj: "leads", systems: ["youtube", "sales_crm", "academy", "marketplace_system", "finance_system"], employees: ["sales_manager", "customer_success_manager"], goal: ["Conseguir los primeros clientes de KYNOVA", "Win KYNOVA's first customers"], kpis: [["Empresas activas", "Active companies", "count"], ["Clientes de pago", "Paying customers", "count"], ["Retención", "Retention", "percent"]], ints: [["Stripe (Marketplace)", "Stripe (Marketplace)"]], rec: ["Registra a KYNOVA como primer cliente real: sin datos ficticios.", "Register KYNOVA as the first real customer: no made-up data."] }),
  ind({ id: "from_scratch", es: "Empresa desde cero", en: "Company from scratch", des: "Lo esencial para empezar: marketing orgánico y un asesor ejecutivo.", den: "The essentials to start: organic marketing and an executive advisor.", obj: "first_clients", employees: ["ceo_ai"], goal: ["Definir la oferta y conseguir el primer cliente", "Define the offer and win the first customer"], kpis: [["Clientes nuevos", "New customers", "count"], ["Ventas del mes", "Month sales", "currency"]], ints: [["WhatsApp Business", "WhatsApp Business"]], rec: ["Cuéntale a tu equipo qué vendes y a quién.", "Tell your team what you sell and to whom."] }),
  ind({ id: "real_estate", es: "Inmobiliaria", en: "Real estate", des: "Captación de propiedades, leads de compradores y seguimiento.", den: "Property listings, buyer leads and follow-up.", obj: "leads", systems: ["sales_crm"], employees: ["sales_manager", "lead_manager", "crm_manager", "proposal_manager"], goal: ["Captar propiedades y compradores", "Win listings and buyers"], kpis: [["Propiedades captadas", "Listings won", "count"], ["Visitas agendadas", "Viewings booked", "count"], ["Cierres", "Closed deals", "count"]], ints: [["MLS Connector (Marketplace)", "MLS Connector (Marketplace)"], ["DocuSign (Marketplace)", "DocuSign (Marketplace)"], ["WhatsApp Premium (Marketplace)", "WhatsApp Premium (Marketplace)"]], rec: ["Carga tus primeras propiedades para que el equipo prepare su difusión.", "Add your first listings so the team can prepare their promotion."] }),
  ind({ id: "ecommerce", es: "Ecommerce", en: "Ecommerce", des: "Tienda en línea: catálogo, ventas y recuperación de clientes.", den: "Online store: catalog, sales and customer recovery.", tier: "business", obj: "sell_more", systems: ["ecommerce"], employees: ["support_manager", "customer_success_manager"], goal: ["Aumentar las ventas de la tienda", "Increase store sales"], kpis: [["Pedidos", "Orders", "count"], ["Ticket promedio", "Average order", "currency"], ["Conversión", "Conversion", "percent"]], ints: [["Shopify (Marketplace)", "Shopify (Marketplace)"], ["Stripe (Marketplace)", "Stripe (Marketplace)"]], rec: ["Conecta tu tienda desde el Marketplace cuando lo decidas.", "Connect your store from the Marketplace when you decide."] }),
  ind({ id: "restaurant", es: "Restaurante", en: "Restaurant", des: "Reservas, reseñas y promociones locales.", den: "Bookings, reviews and local promotions.", obj: "first_clients", employees: ["support_manager"], goal: ["Llenar mesas entre semana", "Fill tables on weekdays"], kpis: [["Reservas", "Bookings", "count"], ["Reseñas nuevas", "New reviews", "count"]], ints: [["Google Business Profile", "Google Business Profile"], ["WhatsApp Business", "WhatsApp Business"]], rec: ["Completa tu perfil de Google Business con fotos y horario.", "Complete your Google Business profile with photos and hours."] }),
  ind({ id: "clinic", es: "Clínica", en: "Clinic", des: "Citas, recordatorios y reputación local.", den: "Appointments, reminders and local reputation.", obj: "leads", employees: ["support_manager", "customer_success_manager"], goal: ["Aumentar las citas nuevas", "Increase new appointments"], kpis: [["Citas nuevas", "New appointments", "count"], ["Asistencia", "Attendance", "percent"]], ints: [["Google Business Profile", "Google Business Profile"], ["Calendario de citas (Marketplace)", "Appointment calendar (Marketplace)"]], rec: ["Define los servicios y horarios que quieres promover.", "Define the services and hours you want to promote."] }),
  ind({ id: "hotel", es: "Hotel", en: "Hotel", des: "Ocupación, reservas directas y reseñas.", den: "Occupancy, direct bookings and reviews.", tier: "business", obj: "sell_more", employees: ["support_manager", "customer_success_manager"], goal: ["Aumentar las reservas directas", "Increase direct bookings"], kpis: [["Ocupación", "Occupancy", "percent"], ["Reservas directas", "Direct bookings", "count"]], ints: [["Motor de reservas (Marketplace)", "Booking engine (Marketplace)"], ["Google Business Profile", "Google Business Profile"]], rec: ["Indica tus temporadas altas y bajas.", "Tell us your high and low seasons."] }),
  ind({ id: "law_firm", es: "Abogado", en: "Law firm", des: "Captación de consultas y seguimiento de casos.", den: "Inquiry intake and case follow-up.", obj: "leads", employees: ["legal_assistant", "contract_manager", "lead_manager"], goal: ["Captar consultas calificadas", "Win qualified inquiries"], kpis: [["Consultas", "Inquiries", "count"], ["Casos nuevos", "New cases", "count"]], ints: [["DocuSign (Marketplace)", "DocuSign (Marketplace)"]], rec: ["Define tus áreas de práctica para orientar el contenido.", "Define your practice areas to guide the content."] }),
  ind({ id: "architecture", es: "Arquitectura", en: "Architecture", des: "Portafolio, propuestas y clientes de proyecto.", den: "Portfolio, proposals and project clients.", obj: "brand_awareness", employees: ["proposal_manager", "brand_manager"], goal: ["Posicionar el portafolio y recibir solicitudes", "Position the portfolio and receive requests"], kpis: [["Solicitudes de proyecto", "Project requests", "count"], ["Propuestas enviadas", "Proposals sent", "count"]], ints: [["Canva (Marketplace)", "Canva (Marketplace)"]], rec: ["Sube tus proyectos reales: el equipo no inventa portafolio.", "Add your real projects: the team never invents a portfolio."] }),
  ind({ id: "marketing", es: "Marketing", en: "Marketing", des: "Para negocios de marketing que operan su propio crecimiento.", den: "For marketing businesses running their own growth.", obj: "leads", employees: ["ads_manager", "brand_manager"], goal: ["Conseguir clientes para el servicio de marketing", "Win clients for the marketing service"], kpis: [["Leads", "Leads", "count"], ["Clientes nuevos", "New customers", "count"]], ints: [["Canva (Marketplace)", "Canva (Marketplace)"]], rec: ["Muestra casos reales de clientes (con permiso).", "Show real client cases (with permission)."] }),
  ind({ id: "agency", es: "Agencia", en: "Agency", des: "Agencia con varios clientes: captación, propuestas y reportes.", den: "Multi-client agency: intake, proposals and reports.", tier: "business", obj: "leads", systems: ["sales_crm"], employees: ["proposal_manager", "analytics_advisor", "ads_manager"], goal: ["Captar cuentas nuevas y retener las actuales", "Win new accounts and keep current ones"], kpis: [["Cuentas activas", "Active accounts", "count"], ["Retención", "Retention", "percent"]], ints: [["Canva (Marketplace)", "Canva (Marketplace)"], ["Stripe (Marketplace)", "Stripe (Marketplace)"]], rec: ["Define tus servicios y precios de referencia.", "Define your services and reference prices."] }),
  ind({ id: "construction", es: "Constructora", en: "Construction", des: "Licitaciones, cotizaciones y avance de obras.", den: "Bids, quotes and project progress.", tier: "business", obj: "leads", employees: ["proposal_manager", "contract_manager", "finance_manager"], goal: ["Captar proyectos y cotizar a tiempo", "Win projects and quote on time"], kpis: [["Cotizaciones", "Quotes", "count"], ["Proyectos ganados", "Projects won", "count"]], ints: [["DocuSign (Marketplace)", "DocuSign (Marketplace)"]], rec: ["Carga tus obras terminadas como referencias.", "Add your finished works as references."] }),
  ind({ id: "consulting", es: "Consultoría", en: "Consulting", des: "Autoridad, captación de reuniones y propuestas.", den: "Authority, meeting intake and proposals.", obj: "leads", employees: ["proposal_manager", "lead_manager"], goal: ["Agendar reuniones con clientes ideales", "Book meetings with ideal clients"], kpis: [["Reuniones", "Meetings", "count"], ["Propuestas ganadas", "Proposals won", "count"]], ints: [["Calendario (Marketplace)", "Calendar (Marketplace)"]], rec: ["Define tu cliente ideal en una frase.", "Define your ideal client in one sentence."] }),
] as BlueprintDef[]).map((b) => REAL_ESTATE_BP(b));
function REAL_ESTATE_BP(b: BlueprintDef): BlueprintDef { // hoisted: BLUEPRINTS uses it above
  return b.id !== "real_estate" ? b : {
  ...b, version: "1.1.0", systems: [...b.systems.filter((x) => x.id !== "sales_crm"), { id: "real_estate", since: "1.1.0" }, { id: "sales_crm" }],
  history: [...b.history, { version: "1.1.0", breaking: false, notes: l("Agrega el AI Business System de Real Estate.", "Adds the Real Estate AI Business System.") }],
  };
}
export const BLUEPRINT_BY_ID: ReadonlyMap<string, BlueprintDef> = new Map(BLUEPRINTS.map((b) => [b.id, b]));
export const SYSTEM_BY_ID: ReadonlyMap<string, SystemDef> = new Map(SYSTEMS.map((s) => [s.id, s]));
export const emptyContent = empty;
