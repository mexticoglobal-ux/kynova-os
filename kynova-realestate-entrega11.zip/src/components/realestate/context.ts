import { redirect } from "next/navigation";
import { requireModuleAccess } from "@/platform/auth/session";
import { getRealEstateService, tr, realEstateLocale, type Actor, type RealEstateKey } from "@/modules/realestate";

/** Server-side context of the RealEstate pages: verified session, actor, service and translator. The tenant always comes from the session. */
export async function realestateContext() {
  const s = await requireModuleAccess("realestate");
  if (!s.tenantId) redirect("/app/profile");
  const actor: Actor = { tenantId: s.tenantId, userId: s.user.id, role: s.role };
  const locale = realEstateLocale(s.user.locale);
  return { actor, locale, svc: await getRealEstateService(), t: (k: RealEstateKey, v?: Record<string, string | number>) => tr(locale, k, v) };
}
