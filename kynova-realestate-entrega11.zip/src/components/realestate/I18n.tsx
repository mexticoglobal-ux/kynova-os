"use client";
import { createContext, useCallback, useContext, type ReactNode } from "react";
import type { RealEstateKey } from "@/modules/realestate/i18n";

const Ctx = createContext<{ dict: Record<RealEstateKey, string>; locale: string } | null>(null);
export function RealEstateI18n({ dict, locale, children }: { dict: Record<RealEstateKey, string>; locale: string; children: ReactNode }) { return <Ctx.Provider value={{ dict, locale }}>{children}</Ctx.Provider>; }
export function useT() {
  const c = useContext(Ctx);
  const t = useCallback((key: RealEstateKey, vars: Record<string, string | number> = {}) => (c?.dict[key] ?? key).replace(/\{(\w+)\}/g, (_m, k: string) => String(vars[k] ?? "")), [c]);
  return { t, locale: c?.locale ?? "en" };
}
