"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { wfCall } from "@/components/workforce/api";
import type { RealEstateKey } from "@/modules/realestate/i18n";
import { useT } from "./I18n";

const btn = "rounded-lg border border-line px-2.5 py-1 text-xs hover:bg-ac/10 disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-ac2";
const primary = "rounded-lg bg-ac px-3 py-1.5 text-sm font-medium text-white disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ac2";
const field = "w-full rounded-lg border border-line bg-transparent px-3 py-2 text-sm focus-visible:outline-2 focus-visible:outline-ac2";
function useRun() {
  const router = useRouter(), { t } = useT(), [busy, setBusy] = useState(false), [err, setErr] = useState<string | null>(null);
  async function run(fn: () => ReturnType<typeof wfCall>, after?: () => void) {
    setBusy(true); setErr(null); const r = await fn(); setBusy(false);
    if (!r.ok) { setErr(r.status === 503 ? t("common.error") : r.message ?? t("common.error")); return; }
    after?.(); router.refresh();
  }
  return { busy, err, run };
}
const Err = ({ err }: { err: string | null }) => <p role="status" aria-live="polite" className="text-xs text-rose-700 dark:text-rose-300">{err}</p>;

/** `money` is typed in whole units and sent in minor units; `datetime` is sent as epoch ms; `list` is split on commas. */
export type FieldSpec = { name: string; label: RealEstateKey | string; type: "text" | "number" | "money" | "datetime" | "list" | "select"; options?: { value: string; label: string }[]; required?: boolean };
export function QuickForm({ path, fields, fixed = {}, submit }: { path: string; fields: FieldSpec[]; fixed?: Record<string, unknown>; submit?: RealEstateKey }) {
  const { t } = useT(), { busy, err, run } = useRun(), [v, setV] = useState<Record<string, string>>({});
  const lab = (l: string) => (l.includes(".") ? t(l as RealEstateKey) : l);
  function body() {
    const o: Record<string, unknown> = { ...fixed };
    for (const f of fields) {
      const x = (v[f.name] ?? "").trim(); if (!x && !f.required) continue;
      o[f.name] = f.type === "money" ? Math.round(Number(x) * 100) : f.type === "number" ? Number(x) : f.type === "datetime" ? new Date(x).getTime() : f.type === "list" ? x.split(",").map((s) => s.trim()).filter(Boolean) : x;
    }
    return o;
  }
  return (
    <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); void run(() => wfCall("POST", path, body()), () => setV({})); }}>
      {fields.map((f) => (
        <label key={f.name} className="grid min-w-32 flex-1 gap-1 text-xs text-muted">{lab(f.label)}
          {f.type === "select" ? <select className={field} value={v[f.name] ?? f.options?.[0]?.value ?? ""} onChange={(e) => setV({ ...v, [f.name]: e.target.value })}>{f.options?.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select>
            : <input className={field} type={f.type === "datetime" ? "datetime-local" : f.type === "number" || f.type === "money" ? "number" : "text"} min={f.type === "text" || f.type === "list" || f.type === "datetime" ? undefined : 0} step="any" required={f.required} value={v[f.name] ?? ""} onChange={(e) => setV({ ...v, [f.name]: e.target.value })} />}
        </label>))}
      <button type="submit" className={primary} disabled={busy}>{busy ? t("common.saving") : t(submit ?? "common.add")}</button><Err err={err} />
    </form>
  );
}
/** One-click PATCH/POST action (status changes, approvals). `ask` asks for the real closing price first. */
export function ActionButton({ method = "PATCH", path, body, label, ask }: { method?: "PATCH" | "POST"; path: string; body: Record<string, unknown>; label: string; ask?: RealEstateKey }) {
  const { t } = useT(), { busy, err, run } = useRun(), [price, setPrice] = useState(""), [open, setOpen] = useState(false);
  const send = () => run(() => wfCall(method, path, ask ? { ...body, closedPriceMinor: Math.round(Number(price) * 100) } : body), () => setOpen(false));
  return (
    <span className="inline-flex flex-wrap items-center gap-1">
      {ask && open ? <><input className={`${field} w-32 !py-1`} aria-label={t(ask)} placeholder={t(ask)} type="number" min="0" step="any" value={price} onChange={(e) => setPrice(e.target.value)} /><button type="button" className={btn} disabled={busy || !(Number(price) > 0)} onClick={() => void send()}>{label}</button></>
        : <button type="button" className={btn} disabled={busy} onClick={() => (ask ? setOpen(true) : void send())}>{label}</button>}
      <Err err={err} />
    </span>
  );
}
export function PrepareForm({ properties, channels, locale }: { properties: { id: string; title: string }[]; channels: { value: string; label: string }[]; locale: string }) {
  const { t } = useT(), { busy, err, run } = useRun(), [pid, setPid] = useState(properties[0]?.id ?? ""), [sel, setSel] = useState<string[]>(["facebook", "instagram"]);
  const toggle = (c: string) => setSel(sel.includes(c) ? sel.filter((x) => x !== c) : [...sel, c]);
  return (
    <form className="flex flex-wrap items-end gap-3" onSubmit={(e) => { e.preventDefault(); void run(() => wfCall("POST", "/realestate/publications/prepare", { propertyId: pid, channels: sel, locale })); }}>
      <label className="grid min-w-48 gap-1 text-xs text-muted">{t("pub.property")}<select className={field} value={pid} onChange={(e) => setPid(e.target.value)}>{properties.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}</select></label>
      <fieldset className="flex flex-wrap gap-3 text-sm">{channels.map((c) => <label key={c.value} className="flex items-center gap-1"><input type="checkbox" checked={sel.includes(c.value)} onChange={() => toggle(c.value)} />{c.label}</label>)}</fieldset>
      <button type="submit" className={primary} disabled={busy || !pid || sel.length === 0}>{t("pub.prepare")}</button><Err err={err} />
    </form>
  );
}
