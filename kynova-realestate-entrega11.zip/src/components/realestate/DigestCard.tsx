import { Card, Empty } from "@/components/workforce/ui";
import type { RealEstateKey } from "@/modules/realestate";

export type DigestData = { items: { employee: string; key: string; count: number; subjects: { label: string }[] }[] };
/** "Mientras estabas fuera…": every line is a real count from the company's data, attributed to the AI Employee who owns that slice. */
export function RealEstateDigest({ digest, t, names }: { digest: DigestData; t: (k: RealEstateKey, v?: Record<string, number | string>) => string; names: Record<string, string> }) {
  return (
    <Card title={t("digest.title")}>
      {digest.items.length === 0 ? <Empty>{t("digest.none")}</Empty> : (
        <ul className="grid gap-2 text-sm">{digest.items.map((i) => (
          <li key={i.key} className="rounded-lg border border-line px-3 py-2"><p><strong>{names[i.employee] ?? i.employee}:</strong> {t(`d.${i.key}` as RealEstateKey, { n: i.count })}</p>
            <p className="text-xs text-muted">{i.subjects.map((s) => s.label).join(" · ")}</p></li>))}</ul>)}
    </Card>
  );
}
