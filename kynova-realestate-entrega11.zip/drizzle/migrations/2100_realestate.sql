-- Real Estate AI Business System V1 (Entrega 11). Owned by src/modules/realestate.
-- Tenant-owned: tenant_id references companies and every index leads with tenant_id. Nothing is deleted (archive / lost / cancelled instead).

CREATE TABLE `re_owners` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `name` text NOT NULL, `phone` text DEFAULT '' NOT NULL, `email` text DEFAULT '' NOT NULL, `source` text DEFAULT '' NOT NULL, `stage` text DEFAULT 'new' NOT NULL,
	`next_action` text DEFAULT '' NOT NULL, `next_action_at` integer, `notes` text DEFAULT '' NOT NULL, `created_by` text NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`stage` IN ('new', 'contacted', 'meeting', 'mandate', 'lost'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `re_owners_tenant_id_uq` ON `re_owners` (`tenant_id`,`id`);--> statement-breakpoint
CREATE INDEX `re_owners_stage_idx` ON `re_owners` (`tenant_id`,`stage`,`created_at`);--> statement-breakpoint
CREATE TABLE `re_properties` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `title` text NOT NULL, `operation` text NOT NULL, `kind` text DEFAULT 'house' NOT NULL, `status` text DEFAULT 'active' NOT NULL, `price_minor` integer NOT NULL,
	`currency` text DEFAULT 'USD' NOT NULL, `zone` text DEFAULT '' NOT NULL, `address` text DEFAULT '' NOT NULL, `bedrooms` integer DEFAULT 0 NOT NULL, `bathrooms` integer DEFAULT 0 NOT NULL, `area_m2` integer DEFAULT 0 NOT NULL,
	`description` text DEFAULT '' NOT NULL, `owner_id` text, `commission_bp` integer DEFAULT 300 NOT NULL, `listed_at` integer NOT NULL, `closed_at` integer, `closed_price_minor` integer, `commission_minor` integer,
	`created_by` text NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`tenant_id`, `owner_id`) REFERENCES `re_owners`(`tenant_id`, `id`) ON UPDATE no action ON DELETE no action,
	CHECK (`operation` IN ('sale', 'rent')), CHECK (`kind` IN ('house', 'apartment', 'land', 'commercial', 'other')), CHECK (`status` IN ('active', 'reserved', 'sold', 'rented', 'archived')),
	CHECK (`price_minor` >= 0), CHECK (`commission_bp` BETWEEN 0 AND 10000), CHECK (length(`currency`) = 3),
	CHECK ((`status` IN ('sold', 'rented')) = (`closed_at` IS NOT NULL) OR `status` = 'archived')
);
--> statement-breakpoint
CREATE UNIQUE INDEX `re_properties_tenant_id_uq` ON `re_properties` (`tenant_id`,`id`);--> statement-breakpoint
CREATE INDEX `re_properties_status_idx` ON `re_properties` (`tenant_id`,`status`,`created_at`);--> statement-breakpoint
CREATE TABLE `re_buyers` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `name` text NOT NULL, `phone` text DEFAULT '' NOT NULL, `email` text DEFAULT '' NOT NULL, `intent` text DEFAULT 'sale' NOT NULL, `budget_min_minor` integer DEFAULT 0 NOT NULL,
	`budget_max_minor` integer DEFAULT 0 NOT NULL, `currency` text DEFAULT 'USD' NOT NULL, `zones` text DEFAULT '[]' NOT NULL, `kinds` text DEFAULT '[]' NOT NULL, `bedrooms_min` integer DEFAULT 0 NOT NULL, `stage` text DEFAULT 'new' NOT NULL,
	`next_action` text DEFAULT '' NOT NULL, `next_action_at` integer, `notes` text DEFAULT '' NOT NULL, `created_by` text NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`intent` IN ('sale', 'rent')), CHECK (`stage` IN ('new', 'contacted', 'searching', 'visiting', 'negotiating', 'won', 'lost')),
	CHECK (`budget_min_minor` >= 0), CHECK (`budget_max_minor` = 0 OR `budget_max_minor` >= `budget_min_minor`), CHECK (length(`currency`) = 3)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `re_buyers_tenant_id_uq` ON `re_buyers` (`tenant_id`,`id`);--> statement-breakpoint
CREATE INDEX `re_buyers_stage_idx` ON `re_buyers` (`tenant_id`,`stage`,`created_at`);--> statement-breakpoint
CREATE TABLE `re_activities` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `kind` text NOT NULL, `title` text NOT NULL, `when_at` integer NOT NULL, `status` text DEFAULT 'planned' NOT NULL, `property_id` text, `buyer_id` text, `owner_id` text,
	`notes` text DEFAULT '' NOT NULL, `created_by` text NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`tenant_id`, `property_id`) REFERENCES `re_properties`(`tenant_id`, `id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`tenant_id`, `buyer_id`) REFERENCES `re_buyers`(`tenant_id`, `id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`tenant_id`, `owner_id`) REFERENCES `re_owners`(`tenant_id`, `id`) ON UPDATE no action ON DELETE no action,
	CHECK (`kind` IN ('visit', 'open_house', 'call', 'follow_up', 'reminder')), CHECK (`status` IN ('planned', 'done', 'cancelled'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `re_activities_tenant_id_uq` ON `re_activities` (`tenant_id`,`id`);--> statement-breakpoint
CREATE INDEX `re_activities_when_idx` ON `re_activities` (`tenant_id`,`when_at`,`status`);--> statement-breakpoint
CREATE TABLE `re_publications` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `property_id` text NOT NULL, `channel` text NOT NULL, `title` text NOT NULL, `body` text NOT NULL, `status` text DEFAULT 'proposed' NOT NULL, `outcome` text DEFAULT '' NOT NULL,
	`ref_id` text, `prepared_by` text NOT NULL, `decided_by` text, `decided_at` integer, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`tenant_id`, `property_id`) REFERENCES `re_properties`(`tenant_id`, `id`) ON UPDATE no action ON DELETE no action,
	CHECK (`channel` IN ('facebook', 'instagram', 'linkedin', 'whatsapp', 'email')), CHECK (`status` IN ('proposed', 'approved', 'rejected')), CHECK (`outcome` IN ('', 'draft_created', 'prepared')),
	CHECK ((`status` = 'proposed') = (`decided_at` IS NULL))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `re_publications_tenant_id_uq` ON `re_publications` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `re_publications_property_channel_uq` ON `re_publications` (`tenant_id`,`property_id`,`channel`);--> statement-breakpoint
CREATE INDEX `re_publications_status_idx` ON `re_publications` (`tenant_id`,`status`,`created_at`);--> statement-breakpoint
CREATE TRIGGER re_owners_frozen BEFORE UPDATE OF tenant_id ON re_owners BEGIN SELECT RAISE(ABORT, 'real estate owner tenant cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER re_properties_frozen BEFORE UPDATE OF tenant_id ON re_properties BEGIN SELECT RAISE(ABORT, 'real estate property tenant cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER re_buyers_frozen BEFORE UPDATE OF tenant_id ON re_buyers BEGIN SELECT RAISE(ABORT, 'real estate buyer tenant cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER re_activities_frozen BEFORE UPDATE OF tenant_id ON re_activities BEGIN SELECT RAISE(ABORT, 'real estate activity tenant cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER re_publications_frozen BEFORE UPDATE OF tenant_id, property_id, channel ON re_publications BEGIN SELECT RAISE(ABORT, 'real estate publication identity cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER re_publications_decided_once BEFORE UPDATE OF status ON re_publications WHEN OLD.status <> 'proposed' AND NEW.status <> OLD.status BEGIN SELECT RAISE(ABORT, 'a decided publication cannot be decided again'); END;
--> statement-breakpoint
CREATE TRIGGER re_owners_no_delete BEFORE DELETE ON re_owners BEGIN SELECT RAISE(ABORT, 're_owners rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER re_properties_no_delete BEFORE DELETE ON re_properties BEGIN SELECT RAISE(ABORT, 're_properties rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER re_buyers_no_delete BEFORE DELETE ON re_buyers BEGIN SELECT RAISE(ABORT, 're_buyers rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER re_activities_no_delete BEFORE DELETE ON re_activities BEGIN SELECT RAISE(ABORT, 're_activities rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER re_publications_no_delete BEFORE DELETE ON re_publications BEGIN SELECT RAISE(ABORT, 're_publications rows cannot be deleted'); END;
