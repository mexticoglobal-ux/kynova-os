import { redirect } from "next/navigation";
import { requireModuleAccess } from "@/platform/auth/session";
import { getGrowthService, tr, growthLocale, type Actor, type GrowthKey } from "@/modules/growth";

/** Server-side context of the Growth page: verified session, actor, service and translator. The tenant always comes from the session. */
export async function growthContext() {
  const s = await requireModuleAccess("growth");
  if (!s.tenantId) redirect("/app/profile");
  const actor: Actor = { tenantId: s.tenantId, userId: s.user.id, role: s.role };
  const locale = growthLocale(s.user.locale);
  return { actor, locale, svc: await getGrowthService(), t: (k: GrowthKey, v?: Record<string, string | number>) => tr(locale, k, v) };
}
export const money = (minor: number, currency: string, locale: string) => new Intl.NumberFormat(locale, { style: "currency", currency, maximumFractionDigits: minor % 100 === 0 ? 0 : 2 }).format(minor / 100);
