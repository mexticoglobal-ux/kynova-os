"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { wfCall } from "@/components/workforce/api";
import { useT } from "./I18n";
import type { GrowthKey } from "@/modules/growth/i18n";

const btn = "rounded-lg border border-line px-3 py-1.5 text-sm hover:bg-ac/10 disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-ac2";
const primary = "rounded-lg bg-ac px-3 py-1.5 text-sm font-medium text-white disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ac2";
const field = "w-full rounded-lg border border-line bg-transparent px-3 py-2 text-sm focus-visible:outline-2 focus-visible:outline-ac2";
const OBJECTIVES = ["first_clients", "sell_more", "brand_awareness", "leads", "social_growth", "youtube", "other"] as const;
const SCENARIOS = ["entrepreneur", "growth", "scaling", "enterprise"] as const;

function useRun() {
  const router = useRouter(), { t } = useT(), [busy, setBusy] = useState(false), [err, setErr] = useState<string | null>(null);
  async function run(fn: () => ReturnType<typeof wfCall>, after?: () => void) {
    setBusy(true); setErr(null); const r = await fn(); setBusy(false);
    if (!r.ok) { setErr(r.status === 503 ? t("common.error") : r.message ?? t("common.error")); return false; }
    after?.(); router.refresh(); return true;
  }
  return { busy, err, run };
}
const Err = ({ err }: { err: string | null }) => <p role="status" aria-live="polite" className="text-xs text-rose-700 dark:text-rose-300">{err}</p>;
const fmt = (minor: number, cur: string, locale: string) => new Intl.NumberFormat(locale, { style: "currency", currency: cur, maximumFractionDigits: 0 }).format(minor / 100);

type Scenario = { scenario: (typeof SCENARIOS)[number]; amountMinor: number };

/** Objective first, then investment: recommended scenarios are reference points; the amount box accepts anything, including $0. */
export function PlanForm({ initial, currency }: { initial: { objective: string; note: string; investmentMinor: number } | null; currency: string }) {
  const { t, locale } = useT(), { busy, err, run } = useRun();
  const [objective, setObjective] = useState(initial?.objective ?? ""), [note, setNote] = useState(initial?.note ?? ""), [amount, setAmount] = useState(initial ? String(initial.investmentMinor / 100) : "");
  const [scenario, setScenario] = useState<string>("custom"), [scenarios, setScenarios] = useState<Scenario[]>([]);
  async function pick(o: string) {
    setObjective(o); setScenarios([]);
    const r = await wfCall<{ scenarios: Scenario[] }>("GET", `/growth/recommendation?objective=${o}`);
    if (r.ok && r.data) setScenarios(r.data.scenarios);
  }
  const valid = objective && amount.trim() !== "" && Number(amount) >= 0 && (objective !== "other" || note.trim());
  return (
    <form className="grid gap-4" onSubmit={(e) => { e.preventDefault(); void run(() => wfCall("PUT", "/growth/plan", { objective, objectiveNote: note, investmentMinor: Math.round(Number(amount) * 100), currency, scenario })); }}>
      <fieldset className="grid gap-2"><legend className="mb-1 text-sm font-semibold">{t("q.objective")}</legend>
        <div className="flex flex-wrap gap-2">{OBJECTIVES.map((o) => <button key={o} type="button" aria-pressed={objective === o} onClick={() => void pick(o)} className={`${btn} ${objective === o ? "border-ac bg-ac/10 font-medium" : ""}`}>{t(`obj.${o}` as GrowthKey)}</button>)}</div>
        {objective === "other" && <label className="grid gap-1 text-xs text-muted">{t("obj.note")}<input className={field} value={note} maxLength={200} onChange={(e) => setNote(e.target.value)} required /></label>}
      </fieldset>
      {objective && (
        <section className="grid gap-2" aria-label={t("inv.reco")}>
          <h3 className="text-sm font-semibold">{t("inv.reco")}</h3><p className="text-xs text-muted">{t("inv.recoNote")}</p>
          <ul className="grid gap-2 sm:grid-cols-2 xl:grid-cols-4">{scenarios.map((s) => (
            <li key={s.scenario} className="grid gap-1 rounded-xl border border-line p-3"><span className="text-sm font-medium">{t(`inv.s.${s.scenario}` as GrowthKey)}</span><span className="text-lg font-bold tabular-nums">{fmt(s.amountMinor, currency, locale)}</span>
              <button type="button" className={btn} onClick={() => { setAmount(String(s.amountMinor / 100)); setScenario(s.scenario); }}>{t("inv.use")}</button></li>))}</ul>
        </section>)}
      <label className="grid max-w-xs gap-1 text-sm font-medium">{t("inv.free")}
        <span className="flex items-center gap-1"><span aria-hidden="true">$</span><input className={field} inputMode="decimal" min="0" step="any" type="number" value={amount} onChange={(e) => { setAmount(e.target.value); setScenario("custom"); }} required /></span>
        <span className="text-xs font-normal text-muted">{t("inv.freeHint")}</span></label>
      <div className="flex flex-wrap items-center gap-3"><button type="submit" className={primary} disabled={busy || !valid}>{busy ? t("common.saving") : t("inv.save")}</button><Err err={err} /></div>
    </form>
  );
}
export function GenerateButton() {
  const { t } = useT(), { busy, err, run } = useRun();
  return <div className="grid gap-1"><button type="button" className={primary} disabled={busy} onClick={() => void run(() => wfCall("POST", "/growth/proposals/generate", {}))}>{busy ? t("prop.generating") : t("prop.generate")}</button><Err err={err} /></div>;
}
export function DecisionButtons({ id }: { id: string }) {
  const { t } = useT(), { busy, err, run } = useRun();
  return <div className="grid gap-1"><div className="flex gap-2">
    <button type="button" className={primary} disabled={busy} onClick={() => void run(() => wfCall("POST", `/growth/proposals/${id}/decision`, { approve: true }))}>{t("act.approve")}</button>
    <button type="button" className={btn} disabled={busy} onClick={() => void run(() => wfCall("POST", `/growth/proposals/${id}/decision`, { approve: false }))}>{t("act.reject")}</button></div><Err err={err} /></div>;
}
export function ReviewButton({ period }: { period: string }) {
  const { t } = useT(), { busy, err, run } = useRun();
  return <div className="grid gap-1"><button type="button" className={btn} disabled={busy} onClick={() => void run(() => wfCall("POST", "/growth/reviews", { period }))}>{t("roi.review")}</button><Err err={err} /></div>;
}
export function ResultForm({ period, currency }: { period: string; currency: string }) {
  const { t } = useT(), { busy, err, run } = useRun(), [v, setV] = useState({ investment: "", sales: "", leads: "", customers: "" });
  const set = (k: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement>) => setV({ ...v, [k]: e.target.value });
  const cell = (k: keyof typeof v, label: GrowthKey) => <label className="grid gap-1 text-xs text-muted">{t(label)}<input className={field} type="number" min="0" step="any" inputMode="decimal" value={v[k]} onChange={set(k)} /></label>;
  return (
    <form className="grid gap-3" onSubmit={(e) => { e.preventDefault(); void run(() => wfCall("PUT", "/growth/results", { period, investmentMinor: Math.round(Number(v.investment || 0) * 100), salesMinor: Math.round(Number(v.sales || 0) * 100), leads: Math.round(Number(v.leads || 0)), customers: Math.round(Number(v.customers || 0)), currency }), () => setV({ investment: "", sales: "", leads: "", customers: "" })); }}>
      <p className="text-sm font-medium">{t("roi.record")} · {period}</p>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">{cell("investment", "roi.investment")}{cell("sales", "roi.sales")}{cell("leads", "roi.leads")}{cell("customers", "roi.customers")}</div>
      <div className="flex items-center gap-3"><button type="submit" className={primary} disabled={busy}>{busy ? t("common.saving") : t("common.save")}</button><Err err={err} /></div>
    </form>
  );
}
