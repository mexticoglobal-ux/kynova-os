import { AD_NETWORKS, BOOTSTRAP_BELOW_MINOR, SCENARIOS, type AdNetwork, type GrowthObjective, type OrganicChannel, type Scenario } from "./domain";

/**
 * Deterministic planning: reference scenarios, channel priorities, calendar skeleton and the month review. No model is involved and nothing here
 * invents a result: every number comes from the company's own recorded data or from the reference table below, which is labelled "referencial".
 */
/** Reference monthly investment per scenario, in USD cents. A starting point to compare, never a requirement. */
export const SCENARIO_BASE: Record<Scenario, number> = { entrepreneur: 15_000, growth: 50_000, scaling: 150_000, enterprise: 500_000 };
const OBJECTIVE_FACTOR: Record<GrowthObjective, number> = { first_clients: 0.7, sell_more: 1, brand_awareness: 1.2, leads: 1, social_growth: 0.6, youtube: 0.6, other: 1 };
const round = (minor: number) => Math.max(1000, Math.round(minor / 1000) * 1000);

export const PRIORITY_CHANNELS: Record<GrowthObjective, readonly OrganicChannel[]> = {
  first_clients: ["google_business", "whatsapp", "instagram", "seo", "email"], sell_more: ["email", "whatsapp", "instagram", "seo", "blog"],
  brand_awareness: ["instagram", "tiktok", "youtube", "blog", "seo"], leads: ["seo", "blog", "email", "whatsapp", "google_business"],
  social_growth: ["instagram", "tiktok", "facebook", "youtube"], youtube: ["youtube", "tiktok", "instagram", "seo"], other: ["seo", "instagram", "email", "whatsapp"],
};
export const PAID_NETWORKS: Record<GrowthObjective, readonly AdNetwork[]> = {
  first_clients: ["meta_ads", "google_ads"], sell_more: ["meta_ads", "google_ads"], brand_awareness: ["meta_ads", "tiktok_ads", "youtube_ads"], leads: ["google_ads", "meta_ads", "linkedin_ads"],
  social_growth: ["meta_ads", "tiktok_ads"], youtube: ["youtube_ads"], other: ["meta_ads"],
};
export const FORMAT: Record<OrganicChannel, string> = { seo: "page", blog: "article", instagram: "reel", facebook: "post", tiktok: "short_video", youtube: "short", linkedin: "post", google_business: "update", whatsapp: "message", email: "newsletter" };
export const isBootstrap = (investmentMinor: number): boolean => investmentMinor < BOOTSTRAP_BELOW_MINOR;

export interface ScenarioOption { scenario: Scenario; amountMinor: number; networks: AdNetwork[]; channels: OrganicChannel[] }
/** Four scenarios adapted to the objective. The client may ignore all of them and type any amount. */
export function scenariosFor(objective: GrowthObjective): ScenarioOption[] {
  return SCENARIOS.map((scenario) => ({
    scenario, amountMinor: round(SCENARIO_BASE[scenario] * OBJECTIVE_FACTOR[objective]),
    networks: scenario === "entrepreneur" ? PAID_NETWORKS[objective].slice(0, 1) : scenario === "growth" ? PAID_NETWORKS[objective].slice(0, 2) : [...PAID_NETWORKS[objective]],
    channels: [...PRIORITY_CHANNELS[objective]],
  }));
}
/** Channels of a plan: organic always; paid networks only when there is a real investment (never in Bootstrap). */
export function channelsFor(objective: GrowthObjective, investmentMinor: number): { organic: OrganicChannel[]; paid: AdNetwork[] } {
  return { organic: [...PRIORITY_CHANNELS[objective]], paid: isBootstrap(investmentMinor) ? [] : PAID_NETWORKS[objective].filter((n) => (AD_NETWORKS as readonly string[]).includes(n)) };
}
/** Even split of the client's own amount across the networks that make sense for the objective (a suggestion the client can change). */
export function allocate(investmentMinor: number, networks: readonly AdNetwork[]): { network: AdNetwork; amountMinor: number }[] {
  if (networks.length === 0) return [];
  const each = Math.floor(investmentMinor / networks.length);
  return networks.map((network, i) => ({ network, amountMinor: i === 0 ? investmentMinor - each * (networks.length - 1) : each }));
}

export interface Slot { week: number; day: string; channel: OrganicChannel; format: string; topic: string }
const DAYS = ["mon", "tue", "wed", "thu", "fri"] as const;
const TOPICS = ["offer", "faq", "story", "proof", "tip", "behind_scenes", "invite"] as const;
/** A 4-week skeleton: the channels in priority order, rotating formats and topic types. The copy itself is not written here. */
export function calendarFor(channels: readonly OrganicChannel[], perWeek = 3): Slot[] {
  const usable = [...channels];
  if (usable.length === 0) return [];
  const out: Slot[] = []; let n = 0;
  for (let week = 1; week <= 4; week++) for (let i = 0; i < perWeek; i++) {
    const channel = usable[(n + i) % usable.length] as OrganicChannel;
    out.push({ week, day: DAYS[(i * 2) % DAYS.length] as string, channel, format: FORMAT[channel], topic: TOPICS[(n + i) % TOPICS.length] as string }); n += 1;
  }
  return out;
}

export interface Roi {
  period: string; state: "no_data" | "organic_only" | "complete" | "sales_missing";
  investmentMinor: number; salesMinor: number; leads: number; customers: number; currency: string;
  roi: number | null; costPerLeadMinor: number | null; costPerCustomerMinor: number | null; sources: { manual: boolean; marketing: boolean };
}
export function computeRoi(i: { period: string; currency: string; manual: { investmentMinor: number; salesMinor: number; leads: number; customers: number; rows: number }; marketing: { spendMinor: number; conversions: number } | null }): Roi {
  const inv = i.manual.investmentMinor > 0 ? i.manual.investmentMinor : i.marketing?.spendMinor ?? 0, sales = i.manual.salesMinor, leads = i.manual.leads, customers = i.manual.customers;
  const any = i.manual.rows > 0 || (i.marketing?.spendMinor ?? 0) > 0;
  const state: Roi["state"] = !any ? "no_data" : inv === 0 ? (sales > 0 || leads > 0 || customers > 0 ? "organic_only" : "no_data") : sales === 0 ? "sales_missing" : "complete";
  return {
    period: i.period, state, investmentMinor: inv, salesMinor: sales, leads, customers, currency: i.currency,
    roi: inv > 0 && sales > 0 ? Math.round((sales / inv) * 100) / 100 : null, costPerLeadMinor: inv > 0 && leads > 0 ? Math.round(inv / leads) : null,
    costPerCustomerMinor: inv > 0 && customers > 0 ? Math.round(inv / customers) : null, sources: { manual: i.manual.rows > 0, marketing: (i.marketing?.spendMinor ?? 0) > 0 },
  };
}
export type NextStep = { key: "register_results" | "register_sales" | "stay_organic" | "consider_small_investment" | "review_before_scaling" | "scale_with_control"; vars?: Record<string, number> };
/** Recommendations for next month from REAL results only. Bootstrap companies are never pushed to invest: a small investment is suggested only once organic work shows sales. */
export function nextSteps(r: Roi, bootstrap: boolean): NextStep[] {
  if (r.state === "no_data") return [{ key: "register_results" }];
  if (r.state === "sales_missing") return [{ key: "register_sales" }];
  if (r.state === "organic_only") return r.salesMinor > 0 && bootstrap ? [{ key: "stay_organic" }, { key: "consider_small_investment", vars: { amountMinor: Math.max(1000, Math.round((r.salesMinor * 0.1) / 1000) * 1000) } }] : [{ key: "stay_organic" }];
  if ((r.roi ?? 0) >= 3) return [{ key: "scale_with_control" }];
  return [{ key: "review_before_scaling" }];
}

const TOPIC_LABEL: Record<string, { es: string; en: string }> = {
  offer: { es: "Presenta tu oferta principal y a quién ayuda", en: "Present your main offer and who it helps" }, faq: { es: "Responde una pregunta frecuente de tus clientes", en: "Answer a question your customers often ask" },
  story: { es: "Cuenta una historia real de tu negocio", en: "Tell a real story from your business" }, proof: { es: "Muestra un resultado o caso real (solo si existe)", en: "Show a real result or case (only if it exists)" },
  tip: { es: "Comparte un consejo útil de tu especialidad", en: "Share a useful tip from your field" }, behind_scenes: { es: "Muestra cómo trabajas por dentro", en: "Show how you work behind the scenes" }, invite: { es: "Invita a dar el siguiente paso (escribirte, reservar, comprar)", en: "Invite the next step (message you, book, buy)" },
};
/** The brief a person (or, later, a connected AI provider) writes the final copy from. It is a brief, not finished copy: nothing is invented. */
export function postBrief(slot: Slot, locale: "es" | "en"): { title: string; body: string } {
  const topic = TOPIC_LABEL[slot.topic]?.[locale] ?? slot.topic;
  return locale === "es"
    ? { title: `${slot.channel} · ${slot.format} · semana ${slot.week}`, body: `BRIEF (borrador sin texto final)\nCanal: ${slot.channel}\nFormato: ${slot.format}\nTema: ${topic}\nTexto: pendiente (se escribe a mano o cuando haya un proveedor de IA conectado).` }
    : { title: `${slot.channel} · ${slot.format} · week ${slot.week}`, body: `BRIEF (draft without final copy)\nChannel: ${slot.channel}\nFormat: ${slot.format}\nTopic: ${topic}\nCopy: pending (written by hand or once an AI provider is connected).` };
}
