import type { Kind } from "./store";

export const TABLE: Record<Kind, string> = { plan: "gr_plans", proposal: "gr_proposals", result: "gr_results" };
export const KIND_LIST = Object.keys(TABLE) as Kind[];
/** Nothing is deleted: a plan is superseded, a proposal is decided, a result is corrected. */
export const SOFT_DELETE: ReadonlySet<Kind> = new Set<Kind>();
export const REMOVABLE: ReadonlySet<Kind> = new Set<Kind>();
export const IMMUTABLE_KINDS: ReadonlySet<Kind> = new Set<Kind>();
export const FROZEN_COLS: Partial<Record<Kind, readonly string[]>> = { proposal: ["planId", "kind", "channel", "dedupeKey"], result: ["period", "channel"] };
export const BOOLEAN_COLS: ReadonlySet<string> = new Set(["bootstrap"]);
export const JSON_COLS: ReadonlySet<string> = new Set(["channels", "payload"]);
export const COLUMNS: Record<Kind, readonly string[]> = {
  plan: ["id", "tenantId", "objective", "objectiveNote", "investmentMinor", "currency", "scenario", "bootstrap", "channels", "status", "createdBy", "createdAt", "updatedAt"],
  proposal: ["id", "tenantId", "planId", "kind", "channel", "authorKey", "title", "body", "payload", "status", "outcome", "refId", "dedupeKey", "decidedBy", "decidedAt", "createdAt", "updatedAt"],
  result: ["id", "tenantId", "period", "channel", "investmentMinor", "salesMinor", "leads", "customers", "currency", "note", "recordedBy", "createdAt", "updatedAt"],
};
export const UNIQUE: Partial<Record<Kind, readonly (readonly string[])[]>> = { proposal: [["dedupeKey"]], result: [["period", "channel"]] };
/** One active plan per company. */
export const UNIQUE_WHEN: Partial<Record<Kind, readonly { cols: readonly string[]; col: string; in: readonly string[] }[]>> = { plan: [{ cols: ["tenantId"], col: "status", in: ["active"] }] };
export const snake = (k: string) => k.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
export const camel = (k: string) => k.replace(/_([a-z0-9])/g, (_m, c: string) => c.toUpperCase());
