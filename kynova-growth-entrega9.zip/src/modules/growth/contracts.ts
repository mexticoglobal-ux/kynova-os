/** What is and is not implemented in the Marketing & Growth system. Shown as-is in the UI so nothing is presented as more than it is. */
export const ARCHITECTURE_STATUS = {
  team: "built_ten_roles",
  objective_to_investment_flow: "built",
  bootstrap_mode: "built",
  proposals: "built_rule_based",
  generative_copy: "not_connected",
  human_approval: "built",
  post_drafts: "built_creates_marketing_drafts",
  email_campaigns: "prepared_not_sent",
  whatsapp_campaigns: "prepared_not_sent",
  ad_networks: "prepared_not_connected",
  roi: "built_from_recorded_results",
  continuous_worker: "not_built",
  cross_company_learning: "not_built",
} as const;
