import type { Role } from "@/config/roles";
import { DEFAULT_CAPABILITIES, type Capability } from "./domain";

/** Capabilities INSIDE Growth. Whether a role may open /app/growth at all is decided only by src/config/modules.ts. */
export const allows = (role: Role, c: Capability): boolean => DEFAULT_CAPABILITIES[role].includes(c);
