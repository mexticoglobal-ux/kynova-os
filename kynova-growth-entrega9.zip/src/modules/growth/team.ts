import type { ProposalKind } from "./domain";

/**
 * The Marketing & Growth AI Business System: a team, not one employee. The Marketing Manager coordinates; the Communication Manager leads the
 * Communication Team, which executes the messaging channels. Responsibilities are fixed here (and described in i18n); who authors what follows from them.
 */
export interface GrowthMember { key: string; role: "coordinator" | "specialist" | "lead" | "executor"; authors: readonly ProposalKind[]; parent?: string }
export const GROWTH_TEAM: readonly GrowthMember[] = [
  { key: "marketing_manager", role: "coordinator", authors: ["recommendation", "ad_campaign"] },
  { key: "content_manager", role: "specialist", authors: ["calendar"] },
  { key: "social_media_manager", role: "specialist", authors: ["post"] },
  { key: "seo_manager", role: "specialist", authors: ["recommendation"] },
  { key: "analytics_manager", role: "specialist", authors: ["review"] },
  { key: "communication_manager", role: "lead", authors: ["recommendation"] },
  { key: "whatsapp_manager", role: "executor", parent: "communication_manager", authors: ["whatsapp_campaign"] },
  { key: "email_manager", role: "executor", parent: "communication_manager", authors: ["email_campaign"] },
  { key: "social_messaging_manager", role: "executor", parent: "communication_manager", authors: ["reply_templates"] },
  { key: "follow_up_manager", role: "executor", parent: "communication_manager", authors: ["follow_up"] },
];
export const GROWTH_KEYS: readonly string[] = GROWTH_TEAM.map((m) => m.key);
export const COORDINATOR = "marketing_manager";
