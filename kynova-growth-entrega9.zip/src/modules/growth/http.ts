import { NextResponse, type NextRequest } from "next/server";
import { canAccess } from "@/config/modules";
import { isConfigError } from "@/platform/auth/errors";
import { assertSameOrigin, getAuthConfig, ok, problem, route } from "@/platform/auth/http";
import { requireApiSession } from "@/platform/auth/session";
import { GrowthError, isGrowthError } from "./errors";
import { getGrowthService } from "./server";
import type { Actor, GrowthService } from "./service";
import { fromWire, queryObject, toWire } from "./wire";

/** Growth has its own module slug in src/config/modules.ts. */
export const GROWTH_SLUG = "growth";
export interface GrowthRouteContext { actor: Actor; rid: string; svc: GrowthService }

/** Verified session, module access for the role, an active company, CSRF checks on mutations, and Growth/AI errors as problem+json. */
export function growthRoute<C = unknown>(fn: (req: NextRequest, ctx: C, a: GrowthRouteContext) => Promise<NextResponse>, opts: { mutating?: boolean } = {}) {
  return route<C>(async (req, ctx, rid) => {
    try {
      if (opts.mutating) assertSameOrigin(req, getAuthConfig());
      const s = await requireApiSession();
      if (!s.tenantId) throw new GrowthError("forbidden", "Select or create a company first.");
      if (!canAccess(s.role, GROWTH_SLUG)) throw new GrowthError("forbidden", "Your role cannot use Growth.");
      const actor: Actor = { tenantId: s.tenantId, userId: s.user.id, role: s.role, requestId: rid };
      return await fn(req, ctx, { actor, rid, svc: await getGrowthService() });
    } catch (e) {
      if (isGrowthError(e)) return problem(e.code, e.status, e.message, rid, { ...(e.details?.fields ? { errors: e.details.fields } : {}), ...(e.details && !e.details.fields ? { details: e.details } : {}) });
      if (isConfigError(e) && !(e as { name?: string }).name?.startsWith("Missing")) return problem("ai_unavailable", 503, "This service is temporarily unavailable.", rid);
      throw e;
    }
  });
}
export async function readBody(req: NextRequest): Promise<unknown> {
  if (!req.headers.get("content-type")?.toLowerCase().startsWith("application/json")) throw new GrowthError("validation_failed", "Content-Type must be application/json.");
  const text = await req.text();
  if (!text.trim()) return {};
  try { const b = JSON.parse(text) as unknown; if (b === null || typeof b !== "object" || Array.isArray(b)) throw 0; return fromWire(b); }
  catch { throw new GrowthError("validation_failed", "The body must be a JSON object."); }
}
export const respond = (data: unknown, rid: string, status = 200) => ok(toWire(data), rid, status);
export const noContent = (rid: string) => new NextResponse(null, { status: 204, headers: { "X-Request-Id": rid, "Cache-Control": "no-store" } });

