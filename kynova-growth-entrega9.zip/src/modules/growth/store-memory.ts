import { FROZEN_COLS, IMMUTABLE_KINDS, KIND_LIST, REMOVABLE, SOFT_DELETE, UNIQUE, UNIQUE_WHEN } from "./columns";
import { GrowthError } from "./errors";
import type { Cond, Kind, KindMap, QuerySpec, GrowthStore, WriteOp } from "./store";

type Row = Record<string, unknown>;
const KINDS: Kind[] = KIND_LIST;
const IMMUTABLE: ReadonlySet<Kind> = IMMUTABLE_KINDS;

/** In-memory store: local development without a D1 binding and unit tests. Same contract as the D1 store, including tenant scoping and its constraints. */
export function createMemoryGrowthStore(): GrowthStore {
  const tables = new Map<Kind, Map<string, Row>>(KINDS.map((k) => [k, new Map()]));
  const tbl = (k: Kind) => tables.get(k) as Map<string, Row>;
  /** JSON columns round-trip through JSON so a caller can never keep a live reference into the store. */
  const clone = <T>(r: T): T => structuredClone(r);

  function matches(row: Row, c: Cond<Kind>): boolean {
    const v = row[c.col];
    switch (c.op) {
      case "eq": return v === c.value; case "ne": return v !== c.value;
      case "in": return typeof v === "string" && c.value.includes(v);
      case "gte": return typeof v === "number" && v >= c.value; case "lte": return typeof v === "number" && v <= c.value;
      case "null": return v === null || v === undefined; case "notnull": return v !== null && v !== undefined;
    }
  }
  function select(kind: Kind, tenantId: string, where: readonly Cond<Kind>[] = [], search?: QuerySpec<Kind>["search"]): Row[] {
    const needle = search?.text.trim().toLowerCase();
    return [...tbl(kind).values()].filter((r) => r.tenantId === tenantId && (!SOFT_DELETE.has(kind) || r.deletedAt == null) && where.every((c) => matches(r, c))
      && (!needle || search?.cols.some((c) => String(r[c] ?? "").toLowerCase().includes(needle))));
  }
  function applyOp(o: WriteOp): void {
    if (o.op === "insert") {
      if (tbl(o.kind).has(o.row.id)) throw new GrowthError("conflict", "Duplicate id.");
      const r = o.row as unknown as Row;
      // Mirrors the unique indexes of the D1 migration (partial on live rows for soft-deletable kinds).
      for (const cols of UNIQUE[o.kind] ?? []) {
        if (cols.every((c) => r[c] != null) && [...tbl(o.kind).values()].some((x) => x.tenantId === r.tenantId && (!SOFT_DELETE.has(o.kind) || x.deletedAt == null) && cols.every((c) => x[c] === r[c]))) throw new GrowthError("duplicate", "A record with the same unique value already exists.");
      }
      for (const u of UNIQUE_WHEN[o.kind] ?? []) {
        if (u.in.includes(String(r[u.col])) && u.cols.every((c) => r[c] != null) && [...tbl(o.kind).values()].some((x) => x.tenantId === r.tenantId && u.in.includes(String(x[u.col])) && u.cols.every((c) => x[c] === r[c]))) throw new GrowthError("duplicate", "A record with the same unique value already exists.");
      }
      tbl(o.kind).set(o.row.id, clone(r));
    } else {
      const cur = tbl(o.kind).get(o.id);
      if (!cur || cur.tenantId !== o.tenantId) throw new GrowthError("not_found", "Record not found.");
      if (IMMUTABLE.has(o.kind)) throw new GrowthError("invalid_state", "That change is not allowed.");
      const next: Row = { ...cur, ...clone(o.patch as Row), id: cur.id, tenantId: cur.tenantId };
      for (const cols of UNIQUE[o.kind] ?? []) {
        if (cols.every((c) => next[c] != null) && [...tbl(o.kind).values()].some((x) => x.id !== cur.id && x.tenantId === next.tenantId && (!SOFT_DELETE.has(o.kind) || x.deletedAt == null) && (!SOFT_DELETE.has(o.kind) || next.deletedAt == null) && cols.every((c) => x[c] === next[c]))) throw new GrowthError("duplicate", "A record with the same unique value already exists.");
      }
      for (const c of FROZEN_COLS[o.kind] ?? []) if (c in (o.patch as Row) && (o.patch as Row)[c] !== cur[c]) throw new GrowthError("invalid_state", "That change is not allowed.");
      for (const u of UNIQUE_WHEN[o.kind] ?? []) {
        if (u.in.includes(String(next[u.col])) && u.cols.every((c) => next[c] != null) && [...tbl(o.kind).values()].some((x) => x.id !== cur.id && x.tenantId === next.tenantId && u.in.includes(String(x[u.col])) && u.cols.every((c) => x[c] === next[c]))) throw new GrowthError("duplicate", "A record with the same unique value already exists.");
      }
      tbl(o.kind).set(o.id, next);
    }
  }
  const out = <K extends Kind>(r: Row): KindMap[K] => clone(r) as unknown as KindMap[K];

  return {
    async insert(kind, row) { applyOp({ op: "insert", kind, row }); },
    async get(kind, tenantId, id) { const r = tbl(kind).get(id); return r && r.tenantId === tenantId && !(SOFT_DELETE.has(kind) && r.deletedAt != null) ? out(r) : null; },
    async update(kind, tenantId, id, patch) {
      const cur = tbl(kind).get(id);
      if (!cur || cur.tenantId !== tenantId) return null;
      applyOp({ op: "update", kind, tenantId, id, patch });
      const next = tbl(kind).get(id) as Row;
      return SOFT_DELETE.has(kind) && next.deletedAt != null ? null : out(next);
    },
    async query(kind, tenantId, spec) {
      const col = spec.orderBy?.col ?? "createdAt", dir = spec.orderBy?.dir ?? "desc", sgn = dir === "desc" ? -1 : 1;
      const cmp = (a: Row, b: Row) => { const av = a[col] as string | number, bv = b[col] as string | number; return (av < bv ? -1 : av > bv ? 1 : 0) * sgn || (String(a.id) < String(b.id) ? -1 : String(a.id) > String(b.id) ? 1 : 0) * sgn; };
      let rows = select(kind, tenantId, spec.where as readonly Cond<Kind>[], spec.search as QuerySpec<Kind>["search"]).sort(cmp);
      const after = spec.after;
      if (after) rows = rows.filter((r) => cmp(r, { [col]: after.value, id: after.id }) > 0);
      return rows.slice(0, spec.limit).map((r) => out(r));
    },
    async count(kind, tenantId, where) { return select(kind, tenantId, where as readonly Cond<Kind>[] | undefined).length; },
    async sum(kind, tenantId, col, where) { return select(kind, tenantId, where as readonly Cond<Kind>[] | undefined).reduce((n, r) => n + (Number(r[col]) || 0), 0); },
    async remove(kind, tenantId, id) {
      if (!REMOVABLE.has(kind)) throw new GrowthError("invalid_state", "That record cannot be deleted.");
      const cur = tbl(kind).get(id);
      if (!cur || cur.tenantId !== tenantId) return false;
      tbl(kind).delete(id);
      return true;
    },
    async batch(ops) {
      const snapshot = new Map(KINDS.map((k) => [k, new Map([...tbl(k)].map(([id, r]) => [id, clone(r)]))]));
      try { for (const o of ops) applyOp(o); }
      catch (e) { for (const k of KINDS) tables.set(k, snapshot.get(k) as Map<string, Row>); throw e; }
    },
  };
}
