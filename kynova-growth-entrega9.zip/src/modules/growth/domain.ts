import { z } from "zod";
import { ROLES } from "@/config/roles";

/** Capabilities INSIDE Growth. Whether a role may open /app/growth at all is decided only by src/config/modules.ts. */
export const CAPABILITIES = ["view", "manage", "approve"] as const;
export type Capability = (typeof CAPABILITIES)[number];
export const DEFAULT_CAPABILITIES: Record<(typeof ROLES)[number], readonly Capability[]> = {
  super_admin: [...CAPABILITIES], owner: [...CAPABILITIES], administrator: [...CAPABILITIES], ceo: [...CAPABILITIES], manager: ["view", "manage"],
  marketing: ["view", "manage"], sales: ["view"], finance: [], support: [], hr: [], employee: [], guest: [],
};

/** "¿Cuál es tu objetivo?" */
export const OBJECTIVES = ["first_clients", "sell_more", "brand_awareness", "leads", "social_growth", "youtube", "other"] as const;
export type GrowthObjective = (typeof OBJECTIVES)[number];
export const SCENARIOS = ["entrepreneur", "growth", "scaling", "enterprise"] as const;
export type Scenario = (typeof SCENARIOS)[number];
/** The company chose a scenario, typed its own amount, or did not invest. */
export type PlanScenario = Scenario | "custom" | "none";
export const ORGANIC_CHANNELS = ["seo", "blog", "instagram", "facebook", "tiktok", "youtube", "linkedin", "google_business", "whatsapp", "email"] as const;
export type OrganicChannel = (typeof ORGANIC_CHANNELS)[number];
/** Paid networks. The flow is prepared; none is connected (Entrega 9 connects no provider). */
export const AD_NETWORKS = ["meta_ads", "google_ads", "youtube_ads", "tiktok_ads", "linkedin_ads"] as const;
export type AdNetwork = (typeof AD_NETWORKS)[number];
export const PROPOSAL_KINDS = ["recommendation", "calendar", "post", "ad_campaign", "whatsapp_campaign", "email_campaign", "reply_templates", "follow_up", "review"] as const;
export type ProposalKind = (typeof PROPOSAL_KINDS)[number];
export const PROPOSAL_STATUS = ["proposed", "approved", "rejected"] as const;
export const OUTCOMES = ["", "draft_created", "prepared"] as const;
/** Below this monthly investment (USD cents) a company is in Bootstrap mode: organic growth only, never pressure to invest. */
export const BOOTSTRAP_BELOW_MINOR = 5000;
export const MAX_INVESTMENT_MINOR = 100_000_000_00;

type V<T extends readonly string[]> = T[number];
export interface PlanRecord { id: string; tenantId: string; objective: GrowthObjective; objectiveNote: string; investmentMinor: number; currency: string; scenario: PlanScenario; bootstrap: boolean; channels: string[]; status: "active" | "superseded"; createdBy: string; createdAt: number; updatedAt: number }
export interface ProposalRecord { id: string; tenantId: string; planId: string; kind: ProposalKind; channel: string; authorKey: string; title: string; body: string; payload: Record<string, unknown>; status: V<typeof PROPOSAL_STATUS>; outcome: V<typeof OUTCOMES>; refId: string | null; dedupeKey: string; decidedBy: string | null; decidedAt: number | null; createdAt: number; updatedAt: number }
export interface ResultRecord { id: string; tenantId: string; period: string; channel: string; investmentMinor: number; salesMinor: number; leads: number; customers: number; currency: string; note: string; recordedBy: string; createdAt: number; updatedAt: number }

const text = (max: number) => z.string().trim().max(max);
const money = z.number().int().min(0).max(MAX_INVESTMENT_MINOR);
const count = z.number().int().min(0).max(1_000_000_000);
export const recommendInput = z.object({ objective: z.enum(OBJECTIVES) }).strict();
/** The client always decides: `investmentMinor` is any amount from zero up; `scenario` is only a label of where the number came from. */
export const planInput = z.object({
  objective: z.enum(OBJECTIVES), objectiveNote: text(200).default(""), investmentMinor: money, currency: z.string().trim().toUpperCase().regex(/^[A-Z]{3}$/).default("USD"),
  scenario: z.enum([...SCENARIOS, "custom", "none"]).default("custom"),
}).strict().superRefine((v, ctx) => { if (v.objective === "other" && !v.objectiveNote.trim()) ctx.addIssue({ code: "custom", path: ["objectiveNote"], message: "Describe your objective." }); });
export const decisionInput = z.object({ approve: z.boolean() }).strict();
export const periodSchema = z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/);
export const resultInput = z.object({ period: periodSchema, channel: z.enum(["", ...ORGANIC_CHANNELS, ...AD_NETWORKS]).default(""), investmentMinor: money.default(0), salesMinor: money.default(0), leads: count.default(0), customers: count.default(0), currency: z.string().trim().toUpperCase().regex(/^[A-Z]{3}$/).default("USD"), note: text(300).default("") }).strict();
export const monthOf = (t: number): string => new Date(t).toISOString().slice(0, 7);
