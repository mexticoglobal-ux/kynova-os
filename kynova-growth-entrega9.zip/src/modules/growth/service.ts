import { z } from "zod";
import type { Role } from "@/config/roles";
import type { ActivitySink, SinkEvent } from "@/platform/activity";
import { allows } from "./access";
import {
  AD_NETWORKS, BOOTSTRAP_BELOW_MINOR, decisionInput, monthOf, periodSchema, planInput, recommendInput, resultInput,
  type PlanRecord, type ProposalKind, type ProposalRecord, type ResultRecord, type Capability,
} from "./domain";
import { GrowthError } from "./errors";
import { allocate, calendarFor, channelsFor, computeRoi, isBootstrap, nextSteps, postBrief, scenariosFor, type Roi } from "./planner";
import type { GrowthStore } from "./store";
import { COORDINATOR, GROWTH_TEAM } from "./team";

export interface Actor { tenantId: string; userId: string; role: Role; requestId?: string }
export interface MemberInfo { key: string; name: string; entitled: boolean; active: boolean; activityKey: string }
export interface GrowthPorts {
  member(a: Actor, key: string): Promise<MemberInfo | null>;
  /** Investment and conversions the Marketing module recorded for a month (real campaign metrics), or null when it has none or cannot be read. */
  marketing(a: Actor, period: string): Promise<{ spendMinor: number; conversions: number; currency: string } | null>;
  /** Creates a DRAFT post in Marketing. Nothing is published or sent. */
  createDraft(a: Actor, d: { title: string; body: string }): Promise<{ id: string }>;
}
export interface GrowthDeps { store: GrowthStore; ports: GrowthPorts; newId: () => string; now?: () => number; activity?: ActivitySink; locale?: "es" | "en" }
export type GrowthService = ReturnType<typeof createGrowthService>;

function parse<T extends z.ZodType>(schema: T, input: unknown): z.output<T> {
  const r = schema.safeParse(input);
  if (!r.success) throw new GrowthError("validation_failed", "The request is not valid.", { fields: r.error.issues.map((i) => ({ field: i.path.join("."), message: i.message })) });
  return r.data;
}
const MODE_NOTE = "rules"; // proposals are prepared by deterministic rules from the company's data; no generative model is connected

export function createGrowthService(deps: GrowthDeps) {
  const { store, ports } = deps, now = deps.now ?? Date.now;
  const need = (a: Actor, c: Capability): void => { if (!allows(a.role, c)) throw new GrowthError("forbidden", "Your role cannot do this."); };
  const rec = async (a: Actor, e: SinkEvent): Promise<void> => {
    if (!deps.activity) return;
    await deps.activity.record({ tenantId: a.tenantId, ...(a.requestId ? { requestId: a.requestId } : {}) }, { module: "growth", source: "growth", actorKind: "user", actorId: a.userId, mode: "production", ...e });
  };
  const activePlan = async (a: Actor): Promise<PlanRecord | null> => (await store.query("plan", a.tenantId, { where: [{ col: "status", op: "eq", value: "active" }], limit: 1 }))[0] ?? null;
  const member = async (a: Actor, key: string): Promise<MemberInfo | null> => { try { return await ports.member(a, key); } catch { return null; } };

  /* ───────────── Objective → investment ───────────── */

  /** Scenarios for an objective. Computed, not stored: the company can ignore them and type any amount. */
  function recommend(a: Actor, input: unknown) {
    need(a, "view");
    const { objective } = parse(recommendInput, input);
    return { objective, referential: true, bootstrapBelowMinor: BOOTSTRAP_BELOW_MINOR, currency: "USD", scenarios: scenariosFor(objective), organic: channelsFor(objective, 0).organic };
  }
  async function setPlan(a: Actor, input: unknown): Promise<PlanRecord> {
    need(a, "manage");
    const i = parse(planInput, input), t = now(), cur = await activePlan(a), bootstrap = isBootstrap(i.investmentMinor), ch = channelsFor(i.objective, i.investmentMinor);
    const row: PlanRecord = { id: deps.newId(), tenantId: a.tenantId, objective: i.objective, objectiveNote: i.objectiveNote, investmentMinor: i.investmentMinor, currency: i.currency, scenario: i.investmentMinor === 0 ? "none" : i.scenario, bootstrap, channels: [...ch.organic, ...ch.paid], status: "active", createdBy: a.userId, createdAt: t, updatedAt: t };
    await store.batch([...(cur ? [{ op: "update" as const, kind: "plan" as const, tenantId: a.tenantId, id: cur.id, patch: { status: "superseded" as const, updatedAt: t } }] : []), { op: "insert", kind: "plan", row }]);
    await rec(a, { action: "growth.plan.set", summary: `Growth plan: ${i.objective}, investment ${i.investmentMinor / 100} ${i.currency}${bootstrap ? " (bootstrap)" : ""}`, subjectKind: "plan", subjectId: row.id, reversible: Boolean(cur), ...(cur ? { revertHint: { planId: cur.id } } : {}) });
    return row;
  }
  async function plan(a: Actor): Promise<PlanRecord | null> { need(a, "view"); return activePlan(a); }

  /* ───────────── Team proposals ───────────── */

  /** The specialist who authors a proposal, or the Marketing Manager covering for them when the plan does not include that specialist. */
  async function author(a: Actor, key: string): Promise<{ info: MemberInfo; coveredFor: string | null }> {
    const m = await member(a, key);
    if (m && m.entitled) return { info: m, coveredFor: null };
    const c = await member(a, COORDINATOR);
    return { info: c ?? { key: COORDINATOR, name: "Marketing Manager", entitled: true, active: false, activityKey: COORDINATOR }, coveredFor: key };
  }
  type Draft = { key: string; kind: ProposalKind; channel: string; author: string; title: string; body: string; payload: Record<string, unknown> };
  function drafts(p: PlanRecord): Draft[] {
    const organic = p.channels.filter((c) => !(AD_NETWORKS as readonly string[]).includes(c)), paid = p.channels.filter((c) => (AD_NETWORKS as readonly string[]).includes(c));
    const out: Draft[] = [];
    const base = (kind: ProposalKind, channel: string, n = 0) => `${p.id}:${kind}:${channel}:${n}`;
    out.push({ key: base("recommendation", "all"), kind: "recommendation", channel: "all", author: "marketing_manager", title: "strategy", body: "strategy", payload: { objective: p.objective, bootstrap: p.bootstrap, organic, investmentMinor: p.investmentMinor, currency: p.currency, note: p.objectiveNote } });
    out.push({ key: base("calendar", "all"), kind: "calendar", channel: "all", author: "content_manager", title: "calendar", body: "calendar", payload: { slots: calendarFor(organic as never) } });
    if (organic.includes("seo") || organic.includes("blog") || organic.includes("google_business")) out.push({ key: base("recommendation", "seo"), kind: "recommendation", channel: "seo", author: "seo_manager", title: "seo", body: "seo", payload: { checklist: ["google_business", "key_pages", "blog_topics", "local_keywords"].filter((c) => c !== "google_business" || organic.includes("google_business")) } });
    for (const s of calendarFor(organic.filter((c) => ["instagram", "facebook", "tiktok", "youtube", "linkedin"].includes(c)) as never, 1).slice(0, 3)) out.push({ key: base("post", s.channel, s.week), kind: "post", channel: s.channel, author: "social_media_manager", title: "post", body: "post", payload: { slot: s, ...(() => { const b = postBrief(s, deps.locale ?? "es"); return { draftTitle: b.title, draftBody: b.body }; })() } });
    if (organic.includes("whatsapp")) out.push({ key: base("whatsapp_campaign", "whatsapp"), kind: "whatsapp_campaign", channel: "whatsapp", author: "whatsapp_manager", title: "whatsapp", body: "whatsapp", payload: { segments: ["new_contacts", "past_customers", "quote_requested"], cadence: [0, 2, 7], optIn: true } });
    if (organic.includes("email")) out.push({ key: base("email_campaign", "email"), kind: "email_campaign", channel: "email", author: "email_manager", title: "email", body: "email", payload: { segments: ["subscribers", "past_customers"], sequence: ["welcome", "value", "offer"] } });
    out.push({ key: base("reply_templates", "social"), kind: "reply_templates", channel: "social", author: "social_messaging_manager", title: "replies", body: "replies", payload: { templates: ["greeting", "pricing_question", "availability", "thanks"] } });
    out.push({ key: base("follow_up", "all"), kind: "follow_up", channel: "all", author: "follow_up_manager", title: "follow_up", body: "follow_up", payload: { cadenceDays: [1, 3, 7] } });
    if (!p.bootstrap) for (const al of allocate(p.investmentMinor, paid as never)) out.push({ key: base("ad_campaign", al.network), kind: "ad_campaign", channel: al.network, author: "marketing_manager", title: "ads", body: "ads", payload: { network: al.network, suggestedMinor: al.amountMinor, currency: p.currency, connected: false } });
    return out;
  }
  /** Prepares what the team proposes for the active plan. Idempotent: running it again only adds what is missing. */
  async function generate(a: Actor): Promise<{ created: number; proposals: ProposalRecord[] }> {
    need(a, "manage");
    const p = await activePlan(a);
    if (!p) throw new GrowthError("invalid_state", "Choose your objective and investment first.");
    const existing = new Set((await store.query("proposal", a.tenantId, { where: [{ col: "planId", op: "eq", value: p.id }], limit: 500 })).map((x) => x.dedupeKey));
    const created: ProposalRecord[] = [], t = now();
    for (const d of drafts(p)) {
      if (existing.has(d.key)) continue;
      const who = await author(a, d.author);
      const row: ProposalRecord = { id: deps.newId(), tenantId: a.tenantId, planId: p.id, kind: d.kind, channel: d.channel, authorKey: who.info.key, title: d.title, body: d.body, payload: { ...d.payload, preparedBy: MODE_NOTE, ...(who.coveredFor ? { coveredFor: who.coveredFor } : {}), authorName: who.info.name }, status: "proposed", outcome: "", refId: null, dedupeKey: d.key, decidedBy: null, decidedAt: null, createdAt: t, updatedAt: t };
      await store.insert("proposal", row); created.push(row);
      await rec(a, { action: "growth.proposal.prepared", summary: `${who.info.name} prepared a ${d.kind.replace(/_/g, " ")} proposal`, subjectKind: "proposal", subjectId: row.id, employeeKey: who.info.activityKey, actorKind: "employee", actorId: who.info.activityKey, mode: "simulation", idempotencyKey: `gr-prop:${row.id}` });
    }
    return { created: created.length, proposals: created };
  }
  async function proposals(a: Actor, q: { status?: string } = {}): Promise<ProposalRecord[]> {
    need(a, "view");
    const p = await activePlan(a);
    if (!p) return [];
    return store.query("proposal", a.tenantId, { where: [{ col: "planId", op: "eq", value: p.id }, ...(q.status ? [{ col: "status" as const, op: "eq" as const, value: q.status }] : [])], orderBy: { col: "createdAt", dir: "asc" }, limit: 200 });
  }
  /** The person decides. Approving a post makes a DRAFT in Marketing; every other kind is marked prepared: nothing is published, sent or invested. */
  async function decide(a: Actor, id: string, input: unknown): Promise<ProposalRecord> {
    need(a, "approve");
    const { approve } = parse(decisionInput, input), p = await store.get("proposal", a.tenantId, id);
    if (!p) throw new GrowthError("not_found", "Proposal not found.");
    if (p.status !== "proposed") throw new GrowthError("invalid_state", "That proposal was already decided.");
    const t = now(); let outcome: ProposalRecord["outcome"] = "", refId: string | null = null;
    if (approve) {
      if (p.kind === "post") {
        const slot = p.payload.slot as { channel: string; format: string; topic: string } | undefined;
        const d = await ports.createDraft(a, { title: String(p.payload.draftTitle ?? `${slot?.channel ?? "post"} · ${slot?.format ?? ""}`).slice(0, 200), body: String(p.payload.draftBody ?? "").slice(0, 10000) });
        outcome = "draft_created"; refId = d.id;
      } else outcome = "prepared";
    }
    const r = (await store.update("proposal", a.tenantId, id, { status: approve ? "approved" : "rejected", outcome, refId, decidedBy: a.userId, decidedAt: t, updatedAt: t })) as ProposalRecord;
    await rec(a, { action: approve ? "growth.proposal.approved" : "growth.proposal.rejected", summary: `${approve ? "Approved" : "Rejected"} ${p.kind.replace(/_/g, " ")}${outcome === "draft_created" ? " (draft created in Marketing)" : outcome === "prepared" ? " (prepared, nothing was sent or published)" : ""}`, subjectKind: "proposal", subjectId: id });
    return r;
  }

  /* ───────────── Results and ROI ───────────── */

  async function recordResult(a: Actor, input: unknown): Promise<ResultRecord> {
    need(a, "manage");
    const i = parse(resultInput, input), t = now(), cur = (await store.query("result", a.tenantId, { where: [{ col: "period", op: "eq", value: i.period }, { col: "channel", op: "eq", value: i.channel }], limit: 1 }))[0];
    const row = cur ? (await store.update("result", a.tenantId, cur.id, { investmentMinor: i.investmentMinor, salesMinor: i.salesMinor, leads: i.leads, customers: i.customers, currency: i.currency, note: i.note, recordedBy: a.userId, updatedAt: t })) as ResultRecord
      : await (async () => { const r: ResultRecord = { id: deps.newId(), tenantId: a.tenantId, ...i, recordedBy: a.userId, createdAt: t, updatedAt: t }; await store.insert("result", r); return r; })();
    await rec(a, { action: "growth.result.recorded", summary: `Results recorded for ${i.period}${i.channel ? ` (${i.channel})` : ""}`, subjectKind: "result", subjectId: row.id, quantity: 1, reversible: Boolean(cur), ...(cur ? { revertHint: { previous: { investmentMinor: cur.investmentMinor, salesMinor: cur.salesMinor, leads: cur.leads, customers: cur.customers } } } : {}) });
    return row;
  }
  async function results(a: Actor, period?: string): Promise<ResultRecord[]> {
    need(a, "view");
    return store.query("result", a.tenantId, { where: period ? [{ col: "period", op: "eq", value: parse(periodSchema, period) }] : [], orderBy: { col: "period", dir: "desc" }, limit: 200 });
  }
  async function roi(a: Actor, q: { period?: string } = {}) {
    need(a, "view");
    const period = q.period ? parse(periodSchema, q.period) : monthOf(now()), rows = await results(a, period), p = await activePlan(a);
    const sum = (k: "investmentMinor" | "salesMinor" | "leads" | "customers") => rows.reduce((n, r) => n + r[k], 0);
    const market = await ports.marketing(a, period).catch(() => null);
    const r: Roi = computeRoi({ period, currency: rows[0]?.currency ?? market?.currency ?? p?.currency ?? "USD", manual: { investmentMinor: sum("investmentMinor"), salesMinor: sum("salesMinor"), leads: sum("leads"), customers: sum("customers"), rows: rows.length }, marketing: market });
    return { ...r, byChannel: rows.filter((x) => x.channel).map((x) => ({ channel: x.channel, investmentMinor: x.investmentMinor, salesMinor: x.salesMinor, leads: x.leads, customers: x.customers })), next: nextSteps(r, p?.bootstrap ?? true) };
  }
  /** The Analytics Manager's monthly review: a proposal with the real figures and the next-month recommendations. */
  async function reviewMonth(a: Actor, input: unknown): Promise<ProposalRecord> {
    need(a, "manage");
    const { period } = parse(z.object({ period: periodSchema }).strict(), input), p = await activePlan(a);
    if (!p) throw new GrowthError("invalid_state", "Choose your objective and investment first.");
    const key = `${p.id}:review:${period}:0`, found = (await store.query("proposal", a.tenantId, { where: [{ col: "dedupeKey", op: "eq", value: key }], limit: 1 }))[0];
    const data = await roi(a, { period }), who = await author(a, "analytics_manager"), t = now();
    if (found) return (await store.update("proposal", a.tenantId, found.id, { payload: { period, roi: data, preparedBy: MODE_NOTE, authorName: who.info.name }, updatedAt: t })) as ProposalRecord;
    const row: ProposalRecord = { id: deps.newId(), tenantId: a.tenantId, planId: p.id, kind: "review", channel: period, authorKey: who.info.key, title: "review", body: "review", payload: { period, roi: data, preparedBy: MODE_NOTE, authorName: who.info.name, ...(who.coveredFor ? { coveredFor: who.coveredFor } : {}) }, status: "proposed", outcome: "", refId: null, dedupeKey: key, decidedBy: null, decidedAt: null, createdAt: t, updatedAt: t };
    await store.insert("proposal", row);
    await rec(a, { action: "growth.review.prepared", summary: `${who.info.name} prepared the ${period} review`, subjectKind: "proposal", subjectId: row.id, employeeKey: who.info.activityKey, actorKind: "employee", actorId: who.info.activityKey, mode: "simulation", idempotencyKey: `gr-prop:${row.id}` });
    return row;
  }

  /* ───────────── Overview ───────────── */

  async function overview(a: Actor) {
    need(a, "view");
    const p = await activePlan(a), props = p ? await proposals(a) : [], by = new Map<string, { proposed: number; approved: number }>();
    for (const x of props) { const c = by.get(x.authorKey) ?? { proposed: 0, approved: 0 }; if (x.status === "proposed") c.proposed++; if (x.status === "approved") c.approved++; by.set(x.authorKey, c); }
    const team = await Promise.all(GROWTH_TEAM.map(async (m) => { const info = await member(a, m.key); return { key: m.key, role: m.role, parent: m.parent ?? null, name: info?.name ?? m.key, entitled: info?.entitled ?? false, active: info?.active ?? false, proposed: by.get(m.key)?.proposed ?? 0, approved: by.get(m.key)?.approved ?? 0 }; }));
    return {
      state: !p ? "empty" as const : props.length === 0 ? "planned" as const : "working" as const, plan: p, bootstrap: p?.bootstrap ?? null, team, pending: props.filter((x) => x.status === "proposed").length,
      roi: await roi(a), networks: AD_NETWORKS.map((id) => ({ id, connected: false })), preparedBy: MODE_NOTE,
    };
  }
  return { recommend, setPlan, plan, generate, proposals, decide, recordResult, results, roi, reviewMonth, overview, permissions: (a: Actor) => ({ role: a.role, capabilities: (["view", "manage", "approve"] as const).filter((c) => allows(a.role, c)) }) };
}
