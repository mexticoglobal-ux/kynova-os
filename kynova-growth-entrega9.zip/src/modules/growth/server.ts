import { employeeRegistry, getEmployeeFramework } from "@/platform/ai-employees";
import { getActivitySink } from "@/platform/activity";
import { getDb, plansRepo, tenantDb } from "@/platform/db";
import { ROSTER_BY_KEY, employeeKeyOf, isEntitled, teamOf } from "@/modules/team";
import { getMarketingService } from "@/modules/marketing";
import { getGrowthStore } from "./runtime";
import { createGrowthService, type Actor, type GrowthPorts, type GrowthService } from "./service";

/** Composition root: the only file that meets Marketing, the Team roster, the AI Employees framework and the plan catalog. It reads, and creates DRAFT posts only. */
async function planOf(a: Actor): Promise<string | null> {
  const db = await getDb(), sub = await tenantDb(db, { tenantId: a.tenantId }).subscriptions.current();
  return sub ? ((await plansRepo(db).findById(sub.planId))?.code ?? null) : null;
}
const dayStart = (period: string) => `${period}-01`;
const dayEnd = (period: string) => { const [y, m] = period.split("-").map(Number) as [number, number]; return new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10); };
export const growthPorts: GrowthPorts = {
  async member(a, key) {
    const r = ROSTER_BY_KEY.get(key);
    if (!r) return null;
    const bp = r.blueprint ?? r.key, [records, plan] = await Promise.all([getEmployeeFramework().employees.list(a).catch(() => []), planOf(a).catch(() => null)]);
    const rec = records.find((e) => e.blueprint === bp && e.status !== "retired");
    void employeeRegistry;
    return { key, name: r.name, entitled: isEntitled(teamOf(plan), key), active: Boolean(rec), activityKey: rec ? employeeKeyOf(rec.id) : key };
  },
  async marketing(a, period) {
    const svc = await getMarketingService(), perf = await svc.metrics.performance(a, { from: dayStart(period), to: dayEnd(period) });
    const cur = Object.keys(perf.summary.spend)[0];
    return cur ? { spendMinor: perf.summary.spend[cur] ?? 0, conversions: perf.summary.conversions, currency: cur } : { spendMinor: 0, conversions: perf.summary.conversions, currency: "USD" };
  },
  async createDraft(a, d) { return { id: (await (await getMarketingService()).posts.create(a, { title: d.title, body: d.body })).id }; },
};
export async function getGrowthService(): Promise<GrowthService> {
  return createGrowthService({ store: await getGrowthStore(), ports: growthPorts, newId: () => crypto.randomUUID().replace(/-/g, ""), activity: await getActivitySink("growth") });
}
