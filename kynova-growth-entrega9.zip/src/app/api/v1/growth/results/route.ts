import { growthRoute, readBody, respond } from "@/modules/growth/http";

export const GET = growthRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.results(actor, req.nextUrl.searchParams.get("period") ?? undefined), rid); });
export const PUT = growthRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.recordResult(actor, await readBody(req)), rid); }, { mutating: true });
