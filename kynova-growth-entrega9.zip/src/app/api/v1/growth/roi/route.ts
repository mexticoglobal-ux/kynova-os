import { growthRoute, readBody, respond } from "@/modules/growth/http";

export const GET = growthRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.roi(actor, { period: req.nextUrl.searchParams.get("period") ?? undefined }), rid); });
