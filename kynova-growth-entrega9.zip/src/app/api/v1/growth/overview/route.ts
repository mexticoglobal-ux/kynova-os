import { growthRoute, readBody, respond } from "@/modules/growth/http";

export const GET = growthRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.overview(actor), rid); });
