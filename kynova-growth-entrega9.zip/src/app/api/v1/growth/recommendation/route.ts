import { growthRoute, respond } from "@/modules/growth/http";

export const GET = growthRoute(async (req, _c, { actor, svc, rid }) => respond(await svc.recommend(actor, { objective: req.nextUrl.searchParams.get("objective") ?? undefined }), rid));
