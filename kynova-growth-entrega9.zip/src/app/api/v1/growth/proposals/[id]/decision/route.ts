import { growthRoute, readBody, respond } from "@/modules/growth/http";

type Ctx = { params: Promise<{ id: string }> };

export const POST = growthRoute<Ctx>(async (req, c, { actor, svc, rid }) => { void req; void c; const p = await c.params; return respond(await svc.decide(actor, p.id, await readBody(req)), rid); }, { mutating: true });
