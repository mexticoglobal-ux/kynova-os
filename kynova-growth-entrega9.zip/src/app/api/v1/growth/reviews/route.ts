import { growthRoute, readBody, respond } from "@/modules/growth/http";

export const POST = growthRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.reviewMonth(actor, await readBody(req)), rid, 201); }, { mutating: true });
