import { growthContext, money } from "@/components/growth/context";
import { DecisionButtons, GenerateButton, PlanForm, ResultForm, ReviewButton } from "@/components/growth/Panels";
import { Card, Empty, Notice, Pill, Stat } from "@/components/workforce/ui";
import { AD_NETWORKS, ARCHITECTURE_STATUS, type GrowthKey, type ProposalRecord } from "@/modules/growth";

export const metadata = { title: "Marketing & Growth" };
export const dynamic = "force-dynamic";

const ST = (v: string) => (v.startsWith("built") ? "built" : v === "not_connected" ? "not_connected" : v.startsWith("prepared") ? "prepared" : "not_built");
const TONE = { built: "success", prepared: "warning", not_built: "muted", not_connected: "muted" } as const;
const k = (s: string) => s as GrowthKey;

export default async function GrowthPage() {
  const { t, locale, svc, actor } = await growthContext();
  const [ov, perm, props] = await Promise.all([svc.overview(actor), svc.permissions(actor), svc.proposals(actor)]);
  const manage = perm.capabilities.includes("manage"), approve = perm.capabilities.includes("approve"), p = ov.plan, cur = p?.currency ?? "USD", roi = ov.roi;
  const m = (minor: number) => money(minor, roi.currency, locale), list = (xs: unknown, pre: string) => (Array.isArray(xs) ? xs : []).map((x) => t(k(`${pre}.${String(x)}`))).join(", ");
  const describe = (x: ProposalRecord): string => {
    const d = x.payload as Record<string, unknown>;
    switch (x.kind) {
      case "recommendation": return d.checklist ? `${t("pd.seo")} ${list(d.checklist, "seo")}` : `${t("pd.strategy", { channels: list(d.organic, "ch") })} ${d.bootstrap ? t("pd.bootstrap") : ""}`;
      case "calendar": return ((d.slots as { week: number; channel: string; format: string; topic: string }[]) ?? []).slice(0, 6).map((s) => t("pd.calendar", { week: s.week, channel: t(k(`ch.${s.channel}`)), format: t(k(`fmt.${s.format}`)), topic: t(k(`topic.${s.topic}`)) })).join(" · ");
      case "post": return String(d.draftBody ?? "");
      case "ad_campaign": return t("pd.ad", { network: t(k(`ch.${String(d.network)}`)), amount: money(Number(d.suggestedMinor), String(d.currency), locale) });
      case "whatsapp_campaign": return t("pd.whatsapp", { segments: list(d.segments, "seg"), days: ((d.cadence as number[]) ?? []).join(", ") });
      case "email_campaign": return t("pd.email", { segments: list(d.segments, "seg"), sequence: list(d.sequence, "seq") });
      case "reply_templates": return t("pd.replies", { templates: list(d.templates, "tpl") });
      case "follow_up": return t("pd.followup", { days: ((d.cadenceDays as number[]) ?? []).join(", ") });
      default: return "";
    }
  };
  const nameOf = new Map(ov.team.map((x) => [x.key, x.name]));
  const comm = ov.team.filter((x) => x.parent === "communication_manager"), main = ov.team.filter((x) => x.parent === null);
  const member = (x: (typeof ov.team)[number]) => (
    <li key={x.key} className="grid gap-1 rounded-xl border border-line px-3 py-2 text-sm"><div className="flex flex-wrap items-center justify-between gap-2"><span className="font-medium">{x.name}</span>
      {!x.entitled ? <Pill tone="muted">{t("team.plan")}</Pill> : !x.active ? <Pill tone="muted">{t("team.notActive")}</Pill> : x.proposed > 0 ? <Pill tone="warning">{t("team.pending", { n: x.proposed })}</Pill> : <Pill tone="success">✓</Pill>}</div>
      <p className="text-xs text-muted">{t(k(`m.${x.key}`))}</p>{!x.entitled && <p className="text-xs text-muted">{t("team.covered")}</p>}</li>
  );
  return (
    <div className="grid gap-5">
      <header><h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{t("title")}</h1><p className="mt-1 text-sm text-muted">{t("sub")}</p></header>
      <Notice>{t("prep.rules")}</Notice>
      {ov.bootstrap && <Notice><strong>{t("boot.title")}.</strong> {t("boot.text")}</Notice>}
      <Card title={p ? t("inv.current") : t("inv.title")}>
        {p && <p className="mb-3 text-sm"><Pill tone="info">{t(k(`obj.${p.objective}`))}</Pill> {p.investmentMinor === 0 ? t("inv.none") : t("inv.perMonth", { amount: money(p.investmentMinor, p.currency, locale) })}</p>}
        {manage ? <PlanForm initial={p ? { objective: p.objective, note: p.objectiveNote, investmentMinor: p.investmentMinor } : null} currency={cur} /> : p ? null : <Empty>{t("common.none")}</Empty>}
      </Card>
      <Card title={t("team.title")} action={manage && p ? <GenerateButton /> : undefined}>
        <ul className="grid gap-2 md:grid-cols-2 xl:grid-cols-3">{main.map(member)}</ul>
        <h3 className="mb-1 mt-4 text-sm font-semibold">{t("team.comm")}</h3><p className="mb-2 text-xs text-muted">{t("team.commText")}</p>
        <ul className="grid gap-2 md:grid-cols-2 xl:grid-cols-4">{comm.map(member)}</ul>
      </Card>
      <Card title={t("prop.title")}>
        {props.length === 0 ? <Empty>{t("prop.none")}</Empty> : (
          <ul className="grid gap-2">{props.map((x) => {
            const d = x.payload as Record<string, unknown>;
            return (
              <li key={x.id} className="grid gap-1 rounded-xl border border-line px-3 py-2 text-sm">
                <div className="flex flex-wrap items-center gap-2"><Pill tone="info">{t(k(`kind.${x.kind}`))}</Pill>{x.kind !== "calendar" && x.kind !== "review" && x.channel && x.channel !== "all" && <Pill tone="muted">{t(k(`ch.${x.channel}`) )}</Pill>}
                  <span className="text-xs text-muted">{t("prop.by", { name: String(d.authorName ?? nameOf.get(x.authorKey) ?? x.authorKey) })}{d.coveredFor ? ` ${t("prop.covering", { name: nameOf.get(String(d.coveredFor)) ?? String(d.coveredFor) })}` : ""}</span>
                  <span className="ms-auto"><Pill tone={x.status === "approved" ? "success" : x.status === "rejected" ? "muted" : "warning"}>{t(k(`st.${x.status}`))}</Pill></span></div>
                {x.kind === "review" ? <p>{(d.roi as { state: string } | undefined)?.state}</p> : <p className="whitespace-pre-line">{describe(x)}</p>}
                {x.outcome && <p className="text-xs text-muted">{t(k(`out.${x.outcome}`))}</p>}
                {x.status === "proposed" && approve && <DecisionButtons id={x.id} />}
              </li>);
          })}</ul>)}
      </Card>
      <Card title={t("roi.title")} action={manage && p ? <ReviewButton period={roi.period} /> : undefined}>
        {roi.state === "no_data" ? <p className="mb-3 text-sm text-muted">{t("roi.noData")}</p> : (
          <>
            {roi.state === "organic_only" && <p className="mb-3 text-sm text-muted">{t("roi.organic")}</p>}
            {roi.state === "sales_missing" && <p className="mb-3 text-sm text-muted">{t("roi.salesMissing")}</p>}
            <dl className="mb-3 grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-6">
              <Stat label={t("roi.investment")} value={m(roi.investmentMinor)} /><Stat label={t("roi.sales")} value={m(roi.salesMinor)} /><Stat label={t("roi.roi")} value={roi.roi === null ? "—" : `${roi.roi}X`} />
              <Stat label={t("roi.cpl")} value={roi.costPerLeadMinor === null ? "—" : m(roi.costPerLeadMinor)} /><Stat label={t("roi.leads")} value={roi.leads} /><Stat label={t("roi.customers")} value={roi.customers} />
            </dl>
            <p className="mb-3 text-xs text-muted">{t("roi.sources", { src: [roi.sources.manual && t("roi.srcManual"), roi.sources.marketing && t("roi.srcMarketing")].filter(Boolean).join(", ") })}</p>
          </>)}
        <h3 className="mb-1 text-sm font-semibold">{t("roi.next")}</h3>
        <ul className="mb-4 grid gap-1 text-sm">{roi.next.map((n) => <li key={n.key}>• {t(k(`nx.${n.key}`), { amount: n.vars?.amountMinor ? m(n.vars.amountMinor) : "" })}</li>)}</ul>
        {manage && <ResultForm period={roi.period} currency={roi.currency} />}
      </Card>
      <Card title={t("ads.title")}>
        <p className="mb-3 text-xs text-muted">{t("ads.notConnected")}</p>
        <ul className="grid gap-2 sm:grid-cols-2 xl:grid-cols-5">{AD_NETWORKS.map((n) => <li key={n} className="flex items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span>{t(k(`ch.${n}`))}</span><Pill tone="muted">{t("ads.status")}</Pill></li>)}</ul>
      </Card>
      <Card title={t("arch.title")}>
        <p className="mb-3 text-xs text-muted">{t("arch.notice")}</p>
        <ul className="grid gap-2 sm:grid-cols-2">{Object.entries(ARCHITECTURE_STATUS).map(([key, v]) => <li key={key} className="flex items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span>{t(k(`a.${key}`))}</span><Pill tone={TONE[ST(v) as keyof typeof TONE]}>{t(k(`st.${ST(v) === "built" ? (v.includes("rule") ? "rule_based" : "built") : ST(v) === "prepared" ? "prepared" : ST(v)}`))}</Pill></li>)}</ul>
      </Card>
    </div>
  );
}
