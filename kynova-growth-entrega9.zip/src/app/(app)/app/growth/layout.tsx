import type { ReactNode } from "react";
import { GrowthI18n } from "@/components/growth/I18n";
import { growthContext } from "@/components/growth/context";
import { GROWTH_DICTIONARIES } from "@/modules/growth";

export default async function GrowthLayout({ children }: { children: ReactNode }) {
  const { locale } = await growthContext();
  return <GrowthI18n dict={GROWTH_DICTIONARIES[locale]} locale={locale}><main id="main" className="mx-auto w-full max-w-[96rem] p-4 sm:p-6 lg:p-8">{children}</main></GrowthI18n>;
}
