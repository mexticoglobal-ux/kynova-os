-- Growth (Entrega 9): Marketing & Growth AI Business System. Owned by src/modules/growth.
-- Tenant-owned: tenant_id references companies and every index leads with tenant_id. Nothing is deleted.

CREATE TABLE `gr_plans` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `objective` text NOT NULL, `objective_note` text DEFAULT '' NOT NULL, `investment_minor` integer NOT NULL, `currency` text DEFAULT 'USD' NOT NULL,
	`scenario` text DEFAULT 'custom' NOT NULL, `bootstrap` integer DEFAULT 0 NOT NULL, `channels` text DEFAULT '[]' NOT NULL, `status` text DEFAULT 'active' NOT NULL, `created_by` text NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`objective` IN ('first_clients', 'sell_more', 'brand_awareness', 'leads', 'social_growth', 'youtube', 'other')),
	CHECK (`scenario` IN ('entrepreneur', 'growth', 'scaling', 'enterprise', 'custom', 'none')), CHECK (`status` IN ('active', 'superseded')),
	CHECK (`investment_minor` >= 0), CHECK (`bootstrap` IN (0, 1)), CHECK (length(`currency`) = 3)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `gr_plans_tenant_id_uq` ON `gr_plans` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `gr_plans_active_uq` ON `gr_plans` (`tenant_id`) WHERE `status` = 'active';--> statement-breakpoint

CREATE TABLE `gr_proposals` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `plan_id` text NOT NULL, `kind` text NOT NULL, `channel` text NOT NULL, `author_key` text NOT NULL, `title` text NOT NULL, `body` text NOT NULL,
	`payload` text DEFAULT '{}' NOT NULL, `status` text DEFAULT 'proposed' NOT NULL, `outcome` text DEFAULT '' NOT NULL, `ref_id` text, `dedupe_key` text NOT NULL, `decided_by` text, `decided_at` integer, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`tenant_id`, `plan_id`) REFERENCES `gr_plans`(`tenant_id`, `id`) ON UPDATE no action ON DELETE no action,
	CHECK (`kind` IN ('recommendation', 'calendar', 'post', 'ad_campaign', 'whatsapp_campaign', 'email_campaign', 'reply_templates', 'follow_up', 'review')),
	CHECK (`status` IN ('proposed', 'approved', 'rejected')), CHECK (`outcome` IN ('', 'draft_created', 'prepared')), CHECK (length(`payload`) <= 20000),
	CHECK (`outcome` = '' OR `status` = 'approved')
);
--> statement-breakpoint
CREATE UNIQUE INDEX `gr_proposals_tenant_id_uq` ON `gr_proposals` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `gr_proposals_dedupe_uq` ON `gr_proposals` (`tenant_id`,`dedupe_key`);--> statement-breakpoint
CREATE INDEX `gr_proposals_plan_idx` ON `gr_proposals` (`tenant_id`,`plan_id`,`status`,`created_at`);--> statement-breakpoint

CREATE TABLE `gr_results` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `period` text NOT NULL, `channel` text DEFAULT '' NOT NULL, `investment_minor` integer DEFAULT 0 NOT NULL, `sales_minor` integer DEFAULT 0 NOT NULL,
	`leads` integer DEFAULT 0 NOT NULL, `customers` integer DEFAULT 0 NOT NULL, `currency` text DEFAULT 'USD' NOT NULL, `note` text DEFAULT '' NOT NULL, `recorded_by` text NOT NULL, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (length(`period`) = 7), CHECK (`investment_minor` >= 0), CHECK (`sales_minor` >= 0), CHECK (`leads` >= 0), CHECK (`customers` >= 0), CHECK (length(`currency`) = 3)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `gr_results_tenant_id_uq` ON `gr_results` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `gr_results_period_uq` ON `gr_results` (`tenant_id`,`period`,`channel`);--> statement-breakpoint

CREATE TRIGGER gr_plans_frozen BEFORE UPDATE OF tenant_id ON gr_plans BEGIN SELECT RAISE(ABORT, 'growth plan tenant cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER gr_proposals_frozen BEFORE UPDATE OF tenant_id, plan_id, kind, channel, dedupe_key ON gr_proposals BEGIN SELECT RAISE(ABORT, 'growth proposal identity cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER gr_results_frozen BEFORE UPDATE OF tenant_id, period, channel ON gr_results BEGIN SELECT RAISE(ABORT, 'growth result identity cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER gr_proposals_decided_once BEFORE UPDATE OF status ON gr_proposals WHEN OLD.status <> 'proposed' AND NEW.status <> OLD.status BEGIN SELECT RAISE(ABORT, 'a decided proposal cannot be decided again'); END;
--> statement-breakpoint
CREATE TRIGGER gr_plans_no_delete BEFORE DELETE ON gr_plans BEGIN SELECT RAISE(ABORT, 'gr_plans rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER gr_proposals_no_delete BEFORE DELETE ON gr_proposals BEGIN SELECT RAISE(ABORT, 'gr_proposals rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER gr_results_no_delete BEFORE DELETE ON gr_results BEGIN SELECT RAISE(ABORT, 'gr_results rows cannot be deleted'); END;
