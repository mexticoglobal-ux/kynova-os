# ADR 026 · Marketing & Growth como primer AI Business System

**Estado:** aceptado · **Fecha:** 2026-10-21

## Contexto
El Framework (ADR 025) ya existe. Hay que demostrar trabajo real de AI Employees sin proveedor de IA ni redes publicitarias conectadas.

## Decisión
1. Nuevo módulo `growth` con el mismo patrón que los demás (puerto de almacén D1/memoria, servicio, `growthRoute`, i18n, migración 1900). No se toca el Framework.
2. **Equipo, no un empleado**: 10 roles; Communication Team bajo el Communication Manager. Se agregan 7 miembros al roster de `team` (cambio aditivo) y se amplía el plan Professional; el departamento `communication` es nuevo.
3. **Honestidad**: las propuestas se preparan por reglas (`preparedBy: rules`, modo *simulation*); los posts aprobados son borradores con brief; anuncios/WhatsApp/Email solo "preparados"; redes `connected:false`. Un proveedor de IA futuro entra por el puerto del Framework sin cambiar flujos.
4. **El cliente controla**: escenarios referenciales, monto libre (incluido 0), Bootstrap sin presión, toda acción que afecta al negocio requiere aprobación humana.
5. **ROI solo de datos reales**; sin datos, estado vacío.
6. Terminología única "Inversión".

## Escala a 10,000 empresas
Sí: tablas con `tenant_id` primero en índices, propuestas idempotentes por `dedupe_key`, agregados por SQL, sin estado en memoria ni proceso por empresa.

## Consecuencias
Redacción generativa, envío real y redes publicitarias quedan para el bloque de proveedores/producción.
