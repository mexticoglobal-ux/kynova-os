# 34 · Marketing & Growth (primer AI Business System)

Construido **encima** del AI Employee Framework (Entrega 8), sin rehacerlo. Módulo `src/modules/growth`, API `/api/v1/growth/*`, pantalla `/app/growth`.

## Flujo del cliente
1. **Objetivo** ("¿Cuál es tu objetivo?"): primeros clientes, vender más, marca, leads, redes, YouTube, otro.
2. **Escenarios referenciales** (Emprendedor / Crecimiento / Escalamiento / Enterprise) que se adaptan al objetivo. Son puntos de comparación, nunca obligación.
3. **"Quiero invertir: $____"**: cualquier monto, incluido $0. El plan anterior queda reemplazado (reversible).
4. **Modo Bootstrap** automático con inversión < $50: solo canales orgánicos (SEO, blog, redes, Reels, Shorts, YouTube, TikTok, Google Business Profile, WhatsApp Business, Email). Nunca presiona para invertir; solo con ventas orgánicas reales sugiere una inversión pequeña opcional.

## Equipo
Marketing Manager (coordina) · Content Manager (calendario 4 semanas) · Social Media Manager (publicaciones) · SEO Manager · Analytics Manager (revisión mensual) · Communication Manager, que lidera el **Communication Team**: WhatsApp Manager, Email Manager, Social Messaging Manager, Follow-up Manager (ejecutan). Si el plan no incluye a un especialista, el Marketing Manager lo cubre y la propuesta lo dice.

## Qué hace de verdad y qué no
| Capacidad | Estado |
|---|---|
| Propuestas del equipo (estrategia, calendario, posts, SEO, WhatsApp, Email, respuestas, seguimiento, anuncios) | Preparadas **por reglas** sobre el plan; no es IA generativa |
| Aprobar un post | Crea un **borrador** en Marketing con un *brief* (no se inventa texto); no publica |
| Campañas de anuncios, WhatsApp, Email | **Preparadas, no enviadas**; ninguna red conectada |
| Redes publicitarias (Meta, Google, YouTube, TikTok, LinkedIn) | Flujo preparado, `connected:false` |
| ROI | Solo de resultados **registrados** (manual) o de Marketing; sin datos → estado honesto |
| Proceso 24/7, aprendizaje entre empresas | No construido |

## ROI
Inversión, ventas generadas, ROI (ventas/inversión, p. ej. $300 → $4,500 = 15X), costo por lead, costo por cliente, clientes nuevos y recomendaciones para el próximo mes. Estados: sin datos · orgánico · incompleto (sin ventas) · completo.

## Evidencia (Activity Engine)
`growth.plan.set`, `growth.proposal.prepared` (simulación, actor empleado), `growth.proposal.approved/rejected` (producción, actor persona), `growth.review.prepared`. Idempotentes; el registro nunca rompe la acción.

## "Inversión", no "gasto"
Textos de Growth, Marketing (`metrics.spend`) y Analytics (`metric.marketing_spend`) usan Inversión. Finanzas conserva "Gastos" contables: es contabilidad, no publicidad.

## Datos
Tablas `gr_plans`, `gr_proposals`, `gr_results` (migración 1900): `tenant_id` primero en cada índice, identidad congelada, sin DELETE, una propuesta decidida no se re-decide, un plan activo por empresa.

## KYNOVA como primer cliente
No hay datos sembrados. Una empresa nueva ve "Sin plan / Sin resultados" hasta que registra su objetivo, inversión y resultados.
