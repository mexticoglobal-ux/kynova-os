import { describe, expect, it } from "vitest";
import { employeeKeyOf, ROSTER, ROSTER_BY_KEY, blueprintOf, stageOf, SOON_KEYS } from "../../../src/modules/team/roster";
import { PLAN_TEAMS, STARTER_TEAM, teamOf, isEntitled } from "../../../src/modules/team/entitlements";
import { toEvidence, runsAsSimulation } from "../../../src/modules/team/bridge";
import { BLUEPRINT_KEY } from "@/platform/ai-employees";
import { H, NOW, GUEST, OWNER, SALES, code, emp, ev, fixture, task } from "./helpers";

describe("roster", () => {
  it("is the official list, with valid unique keys and no invented blueprint", () => {
    expect(ROSTER.length).toBe(54); expect(new Set(ROSTER.map((r) => r.key)).size).toBe(ROSTER.length);
    for (const r of ROSTER) expect(blueprintOf(r), r.key).toMatch(BLUEPRINT_KEY);
    expect(ROSTER_BY_KEY.get("partner_manager")?.blueprint).toBe("partner_manager"); expect(ROSTER_BY_KEY.get("ceo_ai")?.blueprint).toBe("executive_advisor");
  });
  it("derives a stable, safe activity key per activated employee", () => { expect(employeeKeyOf("AB-12_cd")).toBe("emp_ab12cd"); expect(employeeKeyOf("x".repeat(80)).length).toBeLessThanOrEqual(44); });
});

describe("overview: honest states", () => {
  it("a new company: everyone not activated, nothing invented", async () => {
    const { svc } = fixture(), o = await svc.overview(OWNER);
    expect([o.state, o.counts.active, o.counts.working, o.counts.approvals, o.away.events, o.timeline.length]).toEqual(["empty", 0, 0, 0, 0, 0]);
    expect(o.team.every((m) => m.status === "inactive")).toBe(true); expect(o.team.find((m) => m.key === "marketing_manager")!.activatable).toBe(true); expect(o.team.find((m) => m.key === "seo_auditor")!.activatable).toBe(false);
    expect(o.sources).toEqual({ employees: true, activity: true });
  });
  it("a activated employee with no evidence is 'empty', not working", async () => {
    const { svc } = fixture({ employees: [emp({ id: "e1", blueprint: "marketing_manager" })] }), m = (await svc.overview(OWNER)).team.find((x) => x.key === "marketing_manager")!;
    expect([m.status, m.lastAt, m.mode]).toEqual(["empty", null, null]);
  });
  it("being activated is not work: the hire event alone leaves the member at 'empty'", async () => {
    const f = fixture({ employees: [emp({ id: "e1", blueprint: "marketing_manager" })], events: [ev({ id: "h", action: "employee.activated", module: "employees", employeeKey: employeeKeyOf("e1"), mode: "simulation" })] });
    const m = (await f.svc.overview(OWNER)).team.find((x) => x.key === "marketing_manager")!; expect([m.status, m.lastAt, m.mode]).toEqual(["empty", null, null]);
  });
  it("derives working, waiting, issue, idle and paused from tasks", async () => {
    const f = fixture({ employees: [emp({ id: "e1", blueprint: "marketing_manager" }), emp({ id: "e2", blueprint: "partner_manager" }), emp({ id: "e3", blueprint: "executive_advisor" }), emp({ id: "e4", blueprint: "billing_advisor", status: "paused" }), emp({ id: "e5", blueprint: "analytics_advisor" })],
      tasks: [task({ id: "t1", employeeId: "e1", status: "running", finishedAt: null }), task({ id: "t2", employeeId: "e2", status: "awaiting_approval", finishedAt: null, result: { actions: [{ capability: "crm.create_note", rationale: "why", status: "pending" }] } }),
        task({ id: "t3", employeeId: "e3", status: "failed" }), task({ id: "t4", employeeId: "e5", status: "succeeded" })] });
    const o = await f.svc.overview(OWNER), st = (k: string) => o.team.find((m) => m.key === k)!.status;
    expect([st("marketing_manager"), st("partner_manager"), st("ceo_ai"), st("billing_manager"), st("analytics_advisor")]).toEqual(["working", "awaiting_approval", "issue", "paused", "idle"]);
    expect(o.counts).toMatchObject({ active: 5, working: 0, approvals: 1, issues: 1 }); expect(o.approvals[0]).toMatchObject({ taskId: "t2", employeeName: "partner_manager", actions: [{ capability: "crm.create_note", rationale: "why" }] });
  });
  it("a later success clears an old failure", async () => {
    const f = fixture({ employees: [emp({ id: "e1", blueprint: "marketing_manager" })], tasks: [task({ id: "a", employeeId: "e1", status: "failed", finishedAt: NOW - 3 * H }), task({ id: "b", employeeId: "e1", status: "succeeded", finishedAt: NOW - H })] });
    expect((await f.svc.overview(OWNER)).team.find((m) => m.key === "marketing_manager")!.status).toBe("idle");
  });
  it("shows the mode of the last evidence, so simulation is never passed off as real work", async () => {
    const f = fixture({ employees: [emp({ id: "e1", blueprint: "marketing_manager" })], events: [ev({ id: "x", action: "employee.task.completed", module: "employees", actorKind: "employee", employeeKey: employeeKeyOf("e1"), mode: "simulation" })], state: "simulation" });
    const o = await f.svc.overview(OWNER), m = o.team.find((x) => x.key === "marketing_manager")!;
    expect([o.state, m.mode, m.status]).toEqual(["simulation", "simulation", "idle"]); expect(o.away.events).toBe(0);
  });
  it("'while you were away' counts only real successful work in the window", async () => {
    const f = fixture({ state: "production", events: [ev({ id: "1", quantity: 3 }), ev({ id: "2", occurredAt: NOW - 30 * H }), ev({ id: "3", outcome: "failed" }), ev({ id: "4", mode: "demo" })] });
    const o = await f.svc.overview(OWNER); expect(o.away.groups).toEqual([{ module: "partners", action: "partners.partner.created", events: 1, quantity: 3 }]);
    expect((await f.svc.overview(OWNER, { since: NOW - 40 * H })).away.events).toBe(2);
  });
  it("clamps the window to 14 days and never to the future", async () => { const { svc } = fixture(); expect((await svc.overview(OWNER, { since: 1 })).until - (await svc.overview(OWNER, { since: 1 })).since).toBe(14 * 86_400_000); expect((await svc.overview(OWNER, { since: NOW + 5 * H })).since).toBe(NOW); });
});

describe("service", () => {
  it("says when a source could not be read instead of showing 'nothing happened'", async () => {
    const f = fixture(); f.f.broken.add("activity"); f.f.broken.add("employees"); const o = await f.svc.overview(OWNER);
    expect(o.sources).toEqual({ employees: false, activity: false });
  });
  it("guests are refused; other roles can see; hire/decide rights come from the framework", async () => {
    const { svc } = fixture(); expect(await code(svc.overview(GUEST))).toBe("forbidden"); expect((await svc.overview(SALES)).can).toEqual({ activate: false, decide: false }); expect((await svc.overview(OWNER)).can).toEqual({ activate: true, decide: true });
  });
  it("a member page: not found for unknown keys, empty when not activated, tasks and evidence when activated", async () => {
    const f = fixture({ employees: [emp({ id: "e1", blueprint: "marketing_manager" })], tasks: [task({ id: "t1", employeeId: "e1" }), task({ id: "t2", employeeId: "other" })], events: [ev({ id: "e", action: "employee.task.completed", module: "employees", employeeKey: employeeKeyOf("e1") }), ev({ id: "z" })] });
    expect(await code(f.svc.member(OWNER, "nope"))).toBe("not_found");
    const none = await f.svc.member(OWNER, "seo_auditor"); expect([none.member.status, none.tasks.length, none.events.length]).toEqual(["inactive", 0, 0]);
    const m = await f.svc.member(OWNER, "marketing_manager"); expect([m.tasks.map((x) => x.id), m.events.map((x) => x.id)]).toEqual([["t1"], ["e"]]);
  });
});

describe("bridge", () => {
  const E = (type: string, detail?: Record<string, unknown>, o: object = {}) => ({ type, tenantId: "t", employeeId: "e1", taskId: "k1", detail, ...o }) as never;
  it("turns task outcomes into evidence and ignores the noise", () => {
    expect(toEvidence(E("employee.task.succeeded"))).toMatchObject({ action: "employee.task.completed", outcome: "success", key: "done:k1" });
    expect(toEvidence(E("employee.task.failed", { code: "x" }))).toMatchObject({ action: "employee.task.failed", outcome: "failed" });
    expect(toEvidence(E("employee.task.awaiting_approval"))).toMatchObject({ outcome: "skipped" });
    expect(toEvidence(E("employee.action.executed", { capability: "crm.create_note" }))).toMatchObject({ key: "act:k1:crm.create_note" });
    expect(toEvidence(E("employee.created", undefined, { taskId: undefined }))).toMatchObject({ action: "employee.activated" });
    for (const t of ["employee.task.started", "employee.task.enqueued", "employee.task.retry_scheduled", "employee.budget.warning", "employee.audit.failed", "employee.updated"]) expect(toEvidence(E(t)), t).toBeNull();
    expect(toEvidence({ type: "employee.task.succeeded", tenantId: "t" })).toBeNull();
  });
  it("local and test runs are labelled simulation; only deployed environments are production", () => {
    expect(runsAsSimulation({ APP_ENV: "local" })).toBe(true); expect(runsAsSimulation({ APP_ENV: "test" })).toBe(true);
    for (const e of ["preview", "staging", "production"]) expect(runsAsSimulation({ APP_ENV: e })).toBe(false);
    expect(runsAsSimulation({ NODE_ENV: "production" })).toBe(false); expect(runsAsSimulation({ NODE_ENV: "development" })).toBe(true);
  });
});

describe("plans decide the team, and readiness decides what may be shown as work", () => {
  it("Starter is the owner's six; Business and Enterprise have everyone; an unknown plan falls back to the smallest team", () => {
    expect([...STARTER_TEAM]).toEqual(["ceo_ai", "marketing_manager", "sales_manager", "customer_success_manager", "finance_manager", "integration_manager"]);
    for (const k of STARTER_TEAM) expect(ROSTER_BY_KEY.has(k), k).toBe(true);
    expect([PLAN_TEAMS.business, PLAN_TEAMS.enterprise]).toEqual(["all", "all"]); expect(teamOf("nonsense")).toBe(PLAN_TEAMS.starter); expect(teamOf(null)).toBe(PLAN_TEAMS.starter);
    expect(isEntitled(teamOf("starter"), "seo_auditor")).toBe(false); expect(isEntitled(teamOf("business"), "seo_auditor")).toBe(true);
  });
  it("stages: tools = ready, nothing behind = soon, everything else in preparation", () => {
    expect(stageOf(ROSTER_BY_KEY.get("partner_manager")!)).toBe("ready"); expect(stageOf(ROSTER_BY_KEY.get("marketing_manager")!)).toBe("preparing"); expect(stageOf(ROSTER_BY_KEY.get("legal_assistant")!)).toBe("soon");
    for (const k of SOON_KEYS) expect(ROSTER_BY_KEY.has(k), k).toBe(true);
  });
  it("a Starter company sees the other members as outside the plan and cannot activate them", async () => {
    const f = fixture({ plan: "starter" }), o = await f.svc.overview(OWNER);
    expect(o.team.filter((m) => m.entitled).map((m) => m.key).sort()).toEqual([...STARTER_TEAM].sort()); expect(o.plan).toEqual({ code: "starter", known: true, team: 6 });
    expect(o.team.find((m) => m.key === "marketing_manager")!.activatable).toBe(true); expect(o.team.find((m) => m.key === "partner_manager")!.activatable).toBe(false);
    expect(await code(f.svc.activate(OWNER, "partner_manager"))).toBe("plan_required"); expect(f.f.activated).toHaveLength(0);
  });
  it("an unreadable plan gets the smallest team and says so", async () => {
    const f = fixture(); f.f.broken.add("plan"); const o = await f.svc.overview(OWNER); expect(o.plan).toMatchObject({ known: false, team: 6 });
  });
  it("activation: only what is in the plan and has something behind it, once, by a role that may", async () => {
    const f = fixture({ plan: "business", registered: ["marketing_manager", "partner_manager"] });
    expect(await code(f.svc.activate(OWNER, "nope"))).toBe("not_found"); expect(await code(f.svc.activate(OWNER, "legal_assistant"))).toBe("invalid_state"); expect(await code(f.svc.activate(OWNER, "seo_auditor"))).toBe("invalid_state");
    expect(await code(f.svc.activate(GUEST, "marketing_manager"))).toBe("forbidden");
    expect(await code(f.svc.activate(OWNER, "marketing_manager"))).toBe("ok"); expect(f.f.activated).toEqual([expect.objectContaining({ blueprint: "marketing_manager", name: "Marketing Manager" })]);
    f.f.employees.push(emp({ id: "e1", blueprint: "marketing_manager" })); expect(await code(f.svc.activate(OWNER, "marketing_manager"))).toBe("conflict");
    expect(await code(f.svc.activate(OWNER, "partner_manager"))).toBe("ok"); expect(f.f.activated.at(-1)).toMatchObject({ blueprint: "partner_manager" });
    f.f.broken.add("employees"); expect(await code(f.svc.activate(OWNER, "partner_manager"))).toBe("unavailable");
  });
  it("a member in preparation is never counted or listed as working, even with a running task", async () => {
    const f = fixture({ employees: [emp({ id: "e1", blueprint: "marketing_manager" }), emp({ id: "e2", blueprint: "partner_manager" })], tasks: [task({ id: "a", employeeId: "e1", status: "running", finishedAt: null }), task({ id: "b", employeeId: "e2", status: "running", finishedAt: null })] });
    const o = await f.svc.overview(OWNER), prep = o.team.find((m) => m.key === "marketing_manager")!, ready = o.team.find((m) => m.key === "partner_manager")!;
    expect([prep.stage, prep.relevant, ready.stage, ready.relevant, o.counts.working, o.counts.relevant]).toEqual(["preparing", false, "ready", true, 1, 1]);
  });
  it("the teams summary folds the roster by department", async () => {
    const o = await fixture({ plan: "starter" }).svc.overview(OWNER); const m = o.teams.find((t) => t.department === "marketing")!;
    expect(m).toMatchObject({ total: 7, active: 0, relevant: 0, entitled: 1 }); expect(o.teams.reduce((n, t) => n + t.total, 0)).toBe(54);
  });
});
