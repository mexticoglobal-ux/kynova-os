import type { Role } from "@/config/roles";
import type { ActivitySink, SinkEvent } from "@/platform/activity";
import { createGrowthService, type Actor, type GrowthPorts, type MemberInfo } from "../../../src/modules/growth/service";
import { createMemoryGrowthStore } from "../../../src/modules/growth/store-memory";
import { GROWTH_KEYS } from "../../../src/modules/growth/team";

export const T1 = "tenant-one", T2 = "tenant-two", START = Date.UTC(2026, 9, 20, 12);
export const actor = (role: Role, tenantId = T1): Actor => ({ tenantId, userId: `${role}-1`, role });
export const OWNER = actor("owner"), MARKETING = actor("marketing"), SALES = actor("sales"), FINANCE = actor("finance");
export const code = async (p: Promise<unknown>) => { try { await p; return "ok"; } catch (e) { return (e as { code?: string }).code ?? `other:${(e as Error).message}`; } };

export interface Fixture { notEntitled: Set<string>; marketing: { spendMinor: number; conversions: number; currency: string } | null; drafts: { title: string; body: string }[] }
export function harness(o: Partial<Fixture> = {}) {
  const f: Fixture = { notEntitled: new Set(), marketing: null, drafts: [], ...o };
  const events: (SinkEvent & { tenantId: string })[] = [], clock = { t: START };
  const ports: GrowthPorts = {
    async member(_a, key): Promise<MemberInfo | null> { return GROWTH_KEYS.includes(key) ? { key, name: key.replace(/_/g, " "), entitled: !f.notEntitled.has(key), active: true, activityKey: `emp_${key.replace(/_/g, "")}` } : null; },
    marketing: async () => f.marketing,
    async createDraft(_a, d) { f.drafts.push(d); return { id: `post${f.drafts.length}` }; },
  };
  const activity: ActivitySink = {
    async record(ctx, e) { events.push({ tenantId: ctx.tenantId, ...e }); return { ok: false, error: { code: "test", message: "captured" } }; },
    async recordStrict(ctx, e) { events.push({ tenantId: ctx.tenantId, ...e }); throw new Error("captured"); },
  };
  let n = 0;
  const svc = createGrowthService({ store: createMemoryGrowthStore(), ports, newId: () => `id${String(++n).padStart(6, "0")}`, now: () => clock.t, activity, locale: "es" });
  return { f, svc, events, clock };
}
export type H = ReturnType<typeof harness>;
export const actions = (h: H) => h.events.map((e) => e.action);
export const plan = (h: H, investmentMinor: number, objective = "leads", extra: Record<string, unknown> = {}) => h.svc.setPlan(OWNER, { objective, investmentMinor, ...extra });
