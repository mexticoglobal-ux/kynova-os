import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES, canAccess } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { COLUMNS, TABLE } from "../../../src/modules/growth/columns";
import { ARCHITECTURE_STATUS } from "../../../src/modules/growth/contracts";
import { CAPABILITIES, DEFAULT_CAPABILITIES } from "../../../src/modules/growth/domain";
import { GROWTH_DICTIONARIES } from "../../../src/modules/growth/i18n";
import { GROWTH_TEAM } from "../../../src/modules/growth/team";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => { try { return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; }); } catch { return []; } };
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "growth");
const bad = (dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const badExcept = (skip: string, dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).filter((f) => !f.endsWith(skip)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "growth"), join(SRC, "app", "(app)", "app", "growth")];
const strip = (s: string) => s.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");
const OTHERS = "crm|marketing|seo|ai-studio|finance|communications|billing|security|analytics|analytics-bi|mission-control|integrations|marketplace|partners|referrals|portal|activation|workforce";

describe("Growth module boundaries", () => {
  it("never depends on a vendor SDK, the AI Kernel or an ad network: nothing is sent, published or invested from here", () => {
    expect(bad([MOD, ...UI], /ai-kernel|@anthropic-ai|openai|@google\/generative|mistral|deepseek|facebook-nodejs|google-ads|twilio|sendgrid|resend/i)).toEqual([]);
    expect(files(MOD).filter((f) => /(?<![.\w])fetch\(|XMLHttpRequest|new WebSocket|node:https?|node:net/.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
  });
  it("only server.ts meets the database, the framework, the roster and the other modules", () => {
    expect(badExcept("server.ts", [MOD], new RegExp(`drizzle-orm|platform/db|ai-employees|modules/team|modules/(${OTHERS})`))).toEqual([]);
    expect(bad([MOD, ...UI], /platform\/activity\/(?!$)/)).toEqual([]);
  });
  it("only the store layer knows SQL", () => {
    expect(files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f))).toEqual(["store-d1.ts"]);
  });
  it("frozen code does not know Growth", () => {
    const frozen = ["platform/db", "platform/auth", "platform/ai-kernel", "platform/ai-employees", "platform/activity", ...OTHERS.split("|").map((m) => `modules/${m}`)].map((d) => join(SRC, d));
    expect(bad(frozen, /modules\/growth|components\/growth/)).toEqual([]);
  });
  it("UI uses the module's public interface only, and client components stay free of server-only imports", () => {
    expect(bad(UI, new RegExp(`platform/db|drizzle|modules/growth/(store|columns|runtime|server)|modules/(${OTHERS}|team)`))).toEqual([]);
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThanOrEqual(2);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/growth\/(service|server|http|store|runtime)/.test(i)))).toEqual([]);
  });
});

describe("honesty of the system", () => {
  it("states plainly what is only prepared and what is not built", () => {
    expect(ARCHITECTURE_STATUS).toMatchObject({ generative_copy: "not_connected", email_campaigns: "prepared_not_sent", whatsapp_campaigns: "prepared_not_sent", ad_networks: "prepared_not_connected", continuous_worker: "not_built", cross_company_learning: "not_built" });
  });
  it("the team is the six managers plus the four-person Communication Team", () => {
    expect(GROWTH_TEAM.map((m) => m.key)).toEqual(["marketing_manager", "content_manager", "social_media_manager", "seo_manager", "analytics_manager", "communication_manager", "whatsapp_manager", "email_manager", "social_messaging_manager", "follow_up_manager"]);
    expect(GROWTH_TEAM.filter((m) => m.parent === "communication_manager")).toHaveLength(4);
  });
});

describe("API surface: only /api/v1/growth/*", () => {
  const API = join(SRC, "app", "api", "v1", "growth"), routes = files(API).filter((f) => f.endsWith("route.ts"));
  it("every handler goes through growthRoute; every mutating verb enables CSRF checks", () => {
    expect(routes.length).toBeGreaterThanOrEqual(10);
    for (const f of routes) {
      const src = readFileSync(f, "utf8");
      for (const m of src.matchAll(/export const (GET|POST|PATCH|PUT|DELETE) = (\w+)/g)) {
        expect(m[2], `${relative(SRC, f)} ${m[1]}`).toBe("growthRoute");
        const decl = src.slice(src.indexOf(m[0])), next = decl.indexOf("\nexport const", 10), block = decl.slice(0, next === -1 ? decl.length : next);
        if (m[1] !== "GET") expect(block, `${relative(SRC, f)} ${m[1]}`).toContain("mutating: true"); else expect(block).not.toContain("mutating");
      }
    }
  });
});

describe("migration 1900_growth.sql", () => {
  const sql = readFileSync(join(process.cwd(), "drizzle/migrations/1900_growth.sql"), "utf8");
  const tables = [...sql.matchAll(/CREATE TABLE `(gr_\w+)` \(([\s\S]*?)\n\);/g)];
  it("creates exactly the gr_ tables and touches nothing else", () => {
    expect(tables).toHaveLength(Object.keys(TABLE).length); expect(Object.values(TABLE).sort()).toEqual(tables.map((t) => t[1]).sort());
    expect(sql.replace(/^--.*$/gm, "")).not.toMatch(/ALTER TABLE|DROP TABLE|DROP INDEX|INSERT INTO|DELETE FROM/);
    for (const o of sql.matchAll(/CREATE (?:UNIQUE )?INDEX `(\w+)`/g)) expect(o[1]).toMatch(/^gr_/);
  });
  it("every table is tenant-owned with tenant-first indexes, a frozen identity and no deletes", () => {
    for (const [, name, body] of tables) {
      expect(body, name).toContain("`tenant_id` text NOT NULL"); expect(body, name).toContain("FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`)");
      for (const ix of sql.matchAll(new RegExp(`CREATE (?:UNIQUE )?INDEX \`\\w+\` ON \`${name}\` \\(([^)]*)\\)`, "g"))) expect(ix[1], name).toMatch(/^`tenant_id`/);
      expect(sql, name).toContain(`CREATE TRIGGER ${name}_no_delete`); expect(sql, name).toContain(`CREATE TRIGGER ${name}_frozen`);
    }
  });
  it("whitelists cover each kind and carry the tenant column", () => { for (const k of Object.keys(TABLE) as (keyof typeof TABLE)[]) { expect(COLUMNS[k]).toContain("id"); expect(COLUMNS[k]).toContain("tenantId"); } });
});

describe("access and texts", () => {
  it("module access is the outer gate; default capabilities only narrow it", () => {
    for (const r of ROLES) if (!canAccess(r, "growth")) expect(DEFAULT_CAPABILITIES[r].length, r).toBe(0);
    expect(DEFAULT_CAPABILITIES.owner).toHaveLength(CAPABILITIES.length);
    expect(MODULES.filter((m) => m.slug === "growth")).toHaveLength(1);
  });
  it("English and Spanish have the same keys, no empty text and the word 'gasto' / 'spend' never appears: it is always Inversión", () => {
    const en = GROWTH_DICTIONARIES.en as Record<string, string>, es = GROWTH_DICTIONARIES.es as Record<string, string>;
    expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort());
    for (const [k, v] of Object.entries(es)) { expect(v.trim(), k).not.toBe(""); expect(v, k).not.toMatch(/gast/i); }
    for (const [k, v] of Object.entries(en)) expect(v, k).not.toMatch(/\bspen[dt]|\bspending\b|\bexpense/i);
    for (const k of Object.keys(ARCHITECTURE_STATUS)) expect(en[`a.${k}`], k).toBeTruthy();
    expect(es["inv.free"]).toBe("Quiero invertir:");
  });
});
