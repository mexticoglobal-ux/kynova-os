import { describe, expect, it } from "vitest";
import { computeRoi, nextSteps } from "../../../src/modules/growth/planner";
import { FINANCE, MARKETING, OWNER, SALES, actions, actor, code, harness, plan, T2 } from "./helpers";

describe("objective → investment", () => {
  it("offers four scenarios adapted to the objective, marked as reference, and never a single forced number", () => {
    const { svc } = harness(), a = svc.recommend(OWNER, { objective: "first_clients" }), b = svc.recommend(OWNER, { objective: "brand_awareness" });
    expect(a.scenarios.map((s) => s.scenario)).toEqual(["entrepreneur", "growth", "scaling", "enterprise"]); expect(a.referential).toBe(true);
    expect(a.scenarios.map((s) => s.amountMinor)).toEqual([...a.scenarios.map((s) => s.amountMinor)].sort((x, y) => x - y));
    expect(a.scenarios[1]!.amountMinor).not.toBe(b.scenarios[1]!.amountMinor);
    expect(a.organic[0]).toBe("google_business"); expect(b.organic[0]).toBe("instagram");
    expect(() => svc.recommend(OWNER, { objective: "nonsense" })).toThrow();
  });
  it("accepts ANY amount, including zero, and records what the company chose", async () => {
    const h = harness();
    const zero = await plan(h, 0); expect(zero).toMatchObject({ investmentMinor: 0, scenario: "none", bootstrap: true });
    const odd = await plan(h, 12345, "sell_more", { scenario: "custom" }); expect(odd).toMatchObject({ investmentMinor: 12345, scenario: "custom", bootstrap: false });
    const picked = await plan(h, 50000, "sell_more", { scenario: "growth" }); expect(picked.scenario).toBe("growth");
    expect(await code(plan(h, -5))).toBe("validation_failed"); expect(await code(plan(h, 1.5))).toBe("validation_failed");
    expect(await code(plan(h, 1000, "other"))).toBe("validation_failed"); expect(await code(plan(h, 1000, "other", { objectiveNote: "Vender cursos" }))).toBe("ok");
  });
  it("keeps one active plan and supersedes the old one, with evidence", async () => {
    const h = harness(); await plan(h, 0); const second = await plan(h, 20000);
    expect((await h.svc.plan(OWNER))?.id).toBe(second.id); expect(actions(h).filter((x) => x === "growth.plan.set")).toHaveLength(2);
  });
  it("Bootstrap (zero or very low investment) is organic only: no paid networks, no ad proposals, nothing that pushes to invest", async () => {
    const h = harness(); const p = await plan(h, 3000, "first_clients");
    expect(p.bootstrap).toBe(true); expect(p.channels.some((c) => c.endsWith("_ads"))).toBe(false);
    const { proposals } = await h.svc.generate(OWNER);
    expect(proposals.some((x) => x.kind === "ad_campaign")).toBe(false);
    expect(proposals.map((x) => x.kind)).toEqual(expect.arrayContaining(["recommendation", "calendar", "whatsapp_campaign", "email_campaign", "follow_up", "reply_templates"]));
    expect(JSON.stringify(proposals.map((x) => [x.title, x.body, x.channel]))).not.toMatch(/invest|ads/i);
  });
  it("with a real investment it prepares one ad proposal per network, never connected, splitting only the amount the client typed", async () => {
    const h = harness(); await plan(h, 90000, "brand_awareness");
    const ads = (await h.svc.generate(OWNER)).proposals.filter((x) => x.kind === "ad_campaign");
    expect(ads.map((x) => x.channel)).toEqual(["meta_ads", "tiktok_ads", "youtube_ads"]);
    expect(ads.reduce((n, x) => n + (x.payload.suggestedMinor as number), 0)).toBe(90000); expect(ads.every((x) => x.payload.connected === false)).toBe(true);
  });
});

describe("the team", () => {
  it("each specialist authors its own kind of work, and the Communication Team executes", async () => {
    const h = harness(); await plan(h, 90000, "sell_more");
    const by = new Map((await h.svc.generate(OWNER)).proposals.map((x) => [x.kind, x.authorKey]));
    expect(by.get("calendar")).toBe("content_manager"); expect(by.get("post")).toBe("social_media_manager"); expect(by.get("whatsapp_campaign")).toBe("whatsapp_manager");
    expect(by.get("email_campaign")).toBe("email_manager"); expect(by.get("reply_templates")).toBe("social_messaging_manager"); expect(by.get("follow_up")).toBe("follow_up_manager"); expect(by.get("ad_campaign")).toBe("marketing_manager");
  });
  it("when the plan does not include a specialist, the Marketing Manager covers and says so", async () => {
    const h = harness({ notEntitled: new Set(["content_manager", "whatsapp_manager"]) }); await plan(h, 0, "first_clients");
    const ps = (await h.svc.generate(OWNER)).proposals, cal = ps.find((x) => x.kind === "calendar")!, wa = ps.find((x) => x.kind === "whatsapp_campaign")!;
    expect([cal.authorKey, cal.payload.coveredFor]).toEqual(["marketing_manager", "content_manager"]); expect([wa.authorKey, wa.payload.coveredFor]).toEqual(["marketing_manager", "whatsapp_manager"]);
    const o = await h.svc.overview(OWNER); expect(o.team.find((m) => m.key === "content_manager")).toMatchObject({ entitled: false, proposed: 0 });
  });
  it("generating again adds nothing; no plan means no work", async () => {
    const h = harness(); expect(await code(h.svc.generate(OWNER))).toBe("invalid_state");
    await plan(h, 0); const first = await h.svc.generate(OWNER); expect(first.created).toBeGreaterThan(5);
    expect((await h.svc.generate(OWNER)).created).toBe(0); expect(await h.svc.proposals(OWNER)).toHaveLength(first.created);
  });
  it("leaves evidence for every proposal, attributed to the employee and labelled as prepared by rules (simulation)", async () => {
    const h = harness(); await plan(h, 0); const { created } = await h.svc.generate(OWNER);
    const ev = h.events.filter((e) => e.action === "growth.proposal.prepared");
    expect(ev).toHaveLength(created); expect(ev.every((e) => e.actorKind === "employee" && e.mode === "simulation" && e.employeeKey)).toBe(true);
    expect((await h.svc.proposals(OWNER))[0]!.payload.preparedBy).toBe("rules");
  });
});

describe("human approval", () => {
  it("a post becomes a DRAFT in Marketing (a brief, not invented copy); everything else is only prepared", async () => {
    const h = harness(); await plan(h, 90000, "first_clients"); const ps = (await h.svc.generate(OWNER)).proposals;
    const post = ps.find((x) => x.kind === "post")!, ad = ps.find((x) => x.kind === "ad_campaign")!, wa = ps.find((x) => x.kind === "whatsapp_campaign")!;
    const p = await h.svc.decide(OWNER, post.id, { approve: true }); expect(p).toMatchObject({ status: "approved", outcome: "draft_created", refId: "post1" });
    expect(h.f.drafts).toHaveLength(1); expect(h.f.drafts[0]!.body).toMatch(/BRIEF/); expect(h.f.drafts[0]!.body).toMatch(/pendiente/);
    expect((await h.svc.decide(OWNER, ad.id, { approve: true })).outcome).toBe("prepared"); expect((await h.svc.decide(OWNER, wa.id, { approve: true })).outcome).toBe("prepared");
    expect(h.f.drafts).toHaveLength(1);
    expect(actions(h)).toContain("growth.proposal.approved");
  });
  it("rejecting creates nothing, a decision is final, and only approvers decide", async () => {
    const h = harness(); await plan(h, 0); const [first, second] = (await h.svc.generate(OWNER)).proposals as unknown as [{ id: string }, { id: string }];
    expect((await h.svc.decide(OWNER, first.id, { approve: false })).status).toBe("rejected"); expect(h.f.drafts).toHaveLength(0);
    expect(await code(h.svc.decide(OWNER, first.id, { approve: true }))).toBe("invalid_state");
    expect(await code(h.svc.decide(MARKETING, second.id, { approve: true }))).toBe("forbidden"); expect(await code(h.svc.decide(OWNER, "ghost", { approve: true }))).toBe("not_found");
  });
});

describe("results and ROI", () => {
  it("shows an honest empty state when nothing has been recorded: no invented numbers", async () => {
    const h = harness(); const r = await h.svc.roi(OWNER);
    expect(r).toMatchObject({ state: "no_data", roi: null, costPerLeadMinor: null, investmentMinor: 0, salesMinor: 0 }); expect(r.next.map((n) => n.key)).toEqual(["register_results"]);
    expect((await h.svc.overview(OWNER)).state).toBe("empty");
  });
  it("computes the business ROI from recorded results: $300 → $4,500 = 15x", async () => {
    const h = harness(); await plan(h, 30000);
    await h.svc.recordResult(OWNER, { period: "2026-10", investmentMinor: 30000, salesMinor: 450000, leads: 60, customers: 9 });
    const r = await h.svc.roi(OWNER, { period: "2026-10" });
    expect(r).toMatchObject({ state: "complete", roi: 15, costPerLeadMinor: 500, costPerCustomerMinor: 3333 }); expect(r.next.map((n) => n.key)).toEqual(["scale_with_control"]);
  });
  it("uses the investment Marketing recorded when no manual figure exists, and says where it came from", async () => {
    const h = harness({ marketing: { spendMinor: 20000, conversions: 4, currency: "USD" } }); await plan(h, 20000);
    await h.svc.recordResult(OWNER, { period: "2026-10", salesMinor: 100000, leads: 10 });
    const r = await h.svc.roi(OWNER, { period: "2026-10" }); expect(r).toMatchObject({ investmentMinor: 20000, roi: 5, sources: { manual: true, marketing: true } });
  });
  it("a Bootstrap company with organic sales is told to stay organic, and only then offered a small optional investment", async () => {
    const h = harness(); await plan(h, 0);
    expect((await h.svc.roi(OWNER)).next.map((n) => n.key)).toEqual(["register_results"]);
    await h.svc.recordResult(OWNER, { period: "2026-10", salesMinor: 200000, leads: 12, customers: 3 });
    const r = await h.svc.roi(OWNER, { period: "2026-10" }); expect(r.state).toBe("organic_only"); expect(r.roi).toBeNull();
    expect(r.next.map((n) => n.key)).toEqual(["stay_organic", "consider_small_investment"]);
    const none = harness(); await plan(none, 0); await none.svc.recordResult(OWNER, { period: "2026-10", leads: 5 });
    expect((await none.svc.roi(OWNER, { period: "2026-10" })).next.map((n) => n.key)).toEqual(["stay_organic"]);
  });
  it("flags missing sales and weak ROI instead of celebrating", () => {
    const base = { period: "2026-10", currency: "USD", marketing: null };
    expect(computeRoi({ ...base, manual: { investmentMinor: 10000, salesMinor: 0, leads: 3, customers: 0, rows: 1 } }).state).toBe("sales_missing");
    const weak = computeRoi({ ...base, manual: { investmentMinor: 10000, salesMinor: 5000, leads: 3, customers: 1, rows: 1 } });
    expect(nextSteps(weak, false).map((n) => n.key)).toEqual(["review_before_scaling"]);
  });
  it("re-recording a month corrects it instead of duplicating; the monthly review is one proposal per month", async () => {
    const h = harness(); await plan(h, 30000);
    await h.svc.recordResult(OWNER, { period: "2026-10", salesMinor: 1000 }); await h.svc.recordResult(OWNER, { period: "2026-10", salesMinor: 2000 });
    expect(await h.svc.results(OWNER, "2026-10")).toHaveLength(1);
    const r1 = await h.svc.reviewMonth(OWNER, { period: "2026-10" }), r2 = await h.svc.reviewMonth(OWNER, { period: "2026-10" });
    expect(r1.id).toBe(r2.id); expect(r1.kind).toBe("review"); expect((r1.payload.roi as { salesMinor: number }).salesMinor).toBe(2000);
  });
});

describe("access and isolation", () => {
  it("roles: sales can look but not change; finance sees nothing; companies never mix", async () => {
    const h = harness();
    expect(await code(h.svc.setPlan(SALES, { objective: "leads", investmentMinor: 0 }))).toBe("forbidden"); expect(await code(h.svc.overview(SALES))).toBe("ok"); expect(await code(h.svc.overview(FINANCE))).toBe("forbidden");
    expect(await code(h.svc.setPlan(MARKETING, { objective: "leads", investmentMinor: 0 }))).toBe("ok");
    await h.svc.generate(MARKETING); const B = actor("owner", T2);
    expect(await h.svc.plan(B)).toBeNull(); expect(await h.svc.proposals(B)).toEqual([]); expect((await h.svc.roi(B)).state).toBe("no_data");
  });
});
