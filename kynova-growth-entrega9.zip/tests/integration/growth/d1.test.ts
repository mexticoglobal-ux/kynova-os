import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { COLUMNS, TABLE } from "../../../src/modules/growth/columns";
import { createD1GrowthStore } from "../../../src/modules/growth/store-d1";
import type { GrowthStore } from "../../../src/modules/growth/store";
import { createGrowthService, type Actor, type GrowthPorts } from "../../../src/modules/growth/service";
import { GROWTH_KEYS } from "../../../src/modules/growth/team";
import { createTestDb, newCompany, newUser } from "../db/helpers";

let t: Awaited<ReturnType<typeof createTestDb>>;
let store: GrowthStore;
const snake = (s: string) => s.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
const refused = async (p: Promise<unknown>) => { try { await p; return "no error"; } catch { return "refused"; } };
const fresh = async (): Promise<Actor> => { const u = await newUser(t.db), c = await newCompany(t.db, u.id); return { tenantId: c.companyId, userId: u.id, role: "owner" }; };
const drafts: { title: string; body: string }[] = [];
const ports: GrowthPorts = {
  async member(_a, key) { return GROWTH_KEYS.includes(key) ? { key, name: key, entitled: true, active: true, activityKey: `emp_${key.replace(/_/g, "")}` } : null; },
  marketing: async () => null,
  async createDraft(_a, d) { drafts.push(d); return { id: `post${drafts.length}` }; },
};
const noop = { record: async () => ({ ok: false as const, error: { code: "test", message: "off" } }), recordStrict: async () => { throw new Error("off"); } };

beforeAll(async () => { t = await createTestDb(); store = createD1GrowthStore(t.d1); }, 60_000);
afterAll(async () => { await t.dispose(); });

describe("schema contract", () => {
  it("every whitelisted column exists in the migration, and every column is whitelisted", async () => {
    for (const [kind, table] of Object.entries(TABLE)) {
      const info = (await t.d1.prepare(`PRAGMA table_info(${table})`).all<{ name: string }>()).results.map((c) => c.name).sort();
      expect(COLUMNS[kind as keyof typeof COLUMNS].map(snake).sort(), table).toEqual(info);
    }
  });
});

const harness = async () => {
  const A = await fresh(); let n = 0; const salt = crypto.randomUUID().slice(0, 8);
  const svc = createGrowthService({ store, ports, newId: () => `id${salt}${String(++n).padStart(6, "0")}`, now: () => Date.UTC(2026, 9, 20, 12), activity: noop, locale: "es" });
  return { A, svc };
};

describe("the service on D1", () => {
  it("plans with any amount, supersedes the old plan, generates once and approves a post into a draft", async () => {
    const { A, svc } = await harness();
    const p1 = await svc.setPlan(A, { objective: "leads", investmentMinor: 0 }); expect(p1.bootstrap).toBe(true);
    const p2 = await svc.setPlan(A, { objective: "sell_more", investmentMinor: 31_500 }); expect(p2.bootstrap).toBe(false);
    expect((await svc.plan(A))?.id).toBe(p2.id);
    const g1 = await svc.generate(A), g2 = await svc.generate(A); expect(g1.created).toBeGreaterThan(0); expect(g2.created).toBe(0);
    const post = (await svc.proposals(A)).find((x) => x.kind === "post")!;
    expect((await svc.decide(A, post.id, { approve: true })).outcome).toBe("draft_created"); expect(drafts.length).toBe(1);
  });
  it("records results, upserts the same month and channel, and computes ROI only from them", async () => {
    const { A, svc } = await harness(); await svc.setPlan(A, { objective: "leads", investmentMinor: 30_000 });
    expect((await svc.roi(A, { period: "2026-10" })).state).toBe("no_data");
    await svc.recordResult(A, { period: "2026-10", investmentMinor: 30_000, salesMinor: 450_000, leads: 20, customers: 3 });
    await svc.recordResult(A, { period: "2026-10", investmentMinor: 30_000, salesMinor: 450_000, leads: 25, customers: 3 });
    expect(await svc.results(A, "2026-10")).toHaveLength(1);
    expect(await svc.roi(A, { period: "2026-10" })).toMatchObject({ state: "complete", roi: 15, leads: 25, costPerLeadMinor: 1200 });
  });
  it("the database refuses what the service would never do", async () => {
    const { A, svc } = await harness(), B = await fresh();
    const p = await svc.setPlan(A, { objective: "leads", investmentMinor: 0 }); await svc.generate(A);
    const prop = (await svc.proposals(A))[0]!;
    await svc.decide(A, prop.id, { approve: false });
    expect(await refused(t.d1.prepare("UPDATE gr_proposals SET status = 'approved' WHERE id = ?").bind(prop.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("DELETE FROM gr_proposals WHERE id = ?").bind(prop.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE gr_plans SET tenant_id = ? WHERE id = ?").bind(B.tenantId, p.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("DELETE FROM gr_plans WHERE id = ?").bind(p.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE gr_plans SET status = 'active' WHERE 1 = 0").run())).toBe("no error");
  });
  it("companies never see each other's data", async () => {
    const a = await harness(), b = await harness(); await a.svc.setPlan(a.A, { objective: "leads", investmentMinor: 0 });
    expect(await b.svc.plan(b.A)).toBeNull();
  });
});
