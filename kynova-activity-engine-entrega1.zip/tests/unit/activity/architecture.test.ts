import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { toWire } from "../../../src/platform/activity/wire";
import { createMemoryActivityStore } from "../../../src/platform/activity/store-memory";

const files = (d: string): string[] => readdirSync(d).flatMap((f) => (statSync(join(d, f)).isDirectory() ? files(join(d, f)) : [join(d, f)]));
const ROOT = "src/platform/activity";

describe("Activity Engine architecture", () => {
  it("is a Core service: it imports no module and no module internals", () => {
    for (const f of files(ROOT)) expect(readFileSync(f, "utf8"), f).not.toMatch(/from "@\/modules\//);
  });
  it("the store port is append-only: no update, no delete", () => {
    const keys = Object.keys(createMemoryActivityStore());
    expect(keys.sort()).toEqual(["append", "count", "get", "getByIdempotencyKey", "getRevertOf", "list", "rollups"]);
  });
  it("has no HTTP write path for events: only the undo is a POST", () => {
    const posts = files("src/app/api/v1/activity").filter((f) => /export const POST/.test(readFileSync(f, "utf8")));
    expect(posts).toEqual(["src/app/api/v1/activity/events/[id]/revert/route.ts"]);
  });
  it("the wire format is snake_case with ISO timestamps and hides the tenant", () => {
    expect(toWire({ tenantId: "t", occurredAt: 0, revertHint: { aB: 1 } })).toEqual({ occurred_at: "1970-01-01T00:00:00.000Z", revert_hint: { a_b: 1 } });
  });
  it("every query in the D1 store is tenant scoped", () => {
    const sql = readFileSync(`${ROOT}/store-d1.ts`, "utf8");
    expect(sql).toContain('const sql = ["tenant_id = ?"]'); // where() always starts with the tenant
    for (const m of sql.matchAll(/(SELECT|UPDATE|DELETE)[^`]*FROM \$\{[A-Z_]+\}[^`]*/g)) expect(m[0], m[0]).toMatch(/tenant_id = \?|\$\{(w\.)?sql\}/);
  });
});
