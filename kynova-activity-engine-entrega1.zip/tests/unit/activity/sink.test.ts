import { describe, expect, it } from "vitest";
import { createActivitySink, noopSink } from "../../../src/platform/activity/sink";
import { OWNER, T1, ev, setup } from "./helpers";

describe("activity sink (common adapter)", () => {
  it("fills the module and source and records", async () => {
    const { svc } = setup(), sink = createActivitySink(svc, { module: "partners", source: "life_os" });
    const r = await sink.record({ tenantId: T1, requestId: "r1" }, { action: "partners.invite.sent", summary: "Invitation sent" });
    expect(r.ok && r.event).toMatchObject({ module: "partners", source: "life_os", requestId: "r1" });
    expect((await svc.list(OWNER, {})).items).toHaveLength(1);
    const o = await sink.record({ tenantId: T1 }, ev({ module: "referrals", source: "kynova" }));
    expect(o.ok && o.event.module).toBe("referrals");
  });
  it("never throws on record: a bad event is reported and logged, the host operation continues", async () => {
    const lines: string[] = [], { svc } = setup(), sink = createActivitySink(svc, { module: "partners" }, (l) => lines.push(l));
    const r = await sink.record({ tenantId: T1 }, { action: "BAD", summary: "x" });
    expect(r).toMatchObject({ ok: false, error: { code: "validation_failed" } });
    expect(JSON.parse(lines[0]!)).toMatchObject({ msg: "activity_record_failed", module: "partners", tenant_id: T1 });
    expect((await svc.list(OWNER, {})).items).toHaveLength(0);
  });
  it("recordStrict throws, and a broken store is also contained by record", async () => {
    const { svc } = setup(), sink = createActivitySink(svc, { module: "partners" }, () => {});
    await expect(sink.recordStrict({ tenantId: T1 }, { action: "BAD", summary: "x" })).rejects.toMatchObject({ code: "validation_failed" });
    const broken = createActivitySink({ record: async () => { throw new Error("db down"); } }, { module: "partners" }, () => {});
    expect(await broken.record({ tenantId: T1 }, { action: "partners.a.b", summary: "x" })).toMatchObject({ ok: false, error: { code: "internal_error" } });
  });
  it("noopSink is safe to inject in tests", async () => {
    expect((await noopSink.record({ tenantId: T1 }, { action: "a.b", summary: "x" })).ok).toBe(false);
    await expect(noopSink.recordStrict({ tenantId: T1 }, { action: "a.b", summary: "x" })).rejects.toThrow();
  });
});
