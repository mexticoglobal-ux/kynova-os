import { describe, expect, it } from "vitest";
import { registerReverter } from "../../../src/platform/activity/service";
import { AGENT, DAY, GUEST, HOUR, MANAGER, MKT, OWNER, START, T1, T2, actor, code, ev, setup } from "./helpers";

const T = { tenantId: T1 }, T_2 = { tenantId: T2 };

describe("record", () => {
  it("stores an event with defaults and a stable shape", async () => {
    const { svc } = setup(), { event, duplicate } = await svc.record(T, ev({ actorKind: "employee", employeeKey: "seo_employee", quantity: 5, subjectKind: "page", subjectId: "p1" }));
    expect(duplicate).toBe(false);
    expect(event).toMatchObject({ tenantId: T1, source: "kynova", mode: "production", outcome: "success", quantity: 5, schemaVersion: 1, occurredAt: START, revertsId: null, reversible: false });
  });
  it("validates every field", async () => {
    const { svc } = setup();
    for (const bad of [{ action: "Bad Action" }, { action: "single" }, { module: "X" }, { summary: "" }, { summary: "x".repeat(241) }, { quantity: -1 }, { quantity: 1.5 }, { mode: "live" },
      { actorKind: "employee" }, { reversible: true }, { subjectKind: "page" }, { reversible: true, revertHint: { x: "y".repeat(1100) } }, { extra: 1 }, { source: "Bad Source" }])
      expect(await code(svc.record(T, ev(bad))), JSON.stringify(bad)).toBe("validation_failed");
  });
  it("refuses events from the future and events that are too old", async () => {
    const { svc } = setup();
    expect(await code(svc.record(T, ev({ occurredAt: START + HOUR })))).toBe("validation_failed");
    expect(await code(svc.record(T, ev({ occurredAt: START - 401 * DAY })))).toBe("validation_failed");
    expect(await code(svc.record(T, ev({ occurredAt: START - 30 * DAY })))).toBe("ok");
  });
  it("is idempotent: a repeated key returns the first event and counts once", async () => {
    const { svc } = setup(), a = await svc.record(T, ev({ idempotencyKey: "job:1", quantity: 3 })), b = await svc.record(T, ev({ idempotencyKey: "job:1", quantity: 3 }));
    expect(b.duplicate).toBe(true); expect(b.event.id).toBe(a.event.id);
    expect((await svc.summary(OWNER)).production.quantity).toBe(3);
    expect((await svc.record(T_2, ev({ idempotencyKey: "job:1" }))).duplicate).toBe(false);
  });
  it("derives the key from source + external ref so LIFE OS and Maka can retry safely", async () => {
    const { svc } = setup(), a = await svc.record(T, ev({ source: "maka", externalRef: "tx-9", actorKind: "integration" })), b = await svc.record(T, ev({ source: "maka", externalRef: "tx-9", actorKind: "integration" }));
    expect(a.event.idempotencyKey).toBe("maka:tx-9"); expect(b.duplicate).toBe(true);
    expect((await svc.record(T, ev({ source: "life_os", externalRef: "tx-9", actorKind: "integration" }))).duplicate).toBe(false);
  });
});

describe("reading", () => {
  it("is tenant scoped", async () => {
    const { svc } = setup(), a = await svc.record(T, ev());
    await svc.record(T_2, ev());
    expect((await svc.list(OWNER, {})).items).toHaveLength(1);
    expect(await code(svc.get(actor("owner", "o2", T2), a.event.id))).toBe("not_found");
    expect((await svc.summary(actor("owner", "o2", T2))).production.events).toBe(1);
  });
  it("filters and paginates newest first with a keyset cursor", async () => {
    const { svc, clock } = setup();
    for (let i = 0; i < 7; i++) { clock.t += 1000; await svc.record(T, ev({ module: i % 2 ? "crm" : "seo", action: i % 2 ? "crm.lead.created" : "seo.audit.completed" })); }
    const p1 = await svc.list(OWNER, { limit: 3 }), p2 = await svc.list(OWNER, { limit: 3, cursor: p1.nextCursor }), p3 = await svc.list(OWNER, { limit: 3, cursor: p2.nextCursor });
    const ids = [...p1.items, ...p2.items, ...p3.items].map((e) => e.id);
    expect(ids).toHaveLength(7); expect(new Set(ids).size).toBe(7); expect(p3.nextCursor).toBeNull();
    expect(p1.items[0]!.occurredAt).toBeGreaterThan(p1.items[2]!.occurredAt);
    expect((await svc.list(OWNER, { module: "crm" })).items).toHaveLength(3);
    expect((await svc.list(OWNER, { since: START + 5000 })).items).toHaveLength(3);
    expect(await code(svc.list(OWNER, { cursor: "garbage" }))).toBe("validation_failed");
    expect(await code(svc.list(OWNER, { limit: 500 }))).toBe("validation_failed");
  });
  it("returns the timeline of one subject", async () => {
    const { svc } = setup();
    await svc.record(T, ev({ subjectKind: "lead", subjectId: "L1" })); await svc.record(T, ev({ subjectKind: "lead", subjectId: "L2" })); await svc.record(T, ev({ subjectKind: "lead", subjectId: "L1", action: "crm.lead.updated" }));
    expect((await svc.timeline(OWNER, "lead", "L1")).items).toHaveLength(2);
  });
  it("gates reads by role and by AI agent", async () => {
    const { svc } = setup(); await svc.record(T, ev());
    expect(await code(svc.list(GUEST, {}))).toBe("forbidden");
    expect(await code(svc.list(MKT, {}))).toBe("ok"); expect(await code(svc.list(AGENT, {}))).toBe("ok");
    expect(svc.permissions(MKT)).toEqual({ view: true, revert: false }); expect(svc.permissions(AGENT)).toEqual({ view: true, revert: false }); expect(svc.permissions(MANAGER).revert).toBe(true);
  });
});

describe("summary (State Driven UX)", () => {
  it("walks empty → demo → simulation → production and never mixes them", async () => {
    const { svc } = setup();
    expect((await svc.summary(OWNER)).state).toBe("empty");
    await svc.record(T, ev({ mode: "demo", quantity: 18 }));
    let s = await svc.summary(OWNER); expect(s.state).toBe("demo"); expect(s.demo.quantity).toBe(18); expect(s.production.quantity).toBe(0);
    await svc.record(T, ev({ mode: "simulation", quantity: 4 }));
    s = await svc.summary(OWNER); expect(s.state).toBe("simulation"); expect(s.simulation.quantity).toBe(4);
    await svc.record(T, ev({ quantity: 14 })); await svc.record(T, ev({ outcome: "failed", quantity: 2 })); await svc.record(T, ev({ outcome: "skipped" }));
    s = await svc.summary(OWNER);
    expect(s.state).toBe("production"); expect(s.production).toMatchObject({ events: 1, quantity: 14, failed: 1, skipped: 1 }); expect(s.demo.quantity).toBe(18);
  });
  it("groups by module and action, fills every day of the window, and respects it", async () => {
    const { svc, clock } = setup();
    await svc.record(T, ev({ quantity: 2 })); await svc.record(T, ev({ module: "crm", action: "crm.lead.created", quantity: 9 }));
    clock.t += 3 * DAY; await svc.record(T, ev({ quantity: 1 }));
    const s = await svc.summary(OWNER, { days: 7 });
    expect(s.daily).toHaveLength(7); expect(s.daily.reduce((n, d) => n + d.quantity, 0)).toBe(12);
    expect(s.byModule.map((m) => m.module)).toEqual(["crm", "seo"]); expect(s.byAction[0]).toMatchObject({ action: "crm.lead.created", quantity: 9 });
    expect((await svc.summary(OWNER, { days: 1 })).production.quantity).toBe(1);
    expect((await svc.summary(OWNER, { days: 1 })).state).toBe("production");
    expect(await code(svc.summary(OWNER, { days: 91 }))).toBe("validation_failed");
  });
  it("a workspace that was quiet for months is empty again after 90 days", async () => {
    const { svc, clock } = setup(); await svc.record(T, ev()); clock.t += 91 * DAY;
    expect((await svc.summary(OWNER)).state).toBe("empty");
  });
});

describe("digest", () => {
  it("lists real, successful work since a moment, grouped", async () => {
    const { svc, clock } = setup();
    await svc.record(T, ev({ quantity: 14, action: "comms.message.replied", module: "communications" })); clock.t += HOUR;
    const since = clock.t; await svc.record(T, ev({ quantity: 3, action: "comms.message.replied", module: "communications" })); await svc.record(T, ev({ quantity: 5 }));
    await svc.record(T, ev({ mode: "demo", quantity: 99 })); await svc.record(T, ev({ outcome: "failed", quantity: 50 }));
    const d = await svc.digest(OWNER, { since });
    expect(d.truncated).toBe(false); expect(d.groups.map((g) => [g.action, g.events, g.quantity])).toEqual([["seo.audit.completed", 1, 5], ["comms.message.replied", 1, 3]]);
    expect(await code(svc.digest(OWNER, {}))).toBe("validation_failed");
  });
});

describe("revert", () => {
  const reversible = (o = {}) => ev({ module: "marketing", action: "marketing.campaign.created", reversible: true, revertHint: { campaignId: "c1" }, subjectKind: "campaign", subjectId: "c1", ...o });
  it("refuses what cannot be undone, and who may not undo", async () => {
    const { svc } = setup(), plain = await svc.record(T, ev()), rev = await svc.record(T, reversible());
    expect(await code(svc.revert(MKT, rev.event.id))).toBe("forbidden"); expect(await code(svc.revert(AGENT, rev.event.id))).toBe("forbidden");
    expect(await code(svc.revert(OWNER, plain.event.id))).toBe("invalid_state"); expect(await code(svc.revert(OWNER, "nope"))).toBe("not_found");
    expect(await code(svc.revert(actor("owner", "o2", T2), rev.event.id))).toBe("not_found");
    registerReverter("marketing", async () => ({}));
    try { await svc.revert(OWNER, plain.event.id); } catch (e) { expect((e as { details?: { reason?: string } }).details?.reason).toBe("not_reversible"); }
  });
  it("needs a reverter registered by the owning module", async () => {
    const { svc } = setup(), r = await svc.record(T, reversible({ module: "orphan", action: "orphan.thing.done" }));
    try { await svc.revert(OWNER, r.event.id); throw new Error("no error"); } catch (e) { expect((e as { details?: { reason?: string } }).details?.reason).toBe("no_reverter"); }
  });
  it("calls the reverter once, records the undo as an event, and refuses a second undo", async () => {
    let calls = 0; registerReverter("marketing", async (e) => { calls++; expect(e.revertHint).toEqual({ campaignId: "c1" }); return { summary: "Campaign c1 removed" }; });
    const { svc } = setup(), r = await svc.record(T, reversible()), out = await svc.revert(MANAGER, r.event.id, { reason: "wrong audience" });
    expect(calls).toBe(1); expect(out.event).toMatchObject({ action: "activity.reverted", revertsId: r.event.id, subjectId: "c1", summary: "Campaign c1 removed" });
    expect((await svc.get(OWNER, r.event.id)).revertedBy?.id).toBe(out.event.id);
    expect(await code(svc.revert(OWNER, r.event.id))).toBe("invalid_state"); expect(calls).toBe(1);
    expect(await code(svc.revert(OWNER, out.event.id))).toBe("invalid_state");
  });
  it("records a failed attempt when the reverter throws, and allows a retry", async () => {
    let fail = true; registerReverter("marketing", async () => { if (fail) throw new Error("boom"); return {}; });
    const { svc } = setup(), r = await svc.record(T, reversible());
    expect(await code(svc.revert(OWNER, r.event.id))).toBe("invalid_state");
    expect((await svc.list(OWNER, { action: "activity.revert_failed" })).items).toHaveLength(1);
    fail = false; expect((await svc.revert(OWNER, r.event.id)).event.action).toBe("activity.reverted");
  });
  it("two concurrent undos write a single revert event", async () => {
    registerReverter("marketing", async () => ({}));
    const { svc } = setup(), r = await svc.record(T, reversible()), res = await Promise.allSettled([svc.revert(OWNER, r.event.id), svc.revert(OWNER, r.event.id)]);
    expect(res.filter((x) => x.status === "fulfilled")).toHaveLength(1);
    expect((await svc.list(OWNER, { action: "activity.reverted" })).items).toHaveLength(1);
  });
});
