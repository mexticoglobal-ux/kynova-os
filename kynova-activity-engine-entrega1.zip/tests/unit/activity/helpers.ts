import type { Role } from "@/config/roles";
import { createMemoryActivityStore } from "../../../src/platform/activity/store-memory";
import type { ActivityStore } from "../../../src/platform/activity/store";
import { createActivityService, type Actor } from "../../../src/platform/activity/service";

export const T1 = "tenant-one", T2 = "tenant-two";
export const HOUR = 3_600_000, DAY = 86_400_000;
export const START = Date.UTC(2026, 9, 20, 12);
export const actor = (role: Role, userId = `${role}-1`, tenantId = T1): Actor => ({ tenantId, userId, role });
export const OWNER = actor("owner"), MANAGER = actor("manager"), MKT = actor("marketing"), GUEST = actor("guest");
export const AGENT: Actor = { ...OWNER, agentId: "agent-1" };
export const code = async (p: Promise<unknown>) => { try { await p; return "ok"; } catch (e) { return (e as { code?: string }).code ?? `other:${(e as Error).message}`; } };
export const ev = (o: Record<string, unknown> = {}) => ({ module: "seo", action: "seo.audit.completed", summary: "Audit done", ...o }) as never;

export function setup(over: { store?: ActivityStore; prefix?: string } = {}) {
  const clock = { t: START }; let n = 0;
  const store = over.store ?? createMemoryActivityStore();
  const svc = createActivityService({ store, newId: () => `${over.prefix ?? ""}ev${String(++n).padStart(6, "0")}`, now: () => clock.t });
  return { svc, store, clock };
}
