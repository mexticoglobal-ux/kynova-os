import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { EVENTS_TABLE, EVENT_COLUMNS, ROLLUP_COLUMNS, ROLLUP_TABLE } from "../../../src/platform/activity/columns";
import { createD1ActivityStore } from "../../../src/platform/activity/store-d1";
import { registerReverter, type Actor } from "../../../src/platform/activity/service";
import type { ActivityStore } from "../../../src/platform/activity/store";
import { createTestDb, newCompany, newUser } from "../db/helpers";
import { DAY, START, code, ev, setup } from "../../unit/activity/helpers";

let t: Awaited<ReturnType<typeof createTestDb>>;
let store: ActivityStore, A: Actor, B: Actor;
const snake = (s: string) => s.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
const refused = async (sql: string, ...b: (string | number)[]) => { try { await t.d1.prepare(sql).bind(...b).run(); return "no error"; } catch { return "refused"; } };

beforeAll(async () => {
  t = await createTestDb(); store = createD1ActivityStore(t.d1);
  const [o, ob] = [await newUser(t.db), await newUser(t.db)], a = await newCompany(t.db, o.id), b = await newCompany(t.db, ob.id);
  A = { tenantId: a.companyId, userId: o.id, role: "owner" }; B = { tenantId: b.companyId, userId: ob.id, role: "owner" };
}, 60_000);
afterAll(async () => { await t.dispose(); });

describe("schema contract", () => {
  it("every whitelisted column exists in the migration, and every column is whitelisted", async () => {
    const cols = async (tbl: string) => (await t.d1.prepare(`PRAGMA table_info(${tbl})`).all<{ name: string }>()).results.map((c) => c.name).sort();
    expect(EVENT_COLUMNS.map(snake).sort()).toEqual(await cols(EVENTS_TABLE));
    expect(ROLLUP_COLUMNS.map(snake).sort()).toEqual(await cols(ROLLUP_TABLE));
  });
});

describe("the service on D1", () => {
  it("records, lists, summarizes from rollups and keeps tenants apart", async () => {
    const { svc, clock } = setup({ store, prefix: crypto.randomUUID().slice(0, 8) }); clock.t = Date.now();
    const a = await svc.record(A, ev({ quantity: 4, subjectKind: "page", subjectId: "p1", revertHint: { a: 1 }, reversible: true })), b = await svc.record(B, ev({ quantity: 9 }));
    await svc.record(A, ev({ quantity: 6 })); await svc.record(A, ev({ mode: "demo", quantity: 50 }));
    expect(a.event.revertHint).toEqual({ a: 1 }); expect((await svc.get(A, a.event.id)).event.reversible).toBe(true);
    expect((await svc.list(A, { limit: 100 })).items.map((e) => e.tenantId)).toEqual([A.tenantId, A.tenantId, A.tenantId]);
    const s = await svc.summary(A);
    expect(s.state).toBe("production"); expect(s.production).toMatchObject({ events: 2, quantity: 10 }); expect(s.demo.quantity).toBe(50);
    expect((await svc.summary(B)).production.quantity).toBe(9); expect(await code(svc.get(A, b.event.id))).toBe("not_found");
    expect((await svc.timeline(A, "page", "p1")).items).toHaveLength(1);
  });
  it("is idempotent under the unique index, and counts once in the rollup", async () => {
    const { svc, clock } = setup({ store, prefix: crypto.randomUUID().slice(0, 8) }); clock.t = Date.now();
    const first = await svc.record(A, ev({ idempotencyKey: "d1:idem", quantity: 7, action: "crm.lead.created", module: "crm" }));
    const [x, y] = await Promise.all([svc.record(A, ev({ idempotencyKey: "d1:idem", quantity: 7, action: "crm.lead.created", module: "crm" })), svc.record(A, ev({ idempotencyKey: "d1:idem", quantity: 7, action: "crm.lead.created", module: "crm" }))]);
    expect(x.event.id).toBe(first.event.id); expect(y.event.id).toBe(first.event.id);
    expect((await svc.summary(A)).byAction.find((g) => g.action === "crm.lead.created")?.quantity).toBe(7);
  });
  it("undoes once: the unique index on reverts_id makes a second undo impossible", async () => {
    const { svc, clock } = setup({ store, prefix: crypto.randomUUID().slice(0, 8) }); clock.t = Date.now(); registerReverter("d1mod", async () => ({}));
    const r = await svc.record(A, ev({ module: "d1mod", action: "d1mod.thing.done", reversible: true, revertHint: { id: 1 } }));
    const out = await svc.revert(A, r.event.id); expect(out.event.revertsId).toBe(r.event.id);
    expect(await code(svc.revert(A, r.event.id))).toBe("invalid_state");
    expect((await svc.get(A, r.event.id)).revertedBy?.id).toBe(out.event.id);
  });
});

describe("database guarantees", () => {
  const row = (id: string, tenant: string, extra: Record<string, string | number> = {}) => ({ id, tenant, ...extra });
  const insert = (id: string, tenant: string, set = "mode", val: string | number = "production") =>
    refused(`INSERT INTO act_events (id, tenant_id, occurred_at, recorded_at, module, action, summary, ${set}) VALUES (?, ?, 1, 1, 'seo', 'seo.a.b', 's', ?)`, id, tenant, val);
  it("events cannot be updated or deleted, and the counters cannot be deleted", async () => {
    const { svc, clock } = setup({ store, prefix: crypto.randomUUID().slice(0, 8) }); clock.t = Date.now(); const e = await svc.record(A, ev());
    expect(await refused(`UPDATE ${EVENTS_TABLE} SET summary = 'x' WHERE id = ?`, e.event.id)).toBe("refused");
    expect(await refused(`DELETE FROM ${EVENTS_TABLE} WHERE id = ?`, e.event.id)).toBe("refused");
    expect(await refused(`DELETE FROM ${ROLLUP_TABLE} WHERE tenant_id = ?`, A.tenantId)).toBe("refused");
    expect(await refused(`UPDATE ${ROLLUP_TABLE} SET tenant_id = ? WHERE tenant_id = ?`, B.tenantId, A.tenantId)).toBe("refused");
  });
  it("the CHECK constraints reject bad values", async () => {
    void row;
    expect(await insert("c1", A.tenantId, "mode", "live")).toBe("refused");
    expect(await insert("c2", A.tenantId, "outcome", "maybe")).toBe("refused");
    expect(await insert("c3", A.tenantId, "quantity", -1)).toBe("refused");
    expect(await insert("c4", A.tenantId, "reversible", 1)).toBe("refused"); // reversible without a hint
    expect(await insert("c5", "no-such-company")).toBe("refused");
    expect(await insert("c6", A.tenantId)).toBe("no error");
  });
  it("an undo cannot point at another company's event", async () => {
    const { svc, clock } = setup({ store, prefix: crypto.randomUUID().slice(0, 8) }); clock.t = Date.now(); const other = await svc.record(B, ev());
    expect(await refused(`INSERT INTO act_events (id, tenant_id, occurred_at, recorded_at, module, action, summary, reverts_id) VALUES ('x1', ?, 1, 1, 'seo', 'seo.a.b', 's', ?)`, A.tenantId, other.event.id)).toBe("refused");
  });
  it("keeps the feed query on its index", async () => {
    const plan = (await t.d1.prepare(`EXPLAIN QUERY PLAN SELECT * FROM act_events WHERE tenant_id = ? ORDER BY occurred_at DESC, id DESC LIMIT 25`).bind(A.tenantId).all<{ detail: string }>()).results.map((r) => r.detail).join(" ");
    expect(plan).toMatch(/act_events_feed_idx/); expect(plan).not.toMatch(/TEMP B-TREE/);
    void START; void DAY;
  });
});
