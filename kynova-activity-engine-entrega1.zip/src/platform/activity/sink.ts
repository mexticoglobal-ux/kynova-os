import type { ActivityEvent, ActivityEventInput } from "./domain";
import type { ActivityService, WriteContext } from "./service";

/** The module defaults to the sink's own module. */
export type SinkEvent = Omit<ActivityEventInput, "module"> & { module?: string };
export type SinkResult = { ok: true; event: ActivityEvent; duplicate: boolean } | { ok: false; error: { code: string; message: string } };
/**
 * The common adapter every module, AI employee and external system (LIFE OS, Maka) uses to leave evidence. A module never imports the store or
 * the service: it receives a sink, and its own tests pass `memorySink()` or `noopSink`. `record` never throws: losing the log must not break the
 * business operation, so a failure comes back as `{ ok: false }` and is logged as one structured line. Use `recordStrict` where the evidence IS the operation.
 */
export interface ActivitySink {
  record(ctx: WriteContext, event: SinkEvent): Promise<SinkResult>;
  recordStrict(ctx: WriteContext, event: SinkEvent): Promise<{ event: ActivityEvent; duplicate: boolean }>;
}
export interface SinkDefaults { module: string; source?: string }

export function createActivitySink(service: Pick<ActivityService, "record">, defaults: SinkDefaults, log: (line: string) => void = (l) => console.error(l)): ActivitySink {
  const fill = (e: SinkEvent): ActivityEventInput => ({ ...e, module: e.module ?? defaults.module, source: e.source ?? defaults.source ?? "kynova" });
  return {
    async record(ctx, e) {
      try { return { ok: true, ...(await service.record(ctx, fill(e))) }; } catch (err) {
        const error = { code: (err as { code?: string }).code ?? "internal_error", message: err instanceof Error ? err.message : "Activity could not be recorded." };
        log(JSON.stringify({ level: "error", msg: "activity_record_failed", module: defaults.module, tenant_id: ctx.tenantId, request_id: ctx.requestId, ...error }));
        return { ok: false, error };
      }
    },
    recordStrict: (ctx, e) => service.record(ctx, fill(e)),
  };
}
/** For modules that run without an Activity Engine (tests, tools): accepts everything, stores nothing. */
export const noopSink: ActivitySink = {
  async record() { return { ok: false, error: { code: "unavailable", message: "No activity sink." } }; },
  async recordStrict() { throw new Error("No activity sink."); },
};
