import type { Role } from "@/config/roles";
import { DEFAULT_CAPABILITIES, type Capability } from "./domain";

/** Capabilities INSIDE the Activity Engine. Module access (who may open Mission Control) stays in src/config/modules.ts; this never grants it. */
export const allows = (role: Role, c: Capability): boolean => DEFAULT_CAPABILITIES[role].includes(c);
