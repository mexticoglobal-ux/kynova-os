import { getActivityStore } from "./runtime";
import { createActivityService, type ActivityService } from "./service";
import { createActivitySink, type ActivitySink } from "./sink";

/** Composition root: the store is resolved per request (the D1 binding only exists inside a request). */
export async function getActivityService(): Promise<ActivityService> {
  return createActivityService({ store: await getActivityStore(), newId: () => crypto.randomUUID().replace(/-/g, "") });
}
/** What a server-side module calls to leave evidence: `const sink = await getActivitySink("partners"); await sink.record({ tenantId }, { action: "partners.invite.sent", ... })`. */
export async function getActivitySink(module: string, source?: string): Promise<ActivitySink> {
  return createActivitySink(await getActivityService(), { module, source });
}
