import { z } from "zod";
import type { Role } from "@/config/roles";

/** Vocabularies. The same strings are CHECK constraints in drizzle/migrations/1300_activity.sql. */
export const ACTOR_KINDS = ["employee", "user", "system", "integration"] as const;
export const OUTCOMES = ["success", "failed", "skipped"] as const;
/** The four honest states of KYNOVA: only `production` is real work done for the company. */
export const MODES = ["production", "simulation", "demo"] as const;
export const WORKSPACE_STATES = ["empty", "demo", "simulation", "production"] as const;
export const CAPABILITIES = ["view", "revert"] as const;
export type Capability = (typeof CAPABILITIES)[number];
export type ActorKind = (typeof ACTOR_KINDS)[number];
export type Outcome = (typeof OUTCOMES)[number];
export type Mode = (typeof MODES)[number];
export type WorkspaceState = (typeof WORKSPACE_STATES)[number];

export const SCHEMA_VERSION = 1;
export const MAX_SUMMARY = 240;
export const MAX_HINT_BYTES = 1024;
/** Back-dating limit for imports; future-dating tolerance for clock skew. */
export const MAX_BACKDATE_MS = 400 * 86_400_000;
export const MAX_SKEW_MS = 5 * 60_000;
/** Sources: KYNOVA itself or an external system writing through the same sink (LIFE OS, Maka, ...). */
export const KNOWN_SOURCES = ["kynova", "life_os", "maka", "external"] as const;

const id = z.string().min(1).max(64);
const slug = (re: RegExp) => z.string().regex(re);
const MODULE_RE = /^[a-z][a-z0-9-]{1,31}$/, ACTION_RE = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*){1,3}$/, SOURCE_RE = /^[a-z][a-z0-9_]{1,31}$/, KEY_RE = /^[A-Za-z0-9:_.\-]{1,120}$/;

export const eventInput = z.object({
  module: slug(MODULE_RE), action: slug(ACTION_RE),
  summary: z.string().trim().min(1).max(MAX_SUMMARY),
  source: slug(SOURCE_RE).default("kynova"),
  actorKind: z.enum(ACTOR_KINDS).default("system"), actorId: id.nullish(), employeeKey: z.string().regex(/^[a-z][a-z0-9_]{1,63}$/).nullish(),
  outcome: z.enum(OUTCOMES).default("success"), mode: z.enum(MODES).default("production"),
  /** How many things this event stands for ("replied to 14 customers" is one event with quantity 14, or 14 events of 1). */
  quantity: z.number().int().min(0).max(100_000).default(1),
  subjectKind: z.string().regex(/^[a-z][a-z0-9_]{1,31}$/).nullish(), subjectId: id.nullish(),
  occurredAt: z.number().int().positive().optional(),
  reversible: z.boolean().default(false),
  /** What the owning module needs to undo this (ids and previous values; never secrets). Required when reversible. */
  revertHint: z.record(z.string(), z.unknown()).nullish(),
  idempotencyKey: z.string().regex(KEY_RE).nullish(),
  /** The id of this thing in the external system, when source is not kynova. */
  externalRef: z.string().min(1).max(120).nullish(),
}).strict().superRefine((v, ctx) => {
  if (v.reversible && !v.revertHint) ctx.addIssue({ code: "custom", path: ["revertHint"], message: "A reversible event needs a revert hint." });
  if (v.revertHint && new TextEncoder().encode(JSON.stringify(v.revertHint)).length > MAX_HINT_BYTES) ctx.addIssue({ code: "custom", path: ["revertHint"], message: `The revert hint is larger than ${MAX_HINT_BYTES} bytes.` });
  if ((v.subjectKind == null) !== (v.subjectId == null)) ctx.addIssue({ code: "custom", path: ["subjectId"], message: "Give both subjectKind and subjectId, or neither." });
  if (v.actorKind === "employee" && !v.employeeKey) ctx.addIssue({ code: "custom", path: ["employeeKey"], message: "An employee event names the employee." });
});
export type ActivityEventInput = z.input<typeof eventInput>;

export const listQuery = z.object({
  limit: z.coerce.number().int().min(1).max(100).default(25), cursor: z.string().max(300).optional(),
  module: slug(MODULE_RE).optional(), action: slug(ACTION_RE).optional(), source: slug(SOURCE_RE).optional(),
  actorKind: z.enum(ACTOR_KINDS).optional(), employeeKey: z.string().max(64).optional(), mode: z.enum(MODES).optional(), outcome: z.enum(OUTCOMES).optional(),
  subjectKind: z.string().max(32).optional(), subjectId: id.optional(),
  since: z.coerce.number().int().optional(), until: z.coerce.number().int().optional(),
}).strict();
export type ListQuery = z.output<typeof listQuery>;
export const summaryQuery = z.object({ days: z.coerce.number().int().min(1).max(90).default(7) }).strict();
export const digestQuery = z.object({ since: z.coerce.number().int().positive() }).strict();
export const revertInput = z.object({ reason: z.string().trim().max(240).optional() }).strict();

export interface ActivityEvent {
  id: string; tenantId: string; schemaVersion: number; occurredAt: number; recordedAt: number;
  source: string; module: string; action: string; summary: string;
  actorKind: ActorKind; actorId: string | null; employeeKey: string | null;
  outcome: Outcome; mode: Mode; quantity: number;
  subjectKind: string | null; subjectId: string | null;
  reversible: boolean; revertHint: Record<string, unknown> | null; revertsId: string | null;
  idempotencyKey: string | null; externalRef: string | null; requestId: string | null;
}
/** Pre-aggregated counters per tenant and UTC day: dashboards read these, never scan events. */
export interface DailyRollup { tenantId: string; day: number; module: string; action: string; mode: Mode; outcome: Outcome; events: number; quantity: number }

export const DEFAULT_CAPABILITIES: Record<Role, readonly Capability[]> = {
  owner: ["view", "revert"], super_admin: ["view", "revert"], administrator: ["view", "revert"], ceo: ["view", "revert"], manager: ["view", "revert"],
  marketing: ["view"], sales: ["view"], finance: ["view"], support: ["view"], hr: ["view"], employee: ["view"], guest: [],
};
