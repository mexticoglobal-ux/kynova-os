import { NextResponse, type NextRequest } from "next/server";
import { canAccess } from "@/config/modules";
import { isConfigError } from "@/platform/auth/errors";
import { assertSameOrigin, getAuthConfig, ok, problem, route } from "@/platform/auth/http";
import { requireApiSession } from "@/platform/auth/session";
import { ActivityError, isActivityError } from "./errors";
import { getActivityService } from "./server";
import type { Actor, ActivityService } from "./service";
import { fromWire, queryObject, toWire } from "./wire";

/** Reads and undo go through Mission Control's module slug; writes have no HTTP path at all (see sink.ts). */
export const ACTIVITY_SLUG = "mission-control";
export interface ActivityRouteContext { actor: Actor; rid: string; svc: ActivityService }

export function activityRoute<C = unknown>(fn: (req: NextRequest, ctx: C, a: ActivityRouteContext) => Promise<NextResponse>, opts: { mutating?: boolean } = {}) {
  return route<C>(async (req, ctx, rid) => {
    try {
      if (opts.mutating) assertSameOrigin(req, getAuthConfig());
      const s = await requireApiSession();
      if (!s.tenantId) throw new ActivityError("forbidden", "Select or create a company first.");
      if (!canAccess(s.role, ACTIVITY_SLUG)) throw new ActivityError("forbidden", "Your role cannot see activity.");
      const actor: Actor = { tenantId: s.tenantId, userId: s.user.id, role: s.role, requestId: rid };
      return await fn(req, ctx, { actor, rid, svc: await getActivityService() });
    } catch (e) {
      if (isActivityError(e)) return problem(e.code, e.status, e.message, rid, { ...(e.details?.fields ? { errors: e.details.fields } : {}), ...(e.details && !e.details.fields ? { details: e.details } : {}) });
      if (isConfigError(e) && !(e as { name?: string }).name?.startsWith("Missing")) return problem("unavailable", 503, "This service is temporarily unavailable.", rid);
      throw e;
    }
  });
}
export async function readBody(req: NextRequest): Promise<unknown> {
  if (!req.headers.get("content-type")?.toLowerCase().startsWith("application/json")) throw new ActivityError("validation_failed", "Content-Type must be application/json.");
  const text = await req.text();
  if (!text.trim()) return {};
  try { const b = JSON.parse(text) as unknown; if (b === null || typeof b !== "object" || Array.isArray(b)) throw 0; return fromWire(b); }
  catch { throw new ActivityError("validation_failed", "The body must be a JSON object."); }
}
export const queryOf = (req: NextRequest) => queryObject(req.nextUrl.searchParams);
export const respond = (data: unknown, rid: string, status = 200) => ok(toWire(data), rid, status);
