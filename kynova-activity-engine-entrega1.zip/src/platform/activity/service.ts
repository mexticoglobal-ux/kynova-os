import { z } from "zod";
import { canAccess } from "@/config/modules";
import type { Role } from "@/config/roles";
import { allows } from "./access";
import {
  MAX_BACKDATE_MS, MAX_SKEW_MS, SCHEMA_VERSION, digestQuery, eventInput, listQuery, revertInput, summaryQuery,
  type ActivityEvent, type ActivityEventInput, type Capability, type DailyRollup, type ListQuery, type Mode, type WorkspaceState,
} from "./domain";
import { ActivityError } from "./errors";
import type { ActivityStore, EventFilter } from "./store";

export interface Actor { tenantId: string; userId: string; role: Role; requestId?: string; /** Set when an AI employee acts for the person: it may read, never revert. */ agentId?: string }
/** Who is writing: server code only. There is no HTTP write path, so a browser can never forge activity. */
export interface WriteContext { tenantId: string; requestId?: string }
export interface Page<T> { items: T[]; nextCursor: string | null }
export interface ActivityDeps { store: ActivityStore; newId: () => string; now?: () => number }
/** A module that can undo its own events registers one of these; the engine never touches another module's data. */
export type Reverter = (event: ActivityEvent, actor: Actor) => Promise<{ summary?: string }>;

const DAY = 86_400_000, STATE_WINDOW_DAYS = 90, DIGEST_MAX = 2000;
const dayOf = (t: number) => Math.floor(t / DAY) * DAY;
const enc = (v: number, id: string): string => btoa(JSON.stringify({ v, id })).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
function dec(c?: string): { occurredAt: number; id: string } | undefined {
  if (!c) return undefined;
  try { const o = JSON.parse(atob(c.replace(/-/g, "+").replace(/_/g, "/"))) as { v: unknown; id: unknown }; if (typeof o.v === "number" && typeof o.id === "string") return { occurredAt: o.v, id: o.id }; } catch { /* fall through */ }
  throw new ActivityError("validation_failed", "Invalid cursor.", { fields: [{ field: "cursor", message: "Invalid cursor." }] });
}

const reverters = (): Map<string, Reverter> => ((globalThis as unknown as { __kynovaReverters?: Map<string, Reverter> }).__kynovaReverters ??= new Map());
/** Registered once at startup by the module that owns the events. */
export const registerReverter = (module: string, fn: Reverter): void => { reverters().set(module, fn); };

export function createActivityService(deps: ActivityDeps) {
  const { store } = deps, now = deps.now ?? Date.now;
  const parse = <S extends z.ZodType>(schema: S, input: unknown): z.output<S> => {
    const r = schema.safeParse(input);
    if (!r.success) throw new ActivityError("validation_failed", "One or more fields are invalid.", { fields: r.error.issues.map((i) => ({ field: i.path.join(".") || "_", message: i.message })) });
    return r.data;
  };
  const can = (a: Actor, c: Capability): boolean => canAccess(a.role, "mission-control") && allows(a.role, c) && (!a.agentId || c === "view");
  const need = (a: Actor, c: Capability): void => { if (!can(a, c)) throw new ActivityError("forbidden", a.agentId && c !== "view" ? "AI employees cannot undo activity." : `Your role cannot do this (${c}).`); };
  const filterOf = (q: ListQuery): EventFilter => { const { limit: _l, cursor: _c, ...f } = q; return Object.fromEntries(Object.entries(f).filter(([, v]) => v !== undefined)) as EventFilter; };

  async function page(a: Actor, q: ListQuery): Promise<Page<ActivityEvent>> {
    const rows = await store.list(a.tenantId, { where: filterOf(q), limit: q.limit + 1, after: dec(q.cursor) });
    const items = rows.slice(0, q.limit), last = items.at(-1);
    return { items, nextCursor: rows.length > q.limit && last ? enc(last.occurredAt, last.id) : null };
  }
  const totals = (rs: DailyRollup[]) => ({ events: rs.reduce((n, r) => n + r.events, 0), quantity: rs.reduce((n, r) => n + r.quantity, 0) });
  function group(rs: DailyRollup[], keys: ("module" | "action")[]) {
    const m = new Map<string, { module: string; action?: string; events: number; quantity: number }>();
    for (const r of rs) { const k = keys.map((x) => r[x]).join("|"), g = m.get(k) ?? { module: r.module, ...(keys.includes("action") ? { action: r.action } : {}), events: 0, quantity: 0 }; g.events += r.events; g.quantity += r.quantity; m.set(k, g); }
    return [...m.values()].sort((x, y) => y.quantity - x.quantity || y.events - x.events || (x.module + (x.action ?? "")).localeCompare(y.module + (y.action ?? "")));
  }

  /** The single write path (see record). `revertsId` is set only by revert(), so the unique index makes a double undo impossible. */
  async function write(ctx: WriteContext, input: ActivityEventInput, revertsId: string | null = null): Promise<{ event: ActivityEvent; duplicate: boolean }> {
    const i = parse(eventInput, input), t = now(), occurredAt = i.occurredAt ?? t;
    if (occurredAt > t + MAX_SKEW_MS) throw new ActivityError("validation_failed", "The event is dated in the future.", { fields: [{ field: "occurredAt", message: "The event is dated in the future." }] });
    if (occurredAt < t - MAX_BACKDATE_MS) throw new ActivityError("validation_failed", "The event is too old.", { fields: [{ field: "occurredAt", message: "The event is too old." }] });
    const key = i.idempotencyKey ?? (i.source !== "kynova" && i.externalRef ? `${i.source}:${i.externalRef}` : null);
    if (key) { const prev = await store.getByIdempotencyKey(ctx.tenantId, key); if (prev) return { event: prev, duplicate: true }; }
    const event: ActivityEvent = {
      id: deps.newId(), tenantId: ctx.tenantId, schemaVersion: SCHEMA_VERSION, occurredAt, recordedAt: t, source: i.source, module: i.module, action: i.action, summary: i.summary,
      actorKind: i.actorKind, actorId: i.actorId ?? null, employeeKey: i.employeeKey ?? null, outcome: i.outcome, mode: i.mode, quantity: i.quantity,
      subjectKind: i.subjectKind ?? null, subjectId: i.subjectId ?? null, reversible: i.reversible, revertHint: i.revertHint ?? null, revertsId,
      idempotencyKey: key, externalRef: i.externalRef ?? null, requestId: ctx.requestId ?? null,
    };
    try { await store.append(event); } catch (e) {
      if (key && (e as { code?: string } | null)?.code === "duplicate") { const prev = await store.getByIdempotencyKey(ctx.tenantId, key); if (prev) return { event: prev, duplicate: true }; }
      throw e;
    }
    return { event, duplicate: false };
  }

  return {
    /**
     * The single write path. Idempotent: a repeated idempotency key (or a repeated source + external ref) returns the first event and counts once.
     * Only `mode: "production"` events are real work; `simulation` and `demo` events are stored apart and never mixed into headline numbers.
     */
    record: (ctx: WriteContext, input: ActivityEventInput) => write(ctx, input),

    async list(a: Actor, q: unknown): Promise<Page<ActivityEvent>> { need(a, "view"); return page(a, parse(listQuery, q)); },
    async get(a: Actor, id: string): Promise<{ event: ActivityEvent; revertedBy: ActivityEvent | null }> {
      need(a, "view");
      const event = await store.get(a.tenantId, id); if (!event) throw new ActivityError("not_found", "Event not found.");
      return { event, revertedBy: await store.getRevertOf(a.tenantId, id) };
    },
    /** Everything that happened to one thing (a lead, an order, a page), newest first. */
    async timeline(a: Actor, subjectKind: string, subjectId: string, q: unknown = {}): Promise<Page<ActivityEvent>> { need(a, "view"); return page(a, parse(listQuery, { ...(q as object), subjectKind, subjectId })); },

    /**
     * Counters for dashboards, read from the daily rollups (never from events). `state` looks at the last 90 days and is what the UI must follow:
     * empty (nothing yet), demo (only demonstration data), simulation (simulated work, no real one) or production (real work exists).
     */
    async summary(a: Actor, q: unknown = {}) {
      need(a, "view");
      const { days } = parse(summaryQuery, q), today = dayOf(now()), from = today - (days - 1) * DAY;
      const all = await store.rollups(a.tenantId, today - (STATE_WINDOW_DAYS - 1) * DAY, today);
      const has = (m: Mode) => all.some((r) => r.mode === m && r.events > 0);
      const state: WorkspaceState = has("production") ? "production" : has("simulation") ? "simulation" : has("demo") ? "demo" : "empty";
      const win = all.filter((r) => r.day >= from), by = (m: Mode, o?: string) => win.filter((r) => r.mode === m && (!o || r.outcome === o));
      const real = by("production", "success");
      const daily = Array.from({ length: days }, (_, k) => { const d = from + k * DAY, rs = real.filter((r) => r.day === d); return { day: d, ...totals(rs) }; });
      const latest = await store.list(a.tenantId, { where: { mode: "production" }, limit: 1 });
      return {
        state, days, from, to: today + DAY - 1, stateWindowDays: STATE_WINDOW_DAYS,
        production: { ...totals(real), failed: totals(by("production", "failed")).events, skipped: totals(by("production", "skipped")).events },
        simulation: totals(by("simulation")), demo: totals(by("demo")),
        byModule: group(real, ["module"]), byAction: group(real, ["module", "action"]), daily, lastEventAt: latest[0]?.occurredAt ?? null,
      };
    },

    /** "While you were away": real, successful work since a moment, grouped by action. Reads events, so it is capped. */
    async digest(a: Actor, q: unknown) {
      need(a, "view");
      const { since } = parse(digestQuery, q), until = now(), groups = new Map<string, { module: string; action: string; events: number; quantity: number }>();
      let after: { occurredAt: number; id: string } | undefined, seen = 0, truncated = false;
      while (seen < DIGEST_MAX) {
        const rows = await store.list(a.tenantId, { where: { since, mode: "production", outcome: "success" }, limit: 500, after });
        for (const e of rows) { const k = `${e.module}|${e.action}`, g = groups.get(k) ?? { module: e.module, action: e.action, events: 0, quantity: 0 }; g.events += 1; g.quantity += e.quantity; groups.set(k, g); }
        seen += rows.length;
        if (rows.length < 500) break;
        const last = rows.at(-1) as ActivityEvent; after = { occurredAt: last.occurredAt, id: last.id };
        if (seen >= DIGEST_MAX) truncated = true;
      }
      return { since, until, truncated, groups: [...groups.values()].sort((x, y) => y.quantity - x.quantity || x.action.localeCompare(y.action)) };
    },

    /**
     * Undo something an employee or module did. The engine only coordinates: the module that owns the event registers a reverter and does the
     * actual undo, and a reverter MUST be idempotent (two concurrent undos may both call it; only one revert event can be written). A revert is itself an event (append-only).
     */
    async revert(a: Actor, id: string, input: unknown = {}): Promise<{ event: ActivityEvent; reverted: ActivityEvent }> {
      need(a, "revert");
      const { reason } = parse(revertInput, input), orig = await store.get(a.tenantId, id);
      if (!orig) throw new ActivityError("not_found", "Event not found.");
      if (!orig.reversible || orig.outcome !== "success") throw new ActivityError("invalid_state", "This activity cannot be undone.", { reason: "not_reversible" });
      if (orig.action.startsWith("activity.")) throw new ActivityError("invalid_state", "This activity cannot be undone.", { reason: "not_reversible" });
      if (await store.getRevertOf(a.tenantId, id)) throw new ActivityError("invalid_state", "This activity was already undone.", { reason: "already_reverted" });
      const fn = reverters().get(orig.module);
      if (!fn) throw new ActivityError("invalid_state", "That module cannot undo this activity yet.", { reason: "no_reverter" });
      const base = { tenantId: a.tenantId, requestId: a.requestId }, t = now();
      let result: { summary?: string };
      try { result = await fn(orig, a); } catch (e) {
        const msg = e instanceof Error ? e.message : "The undo failed.";
        await write(base, { module: orig.module, action: "activity.revert_failed", summary: `Could not undo: ${orig.summary}`.slice(0, 240), actorKind: "user", actorId: a.userId, outcome: "failed", mode: orig.mode, subjectKind: orig.subjectKind, subjectId: orig.subjectId, occurredAt: t });
        throw new ActivityError("invalid_state", "The undo failed.", { reason: "reverter_failed", message: msg.slice(0, 160) });
      }
      const { event } = await write(base, {
        module: orig.module, action: "activity.reverted", summary: (result.summary ?? `Undone: ${orig.summary}${reason ? ` (${reason})` : ""}`).slice(0, 240), actorKind: "user", actorId: a.userId,
        mode: orig.mode, subjectKind: orig.subjectKind, subjectId: orig.subjectId, occurredAt: t,
      }, id);
      return { event, reverted: orig };
    },
    permissions(a: Actor): Record<Capability, boolean> { return { view: can(a, "view"), revert: can(a, "revert") }; },
  };
}
export type ActivityService = ReturnType<typeof createActivityService>;
