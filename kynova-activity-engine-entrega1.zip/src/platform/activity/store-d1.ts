import type { D1Database } from "@cloudflare/workers-types";
import { EVENTS_TABLE, EVENT_COLUMNS, ROLLUP_TABLE, camel, snake } from "./columns";
import type { ActivityEvent, DailyRollup } from "./domain";
import { ActivityError } from "./errors";
import type { ActivityStore, EventFilter } from "./store";

type Row = Record<string, unknown>;
type Bind = string | number | null;
const DAY_MS = 86_400_000;

function mapError(e: unknown): never {
  const m = e instanceof Error ? `${e.message} ${(e.cause as Error | undefined)?.message ?? ""}` : String(e);
  if (/UNIQUE constraint failed/i.test(m)) throw new ActivityError("duplicate", "A record with the same unique value already exists.");
  if (/FOREIGN KEY constraint failed/i.test(m)) throw new ActivityError("validation_failed", "A referenced record does not exist.");
  if (/CHECK constraint failed/i.test(m)) throw new ActivityError("validation_failed", "A value is not allowed.");
  if (/append-only|cannot change|immutable/i.test(m)) throw new ActivityError("invalid_state", "That change is not allowed.");
  throw e;
}
const dec = (r: Row): ActivityEvent => {
  const o: Row = {};
  for (const [k, v] of Object.entries(r)) { const c = camel(k); o[c] = c === "revertHint" ? (typeof v === "string" ? JSON.parse(v) : null) : c === "reversible" ? v === 1 : v ?? null; }
  return o as unknown as ActivityEvent;
};
const FILTERS: [keyof EventFilter, string, "eq" | "gte" | "lte"][] = [
  ["module", "module", "eq"], ["action", "action", "eq"], ["source", "source", "eq"], ["actorKind", "actor_kind", "eq"], ["employeeKey", "employee_key", "eq"], ["mode", "mode", "eq"],
  ["outcome", "outcome", "eq"], ["subjectKind", "subject_kind", "eq"], ["subjectId", "subject_id", "eq"], ["since", "occurred_at", "gte"], ["until", "occurred_at", "lte"],
];
function where(tenantId: string, f: EventFilter = {}): { sql: string; binds: Bind[] } {
  const sql = ["tenant_id = ?"], binds: Bind[] = [tenantId];
  for (const [key, col, op] of FILTERS) { const v = f[key]; if (v === undefined) continue; sql.push(`${col} ${op === "eq" ? "=" : op === "gte" ? ">=" : "<="} ?`); binds.push(v as Bind); }
  return { sql: sql.join(" AND "), binds };
}

/** Cloudflare D1 store in plain parameterized SQL. Identifiers come from a fixed whitelist, values are always bound, every statement is scoped by tenant_id. */
export function createD1ActivityStore(d1: D1Database): ActivityStore {
  const one = async (sql: string, ...b: Bind[]) => { const r = await d1.prepare(sql).bind(...b).first<Row>(); return r ? dec(r) : null; };
  return {
    async append(e) {
      const r = e as unknown as Row, cols = EVENT_COLUMNS.filter((c) => r[c] !== undefined);
      const vals = cols.map((c): Bind => (c === "revertHint" ? (r[c] == null ? null : JSON.stringify(r[c])) : c === "reversible" ? (r[c] ? 1 : 0) : ((r[c] ?? null) as Bind)));
      const day = Math.floor(e.occurredAt / DAY_MS) * DAY_MS;
      try {
        await d1.batch([
          d1.prepare(`INSERT INTO ${EVENTS_TABLE} (${cols.map(snake).join(", ")}) VALUES (${cols.map(() => "?").join(", ")})`).bind(...vals),
          d1.prepare(`INSERT INTO ${ROLLUP_TABLE} (tenant_id, day, module, action, mode, outcome, events, quantity) VALUES (?, ?, ?, ?, ?, ?, 1, ?) ON CONFLICT (tenant_id, day, module, action, mode, outcome) DO UPDATE SET events = events + 1, quantity = quantity + excluded.quantity`)
            .bind(e.tenantId, day, e.module, e.action, e.mode, e.outcome, e.quantity),
        ]);
      } catch (err) { mapError(err); }
    },
    get: (t, id) => one(`SELECT * FROM ${EVENTS_TABLE} WHERE tenant_id = ? AND id = ?`, t, id),
    getByIdempotencyKey: (t, k) => one(`SELECT * FROM ${EVENTS_TABLE} WHERE tenant_id = ? AND idempotency_key = ?`, t, k),
    getRevertOf: (t, id) => one(`SELECT * FROM ${EVENTS_TABLE} WHERE tenant_id = ? AND reverts_id = ?`, t, id),
    async list(t, spec) {
      const w = where(t, spec.where), binds = [...w.binds];
      let sql = w.sql;
      if (spec.after) { sql += " AND (occurred_at < ? OR (occurred_at = ? AND id < ?))"; binds.push(spec.after.occurredAt, spec.after.occurredAt, spec.after.id); }
      const rows = await d1.prepare(`SELECT * FROM ${EVENTS_TABLE} WHERE ${sql} ORDER BY occurred_at DESC, id DESC LIMIT ?`).bind(...binds, Math.min(500, Math.max(1, spec.limit))).all<Row>();
      return rows.results.map(dec);
    },
    async count(t, f) { const w = where(t, f), r = await d1.prepare(`SELECT COUNT(*) AS n FROM ${EVENTS_TABLE} WHERE ${w.sql}`).bind(...w.binds).first<{ n: number }>(); return Number(r?.n ?? 0); },
    async rollups(t, from, to) {
      const r = await d1.prepare(`SELECT * FROM ${ROLLUP_TABLE} WHERE tenant_id = ? AND day >= ? AND day <= ?`).bind(t, from, to).all<Row>();
      return r.results.map((x): DailyRollup => ({ tenantId: String(x.tenant_id), day: Number(x.day), module: String(x.module), action: String(x.action), mode: x.mode as DailyRollup["mode"], outcome: x.outcome as DailyRollup["outcome"], events: Number(x.events), quantity: Number(x.quantity) }));
    },
  };
}
