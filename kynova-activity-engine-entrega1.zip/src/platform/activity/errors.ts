export type ActivityErrorCode = "forbidden" | "not_found" | "validation_failed" | "duplicate" | "invalid_state" | "unavailable";
const STATUS: Record<ActivityErrorCode, number> = { forbidden: 403, not_found: 404, validation_failed: 422, duplicate: 409, invalid_state: 409, unavailable: 503 };
export class ActivityError extends Error {
  readonly status: number;
  constructor(readonly code: ActivityErrorCode, message: string, readonly details?: Record<string, unknown>) { super(message); this.name = "ActivityError"; this.status = STATUS[code]; }
}
export const isActivityError = (e: unknown): e is ActivityError => e instanceof ActivityError || (typeof e === "object" && e !== null && (e as { name?: string }).name === "ActivityError");
