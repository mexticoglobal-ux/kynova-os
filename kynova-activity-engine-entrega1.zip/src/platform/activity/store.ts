import type { ActivityEvent, DailyRollup, Mode, Outcome, ActorKind } from "./domain";

export interface EventFilter {
  module?: string; action?: string; source?: string; actorKind?: ActorKind; employeeKey?: string; mode?: Mode; outcome?: Outcome;
  subjectKind?: string; subjectId?: string; since?: number; until?: number;
}
export interface ListSpec { where?: EventFilter; limit: number; after?: { occurredAt: number; id: string } }

/**
 * Persistence port of the Activity Engine. The log is APPEND-ONLY: there is no update and no delete. EVERY method takes the tenant id and every
 * statement is scoped by it. Two implementations: D1 (production) and in-memory (local development and tests).
 */
export interface ActivityStore {
  /** Inserts the event and bumps its daily rollup atomically. Throws ActivityError("duplicate") on a repeated idempotency key or a second revert of the same event. */
  append(event: ActivityEvent): Promise<void>;
  get(tenantId: string, id: string): Promise<ActivityEvent | null>;
  getByIdempotencyKey(tenantId: string, key: string): Promise<ActivityEvent | null>;
  /** The event that reverted `id`, if any. */
  getRevertOf(tenantId: string, id: string): Promise<ActivityEvent | null>;
  /** Newest first: occurredAt desc, id desc. */
  list(tenantId: string, spec: ListSpec): Promise<ActivityEvent[]>;
  count(tenantId: string, where?: EventFilter): Promise<number>;
  rollups(tenantId: string, fromDay: number, toDay: number): Promise<DailyRollup[]>;
}
