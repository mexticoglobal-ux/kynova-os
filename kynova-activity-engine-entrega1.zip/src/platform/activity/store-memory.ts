import { ActivityError } from "./errors";
import type { ActivityEvent, DailyRollup } from "./domain";
import type { ActivityStore, EventFilter } from "./store";

export const DAY_MS = 86_400_000;
export const dayOf = (t: number): number => Math.floor(t / DAY_MS) * DAY_MS;

const matches = (e: ActivityEvent, w: EventFilter = {}): boolean =>
  (w.module === undefined || e.module === w.module) && (w.action === undefined || e.action === w.action) && (w.source === undefined || e.source === w.source)
  && (w.actorKind === undefined || e.actorKind === w.actorKind) && (w.employeeKey === undefined || e.employeeKey === w.employeeKey) && (w.mode === undefined || e.mode === w.mode)
  && (w.outcome === undefined || e.outcome === w.outcome) && (w.subjectKind === undefined || e.subjectKind === w.subjectKind) && (w.subjectId === undefined || e.subjectId === w.subjectId)
  && (w.since === undefined || e.occurredAt >= w.since) && (w.until === undefined || e.occurredAt <= w.until);

/** In-memory store: same contract as D1, including tenant scoping, uniqueness and atomic event + rollup. */
export function createMemoryActivityStore(): ActivityStore {
  const events = new Map<string, ActivityEvent>(), rolls = new Map<string, DailyRollup>();
  const mine = (t: string) => [...events.values()].filter((e) => e.tenantId === t);
  return {
    async append(e) {
      if (events.has(e.id)) throw new ActivityError("duplicate", "Duplicate id.");
      const all = mine(e.tenantId);
      if (e.idempotencyKey && all.some((x) => x.idempotencyKey === e.idempotencyKey)) throw new ActivityError("duplicate", "That idempotency key was already used.");
      if (e.revertsId && all.some((x) => x.revertsId === e.revertsId)) throw new ActivityError("duplicate", "That event was already reverted.");
      if (e.revertsId && !all.some((x) => x.id === e.revertsId)) throw new ActivityError("validation_failed", "The reverted event does not exist.");
      events.set(e.id, structuredClone(e));
      const day = dayOf(e.occurredAt), k = [e.tenantId, day, e.module, e.action, e.mode, e.outcome].join("|"), cur = rolls.get(k);
      rolls.set(k, cur ? { ...cur, events: cur.events + 1, quantity: cur.quantity + e.quantity } : { tenantId: e.tenantId, day, module: e.module, action: e.action, mode: e.mode, outcome: e.outcome, events: 1, quantity: e.quantity });
    },
    async get(t, id) { const e = events.get(id); return e && e.tenantId === t ? structuredClone(e) : null; },
    async getByIdempotencyKey(t, key) { const e = mine(t).find((x) => x.idempotencyKey === key); return e ? structuredClone(e) : null; },
    async getRevertOf(t, id) { const e = mine(t).find((x) => x.revertsId === id); return e ? structuredClone(e) : null; },
    async list(t, spec) {
      const cmp = (a: { occurredAt: number; id: string }, b: { occurredAt: number; id: string }) => b.occurredAt - a.occurredAt || (a.id < b.id ? 1 : a.id > b.id ? -1 : 0);
      let rows = mine(t).filter((e) => matches(e, spec.where)).sort(cmp);
      const after = spec.after;
      if (after) rows = rows.filter((e) => cmp(e, after) > 0);
      return rows.slice(0, spec.limit).map((e) => structuredClone(e));
    },
    async count(t, where) { return mine(t).filter((e) => matches(e, where)).length; },
    async rollups(t, from, to) { return [...rolls.values()].filter((r) => r.tenantId === t && r.day >= from && r.day <= to).map((r) => ({ ...r })); },
  };
}
