/** The only columns the D1 store reads or writes (property names; snake_case in SQL). A test checks them against the migration. */
export const EVENT_COLUMNS = ["id", "tenantId", "schemaVersion", "occurredAt", "recordedAt", "source", "module", "action", "summary", "actorKind", "actorId", "employeeKey", "outcome", "mode", "quantity", "subjectKind", "subjectId", "reversible", "revertHint", "revertsId", "idempotencyKey", "externalRef", "requestId"] as const;
export const ROLLUP_COLUMNS = ["tenantId", "day", "module", "action", "mode", "outcome", "events", "quantity"] as const;
export const EVENTS_TABLE = "act_events", ROLLUP_TABLE = "act_daily";
export const snake = (k: string) => k.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
export const camel = (k: string) => k.replace(/_([a-z0-9])/g, (_m, c: string) => c.toUpperCase());
