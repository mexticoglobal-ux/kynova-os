import { activityRoute, queryOf, respond } from "@/platform/activity/http";

export const GET = activityRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.list(actor, queryOf(req)), rid); });
