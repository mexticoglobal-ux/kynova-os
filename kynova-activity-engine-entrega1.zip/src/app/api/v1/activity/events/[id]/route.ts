import { activityRoute, respond } from "@/platform/activity/http";

type Ctx = { params: Promise<{ id: string }> };

export const GET = activityRoute<Ctx>(async (req, c, { actor, svc, rid }) => { void req; const p = await c.params; return respond(await svc.get(actor, p.id), rid); });
