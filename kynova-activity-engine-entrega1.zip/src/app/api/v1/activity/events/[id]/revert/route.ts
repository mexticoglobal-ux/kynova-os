import { activityRoute, readBody, respond } from "@/platform/activity/http";

type Ctx = { params: Promise<{ id: string }> };

export const POST = activityRoute<Ctx>(async (req, c, { actor, svc, rid }) => { const p = await c.params; return respond(await svc.revert(actor, p.id, await readBody(req)), rid); }, { mutating: true });
