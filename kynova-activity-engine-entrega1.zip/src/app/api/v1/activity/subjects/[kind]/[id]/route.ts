import { activityRoute, queryOf, respond } from "@/platform/activity/http";

type Ctx = { params: Promise<{ kind: string; id: string }> };

export const GET = activityRoute<Ctx>(async (req, c, { actor, svc, rid }) => { const p = await c.params; return respond(await svc.timeline(actor, p.kind, p.id, queryOf(req)), rid); });
