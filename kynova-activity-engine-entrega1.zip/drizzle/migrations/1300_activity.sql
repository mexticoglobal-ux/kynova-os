-- Activity Engine (Core service). Owned by src/platform/activity. One append-only log that every AI employee, module and external system (LIFE OS, Maka) writes to
-- through a common adapter; Mission Control, Analytics, the Dashboard and the Customer Portal only read it.
-- Scale: every index leads with tenant_id, lists are keyset-paginated, and act_daily holds per-day counters written in the same batch as the event, so dashboards
-- read O(days) rows however many events exist. Events can be exported and trimmed by month without touching the contract.
-- act_events is immutable (no update, no delete). act_daily only ever grows its counters. Nothing here reads other modules' tables.

CREATE TABLE `act_events` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`schema_version` integer DEFAULT 1 NOT NULL,
	`occurred_at` integer NOT NULL,
	`recorded_at` integer NOT NULL,
	`source` text DEFAULT 'kynova' NOT NULL,
	`module` text NOT NULL,
	`action` text NOT NULL,
	`summary` text NOT NULL,
	`actor_kind` text DEFAULT 'system' NOT NULL,
	`actor_id` text,
	`employee_key` text,
	`outcome` text DEFAULT 'success' NOT NULL,
	`mode` text DEFAULT 'production' NOT NULL,
	`quantity` integer DEFAULT 1 NOT NULL,
	`subject_kind` text,
	`subject_id` text,
	`reversible` integer DEFAULT 0 NOT NULL,
	`revert_hint` text,
	`reverts_id` text,
	`idempotency_key` text,
	`external_ref` text,
	`request_id` text,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`tenant_id`, `reverts_id`) REFERENCES `act_events`(`tenant_id`, `id`) ON UPDATE no action ON DELETE no action,
	CHECK (`actor_kind` IN ('employee', 'user', 'system', 'integration')),
	CHECK (`outcome` IN ('success', 'failed', 'skipped')),
	CHECK (`mode` IN ('production', 'simulation', 'demo')),
	CHECK (`quantity` BETWEEN 0 AND 100000),
	CHECK (`reversible` IN (0, 1)),
	CHECK (`reversible` = 0 OR `revert_hint` IS NOT NULL),
	CHECK (`revert_hint` IS NULL OR (json_valid(`revert_hint`) AND length(`revert_hint`) <= 1024)),
	CHECK (length(`summary`) BETWEEN 1 AND 240),
	CHECK (length(`source`) BETWEEN 2 AND 32),
	CHECK ((`subject_kind` IS NULL) = (`subject_id` IS NULL))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `act_events_tenant_id_uq` ON `act_events` (`tenant_id`,`id`);--> statement-breakpoint
CREATE INDEX `act_events_feed_idx` ON `act_events` (`tenant_id`,`occurred_at`,`id`);--> statement-breakpoint
CREATE INDEX `act_events_module_idx` ON `act_events` (`tenant_id`,`module`,`occurred_at`);--> statement-breakpoint
CREATE INDEX `act_events_action_idx` ON `act_events` (`tenant_id`,`action`,`occurred_at`);--> statement-breakpoint
CREATE INDEX `act_events_subject_idx` ON `act_events` (`tenant_id`,`subject_kind`,`subject_id`,`occurred_at`) WHERE `subject_id` IS NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX `act_events_idem_uq` ON `act_events` (`tenant_id`,`idempotency_key`) WHERE `idempotency_key` IS NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX `act_events_revert_uq` ON `act_events` (`tenant_id`,`reverts_id`) WHERE `reverts_id` IS NOT NULL;--> statement-breakpoint
CREATE TRIGGER act_events_immutable BEFORE UPDATE ON act_events BEGIN SELECT RAISE(ABORT, 'activity events are append-only'); END;
--> statement-breakpoint
CREATE TRIGGER act_events_no_delete BEFORE DELETE ON act_events BEGIN SELECT RAISE(ABORT, 'activity events are append-only'); END;
--> statement-breakpoint
CREATE TABLE `act_daily` (
	`tenant_id` text NOT NULL,
	`day` integer NOT NULL,
	`module` text NOT NULL,
	`action` text NOT NULL,
	`mode` text NOT NULL,
	`outcome` text NOT NULL,
	`events` integer DEFAULT 0 NOT NULL,
	`quantity` integer DEFAULT 0 NOT NULL,
	PRIMARY KEY (`tenant_id`, `day`, `module`, `action`, `mode`, `outcome`),
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`mode` IN ('production', 'simulation', 'demo')),
	CHECK (`outcome` IN ('success', 'failed', 'skipped')),
	CHECK (`events` >= 0 AND `quantity` >= 0)
);
--> statement-breakpoint
CREATE TRIGGER act_daily_tenant_frozen BEFORE UPDATE OF tenant_id ON act_daily BEGIN SELECT RAISE(ABORT, 'activity tenant cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER act_daily_no_delete BEFORE DELETE ON act_daily BEGIN SELECT RAISE(ABORT, 'activity counters are append-only'); END;
