# ADR 019: Activity Engine as a Core service

Status: accepted · Date: 2026-10-20

## Context
Each module would otherwise keep its own history, so Mission Control, Analytics, the Dashboard and the Portal would each need to know every module's format, and "the AI employee did X" could not be proven in one place. The product rule is that KYNOVA never invents results.

## Decision
One append-only `act_events` log in the Core (`src/platform/activity`), written through a common `ActivitySink` adapter and read through a small API. Daily counters (`act_daily`) are updated in the same batch as each event.

## Consequences
- Dashboards cost O(days), not O(events), so the design holds for 10,000 companies; every index leads with `tenant_id`.
- No HTTP write path: evidence cannot be forged from a browser.
- Undo is coordinated by the engine but executed by the owning module, which keeps modules independent; reverters must be idempotent.
- The `mode` field (production/simulation/demo) makes the four-state UX enforceable by the system, not by convention.
- LIFE OS and Maka use the same sink via `source` and `externalRef`.
- Frozen modules are untouched; they adopt the sink when they are next opened.
- Cost: an extra write per event and a second table to keep consistent (done atomically in one batch).
