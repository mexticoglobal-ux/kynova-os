# KYNOVA Blueprint (living document)

Short on purpose. It changes as the product is built; if a decision here conflicts with `CLAUDE.md`, `CLAUDE.md` wins. Every architecture decision must answer one question:
**does this let KYNOVA scale to 10,000 companies without redesigning the system?** If not, find a more scalable solution first.

## What KYNOVA is
An AI employee that works for a company and leaves evidence of what it did. The customer buys results, not modules.

## The five rules that never break
1. **KYNOVA never invents results.** Anything shown as work done exists as a record.
2. **Every AI employee leaves evidence.** If it did something, an activity event exists (who, when, what, on which thing, outcome).
3. **Everything important is reversible** where it can be. The owning module registers how to undo; the undo is itself recorded.
4. **The customer buys results, not tools.** Screens are organized around goals and work done.
5. **AI recommends, the person decides**, except automations the company explicitly authorized.

## The four states of any screen that shows results
| State | Meaning | Rule |
|---|---|---|
| Empty | Nothing yet | Say so and show how to connect. Never a bare "no data". |
| Demo | Sample data to show the idea | Always labeled "demo data". Never counted as real. |
| Simulation | Real flow, no real side effects (e.g. payments not connected) | Labeled as simulated. Stored apart from production. |
| Production | Real work done for the company | The only state that feeds headline numbers. |
The state comes from the system (`GET /api/v1/activity/summary` → `state`), never from the designer.

## Core services (shared, written once)
- **Activity Engine** (`src/platform/activity`): the one append-only log every module writes to through the `ActivitySink` adapter; Mission Control, Analytics, the Dashboard and the Customer Portal only read it. See `docs/27_ACTIVITY_ENGINE.md`.
- AI Kernel, Auth, Database, AI Employees: already in `src/platform`.

## Scale rules (10,000 companies)
- Every table is tenant-owned and every index leads with `tenant_id`. No query without a tenant.
- Lists are keyset-paginated; dashboards read pre-aggregated counters, never scan logs.
- Writes are idempotent; side effects go through ports so a provider (payments, files, LIFE OS, Maka) is swapped without touching the Core.
- Nothing global that grows with the number of tenants: no cross-tenant scans, no per-tenant cron loops in request paths.

## Integration readiness
LIFE OS and Maka write through the same sink (`source: "life_os" | "maka"`, `externalRef` for safe retries) and, when needed, register as their own modules. The Core does not change for them.

## Roadmap in blocks
Commercial v1.0 (Partners, Referrals, Portal, Onboarding) → Production (deploy, monitoring, backups, performance, QA) → Release Candidate. Pilot goal: Grupo Arya.

## Not connected yet (do not present as working)
Real payments (Stripe, PayPal, Maka), product file storage, Google/Meta/WhatsApp integrations, payouts.
