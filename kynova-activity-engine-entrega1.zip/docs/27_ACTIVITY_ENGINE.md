# 27. Activity Engine (Core service)

`src/platform/activity` · migration `drizzle/migrations/1300_activity.sql` · API `/api/v1/activity/*` · ADR `docs/adr/019-activity-engine.md`.

## What it is
One append-only log of everything AI employees, modules and external systems do for a company. Writers use an adapter; readers (Mission Control, Analytics, Dashboard, Customer Portal, Reports) only read.

## Writing: the `ActivitySink`
```ts
const sink = await getActivitySink("partners");           // module default; optional source
await sink.record({ tenantId, requestId }, {
  action: "partners.invite.sent", summary: "Invitation sent to Acme",
  actorKind: "employee", employeeKey: "sales_employee", subjectKind: "partner", subjectId: id,
  quantity: 1, reversible: true, revertHint: { inviteId },      // optional
});
```
- `record` never throws (a lost log line must not break the business operation); it returns `{ ok: false }` and logs one structured line. `recordStrict` throws, for cases where the evidence is the operation.
- There is **no HTTP endpoint to write events**, so a browser can never forge activity. The only POST is the undo.
- Idempotent: the same `idempotencyKey` (or `source` + `externalRef`) returns the first event and counts once.
- Tests inject `noopSink` or a memory-backed sink. Modules never import the store.

## Event shape
`id, tenantId, schemaVersion, occurredAt, recordedAt, source, module, action (dotted, e.g. seo.audit.completed), summary (≤240), actorKind (employee|user|system|integration), actorId, employeeKey, outcome (success|failed|skipped), mode (production|simulation|demo), quantity, subjectKind/subjectId, reversible, revertHint (≤1 KB, never secrets), revertsId, idempotencyKey, externalRef, requestId`.

## Reading
| Endpoint | Purpose |
|---|---|
| `GET /activity/events` | Feed, newest first, filters + keyset cursor |
| `GET /activity/events/{id}` | One event and the undo event, if any |
| `GET /activity/subjects/{kind}/{id}` | Timeline of one thing |
| `GET /activity/summary?days=` | Counters from daily rollups + `state` (empty/demo/simulation/production, last 90 days) |
| `GET /activity/digest?since=` | "While you were away": real successful work since a moment, grouped |
| `POST /activity/events/{id}/revert` | Undo (owner/admin/CEO/manager; never AI agents) |

Headline numbers are `production` + `success` only. Demo and simulation are returned separately and are never mixed in.

## Undo
The engine coordinates, the owning module acts: `registerReverter("marketing", async (event, actor) => {...})`. A reverter **must be idempotent**. The undo is recorded as an event (`activity.reverted`) linked by `reverts_id` (unique): an event can be undone once. A failed attempt is recorded as `activity.revert_failed` and can be retried.

## Scale
Every index leads with `tenant_id`; the feed is served by `(tenant_id, occurred_at, id)` (checked by an EXPLAIN test). Each write also bumps `act_daily` (per tenant, UTC day, module, action, mode, outcome) in the same D1 batch, so dashboards read O(days) rows regardless of volume. Events can be exported and archived by month without changing the contract.

## LIFE OS and Maka
They write through the same sink with `source: "life_os"` / `"maka"`, `actorKind: "integration"` and `externalRef`. No Core change is needed.

## Assumptions / pending
- No UI of its own (modules.ts is frozen): Mission Control and the Dashboard will read it in later blocks.
- Existing modules (frozen) do not write to it yet; new modules do through the sink.
- No retention/archival job yet (the contract allows it); no queue for very high write rates (D1 batch is enough for the pilot).
