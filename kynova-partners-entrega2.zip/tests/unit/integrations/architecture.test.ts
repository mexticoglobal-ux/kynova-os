import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES, canAccess } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { COLUMNS, TABLE } from "../../../src/modules/integrations/columns";
import { INTEGRATIONS_DICTIONARIES } from "../../../src/modules/integrations/i18n";
import { ARCHITECTURE_STATUS } from "../../../src/modules/integrations/contracts";
import { AI_TOPICS, CAPABILITIES, CATEGORIES, DEFAULT_CAPABILITIES, ERROR_HELP, EVENT_STATUS, HISTORY_STATUS, NOTIFICATION_KINDS, PROVIDER_CATALOG, SYNC_ENTITIES, SYNC_FREQUENCIES, TRANSFORMS } from "../../../src/modules/integrations/domain";
import { INTEGRATIONS_BLUEPRINT } from "../../../src/modules/integrations/employee";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => { try { return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; }); } catch { return []; } };
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "integrations");
const bad = (dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "integrations"), join(SRC, "app", "(app)", "app", "integrations")];
const strip = (s: string) => s.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");

describe("Mission Control module boundaries", () => {
  it("never touches Drizzle, database internals, kernel internals or other product modules", () => {
    expect(bad([MOD], /drizzle-orm|platform\/db|ai-kernel\/|ai-employees\/|platform\/dashboard|components\/dashboard|modules\/(marketing|seo|ai-studio|finance|communications|crm|billing|security|analytics|analytics-bi|mission-control)/)).toEqual([]);
  });
  it("only the store layer knows SQL; no provider host and no network call exist in the module", () => {
    expect(files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f))).toEqual(["store-d1.ts"]);
    expect(files(MOD).filter((f) => /api\.openai\.com|api\.anthropic\.com|smtp\.|sendgrid|mailgun|googleapis\.com|api\.stripe\.com/.test(readFileSync(f, "utf8")))).toEqual([]);
    expect(files(MOD).filter((f) => /(?<![.\w])fetch\(|XMLHttpRequest|new WebSocket|node:https?|node:net/.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
  });
  it("states plainly what it does not do", () => {
    expect(Object.values(ARCHITECTURE_STATUS).length).toBeGreaterThan(0);
  });
  it("UI uses the module's public interface only", () => {
    expect(bad(UI, /platform\/db|drizzle|modules\/integrations\/(store|columns|runtime|ai|server)|modules\/(crm|marketing|seo|finance|ai-studio|communications|billing|security|analytics|analytics-bi|mission-control)|components\/(crm|marketing|seo|finance|ai-studio|communications|billing|security|analytics|analytics-bi|mission-control)/)).toEqual([]);
  });
  it("frozen code does not know Mission Control; it joins through startup registration only", () => {
    const frozen = ["platform/db", "platform/auth", "platform/ai-kernel", "platform/ai-employees", "platform/dashboard", "modules/crm", "modules/marketing", "modules/seo", "modules/ai-studio", "modules/finance", "modules/communications", "modules/billing", "modules/security", "modules/analytics", "modules/mission-control", "modules/analytics-bi"].map((d) => join(SRC, d));
    expect(bad(frozen, /modules\/integrations|components\/integrations/)).toEqual([]);
    const ins = readFileSync(join(SRC, "instrumentation.ts"), "utf8"); expect(ins).toContain("registerIntegrationsWidget"); expect(ins).toContain("registerIntegrationsEmployee");
  });
  it("registers exactly one widget: integrations-overview", () => {
    const w = readFileSync(join(SRC, "components", "integrations", "DashboardWidget.tsx"), "utf8");
    expect([...w.matchAll(/registerWidget</g)]).toHaveLength(1); expect(w).toContain('id: "integrations-overview"');
  });
  it("client components do not import server-only parts", () => {
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThanOrEqual(5);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/integrations$|modules\/integrations\/(service|server|http|store|runtime|ai)/.test(i)))).toEqual([]);
  });
  it("adds exactly one product module slug, open to executives, finance and marketing", () => {
    expect(MODULES).toHaveLength(25); expect(MODULES.filter((m) => m.slug === "integrations")).toHaveLength(1);
    expect(readFileSync(join(MOD, "http.ts"), "utf8")).toContain('INTEGRATIONS_SLUG = "integrations"');
    expect(canAccess("owner", "integrations")).toBe(true); expect(canAccess("manager", "integrations")).toBe(true); expect(canAccess("employee", "integrations")).toBe(false); expect(canAccess("guest", "integrations")).toBe(false);
  });
  it("the Mission Control Advisor never executes actions: its blueprint is read only", () => {
    expect(INTEGRATIONS_BLUEPRINT.maxAutonomy).toBe(1); expect(INTEGRATIONS_BLUEPRINT.defaultInstructions).toMatch(/never execute/i);
    expect(INTEGRATIONS_BLUEPRINT.name).toBe("Integrations Advisor AI"); expect(AI_TOPICS).toHaveLength(6);
    expect(DEFAULT_CAPABILITIES.guest).toHaveLength(0);
    for (const c of INTEGRATIONS_BLUEPRINT.capabilities) expect(c).toMatch(/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/);
    expect(INTEGRATIONS_BLUEPRINT.key).toMatch(/^[a-z][a-z0-9_]*$/);
  });
});

describe("API surface: only /api/v1/integrations/*", () => {
  const API = join(SRC, "app", "api", "v1", "integrations");
  const routes = files(API).filter((f) => f.endsWith("route.ts"));
  it("every handler goes through integrationsRoute; every mutating verb enables CSRF checks", () => {
    expect(routes.length).toBeGreaterThanOrEqual(40);
    for (const f of routes) {
      const src = readFileSync(f, "utf8");
      for (const m of src.matchAll(/export const (GET|POST|PATCH|PUT|DELETE) = (\w+)/g)) {
        expect(m[2], `${relative(SRC, f)} ${m[1]}`).toBe("integrationsRoute");
        const decl = src.slice(src.indexOf(m[0])), next = decl.indexOf("\nexport const", 10), block = decl.slice(0, next === -1 ? decl.length : next);
        if (m[1] !== "GET") expect(block, `${relative(SRC, f)} ${m[1]}`).toContain("mutating: true"); else expect(block).not.toContain("mutating");
      }
    }
  });
  it("there is no public inbound endpoint and no outbound call", () => {
    expect(routes.filter((f) => !readFileSync(f, "utf8").includes("integrationsRoute"))).toEqual([]);
    expect(routes.filter((f) => /fetch\(/.test(readFileSync(f, "utf8")))).toEqual([]);
  });
  it("covers every section and action", () => {
    const rel = new Set(routes.map((f) => relative(API, f).replace(/\/?route\.ts$/, "")));
    for (const p of ["setup", "summary", "permissions", "permissions/mine", "permissions/[id]", "providers", "providers/[id]", "connections", "connections/check-all", "connections/[id]", "connections/[id]/authorize", "connections/[id]/disconnect", "connections/[id]/check", "connections/[id]/refresh-token", "accounts", "accounts/[id]", "tokens", "tokens/refresh-due", "tokens/[id]/revoke", "sync-jobs", "sync-jobs/run-due", "sync-jobs/[id]", "sync-jobs/[id]/run", "sync-jobs/[id]/retry", "sync-history", "webhooks", "webhooks/[id]", "events", "events/[id]/retry", "mappings", "rate-limits", "usage", "usage/summary", "notifications", "notifications/unread", "notifications/read-all", "notifications/[id]/read", "logs", "status", "status/history", "settings", "ai/[id]"]) expect(rel.has(p), p).toBe(true);
  });
});

describe("pages", () => {
  it("has the 14 views", () => {
    const base = join(SRC, "app", "(app)", "app", "integrations"), pages = new Set(files(base).filter((f) => f.endsWith("page.tsx")).map((f) => relative(base, f).replace(/\/?page\.tsx$/, "")));
    expect([...pages].sort()).toEqual(["", "accounts", "connections", "connections/[id]", "events", "logs", "notifications", "permissions", "providers", "rate-limits", "settings", "sync-history", "sync-jobs", "usage", "webhooks"]);
  });
});

describe("migration 1100_integrations.sql", () => {
  const sql = readFileSync(join(process.cwd(), "drizzle/migrations/1100_integrations.sql"), "utf8");
  const tables = [...sql.matchAll(/CREATE TABLE `(int_\w+)` \(([\s\S]*?)\n\);/g)];
  it("creates exactly the 16 int_* tables and touches nothing else", () => {
    expect(tables).toHaveLength(16);
    expect(Object.values(TABLE).sort()).toEqual(tables.map((t) => t[1]).sort());
    for (const n of ["providers", "connections", "accounts", "tokens", "sync_jobs", "sync_history", "webhooks", "events", "mappings", "logs", "permissions", "status", "rate_limits", "usage", "notifications", "settings"]) expect(Object.values(TABLE)).toContain(`int_${n}`);
    expect(sql.replace(/^--.*$/gm, "")).not.toMatch(/ALTER TABLE|DROP TABLE|DROP INDEX|INSERT INTO|DELETE FROM/);
    for (const o of sql.matchAll(/CREATE (?:UNIQUE )?INDEX `(\w+)`/g)) expect(o[1]).toMatch(/^int_/);
    for (const o of sql.matchAll(/CREATE TRIGGER (\w+)/g)) expect(o[1]).toMatch(/^int_/);
  });
  it("every table is tenant-owned with cascade and tenant-first indexes", () => {
    for (const [, name, body] of tables) {
      expect(body, name).toContain("`tenant_id` text NOT NULL");
      expect(body, name).toContain("FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`)");
      for (const ix of sql.matchAll(new RegExp(`CREATE (?:UNIQUE )?INDEX \`\\w+\` ON \`${name}\` \\(([^)]*)\\)`, "g"))) expect(ix[1], name).toMatch(/^`tenant_id`/);
    }
  });
  it("the database enforces tenant freezing, append-only history and the no-secrets rule", () => {
    for (const t of Object.values(TABLE)) expect(sql, t).toContain(`${t}_tenant_frozen`);
    for (const t of ["sync_history", "logs", "status"]) { expect(sql).toContain(`int_${t}_immutable`); expect(sql).toContain(`int_${t}_no_delete`); }
    for (const t of ["connections", "tokens", "events", "notifications", "usage", "providers", "settings"]) expect(sql).toContain(`int_${t}_no_delete`);
    expect(sql).toContain("int_tokens_no_secret"); expect(sql).toContain("CHECK (`secret_ref` IS NULL)");
  });
  it("whitelists cover each kind and carry the tenant column", () => {
    for (const k of Object.keys(TABLE) as (keyof typeof TABLE)[]) { expect(COLUMNS[k]).toContain("id"); expect(COLUMNS[k]).toContain("tenantId"); }
  });
});

describe("architecture-only promises", () => {
  it("no OAuth, no provider SDK and no outbound call exist anywhere in the module or its UI", () => {
    const all = [...files(MOD), ...UI.flatMap(files)].map((f) => ({ f, src: strip(readFileSync(f, "utf8")) }));
    expect(all.filter((x) => /oauth2?\.googleapis|accounts\.google\.com|graph\.facebook|login\.microsoftonline|api\.stripe|api\.paypal|slack\.com\/api|discord\.com\/api|api\.telegram|hubapi|salesforce\.com|myshopify|googleapis\.com|openid/i.test(x.src)).map((x) => relative(SRC, x.f))).toEqual([]);
    expect(all.filter((x) => /from\s+["'](googleapis|stripe|@slack|discord\.js|telegraf|@octokit|passport|openid-client|oauth4webapi|jose)/.test(x.src)).map((x) => relative(SRC, x.f))).toEqual([]);
  });
  it("tokens never carry a secret field and the catalog is the 29 requested providers", () => {
    expect(readFileSync(join(MOD, "domain.ts"), "utf8")).toMatch(/secretRef: string \| null/);
    expect(COLUMNS.token.some((c) => /^(secret|accessToken|refreshToken|value|apiKey)$/.test(c))).toBe(false);
    expect(PROVIDER_CATALOG).toHaveLength(29);
    expect(PROVIDER_CATALOG.map((p) => p.name)).toEqual(["Google", "Google Analytics", "Google Search Console", "Google Business Profile", "Gmail", "Google Drive", "Google Calendar", "Meta", "Facebook Pages", "Instagram Business", "Facebook Ads", "WhatsApp Business", "Stripe", "PayPal", "Microsoft 365", "Outlook", "OneDrive", "Teams", "Slack", "Telegram", "Discord", "HubSpot", "Salesforce", "Shopify", "WooCommerce", "Zapier", "Make", "Webhooks", "API Keys"]);
    expect(new Set(PROVIDER_CATALOG.map((p) => p.code)).size).toBe(29); expect(ARCHITECTURE_STATUS.oauth).toBe("not_implemented");
  });
});

describe("capabilities and texts", () => {
  it("module access is the outer gate; default capabilities only narrow it", () => {
    expect(CAPABILITIES).toHaveLength(10);
    for (const r of ROLES) { if (!canAccess(r, "integrations")) expect(DEFAULT_CAPABILITIES[r].length, r).toBe(0); else expect(DEFAULT_CAPABILITIES[r].includes("view"), r).toBe(true); }
    expect(DEFAULT_CAPABILITIES.owner).toHaveLength(CAPABILITIES.length);
  });
  it("English and Spanish have the same keys, and every vocabulary used by the UI has texts", () => {
    const en = INTEGRATIONS_DICTIONARIES.en as Record<string, string>, es = INTEGRATIONS_DICTIONARIES.es as Record<string, string>;
    expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort());
    const groups: [string, readonly string[]][] = [["cat", CATEGORIES], ["es", EVENT_STATUS], ["hs", HISTORY_STATUS], ["ent", SYNC_ENTITIES], ["fq", SYNC_FREQUENCIES], ["tf", TRANSFORMS], ["topic", AI_TOPICS], ["cap", CAPABILITIES], ["role", ROLES], ["err", Object.keys(ERROR_HELP)], ["nk", []]];
    for (const [p, list] of groups) for (const k of list) expect(en[`${p}.${k}`], `${p}.${k}`).toBeDefined();
    void NOTIFICATION_KINDS;
    for (const [k, v] of Object.entries(es)) expect(v.trim(), k).not.toBe("");
  });
});
