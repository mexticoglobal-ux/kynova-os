import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES, canAccess } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { COLUMNS, TABLE } from "../../../src/modules/analytics-bi/columns";
import { ANALYTICS_BI_DICTIONARIES } from "../../../src/modules/analytics-bi/i18n";
import { ARCHITECTURE_STATUS } from "../../../src/modules/analytics-bi/contracts";
import { AI_TOPICS, CAPABILITIES, DASHBOARD_CATALOG, DEFAULT_CAPABILITIES, DATASET_CATALOG, EXPORT_FORMATS, EXPORT_SOURCES, FORECAST_METHODS, FREQUENCIES, GOAL_STATUS, METRIC_CATALOG, PREDICTION_KINDS, WIDGET_KINDS } from "../../../src/modules/analytics-bi/domain";
import { ANALYTICS_BI_BLUEPRINT } from "../../../src/modules/analytics-bi/employee";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => { try { return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; }); } catch { return []; } };
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "analytics-bi");
const bad = (dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "analytics-bi"), join(SRC, "app", "(app)", "app", "analytics-bi")];
const strip = (s: string) => s.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");

describe("Mission Control module boundaries", () => {
  it("never touches Drizzle, database internals, kernel internals or other product modules", () => {
    expect(bad([MOD], /drizzle-orm|platform\/db|ai-kernel\/|ai-employees\/|platform\/dashboard|components\/dashboard|modules\/(marketing|seo|ai-studio|finance|communications|crm|billing|security|analytics(?!-bi)|mission-control)/)).toEqual([]);
  });
  it("only the store layer knows SQL; no provider host and no network call exist in the module", () => {
    expect(files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f))).toEqual(["store-d1.ts"]);
    expect(files(MOD).filter((f) => /api\.openai\.com|api\.anthropic\.com|smtp\.|sendgrid|mailgun|googleapis\.com|api\.stripe\.com/.test(readFileSync(f, "utf8")))).toEqual([]);
    expect(files(MOD).filter((f) => /(?<![.\w])fetch\(|XMLHttpRequest|new WebSocket|node:https?|node:net/.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
  });
  it("states plainly what it does not do", () => {
    expect(Object.values(ARCHITECTURE_STATUS).length).toBeGreaterThan(0);
  });
  it("UI uses the module's public interface only", () => {
    expect(bad(UI, /platform\/db|drizzle|modules\/analytics-bi\/(store|columns|runtime|ai|server)|modules\/(crm|marketing|seo|finance|ai-studio|communications|billing|security|analytics(?!-bi)|mission-control)|components\/(crm|marketing|seo|finance|ai-studio|communications|billing|security|analytics(?!-bi)|mission-control)/)).toEqual([]);
  });
  it("frozen code does not know Mission Control; it joins through startup registration only", () => {
    const frozen = ["platform/db", "platform/auth", "platform/ai-kernel", "platform/ai-employees", "platform/dashboard", "modules/crm", "modules/marketing", "modules/seo", "modules/ai-studio", "modules/finance", "modules/communications", "modules/billing", "modules/security", "modules/analytics", "modules/mission-control"].map((d) => join(SRC, d));
    expect(bad(frozen, /modules\/analytics-bi|components\/analytics-bi/)).toEqual([]);
    const ins = readFileSync(join(SRC, "instrumentation.ts"), "utf8"); expect(ins).toContain("registerAnalyticsBiWidget"); expect(ins).toContain("registerAnalyticsBiEmployee");
  });
  it("registers exactly one widget: analytics-bi-overview (analytics-overview is Sprint 14's)", () => {
    const w = readFileSync(join(SRC, "components", "analytics-bi", "DashboardWidget.tsx"), "utf8");
    expect([...w.matchAll(/registerWidget</g)]).toHaveLength(1); expect(w).toContain('id: "analytics-bi-overview"');
  });
  it("client components do not import server-only parts", () => {
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThanOrEqual(5);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/analytics-bi$|modules\/analytics-bi\/(service|server|http|store|runtime|ai)/.test(i)))).toEqual([]);
  });
  it("adds exactly one product module slug, open to staff", () => {
    expect(MODULES).toHaveLength(25); expect(MODULES.filter((m) => m.slug === "analytics-bi")).toHaveLength(1);
    expect(readFileSync(join(MOD, "http.ts"), "utf8")).toContain('ANALYTICS_BI_SLUG = "analytics-bi"');
    expect(canAccess("owner", "analytics-bi")).toBe(true); expect(canAccess("employee", "analytics-bi")).toBe(true); expect(canAccess("guest", "analytics-bi")).toBe(false);
  });
  it("the Mission Control Advisor never executes actions: its blueprint is read only", () => {
    expect(ANALYTICS_BI_BLUEPRINT.maxAutonomy).toBe(1); expect(ANALYTICS_BI_BLUEPRINT.defaultInstructions).toMatch(/never execute/i);
    expect(ANALYTICS_BI_BLUEPRINT.name).toBe("Analytics Advisor AI"); expect(AI_TOPICS).toHaveLength(4);
    expect(DEFAULT_CAPABILITIES.guest).toHaveLength(0);
    for (const c of ANALYTICS_BI_BLUEPRINT.capabilities) expect(c).toMatch(/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/);
    expect(ANALYTICS_BI_BLUEPRINT.key).toMatch(/^[a-z][a-z0-9_]*$/);
  });
});

describe("API surface: only /api/v1/analytics-bi/*", () => {
  const API = join(SRC, "app", "api", "v1", "analytics-bi");
  const routes = files(API).filter((f) => f.endsWith("route.ts"));
  it("every handler goes through analyticsBiRoute; every mutating verb enables CSRF checks", () => {
    expect(routes.length).toBeGreaterThanOrEqual(40);
    for (const f of routes) {
      const src = readFileSync(f, "utf8");
      for (const m of src.matchAll(/export const (GET|POST|PATCH|PUT|DELETE) = (\w+)/g)) {
        expect(m[2], `${relative(SRC, f)} ${m[1]}`).toBe("analyticsBiRoute");
        const decl = src.slice(src.indexOf(m[0])), next = decl.indexOf("\nexport const", 10), block = decl.slice(0, next === -1 ? decl.length : next);
        if (m[1] !== "GET") expect(block, `${relative(SRC, f)} ${m[1]}`).toContain("mutating: true"); else expect(block).not.toContain("mutating");
      }
    }
  });
  it("there is no public inbound endpoint and no outbound call", () => {
    expect(routes.filter((f) => !readFileSync(f, "utf8").includes("analyticsBiRoute"))).toEqual([]);
    expect(routes.filter((f) => /fetch\(/.test(readFileSync(f, "utf8")))).toEqual([]);
  });
  it("covers every section and action", () => {
    const rel = new Set(routes.map((f) => relative(API, f).replace(/\/?route\.ts$/, "")));
    for (const p of ["setup", "summary", "permissions/mine", "dashboards", "dashboards/[id]/view", "dashboards/[id]/widgets", "widgets/[id]", "datasets", "dimensions", "filters", "metrics", "metrics/[id]/record", "segments", "segments/[id]/evaluate", "reports", "reports/[id]/run", "saved-reports", "snapshots", "goals", "goals/evaluate", "forecasts", "predictions", "exports", "exports/[id]/download", "scheduled-reports", "scheduled-reports/run-due", "settings", "ai/[id]"]) expect(rel.has(p), p).toBe(true);
  });
});

describe("pages", () => {
  it("has the 14 views", () => {
    const base = join(SRC, "app", "(app)", "app", "analytics-bi"), pages = new Set(files(base).filter((f) => f.endsWith("page.tsx")).map((f) => relative(base, f).replace(/\/?page\.tsx$/, "")));
    expect([...pages].sort()).toEqual(["", "datasets", "exports", "filters", "forecasts", "goals", "metrics", "metrics/[code]", "predictions", "reports", "reports/[id]", "scheduled", "segments", "settings", "snapshots", "widgets"]);
  });
});

describe("migration 1000_analytics.sql", () => {
  const sql = readFileSync(join(process.cwd(), "drizzle/migrations/1000_analytics.sql"), "utf8");
  const tables = [...sql.matchAll(/CREATE TABLE `(an_\w+)` \(([\s\S]*?)\n\);/g)];
  it("creates exactly the 16 an_* tables and touches nothing else", () => {
    expect(tables).toHaveLength(16);
    expect(Object.values(TABLE).sort()).toEqual(tables.map((t) => t[1]).sort());
    for (const n of ["dashboards", "widgets", "datasets", "metrics", "dimensions", "reports", "saved_reports", "filters", "segments", "goals", "forecasts", "predictions", "exports", "scheduled_reports", "snapshots", "settings"]) expect(Object.values(TABLE)).toContain(`an_${n}`);
    expect(sql.replace(/^--.*$/gm, "")).not.toMatch(/ALTER TABLE|DROP TABLE|DROP INDEX|INSERT INTO|DELETE FROM/);
    for (const o of sql.matchAll(/CREATE (?:UNIQUE )?INDEX `(\w+)`/g)) expect(o[1]).toMatch(/^an_/);
    for (const o of sql.matchAll(/CREATE TRIGGER (\w+)/g)) expect(o[1]).toMatch(/^an_/);
  });
  it("every table is tenant-owned with cascade and tenant-first indexes", () => {
    for (const [, name, body] of tables) {
      expect(body, name).toContain("`tenant_id` text NOT NULL");
      expect(body, name).toContain("FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`)");
      for (const ix of sql.matchAll(new RegExp(`CREATE (?:UNIQUE )?INDEX \`\\w+\` ON \`${name}\` \\(([^)]*)\\)`, "g"))) expect(ix[1], name).toMatch(/^`tenant_id`/);
    }
  });
  it("the database enforces tenant freezing and immutable results", () => {
    for (const t of Object.values(TABLE)) expect(sql, t).toContain(`${t}_tenant_frozen`);
    for (const t of ["saved_reports", "forecasts", "predictions", "exports", "snapshots"]) { expect(sql).toContain(`an_${t}_immutable`); expect(sql).toContain(`an_${t}_no_delete`); }
  });
  it("whitelists cover each kind and carry the tenant column", () => {
    for (const k of Object.keys(TABLE) as (keyof typeof TABLE)[]) { expect(COLUMNS[k]).toContain("id"); expect(COLUMNS[k]).toContain("tenantId"); }
  });
});

describe("catalog, capabilities and texts", () => {
  it("the catalog covers the specified sections", () => {
    expect(METRIC_CATALOG).toHaveLength(10); expect(DATASET_CATALOG).toHaveLength(1); expect(DASHBOARD_CATALOG).toHaveLength(1); expect(WIDGET_KINDS).toHaveLength(9); expect(CAPABILITIES).toHaveLength(10);
    expect(EXPORT_FORMATS).toEqual(["csv", "json"]);
  });
  it("module access is the outer gate; default capabilities only narrow it", () => {
    for (const r of ROLES) { if (!canAccess(r, "analytics-bi")) expect(DEFAULT_CAPABILITIES[r].length, r).toBe(0); else expect(DEFAULT_CAPABILITIES[r].includes("view"), r).toBe(true); }
    expect(DEFAULT_CAPABILITIES.owner).toHaveLength(CAPABILITIES.length);
  });
  it("English and Spanish have the same keys, and every vocabulary used by the UI has texts", () => {
    const en = ANALYTICS_BI_DICTIONARIES.en as Record<string, string>, es = ANALYTICS_BI_DICTIONARIES.es as Record<string, string>;
    expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort());
    const groups: [string, readonly string[]][] = [["wk", WIDGET_KINDS], ["topic", AI_TOPICS], ["fm", FORECAST_METHODS], ["pk", PREDICTION_KINDS], ["gs", GOAL_STATUS], ["fq", FREQUENCIES], ["es", EXPORT_SOURCES], ["cap", CAPABILITIES], ["role", ROLES], ["metric", METRIC_CATALOG.map((m) => m.code)], ["dashname", DASHBOARD_CATALOG.map((d) => d.code)], ["dataset", DATASET_CATALOG.map((d) => d.code)]];
    for (const [p, list] of groups) for (const k of list) expect(en[`${p}.${k}`], `${p}.${k}`).toBeDefined();
    for (const [k, v] of Object.entries(es)) expect(v.trim(), k).not.toBe("");
  });
});
