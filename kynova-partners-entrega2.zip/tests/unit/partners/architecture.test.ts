import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES, canAccess } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { COLUMNS, TABLE } from "../../../src/modules/partners/columns";
import { PARTNERS_DICTIONARIES } from "../../../src/modules/partners/i18n";
import { ARCHITECTURE_STATUS } from "../../../src/modules/partners/contracts";
import { CAPABILITIES, DEFAULT_CAPABILITIES } from "../../../src/modules/partners/domain";
import { PARTNERS_BLUEPRINT } from "../../../src/modules/partners/employee";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => { try { return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; }); } catch { return []; } };
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "partners");
const bad = (dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "partners"), join(SRC, "app", "(app)", "app", "partners")];
const strip = (s: string) => s.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");
const OTHERS = "crm|marketing|seo|ai-studio|finance|communications|billing|security|analytics|analytics-bi|mission-control|integrations|marketplace";

describe("Partners module boundaries", () => {
  it("never touches Drizzle, database internals, kernel internals or other product modules; the Activity Engine only through its public index", () => {
    expect(bad([MOD], new RegExp(`drizzle-orm|platform/db|ai-kernel/|ai-employees/|platform/dashboard|components/dashboard|modules/(${OTHERS})`))).toEqual([]);
    expect(bad([MOD, ...UI], /platform\/activity\/(?!$)/)).toEqual([]);
  });
  it("only the store layer knows SQL; no payment host and no network call exist", () => {
    expect(files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f))).toEqual(["store-d1.ts"]);
    expect(files(MOD).filter((f) => /api\.stripe|api\.paypal|paypal\.com\/v|wise\.com|checkout\.stripe|docusign|maka/i.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
    expect(files(MOD).filter((f) => /(?<![.\w])fetch\(|XMLHttpRequest|new WebSocket|node:https?|node:net/.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
  });
  it("states plainly what it does not do", () => {
    expect(ARCHITECTURE_STATUS).toMatchObject({ payouts: "simulated_only", payout_provider: "not_connected", partner_portal: "not_built", e_signature: "not_connected", invitation_delivery: "not_connected", cross_company_linking: "not_implemented", renewal_scheduler: "not_implemented", ai_actions: "never_executed" });
  });
  it("UI uses the module's public interface only", () => {
    expect(bad(UI, new RegExp(`platform/db|drizzle|modules/partners/(store|columns|runtime|ai|server)|modules/(${OTHERS})|components/(${OTHERS})`))).toEqual([]);
  });
  it("frozen code does not know Partners; it joins through startup registration only", () => {
    const frozen = ["platform/db", "platform/auth", "platform/ai-kernel", "platform/ai-employees", "platform/dashboard", "platform/activity", ...OTHERS.split("|").map((m) => `modules/${m}`)].map((d) => join(SRC, d));
    expect(bad(frozen, /modules\/partners|components\/partners/)).toEqual([]);
    const ins = readFileSync(join(SRC, "instrumentation.ts"), "utf8");
    for (const s of ["registerPartnersWidget", "registerPartnersEmployee", "registerPartnersReverters"]) expect(ins).toContain(s);
  });
  it("registers exactly one widget and keeps client components free of server-only imports", () => {
    const w = readFileSync(join(SRC, "components", "partners", "DashboardWidget.tsx"), "utf8");
    expect([...w.matchAll(/registerWidget</g)]).toHaveLength(1); expect(w).toContain('id: "partners-overview"');
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThanOrEqual(3);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/partners$|modules\/partners\/(service|server|http|store|runtime|ai)/.test(i)))).toEqual([]);
  });
  it("is a module slug open to executives, sales, marketing and finance only", () => {
    expect(MODULES.filter((m) => m.slug === "partners")).toHaveLength(1); expect(readFileSync(join(MOD, "http.ts"), "utf8")).toContain('"partners"');
    expect(canAccess("owner", "partners")).toBe(true); expect(canAccess("finance", "partners")).toBe(true); expect(canAccess("employee", "partners")).toBe(false); expect(canAccess("guest", "partners")).toBe(false);
  });
  it("the Partner Manager only recommends: its blueprint is read only", () => {
    expect(PARTNERS_BLUEPRINT.maxAutonomy).toBe(1); expect(PARTNERS_BLUEPRINT.key).toMatch(/^[a-z][a-z0-9_]*$/);
    for (const c of PARTNERS_BLUEPRINT.capabilities) expect(c).toMatch(/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/);
  });
});

describe("API surface: only /api/v1/partners/*", () => {
  const API = join(SRC, "app", "api", "v1", "partners");
  const routes = files(API).filter((f) => f.endsWith("route.ts"));
  it("every handler goes through partnersRoute; every mutating verb enables CSRF checks", () => {
    expect(routes.length).toBeGreaterThanOrEqual(40);
    for (const f of routes) {
      const src = readFileSync(f, "utf8");
      for (const m of src.matchAll(/export const (GET|POST|PATCH|PUT|DELETE) = (\w+)/g)) {
        expect(m[2], `${relative(SRC, f)} ${m[1]}`).toBe("partnersRoute");
        const decl = src.slice(src.indexOf(m[0])), next = decl.indexOf("\nexport const", 10), block = decl.slice(0, next === -1 ? decl.length : next);
        if (m[1] !== "GET") expect(block, `${relative(SRC, f)} ${m[1]}`).toContain("mutating: true"); else expect(block).not.toContain("mutating");
      }
    }
  });
  it("has no webhook, payment-provider or outbound endpoint", () => {
    expect(routes.filter((f) => /fetch\(/.test(readFileSync(f, "utf8")))).toEqual([]);
    expect(routes.map((f) => relative(API, f)).filter((r) => /webhook|stripe|paypal|wise|docusign/i.test(r))).toEqual([]);
  });
});

describe("pages", () => {
  it("has the 11 views plus the partner detail", () => {
    const base = join(SRC, "app", "(app)", "app", "partners"), pages = new Set(files(base).filter((f) => f.endsWith("page.tsx")).map((f) => relative(base, f).replace(/\/?page\.tsx$/, "")));
    expect([...pages].sort()).toEqual(["", "agreements", "clients", "commissions", "deals", "invitations", "notifications", "partners", "partners/[id]", "payouts", "settings", "tiers"]);
  });
});

describe("migration 1400_partners.sql", () => {
  const sql = readFileSync(join(process.cwd(), "drizzle/migrations/1400_partners.sql"), "utf8");
  const tables = [...sql.matchAll(/CREATE TABLE `(pt_\w+)` \(([\s\S]*?)\n\);/g)];
  it("creates exactly the 10 pt_* tables and touches nothing else", () => {
    expect(tables).toHaveLength(10); expect(Object.values(TABLE).sort()).toEqual(tables.map((t) => t[1]).sort());
    expect(sql.replace(/^--.*$/gm, "")).not.toMatch(/ALTER TABLE|DROP TABLE|DROP INDEX|INSERT INTO|DELETE FROM/);
    for (const o of sql.matchAll(/CREATE (?:UNIQUE )?INDEX `(\w+)`/g)) expect(o[1]).toMatch(/^pt_/);
  });
  it("every table is tenant-owned with tenant-first indexes, frozen tenant and no deletes", () => {
    for (const [, name, body] of tables) {
      expect(body, name).toContain("`tenant_id` text NOT NULL"); expect(body, name).toContain("FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`)");
      for (const ix of sql.matchAll(new RegExp(`CREATE (?:UNIQUE )?INDEX \`\\w+\` ON \`${name}\` \\(([^)]*)\\)`, "g"))) expect(ix[1], name).toMatch(/^`tenant_id`/);
      expect(sql, name).toContain(`${name}_tenant_frozen`); expect(sql, name).toContain(`${name}_no_delete`);
    }
  });
  it("the database protects commissions and deals", () => {
    expect(sql).toContain("pt_commissions_frozen"); expect(sql).toMatch(/\(`base_cents` \* `rate_bps` \+ 5000\) \/ 10000|base_cents.*rate_bps.*5000/);
    expect(sql).toMatch(/UNIQUE INDEX[^;]*pt_deals[^;]*client_key[^;]*WHERE/);
  });
  it("whitelists cover each kind and carry the tenant column; the code hash is the only secret", () => {
    for (const k of Object.keys(TABLE) as (keyof typeof TABLE)[]) { expect(COLUMNS[k]).toContain("id"); expect(COLUMNS[k]).toContain("tenantId"); }
    expect(COLUMNS.invitation).not.toContain("code");
  });
});

describe("capabilities and texts", () => {
  it("module access is the outer gate; default capabilities only narrow it", () => {
    for (const r of ROLES) { if (!canAccess(r, "partners")) expect(DEFAULT_CAPABILITIES[r].length, r).toBe(0); else expect(DEFAULT_CAPABILITIES[r].includes("view"), r).toBe(true); }
    expect(DEFAULT_CAPABILITIES.owner).toHaveLength(CAPABILITIES.length);
  });
  it("English and Spanish have the same keys and no empty text", () => {
    const en = PARTNERS_DICTIONARIES.en as Record<string, string>, es = PARTNERS_DICTIONARIES.es as Record<string, string>;
    expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort());
    for (const [k, v] of Object.entries(es)) expect(v.trim(), k).not.toBe("");
  });
});
