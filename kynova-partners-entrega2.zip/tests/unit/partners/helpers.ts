import type { Role } from "@/config/roles";
import { createMemoryPartnersStore } from "../../../src/modules/partners/store-memory";
import type { PartnersStore } from "../../../src/modules/partners/store";
import { createPartnersService, type Actor, type AiFailure, type AiOutcome, type PartnersAi, type PartnersService } from "../../../src/modules/partners/service";
import type { ActivitySink, SinkEvent } from "../../../src/platform/activity";

export const T1 = "tenant-one", T2 = "tenant-two";
export const DAY = 86_400_000;
export const START = Date.UTC(2026, 9, 20, 12);
export const actor = (role: Role, userId: string, tenantId = T1): Actor => ({ tenantId, userId, role });
export const Q = (o: Record<string, unknown> = {}) => ({ limit: 25, ...o }) as never;
export const code = async (p: Promise<unknown>) => { try { await p; return "ok"; } catch (e) { return (e as { code?: string }).code ?? `other:${(e as Error).message}`; } };
export const OWNER = actor("owner", "owner-1"), SALES = actor("sales", "sales-1"), FIN = actor("finance", "fin-1"), EMP = actor("employee", "emp-1"), GUEST = actor("guest", "guest-1"), OTHER = actor("owner", "owner-2", T2);

export function fakeAi(over: { fail?: AiFailure } = {}) {
  const calls = { n: 0 };
  const ai: PartnersAi = { async generate(): Promise<AiOutcome | AiFailure> { calls.n++; if (over.fail) return over.fail; return { ok: true, text: "ok", provider: "mock", model: "mock:1", usage: { inputTokens: 1, outputTokens: 1, costMicros: 3 }, latencyMs: 5, degraded: false }; } };
  return { ai, calls };
}
/** An in-memory sink that keeps what the module records, so tests can see the evidence. */
export function memorySink() {
  const events: SinkEvent[] = [];
  const sink: ActivitySink = {
    async record(_c, e) { events.push(e); return { ok: true, duplicate: false, event: {} as never }; },
    async recordStrict(_c, e) { events.push(e); return { duplicate: false, event: {} as never }; },
  };
  return { sink, events };
}
export interface Harness { svc: PartnersService; clock: { t: number }; store: PartnersStore; events: SinkEvent[]; calls: { n: number } }
export function setup(o: { ai?: PartnersAi; store?: PartnersStore } = {}): Harness {
  const clock = { t: START }, f = fakeAi(), m = memorySink(), salt = crypto.randomUUID().slice(0, 8); let n = 0;
  const store = o.store ?? createMemoryPartnersStore();
  const svc = createPartnersService({ store, newId: () => `id${salt}${String(++n).padStart(6, "0")}`, now: () => clock.t, ai: o.ai ?? f.ai, activity: m.sink });
  return { svc, clock, store, events: m.events, calls: f.calls };
}
export async function ready(h: Harness, a: Actor = OWNER) { await h.svc.setup.initialize(a); return h; }
/** An active partner (created, invited, accepted). */
export async function activePartner(h: Harness, slug: string, a: Actor = OWNER) {
  const p = await h.svc.partners.create(a, { slug, name: `Partner ${slug}`, kind: "agency" });
  const { code: c } = await h.svc.invitations.create(a, { partnerId: p.id, email: `${slug}@example.com` });
  await h.svc.invitations.accept(a, { code: c }); return p;
}
/** An active client with a monthly revenue, for the partner. */
export async function liveClient(h: Harness, partnerId: string, name: string, mrrCents = 100_000, a: Actor = OWNER) {
  return h.svc.clients.create(a, { partnerId, name, status: "active", mrrCents, startedAt: START - 40 * DAY });
}
