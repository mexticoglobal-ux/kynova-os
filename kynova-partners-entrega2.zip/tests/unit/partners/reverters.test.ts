import { describe, expect, it } from "vitest";
import { createActivityService } from "../../../src/platform/activity/service";
import { createMemoryActivityStore } from "../../../src/platform/activity/store-memory";
import { registerPartnersReverters } from "../../../src/modules/partners/reverters";
import { OWNER, Q, START, activePartner, code, liveClient, ready, setup } from "./helpers";

describe("Partners undo through the Activity Engine", () => {
  it("restores a suspended partner, a changed tier and an approved commission, once each", async () => {
    const h = await ready(setup()); registerPartnersReverters(async () => h.svc);
    let n = 0; const act = createActivityService({ store: createMemoryActivityStore(), newId: () => `ev${++n}`, now: () => START });
    const log = (action: string, hint: Record<string, unknown>) => act.record(OWNER, { module: "partners", action, summary: action, reversible: true, revertHint: hint });

    const p = await activePartner(h, "undo"); await h.svc.partners.suspend(OWNER, p.id);
    const e1 = await log("partners.partner.suspended", { partnerId: p.id }); await act.revert(OWNER, e1.event.id);
    expect((await h.svc.partners.get(OWNER, p.id)).partner.status).toBe("active"); expect(await code(act.revert(OWNER, e1.event.id))).not.toBe("ok");

    await h.svc.partners.setTier(OWNER, p.id, { tier: "gold" }); const e2 = await log("partners.partner.tier_changed", { partnerId: p.id, previousTier: "registered" });
    await act.revert(OWNER, e2.event.id); expect((await h.svc.partners.get(OWNER, p.id)).partner.tier).toBe("registered");

    await liveClient(h, p.id, "Undo Client"); await h.svc.commissions.accrue(OWNER, { period: "2026-10" });
    const c = (await h.svc.commissions.list(OWNER, Q())).items[0]!; await h.svc.commissions.approve(OWNER, c.id);
    const e3 = await log("partners.commission.approved", { commissionId: c.id }); await act.revert(OWNER, e3.event.id);
    expect((await h.svc.commissions.get(OWNER, c.id)).status).toBe("accrued");
  });
});
