import { describe, expect, it } from "vitest";
import { clientKey, commissionAmount, evaluateTier, inviteState, newInviteCode, payoutNumber, periodOf, resolveRate } from "../../../src/modules/partners/compute";

describe("partners compute", () => {
  it("rounds commissions half up in integer cents", () => {
    expect(commissionAmount(100_000, 1000)).toBe(10_000); expect(commissionAmount(999, 1500)).toBe(150); expect(commissionAmount(1, 5000)).toBe(1); expect(commissionAmount(0, 2500)).toBe(0);
  });
  it("resolves the rate: active agreement, then tier, then default", () => {
    const tier = { commissionBps: 1500 };
    expect(resolveRate({ agreement: { commissionBps: 3000, status: "active" }, tier, defaultBps: 1000 })).toEqual({ bps: 3000, source: "agreement" });
    expect(resolveRate({ agreement: { commissionBps: 3000, status: "draft" }, tier, defaultBps: 1000 })).toEqual({ bps: 1500, source: "tier" });
    expect(resolveRate({ agreement: null, tier: null, defaultBps: 1000 })).toEqual({ bps: 1000, source: "default" });
  });
  it("evaluates the highest tier whose thresholds are met", () => {
    const t = [{ code: "registered", minActiveClients: 0, minMrrCents: 0 }, { code: "silver", minActiveClients: 3, minMrrCents: 100 }, { code: "gold", minActiveClients: 10, minMrrCents: 1000 }] as never;
    expect(evaluateTier(t, 0, 0)).toBe("registered"); expect(evaluateTier(t, 3, 100)).toBe("silver"); expect(evaluateTier(t, 20, 50)).toBe("registered"); expect(evaluateTier(t, 10, 1000)).toBe("gold");
  });
  it("normalizes client names into a protection key", () => {
    expect(clientKey("  Grupo   ARYA, S.A. ")).toBe(clientKey("grupo arya s.a")); expect(clientKey("Acme")).not.toBe(clientKey("Acme Two"));
  });
  it("builds invitation codes, payout numbers and periods", () => {
    expect(newInviteCode()).toMatch(/^PRT-[A-Z0-9]{5}-[A-Z0-9]{5}$/); expect(newInviteCode()).not.toBe(newInviteCode());
    expect(payoutNumber(Date.UTC(2026, 9, 1), 7)).toBe("PO-2026-0007"); expect(periodOf(Date.UTC(2026, 9, 31))).toBe("2026-10");
    expect(inviteState({ status: "pending", expiresAt: 5 }, 6)).toBe("expired"); expect(inviteState({ status: "pending", expiresAt: 9 }, 6)).toBe("pending");
  });
});
