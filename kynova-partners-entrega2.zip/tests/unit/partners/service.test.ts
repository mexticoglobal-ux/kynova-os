import { describe, expect, it } from "vitest";
import { DAY, EMP, FIN, GUEST, OTHER, OWNER, Q, SALES, activePartner, code, liveClient, ready, setup } from "./helpers";

describe("setup and access", () => {
  it("sets up once with the four tiers and refuses a second run", async () => {
    const h = setup(); expect((await h.svc.setup.status(OWNER)).initialized).toBe(false); await h.svc.setup.initialize(OWNER);
    expect((await h.svc.tiers.list(OWNER)).items.map((t) => t.code)).toEqual(["registered", "silver", "gold", "platinum"]);
    expect(await code(h.svc.setup.initialize(OWNER))).toBe("invalid_state");
  });
  it("roles without capability are refused; tenants never see each other", async () => {
    const h = await ready(setup());
    expect(await code(h.svc.partners.create(SALES, { slug: "x1", name: "X One", kind: "agency" }))).toBe("forbidden"); expect(await code(h.svc.deals.register(SALES, { partnerId: "none", clientName: "Zed" }))).toBe("not_found");
    expect(await code(h.svc.partners.create(GUEST, { slug: "x2", name: "X Two", kind: "agency" }))).toBe("forbidden");
    expect(await code(h.svc.commissions.list(EMP, Q()))).toBe("forbidden");
    expect((await h.svc.partners.list(OTHER, Q())).items).toEqual([]);
  });
  it("rejects a bad body with validation_failed", async () => {
    const h = await ready(setup()); expect(await code(h.svc.partners.create(OWNER, { slug: "A B", name: "", kind: "nope" }))).toBe("validation_failed");
  });
});

describe("invitations", () => {
  it("shows the code once, stores only a hash, and activates the partner on acceptance", async () => {
    const h = await ready(setup()), p = await h.svc.partners.create(OWNER, { slug: "acme", name: "Acme Agency", kind: "agency" });
    const r = await h.svc.invitations.create(OWNER, { partnerId: p.id, email: "a@acme.test" });
    expect(r.code).toMatch(/^PRT-/); expect(JSON.stringify(r.invitation)).not.toContain(r.code); expect(r.invitation.codeHash).not.toBe(r.code); expect(r.invitation.codeHint).toBe(r.code.slice(-4));
    expect((await h.svc.partners.get(OWNER, p.id)).partner.status).toBe("invited");
    const ok = await h.svc.invitations.accept(OWNER, { code: r.code.toLowerCase() }); expect(ok.partner.status).toBe("active");
    expect(await code(h.svc.invitations.accept(OWNER, { code: r.code }))).toBe("invalid_state");
  });
  it("expires after 14 days and a new invitation revokes the previous one", async () => {
    const h = await ready(setup()), p = await h.svc.partners.create(OWNER, { slug: "late", name: "Late Co", kind: "reseller" });
    const a = await h.svc.invitations.create(OWNER, { partnerId: p.id, email: "l@late.test" }), b = await h.svc.invitations.create(OWNER, { partnerId: p.id, email: "l@late.test" });
    expect(await code(h.svc.invitations.accept(OWNER, { code: a.code }))).toBe("invalid_state");
    h.clock.t += 15 * DAY; expect(await code(h.svc.invitations.accept(OWNER, { code: b.code }))).toBe("invalid_state");
  });
});

describe("agreements, clients and deals", () => {
  it("a new active agreement replaces the previous one; a draft needs an active partner", async () => {
    const h = await ready(setup()), p = await activePartner(h, "ag");
    const a1 = await h.svc.agreements.create(OWNER, { partnerId: p.id, label: "Std", commissionBps: 2000 }), a2 = await h.svc.agreements.create(OWNER, { partnerId: p.id, label: "Plus", commissionBps: 3000 });
    await h.svc.agreements.activate(OWNER, a1.id, { signedBy: "Ana" }); await h.svc.agreements.activate(OWNER, a2.id, { signedBy: "Ana" });
    const items = (await h.svc.agreements.list(OWNER, Q({ partnerId: p.id }))).items; expect(items.filter((x) => x.status === "active").map((x) => x.id)).toEqual([a2.id]); expect(items.find((x) => x.id === a1.id)!.status).toBe("ended");
  });
  it("a registered deal protects the client from other partners until it expires", async () => {
    const h = await ready(setup()), p1 = await activePartner(h, "p-one"), p2 = await activePartner(h, "p-two");
    await h.svc.deals.register(OWNER, { partnerId: p1.id, clientName: "Grupo Arya" });
    expect(await code(h.svc.deals.register(OWNER, { partnerId: p2.id, clientName: "  grupo   ARYA " }))).toBe("invalid_state");
    h.clock.t += 91 * DAY; expect(await code(h.svc.deals.register(OWNER, { partnerId: p2.id, clientName: "Grupo Arya" }))).toBe("ok");
    expect((await h.svc.deals.list(OWNER, Q({ partnerId: p1.id }))).items[0]!.stage).toBe("lost");
  });
  it("winning a deal creates the client as a lead and refuses a second win", async () => {
    const h = await ready(setup()), p = await activePartner(h, "win"), d = await h.svc.deals.register(OWNER, { partnerId: p.id, clientName: "Nueva SA", valueCents: 5000 });
    await h.svc.deals.qualify(OWNER, d.id); const w = await h.svc.deals.win(OWNER, d.id); expect(w.deal.stage).toBe("won");
    expect((await h.svc.clients.list(OWNER, Q({ partnerId: p.id }))).items.map((c) => c.status)).toEqual(["lead"]);
    expect(await code(h.svc.deals.win(OWNER, d.id))).toBe("invalid_state");
  });
});

describe("commissions and payouts", () => {
  it("accrues once per client and period using agreement > tier > default, and is idempotent", async () => {
    const h = await ready(setup()), p = await activePartner(h, "com"); await liveClient(h, p.id, "Cliente Uno", 100_000);
    const r1 = await h.svc.commissions.accrue(OWNER, { period: "2026-10" }), r2 = await h.svc.commissions.accrue(OWNER, { period: "2026-10" });
    expect([r1.created, r2.created]).toEqual([1, 0]);
    const c = (await h.svc.commissions.list(OWNER, Q())).items[0]!; expect([c.rateBps, c.amountCents, c.rateSource]).toEqual([1000, 10_000, "tier"]);
    expect(await code(h.svc.commissions.accrue(OWNER, { period: "2027-01" }))).toBe("validation_failed");
  });
  it("approve → payout → pay is simulated and moves no money; reversal is blocked once paid", async () => {
    const h = await ready(setup()), p = await activePartner(h, "pay"); await liveClient(h, p.id, "Cliente Dos", 50_000);
    await h.svc.commissions.accrue(OWNER, { period: "2026-10" }); const c = (await h.svc.commissions.list(OWNER, Q())).items[0]!;
    expect(await code(h.svc.payouts.create(OWNER, { partnerId: p.id }))).toBe("invalid_state");
    await h.svc.commissions.approve(OWNER, c.id); const po = await h.svc.payouts.create(OWNER, { partnerId: p.id });
    expect([po.mode, po.status, po.totalCents]).toEqual(["not_connected", "draft", c.amountCents]);
    const paid = await h.svc.payouts.pay(OWNER, po.id); expect([paid.status, paid.mode]).toEqual(["paid", "simulated"]);
    expect((await h.svc.commissions.get(OWNER, c.id)).status).toBe("paid"); expect(await code(h.svc.commissions.reverse(OWNER, c.id))).toBe("invalid_state");
  });
  it("finance can approve; sales cannot see commissions", async () => {
    const h = await ready(setup()), p = await activePartner(h, "fin"); await liveClient(h, p.id, "Cliente Tres");
    await h.svc.commissions.accrue(FIN, { period: "2026-10" }); expect(await code(h.svc.commissions.list(SALES, Q()))).toBe("forbidden");
  });
});

describe("tiers, notifications and AI", () => {
  it("evaluates tiers read-only until applied, with an audit trail in notifications", async () => {
    const h = await ready(setup()), p = await activePartner(h, "tier");
    for (let i = 0; i < 3; i++) await liveClient(h, p.id, `C${i} Corp`, 200_000);
    const before = (await h.svc.tiers.evaluate(OWNER)).items; expect(before.length).toBeGreaterThan(0);
    expect((await h.svc.partners.get(OWNER, p.id)).partner.tier).toBe("registered");
    await h.svc.tiers.apply(OWNER); expect((await h.svc.partners.get(OWNER, p.id)).partner.tier).not.toBe("registered");
  });
  it("the advisor reports an unavailable AI honestly and never writes", async () => {
    const h = await ready(setup({ ai: { async generate() { return { ok: false, code: "unavailable", message: "down" } as never; } } }));
    const r = await h.svc.ai.run(OWNER, "summarize_program", {}); expect(r.ok).toBe(false);
  });
});

describe("activity evidence", () => {
  it("every important mutation leaves an event, and the module works with no sink", async () => {
    const h = await ready(setup()), p = await activePartner(h, "evi"); await h.svc.partners.suspend(OWNER, p.id);
    const actions = h.events.map((e) => e.action);
    expect(actions).toEqual(expect.arrayContaining(["partners.program.initialized", "partners.partner.created", "partners.invitation.created", "partners.invitation.accepted", "partners.partner.suspended"]));
    expect(JSON.stringify(h.events)).not.toMatch(/PRT-[A-Z0-9]{5}-[A-Z0-9]{5}/);
  });
});
