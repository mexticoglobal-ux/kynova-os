import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES, canAccess } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { COLUMNS, TABLE } from "../../../src/modules/finance/columns";
import { POLICIES, can, mayApprove } from "../../../src/modules/finance/access";
import { FINANCE_DICTIONARIES } from "../../../src/modules/finance/i18n";
import { fromWire, queryObject, toWire } from "../../../src/modules/finance/wire";
import { ACCOUNT_TYPE_KEYS, CASH_FLOW_CLASSES, EXPENSE_STATUS, INVOICE_STATUS, PAYMENT_METHODS, TAX_KINDS, toBase } from "../../../src/modules/finance/domain";
import { FINANCE_BLUEPRINT, FINANCE_CAPABILITIES, FINANCE_ROLES } from "../../../src/modules/finance/employee";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => { try { return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; }); } catch { return []; } };
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "finance");
const bad = (dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "finance"), join(SRC, "app", "(app)", "app", "finance")];
const strip = (s: string) => s.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");

describe("Finance module boundaries (docs/05 section 3)", () => {
  it("never touches Drizzle, the database internals, the kernel/employee internals, the dashboard or other product modules", () => {
    expect(bad([MOD], /drizzle-orm|platform\/db|ai-kernel\/|ai-employees\/|platform\/dashboard|components\/dashboard|modules\/(crm|marketing|seo|ai-studio)/)).toEqual([]);
  });
  it("reaches the platform only through public entry points", () => {
    const platform = new Set(files(MOD).flatMap((f) => imports(f).filter((i) => i.startsWith("@/platform"))));
    expect([...platform].filter((p) => !["@/platform/ai-kernel", "@/platform/ai-employees", "@/platform/auth/errors", "@/platform/auth/http", "@/platform/auth/session"].includes(p))).toEqual([]);
  });
  it("only the store layer knows SQL; no provider host appears; no code in the module performs network calls", () => {
    const sqlFiles = files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f));
    expect(sqlFiles).toEqual(["store-d1.ts"]);
    expect(files(MOD).filter((f) => /api\.openai\.com|api\.anthropic\.com|generativelanguage\.googleapis\.com/.test(readFileSync(f, "utf8")))).toEqual([]);
    expect(files(MOD).filter((f) => /(?<![.\w])fetch\(|XMLHttpRequest|new WebSocket|node:https?|node:net/.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
  });
  it("every model call goes through the AI Kernel", () => {
    const users = files(MOD).filter((f) => /getAiKernel\(/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f));
    expect(users).toEqual(["ai.ts"]);
  });
  it("UI uses the module's public interface, never its stores or other product modules", () => {
    expect(bad(UI, /platform\/db|drizzle|modules\/finance\/(store|columns|runtime|ai)|modules\/(crm|marketing|seo|ai-studio)|components\/(crm|marketing|seo|ai-studio)/)).toEqual([]);
  });
  it("platform, CRM, Marketing, SEO, AI Studio, Dashboard and Landing code do not know Finance (it joins through startup registration only)", () => {
    const frozen = ["platform/db", "platform/auth", "platform/ai-kernel", "platform/ai-employees", "platform/dashboard", "modules/crm", "modules/marketing", "modules/seo", "modules/ai-studio", "components/dashboard", "components/crm", "components/marketing", "components/seo", "components/ai-studio"].map((d) => join(SRC, d));
    expect(bad(frozen, /modules\/finance|components\/finance/)).toEqual([]);
    const startup = readFileSync(join(SRC, "instrumentation.ts"), "utf8");
    expect(startup).toContain("registerFinanceEmployee"); expect(startup).toContain("registerFinanceWidget"); expect(startup).toContain("registerSeoWidget"); expect(startup).toContain("registerStudioWidget");
  });
  it("client components do not import server-only parts of the module", () => {
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThanOrEqual(8);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/finance$|modules\/finance\/(service|server|http|store|runtime|ai)/.test(i)))).toEqual([]);
  });
  it("does not add a product module: Finance uses the existing slug and roles", () => {
    expect(MODULES).toHaveLength(25);
    expect(MODULES.filter((m) => m.slug === "finance")).toHaveLength(1);
    expect(readFileSync(join(MOD, "http.ts"), "utf8")).toContain('FINANCE_SLUG = "finance"');
  });
});

describe("API surface: only /api/v1/finance/*", () => {
  const API = join(SRC, "app", "api", "v1", "finance");
  const routes = files(API).filter((f) => f.endsWith("route.ts"));
  it("every handler goes through financeRoute; every mutating verb enables CSRF checks", () => {
    expect(routes.length).toBeGreaterThanOrEqual(50);
    for (const f of routes) {
      const src = readFileSync(f, "utf8");
      for (const m of src.matchAll(/export const (GET|POST|PATCH|PUT|DELETE) = (\w+)/g)) {
        expect(m[2], `${relative(SRC, f)} ${m[1]}`).toBe("financeRoute");
        const decl = src.slice(src.indexOf(m[0])), next = decl.indexOf("\nexport const", 10), block = decl.slice(0, next === -1 ? decl.length : next);
        if (m[1] !== "GET") expect(block, `${relative(SRC, f)} ${m[1]}`).toContain("mutating: true"); else expect(block).not.toContain("mutating");
      }
    }
  });
  it("is the only API this module adds", () => {
    expect(files(join(SRC, "app", "api")).filter((f) => /modules\/finance/.test(readFileSync(f, "utf8"))).filter((f) => !f.startsWith(API))).toEqual([]);
  });
});

describe("migration 0500_finance.sql", () => {
  const sql = readFileSync(join(process.cwd(), "drizzle/migrations/0500_finance.sql"), "utf8");
  const tables = [...sql.matchAll(/CREATE TABLE `(fin_\w+)` \(([\s\S]*?)\n\);/g)];
  it("is independent: it only creates fin_* objects and touches nothing else", () => {
    expect(tables).toHaveLength(18);
    expect(Object.values(TABLE).sort()).toEqual(tables.map((t) => t[1]).sort());
    expect(sql).not.toMatch(/ALTER TABLE|DROP |ais_|seo_|mkt_|crm_|INSERT INTO|DELETE FROM/);
    for (const o of sql.matchAll(/CREATE (?:UNIQUE )?INDEX `(\w+)`/g)) expect(o[1]).toMatch(/^fin_/);
    for (const o of sql.matchAll(/CREATE TRIGGER (\w+)/g)) expect(o[1]).toMatch(/^fin_/);
  });
  it("every table is tenant-owned with cascade and tenant-first indexes", () => {
    for (const [, name, body] of tables) {
      expect(body, name).toContain("`tenant_id` text NOT NULL");
      expect(body, name).toContain("FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`)");
      for (const ix of sql.matchAll(new RegExp(`CREATE (?:UNIQUE )?INDEX \`\\w+\` ON \`${name}\` \\(([^)]*)\\)`, "g"))) expect(ix[1], name).toMatch(/^`tenant_id`/);
    }
  });
  it("the ledger is immutable, audit is append-only, closed periods and tenants are enforced by the database", () => {
    for (const t of ["fin_activity_append_only", "fin_journal_lines_immutable", "fin_journal_lines_period_open", "fin_journal_entries_posted_immutable", "fin_payments_immutable"]) expect(sql).toContain(t);
    for (const t of Object.values(TABLE)) expect(sql, t).toContain(`${t.replace(/s$/, "")}`.slice(0, 4));
    for (const t of Object.values(TABLE).map((x) => x.replace(/^fin_/, ""))) expect(sql, t).toContain(`fin_${t}_tenant_frozen`);
    expect(sql).toMatch(/WHERE `deleted_at` IS NULL/);
  });
  it("whitelists cover each kind and carry the tenant column", () => {
    for (const k of Object.keys(TABLE) as (keyof typeof TABLE)[]) { expect(COLUMNS[k]).toContain("id"); expect(COLUMNS[k]).toContain("tenantId"); }
  });
});

describe("permissions", () => {
  it("module access is the outer gate; the policy table only narrows it", () => {
    for (const r of ROLES) {
      const levels = Object.values(POLICIES[r].levels);
      if (!canAccess(r, "finance")) expect(levels.every((l) => l === "none"), r).toBe(true);
      else expect(levels.some((l) => l !== "none"), r).toBe(true);
    }
    expect(can("finance", "journal", "manage")).toBe(true); expect(can("ceo", "journal", "write")).toBe(false); expect(can("ceo", "report", "read")).toBe(true);
    expect(can("sales", "invoice", "read")).toBe(false); expect(can("guest", "report", "read")).toBe(false);
  });
  it("four-eyes approval rule", () => {
    expect(mayApprove("finance", "expense", "u1", "u1")).toBe(false); expect(mayApprove("finance", "expense", "u1", "u2")).toBe(true);
    expect(mayApprove("owner", "budget", "u1", "u1")).toBe(true); expect(mayApprove("sales", "expense", "u1", "u2")).toBe(false);
  });
});

describe("the Finance Analyst is an ordinary AI Employee", () => {
  it("has the eight required capabilities plus a summary read, never above 'draft' risk, for Finance roles only", () => {
    expect(FINANCE_CAPABILITIES).toHaveLength(9);
    for (const c of ["analyze_statements", "detect_anomalies", "review_expenses", "explain_movement", "analyze_budget", "suggest_optimizations", "generate_report", "explain_indicators"]) expect(FINANCE_CAPABILITIES).toContain(`finance.${c}`);
    expect(FINANCE_BLUEPRINT.taskClass).toBe("reason"); expect(FINANCE_BLUEPRINT.maxAutonomy).toBeLessThanOrEqual(2);
    for (const r of FINANCE_ROLES) expect(canAccess(r, "finance"), r).toBe(true);
    expect(FINANCE_BLUEPRINT.defaultInstructions).toMatch(/never post entries, approve/i);
  });
});

describe("vocabulary, money and wire format", () => {
  it("every vocabulary used by the UI has texts in both languages", () => {
    const en = FINANCE_DICTIONARIES.en as Record<string, string>;
    for (const k of ACCOUNT_TYPE_KEYS) expect(en[`type.${k}`], k).toBeDefined();
    for (const k of CASH_FLOW_CLASSES) expect(en[`cf.${k}`], k).toBeDefined();
    for (const k of TAX_KINDS) expect(en[`tk.${k}`], k).toBeDefined();
    for (const k of PAYMENT_METHODS) expect(en[`pm.${k}`], k).toBeDefined();
    for (const k of [...INVOICE_STATUS, ...EXPENSE_STATUS, "posted", "reversed", "open", "closed", "active", "inactive"]) expect(en[`status.${k}`], k).toBeDefined();
  });
  it("currency conversion is exact integer arithmetic, rounded half up", () => {
    expect(toBase(10_000, 1_000_000)).toBe(10_000); expect(toBase(333, 1_500_000)).toBe(500); expect(toBase(1, 500_000)).toBe(1); expect(toBase(9_007_199_254_740, 1_000_001)).toBe(9_007_208_261_939);
  });
  it("snake_case and ISO dates on the way out, the reverse on the way in, tenant hidden", () => {
    expect(toWire({ tenantId: "t", accountId: "a", createdAt: 0, rows: [{ updatedAt: 86_400_000, rateMicros: 3 }], totals: { USD: 5 } })).toEqual({ account_id: "a", created_at: "1970-01-01T00:00:00.000Z", rows: [{ updated_at: "1970-01-02T00:00:00.000Z", rate_micros: 3 }], totals: { USD: 5 } });
    expect(fromWire({ account_id: "a", created_at: "1970-01-01T00:00:00.000Z" })).toEqual({ accountId: "a", createdAt: 0 });
    expect(() => queryObject(new URLSearchParams("a=1&a=2"))).toThrow();
  });
  it("Spanish and English have the same keys, no empty texts", () => {
    const en = FINANCE_DICTIONARIES.en, es = FINANCE_DICTIONARIES.es;
    expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort());
    for (const v of [...Object.values(en), ...Object.values(es)]) expect(v.length).toBeGreaterThan(0);
    expect(es["nav.accounts"]).not.toBe(en["nav.accounts"]);
  });
});
