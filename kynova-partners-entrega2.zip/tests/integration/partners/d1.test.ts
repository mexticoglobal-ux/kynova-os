import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { COLUMNS, TABLE } from "../../../src/modules/partners/columns";
import { createD1PartnersStore } from "../../../src/modules/partners/store-d1";
import type { PartnersStore } from "../../../src/modules/partners/store";
import type { Actor } from "../../../src/modules/partners/service";
import { createTestDb, newCompany, newUser } from "../db/helpers";
import { Q, activePartner, code, liveClient, ready, setup } from "../../unit/partners/helpers";

let t: Awaited<ReturnType<typeof createTestDb>>;
let store: PartnersStore, A: Actor, B: Actor;
const fresh = async (): Promise<Actor> => { const u = await newUser(t.db), c = await newCompany(t.db, u.id); return { tenantId: c.companyId, userId: u.id, role: "owner" }; };
const h = () => setup({ store });
const snake = (s: string) => s.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
const refused = async (p: Promise<unknown>) => { try { await p; return "no error"; } catch { return "refused"; } };

beforeAll(async () => {
  t = await createTestDb(); store = createD1PartnersStore(t.d1);
  const [o, ob] = [await newUser(t.db), await newUser(t.db)];
  const a = await newCompany(t.db, o.id), b = await newCompany(t.db, ob.id);
  A = { tenantId: a.companyId, userId: o.id, role: "owner" }; B = { tenantId: b.companyId, userId: ob.id, role: "owner" };
}, 60_000);
afterAll(async () => { await t.dispose(); });

describe("schema contract", () => {
  it("every whitelisted column exists in the migration, and every column is whitelisted", async () => {
    for (const [kind, table] of Object.entries(TABLE)) {
      const info = (await t.d1.prepare(`PRAGMA table_info(${table})`).all<{ name: string }>()).results.map((c) => c.name).sort();
      expect(COLUMNS[kind as keyof typeof COLUMNS].map(snake).sort(), table).toEqual(info);
    }
  });
});

describe("the service on D1", () => {
  it("runs the whole program with real constraints: invite, agree, protect, accrue, approve, pay (simulated)", async () => {
    const x = h(); await ready(x, A);
    const p = await activePartner(x, "d1-agency", A), p2 = await activePartner(x, "d1-other", A);
    const ag = await x.svc.agreements.create(A, { partnerId: p.id, label: "Std", commissionBps: 2000 }); await x.svc.agreements.activate(A, ag.id, { signedBy: "Ana" });
    await x.svc.deals.register(A, { partnerId: p.id, clientName: "Grupo Arya" });
    expect(await code(x.svc.deals.register(A, { partnerId: p2.id, clientName: "grupo arya" }))).toBe("invalid_state");
    await liveClient(x, p.id, "Cliente Real", 100_000, A);
    expect((await x.svc.commissions.accrue(A, { period: "2026-10" })).created).toBe(1); expect((await x.svc.commissions.accrue(A, { period: "2026-10" })).created).toBe(0);
    const c = (await x.svc.commissions.list(A, Q())).items[0]!; expect([c.rateBps, c.amountCents, c.rateSource]).toEqual([2000, 20_000, "agreement"]);
    await x.svc.commissions.approve(A, c.id); const po = await x.svc.payouts.create(A, { partnerId: p.id }); const paid = await x.svc.payouts.pay(A, po.id);
    expect([paid.status, paid.mode, paid.totalCents]).toEqual(["paid", "simulated", 20_000]);
  });
  it("the database refuses what the service would never do", async () => {
    const A = await fresh(), B = await fresh(), x = h(); await ready(x, A); const p = await activePartner(x, "d1-guard", A); await liveClient(x, p.id, "Guard Client", 10_000, A);
    await x.svc.commissions.accrue(A, { period: "2026-10" }); const c = (await x.svc.commissions.list(A, Q())).items[0]!;
    expect(await refused(t.d1.prepare("UPDATE pt_commissions SET amount_cents = 1 WHERE id = ?").bind(c.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE pt_commissions SET tenant_id = ? WHERE id = ?").bind(B.tenantId, c.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("DELETE FROM pt_partners WHERE id = ?").bind(p.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE pt_partners SET tenant_id = ? WHERE id = ?").bind(B.tenantId, p.id).run())).toBe("refused");
  });
  it("two tenants never see each other's data", async () => {
    const A = await fresh(), B = await fresh(), x = h(); await ready(x, A); await activePartner(x, "d1-iso", A); await x.svc.setup.initialize(B);
    expect((await x.svc.partners.list(B, Q())).items).toEqual([]); expect((await x.svc.partners.list(A, Q())).items.length).toBeGreaterThan(0);
    expect(await code(x.svc.partners.get(B, (await x.svc.partners.list(A, Q())).items[0]!.id))).toBe("not_found");
  });
});
