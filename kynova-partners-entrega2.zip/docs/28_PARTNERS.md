# 28 · Partners (Entrega 2, Bloque Comercial)

Módulo de programa de partners: alta, invitaciones, acuerdos, niveles, clientes, oportunidades protegidas, comisiones y liquidaciones.
Sigue el patrón del Marketplace (store D1/memoria, servicio con `Actor`, rutas `/api/v1/partners`, i18n es/en, empleado IA y widget registrados en `instrumentation.ts`).

## Qué hace
- **Partners**: prospect → invited → active ↔ suspended → terminated. Nada se borra.
- **Invitaciones**: código `PRT-XXXXX-XXXXX`, se muestra una vez; solo se guarda el SHA-256 y 4 caracteres de pista. Vence a los 14 días. Una invitación nueva revoca la anterior.
- **Acuerdos**: borrador → activo → terminado. Uno activo por partner; activar uno nuevo termina el anterior.
- **Niveles**: registered / silver / gold / platinum (1000/1500/2000/2500 bps). La evaluación es de solo lectura hasta que se aplica.
- **Oportunidades**: registrar protege al cliente (índice único parcial sobre `client_key` en etapas abiertas). Una oportunidad vencida se marca perdida en el siguiente registro.
- **Comisiones**: tasa = acuerdo activo > nivel > por defecto. Monto `floor((base*bps+5000)/10000)` (también CHECK en BD). Columnas de dinero e identidad congeladas por trigger. Devengo idempotente por cliente y periodo.
- **Liquidaciones**: agrupan comisiones aprobadas. **Simuladas**: `not_connected` → `simulated`; no se mueve dinero.

## Activity Engine
Cada mutación escribe evidencia con `getActivitySink("partners")`. Reversibles (reverters idempotentes en `reverters.ts`): partner suspendido, cambio de nivel, comisión aprobada.

## Estado honesto (`ARCHITECTURE_STATUS`)
payouts simulated_only · payout_provider not_connected · partner_portal not_built · e_signature not_connected · invitation_delivery not_connected · cross_company_linking not_implemented · renewal_scheduler not_implemented · ai_actions never_executed.

## Escala (10 000 empresas)
Todo índice empieza por `tenant_id`; paginación por cursor; sin escaneos globales; la unicidad y la protección viven en la BD, no en memoria.

## Datos
Migración `1400_partners.sql`: 10 tablas `pt_*` y el trigger `pt_commissions_frozen`.
