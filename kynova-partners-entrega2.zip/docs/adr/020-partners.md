# ADR 020 · Partners

**Estado**: aceptado. **Contexto**: primer módulo del Bloque Comercial.

**Decisiones**
1. Mismo patrón que el Marketplace; sin reanalizar la arquitectura.
2. Reglas críticas en la base de datos (CHECK de monto, trigger de congelado, índice único parcial de protección), para que sigan válidas con muchos tenants y escritores concurrentes.
3. Evidencia vía `ActivitySink` común; el módulo funciona sin sink. No se modifican módulos congelados.
4. Liquidaciones simuladas hasta que exista un proveedor; el estado se declara en `ARCHITECTURE_STATUS`.
5. Código de invitación solo como hash; se muestra una vez.
6. Cambios aditivos de configuración: `modules.ts` (slug `partners`), `plans.ts` (plan BUSINESS), `instrumentation.ts`.

**Consecuencias**: portal, firma, envío de invitaciones, vínculo entre cuentas y devengo programado quedan para entregas siguientes (Referidos/Portal).
