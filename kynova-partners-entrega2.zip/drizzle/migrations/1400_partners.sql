-- Partners (Entrega 2). Owned by src/modules/partners. Prepared architecture: no payout provider (a payout marked paid is simulated), no e-signature, no invitation delivery, no partner portal yet.
-- Every table is tenant-owned: tenant_id references companies, composite FKs keep references inside the same company, every index leads with tenant_id.
-- Nothing is deleted: partners are terminated, clients churn, commissions are reversed. The money and identity columns of a commission never change (trigger).
-- Nothing here reads other modules' tables.

CREATE TABLE `pt_partners` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`slug` text NOT NULL,
	`name` text NOT NULL,
	`kind` text DEFAULT 'agency' NOT NULL,
	`tier` text DEFAULT 'registered' NOT NULL,
	`status` text DEFAULT 'prospect' NOT NULL,
	`country` text,
	`website` text,
	`contact_name` text,
	`contact_email` text,
	`notes` text DEFAULT '' NOT NULL,
	`created_by` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`kind` IN ('agency', 'reseller', 'integrator', 'technology')),
	CHECK (`tier` IN ('registered', 'silver', 'gold', 'platinum')),
	CHECK (`status` IN ('prospect', 'invited', 'active', 'suspended', 'terminated')),
	CHECK (`country` IS NULL OR length(`country`) = 2)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pt_partners_tenant_id_uq` ON `pt_partners` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `pt_partners_slug_uq` ON `pt_partners` (`tenant_id`,`slug`);--> statement-breakpoint
CREATE INDEX `pt_partners_status_idx` ON `pt_partners` (`tenant_id`,`status`,`tier`);--> statement-breakpoint
CREATE TRIGGER pt_partners_tenant_frozen BEFORE UPDATE OF tenant_id ON pt_partners BEGIN SELECT RAISE(ABORT, 'partners tenant cannot change'); END;
--> statement-breakpoint
CREATE TABLE `pt_invitations` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`partner_id` text NOT NULL,
	`code_hash` text NOT NULL,
	`code_hint` text NOT NULL,
	`email` text NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`expires_at` integer NOT NULL,
	`accepted_at` integer,
	`created_by` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`tenant_id`,`partner_id`) REFERENCES `pt_partners`(`tenant_id`,`id`) ON UPDATE no action ON DELETE no action,
	CHECK (`status` IN ('pending', 'accepted', 'expired', 'revoked')),
	CHECK (length(`code_hint`) = 4),
	CHECK ((`status` = 'accepted') = (`accepted_at` IS NOT NULL))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pt_invitations_tenant_id_uq` ON `pt_invitations` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `pt_invitations_code_uq` ON `pt_invitations` (`tenant_id`,`code_hash`);--> statement-breakpoint
CREATE INDEX `pt_invitations_partner_idx` ON `pt_invitations` (`tenant_id`,`partner_id`,`status`);--> statement-breakpoint
CREATE TRIGGER pt_invitations_tenant_frozen BEFORE UPDATE OF tenant_id ON pt_invitations BEGIN SELECT RAISE(ABORT, 'partners tenant cannot change'); END;
--> statement-breakpoint
CREATE TABLE `pt_agreements` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`partner_id` text NOT NULL,
	`label` text NOT NULL,
	`commission_bps` integer NOT NULL,
	`recurring_months` integer DEFAULT 12 NOT NULL,
	`starts_at` integer NOT NULL,
	`ends_at` integer,
	`status` text DEFAULT 'draft' NOT NULL,
	`signed_by` text,
	`signed_at` integer,
	`created_by` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`tenant_id`,`partner_id`) REFERENCES `pt_partners`(`tenant_id`,`id`) ON UPDATE no action ON DELETE no action,
	CHECK (`status` IN ('draft', 'active', 'ended')),
	CHECK (`commission_bps` BETWEEN 0 AND 5000),
	CHECK (`recurring_months` BETWEEN 0 AND 60),
	CHECK (`ends_at` IS NULL OR `ends_at` > `starts_at`),
	CHECK (`status` = 'draft' OR (`signed_by` IS NOT NULL AND `signed_at` IS NOT NULL))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pt_agreements_tenant_id_uq` ON `pt_agreements` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `pt_agreements_active_uq` ON `pt_agreements` (`tenant_id`,`partner_id`) WHERE `status` = 'active';--> statement-breakpoint
CREATE INDEX `pt_agreements_partner_idx` ON `pt_agreements` (`tenant_id`,`partner_id`,`status`);--> statement-breakpoint
CREATE TRIGGER pt_agreements_tenant_frozen BEFORE UPDATE OF tenant_id ON pt_agreements BEGIN SELECT RAISE(ABORT, 'partners tenant cannot change'); END;
--> statement-breakpoint
CREATE TABLE `pt_tiers` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`code` text NOT NULL,
	`name` text NOT NULL,
	`min_active_clients` integer DEFAULT 0 NOT NULL,
	`min_mrr_cents` integer DEFAULT 0 NOT NULL,
	`commission_bps` integer NOT NULL,
	`perks` text DEFAULT '' NOT NULL,
	`updated_by` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`code` IN ('registered', 'silver', 'gold', 'platinum')),
	CHECK (`min_active_clients` >= 0),
	CHECK (`min_mrr_cents` >= 0),
	CHECK (`commission_bps` BETWEEN 0 AND 5000)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pt_tiers_tenant_id_uq` ON `pt_tiers` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `pt_tiers_code_uq` ON `pt_tiers` (`tenant_id`,`code`);--> statement-breakpoint
CREATE TRIGGER pt_tiers_tenant_frozen BEFORE UPDATE OF tenant_id ON pt_tiers BEGIN SELECT RAISE(ABORT, 'partners tenant cannot change'); END;
--> statement-breakpoint
CREATE TABLE `pt_clients` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`partner_id` text NOT NULL,
	`name` text NOT NULL,
	`client_key` text NOT NULL,
	`plan` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'lead' NOT NULL,
	`mrr_cents` integer DEFAULT 0 NOT NULL,
	`currency` text DEFAULT 'USD' NOT NULL,
	`started_at` integer,
	`ended_at` integer,
	`created_by` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`tenant_id`,`partner_id`) REFERENCES `pt_partners`(`tenant_id`,`id`) ON UPDATE no action ON DELETE no action,
	CHECK (`status` IN ('lead', 'trial', 'active', 'churned')),
	CHECK (`currency` IN ('USD', 'EUR', 'GBP', 'CRC', 'MXN', 'COP', 'BRL', 'CAD')),
	CHECK (`mrr_cents` >= 0),
	CHECK (length(`client_key`) >= 2)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pt_clients_tenant_id_uq` ON `pt_clients` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `pt_clients_key_uq` ON `pt_clients` (`tenant_id`,`client_key`);--> statement-breakpoint
CREATE INDEX `pt_clients_partner_idx` ON `pt_clients` (`tenant_id`,`partner_id`,`status`);--> statement-breakpoint
CREATE TRIGGER pt_clients_tenant_frozen BEFORE UPDATE OF tenant_id ON pt_clients BEGIN SELECT RAISE(ABORT, 'partners tenant cannot change'); END;
--> statement-breakpoint
CREATE TABLE `pt_deals` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`partner_id` text NOT NULL,
	`client_name` text NOT NULL,
	`client_key` text NOT NULL,
	`value_cents` integer DEFAULT 0 NOT NULL,
	`currency` text DEFAULT 'USD' NOT NULL,
	`stage` text DEFAULT 'registered' NOT NULL,
	`expires_at` integer NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`client_id` text,
	`closed_at` integer,
	`created_by` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`tenant_id`,`partner_id`) REFERENCES `pt_partners`(`tenant_id`,`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`tenant_id`,`client_id`) REFERENCES `pt_clients`(`tenant_id`,`id`) ON UPDATE no action ON DELETE no action,
	CHECK (`stage` IN ('registered', 'qualified', 'won', 'lost')),
	CHECK (`currency` IN ('USD', 'EUR', 'GBP', 'CRC', 'MXN', 'COP', 'BRL', 'CAD')),
	CHECK (`value_cents` >= 0),
	CHECK (length(`client_key`) >= 2),
	CHECK ((`stage` IN ('won','lost')) = (`closed_at` IS NOT NULL)),
	CHECK (`stage` <> 'won' OR `client_id` IS NOT NULL)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pt_deals_tenant_id_uq` ON `pt_deals` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `pt_deals_open_uq` ON `pt_deals` (`tenant_id`,`client_key`) WHERE `stage` IN ('registered','qualified');--> statement-breakpoint
CREATE INDEX `pt_deals_partner_idx` ON `pt_deals` (`tenant_id`,`partner_id`,`stage`);--> statement-breakpoint
CREATE INDEX `pt_deals_expiry_idx` ON `pt_deals` (`tenant_id`,`stage`,`expires_at`);--> statement-breakpoint
CREATE TRIGGER pt_deals_tenant_frozen BEFORE UPDATE OF tenant_id ON pt_deals BEGIN SELECT RAISE(ABORT, 'partners tenant cannot change'); END;
--> statement-breakpoint
CREATE TABLE `pt_commissions` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`partner_id` text NOT NULL,
	`client_id` text NOT NULL,
	`period` text NOT NULL,
	`base_cents` integer NOT NULL,
	`rate_bps` integer NOT NULL,
	`amount_cents` integer NOT NULL,
	`currency` text DEFAULT 'USD' NOT NULL,
	`rate_source` text NOT NULL,
	`status` text DEFAULT 'accrued' NOT NULL,
	`payout_id` text,
	`approved_at` integer,
	`paid_at` integer,
	`reversed_at` integer,
	`created_by` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`tenant_id`,`partner_id`) REFERENCES `pt_partners`(`tenant_id`,`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`tenant_id`,`client_id`) REFERENCES `pt_clients`(`tenant_id`,`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`tenant_id`,`payout_id`) REFERENCES `pt_payouts`(`tenant_id`,`id`) ON UPDATE no action ON DELETE no action,
	CHECK (`status` IN ('accrued', 'approved', 'paid', 'reversed')),
	CHECK (`rate_source` IN ('agreement', 'tier', 'default')),
	CHECK (`currency` IN ('USD', 'EUR', 'GBP', 'CRC', 'MXN', 'COP', 'BRL', 'CAD')),
	CHECK (`period` GLOB '[0-9][0-9][0-9][0-9]-[0-1][0-9]'),
	CHECK (`base_cents` >= 0),
	CHECK (`rate_bps` BETWEEN 0 AND 5000),
	CHECK (`amount_cents` = (`base_cents` * `rate_bps` + 5000) / 10000),
	CHECK (`status` <> 'paid' OR `payout_id` IS NOT NULL),
	CHECK ((`status` = 'paid') = (`paid_at` IS NOT NULL)),
	CHECK ((`status` = 'reversed') = (`reversed_at` IS NOT NULL)),
	CHECK (`status` <> 'reversed' OR `payout_id` IS NULL)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pt_commissions_tenant_id_uq` ON `pt_commissions` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `pt_commissions_client_period_uq` ON `pt_commissions` (`tenant_id`,`client_id`,`period`);--> statement-breakpoint
CREATE INDEX `pt_commissions_partner_idx` ON `pt_commissions` (`tenant_id`,`partner_id`,`status`);--> statement-breakpoint
CREATE INDEX `pt_commissions_period_idx` ON `pt_commissions` (`tenant_id`,`period`);--> statement-breakpoint
CREATE INDEX `pt_commissions_payout_idx` ON `pt_commissions` (`tenant_id`,`payout_id`);--> statement-breakpoint
CREATE TRIGGER pt_commissions_tenant_frozen BEFORE UPDATE OF tenant_id ON pt_commissions BEGIN SELECT RAISE(ABORT, 'partners tenant cannot change'); END;
--> statement-breakpoint
CREATE TABLE `pt_payouts` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`partner_id` text NOT NULL,
	`number` text NOT NULL,
	`status` text DEFAULT 'draft' NOT NULL,
	`currency` text DEFAULT 'USD' NOT NULL,
	`total_cents` integer NOT NULL,
	`item_count` integer NOT NULL,
	`mode` text DEFAULT 'not_connected' NOT NULL,
	`paid_at` integer,
	`cancelled_at` integer,
	`created_by` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`tenant_id`,`partner_id`) REFERENCES `pt_partners`(`tenant_id`,`id`) ON UPDATE no action ON DELETE no action,
	CHECK (`status` IN ('draft', 'paid', 'cancelled')),
	CHECK (`mode` IN ('not_connected', 'simulated')),
	CHECK (`currency` IN ('USD', 'EUR', 'GBP', 'CRC', 'MXN', 'COP', 'BRL', 'CAD')),
	CHECK (`total_cents` >= 0),
	CHECK (`item_count` >= 1),
	CHECK ((`status` = 'paid') = (`paid_at` IS NOT NULL)),
	CHECK (`status` <> 'paid' OR `mode` = 'simulated')
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pt_payouts_tenant_id_uq` ON `pt_payouts` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `pt_payouts_number_uq` ON `pt_payouts` (`tenant_id`,`number`);--> statement-breakpoint
CREATE INDEX `pt_payouts_partner_idx` ON `pt_payouts` (`tenant_id`,`partner_id`,`status`);--> statement-breakpoint
CREATE TRIGGER pt_payouts_tenant_frozen BEFORE UPDATE OF tenant_id ON pt_payouts BEGIN SELECT RAISE(ABORT, 'partners tenant cannot change'); END;
--> statement-breakpoint
CREATE TABLE `pt_notifications` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`kind` text NOT NULL,
	`severity` text NOT NULL,
	`ref_id` text,
	`title` text NOT NULL,
	`body` text NOT NULL,
	`read_at` integer,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`kind` IN ('invitation_accepted', 'deal_registered', 'deal_won', 'partner_suspended', 'tier_changed', 'commission_approved', 'payout_paid')),
	CHECK (`severity` IN ('info', 'warning', 'critical'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pt_notifications_tenant_id_uq` ON `pt_notifications` (`tenant_id`,`id`);--> statement-breakpoint
CREATE INDEX `pt_notifications_unread_idx` ON `pt_notifications` (`tenant_id`,`read_at`,`created_at`);--> statement-breakpoint
CREATE TRIGGER pt_notifications_tenant_frozen BEFORE UPDATE OF tenant_id ON pt_notifications BEGIN SELECT RAISE(ABORT, 'partners tenant cannot change'); END;
--> statement-breakpoint
CREATE TABLE `pt_settings` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant_id` text NOT NULL,
	`default_commission_bps` integer DEFAULT 1000 NOT NULL,
	`deal_protection_days` integer DEFAULT 90 NOT NULL,
	`currency` text DEFAULT 'USD' NOT NULL,
	`notify_on_events` integer DEFAULT 1 NOT NULL,
	`ai_enabled` integer DEFAULT 1 NOT NULL,
	`updated_by` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`default_commission_bps` BETWEEN 0 AND 5000),
	CHECK (`deal_protection_days` BETWEEN 7 AND 365),
	CHECK (`currency` IN ('USD', 'EUR', 'GBP', 'CRC', 'MXN', 'COP', 'BRL', 'CAD')),
	CHECK (`notify_on_events` IN (0,1)),
	CHECK (`ai_enabled` IN (0,1))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pt_settings_tenant_id_uq` ON `pt_settings` (`tenant_id`,`id`);--> statement-breakpoint
CREATE UNIQUE INDEX `pt_settings_tenant_uq` ON `pt_settings` (`tenant_id`);--> statement-breakpoint
CREATE TRIGGER pt_settings_tenant_frozen BEFORE UPDATE OF tenant_id ON pt_settings BEGIN SELECT RAISE(ABORT, 'partners tenant cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER pt_partners_no_delete BEFORE DELETE ON pt_partners
BEGIN SELECT RAISE(ABORT, 'pt_partners rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER pt_invitations_no_delete BEFORE DELETE ON pt_invitations
BEGIN SELECT RAISE(ABORT, 'pt_invitations rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER pt_agreements_no_delete BEFORE DELETE ON pt_agreements
BEGIN SELECT RAISE(ABORT, 'pt_agreements rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER pt_tiers_no_delete BEFORE DELETE ON pt_tiers
BEGIN SELECT RAISE(ABORT, 'pt_tiers rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER pt_clients_no_delete BEFORE DELETE ON pt_clients
BEGIN SELECT RAISE(ABORT, 'pt_clients rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER pt_deals_no_delete BEFORE DELETE ON pt_deals
BEGIN SELECT RAISE(ABORT, 'pt_deals rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER pt_commissions_no_delete BEFORE DELETE ON pt_commissions
BEGIN SELECT RAISE(ABORT, 'pt_commissions rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER pt_payouts_no_delete BEFORE DELETE ON pt_payouts
BEGIN SELECT RAISE(ABORT, 'pt_payouts rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER pt_notifications_no_delete BEFORE DELETE ON pt_notifications
BEGIN SELECT RAISE(ABORT, 'pt_notifications rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER pt_settings_no_delete BEFORE DELETE ON pt_settings
BEGIN SELECT RAISE(ABORT, 'pt_settings rows cannot be deleted'); END;
--> statement-breakpoint
CREATE TRIGGER pt_commissions_frozen BEFORE UPDATE OF partner_id, client_id, period, base_cents, rate_bps, amount_cents, currency, rate_source ON pt_commissions
BEGIN SELECT RAISE(ABORT, 'commission money and identity cannot change'); END;
