import { partnersRoute, noContent, parseListQuery, readBody, respond } from "@/modules/partners/http";

export const GET = partnersRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.setup.status(actor), rid); });
export const POST = partnersRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.setup.initialize(actor), rid, 201); }, { mutating: true });
