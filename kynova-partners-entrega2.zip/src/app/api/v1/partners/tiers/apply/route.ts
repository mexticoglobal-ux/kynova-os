import { partnersRoute, noContent, parseListQuery, readBody, respond } from "@/modules/partners/http";

export const POST = partnersRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.tiers.apply(actor), rid); }, { mutating: true });
