import { partnersRoute, noContent, parseListQuery, readBody, respond } from "@/modules/partners/http";

export const GET = partnersRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.tiers.list(actor), rid); });
