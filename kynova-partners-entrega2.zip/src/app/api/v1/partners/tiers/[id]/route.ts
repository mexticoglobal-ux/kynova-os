import { partnersRoute, noContent, parseListQuery, readBody, respond } from "@/modules/partners/http";

type Ctx = { params: Promise<{ id: string }> };

export const PATCH = partnersRoute<Ctx>(async (req, c, { actor, svc, rid }) => { const p = await c.params; return respond(await svc.tiers.update(actor, p.id, await readBody(req)), rid); }, { mutating: true });
