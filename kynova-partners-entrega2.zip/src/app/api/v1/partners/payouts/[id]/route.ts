import { partnersRoute, noContent, parseListQuery, readBody, respond } from "@/modules/partners/http";

type Ctx = { params: Promise<{ id: string }> };

export const GET = partnersRoute<Ctx>(async (req, c, { actor, svc, rid }) => { const p = await c.params; return respond(await svc.payouts.get(actor, p.id), rid); });
