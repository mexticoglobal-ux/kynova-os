import { partnersRoute, noContent, parseListQuery, readBody, respond } from "@/modules/partners/http";

export const GET = partnersRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.agreements.list(actor, parseListQuery(req)), rid); });
export const POST = partnersRoute(async (req, c, { actor, svc, rid }) => { void c; return respond(await svc.agreements.create(actor, await readBody(req)), rid, 201); }, { mutating: true });
