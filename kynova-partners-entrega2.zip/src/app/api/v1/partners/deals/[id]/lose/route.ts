import { partnersRoute, noContent, parseListQuery, readBody, respond } from "@/modules/partners/http";

type Ctx = { params: Promise<{ id: string }> };

export const POST = partnersRoute<Ctx>(async (req, c, { actor, svc, rid }) => { const p = await c.params; return respond(await svc.deals.lose(actor, p.id), rid); }, { mutating: true });
