import ActionButton from "@/components/partners/ActionButton";
import EntityForm from "@/components/partners/EntityForm";
import LocalTime from "@/components/partners/LocalTime";
import { partnersContext } from "@/components/partners/context";
import { K } from "@/components/partners/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/partners/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/partners/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/partners";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
import { AccrueForm } from "@/components/partners/Forms";
import { COMMISSION_STATUS, periodOf } from "@/modules/partners";
export default async function Page({ searchParams }: SP) {
  const { actor, svc, t, locale, can } = await partnersContext(), q = await cur(searchParams, ["status", "partnerId", "period"]), p = await searchParams;
  const [r, ps] = await Promise.all([svc.commissions.list(actor, q), svc.partners.list(actor, { limit: 100 })]);
  const pn = new Map(ps.items.map((x) => [x.id, x.name])), params = { status: sp1(p.status), partnerId: sp1(p.partnerId), period: sp1(p.period) }, ap = can("approve_commissions");
  return (
    <>
      <PageHeader title={t("nav.commissions")} actions={ap ? <ActionButton path="/commissions/approve-all" label="com.approveAll" confirm /> : undefined} />
      <p className="mb-3 text-xs text-muted">{t("com.notice")}</p>
      <FilterForm t={t} q={false} params={params} selects={[{ name: "status", label: t("common.status"), options: COMMISSION_STATUS.map((x) => ({ value: x, label: t(K(`cmst.${x}`)) })) }, { name: "partnerId", label: t("common.partner"), options: ps.items.map((x) => ({ value: x.id, label: x.name })) }]} />
      {r.items.length === 0 ? <Empty>{t("common.noResults")}</Empty> : (
        <Table right={[2, 3, 4]} head={[t("common.partner"), t("com.period"), t("com.base"), t("com.rate"), t("com.amount"), t("common.status"), ...(ap ? [t("common.actions")] : [])]} rows={r.items.map((c) => ({ key: c.id, cells: [pn.get(c.partnerId) ?? "—", c.period, fmtMoney(c.baseCents, c.currency, locale), <span key="r">{c.rateBps / 100} % <span className="text-xs text-muted">({t(K(`src.${c.rateSource}`))})</span></span>, fmtMoney(c.amountCents, c.currency, locale), <StatusPill key="s" status={c.status} label={t(K(`cmst.${c.status}`))} />, ...(ap ? [<div key="a" className="flex flex-wrap gap-2">{c.status === "accrued" && <ActionButton path={`/commissions/${c.id}/approve`} label="com.approve" />}{c.status === "approved" && !c.payoutId && <ActionButton path={`/commissions/${c.id}/unapprove`} label="com.unapprove" />}{(c.status === "accrued" || (c.status === "approved" && !c.payoutId)) && <ActionButton path={`/commissions/${c.id}/reverse`} label="com.reverse" confirm />}</div>] : [])] }))} />
      )}
      <Pager t={t} base={`${B}/commissions`} params={params} next={r.nextCursor} />
      {ap && <Card title={t("com.accrueTitle")} className="mt-5"><AccrueForm defaultPeriod={periodOf(Date.now())} /><p className="mt-2 text-xs text-muted">{t("com.accrueHint")}</p></Card>}
    </>
  );
}
