import ActionButton from "@/components/partners/ActionButton";
import EntityForm from "@/components/partners/EntityForm";
import LocalTime from "@/components/partners/LocalTime";
import { partnersContext } from "@/components/partners/context";
import { K } from "@/components/partners/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/partners/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/partners/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/partners";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
import { DEAL_STAGES } from "@/modules/partners";
export default async function Page({ searchParams }: SP) {
  const { actor, svc, t, locale, can } = await partnersContext(), q = await cur(searchParams, ["q", "stage", "partnerId"]), p = await searchParams;
  const [r, ps, st] = await Promise.all([svc.deals.list(actor, q), svc.partners.list(actor, { limit: 100 }), svc.settings.get(actor)]);
  const pn = new Map(ps.items.map((x) => [x.id, x.name])), params = { q: sp1(p.q), stage: sp1(p.stage), partnerId: sp1(p.partnerId) };
  return (
    <>
      <PageHeader title={t("nav.deals")} />
      <p className="mb-3 text-xs text-muted">{t("deal.protection", { n: st.dealProtectionDays })}</p>
      <FilterForm t={t} params={params} selects={[{ name: "stage", label: t("deal.stage"), options: DEAL_STAGES.map((x) => ({ value: x, label: t(K(`dst.${x}`)) })) }, { name: "partnerId", label: t("common.partner"), options: ps.items.map((x) => ({ value: x.id, label: x.name })) }]} />
      {r.items.length === 0 ? <Empty>{t("common.noResults")}</Empty> : (
        <Table right={[2]} head={[t("deal.client"), t("common.partner"), t("deal.value"), t("deal.expires"), t("deal.stage"), ...(can("manage_deals") ? [t("common.actions")] : [])]} rows={r.items.map((d) => ({ key: d.id, cells: [d.clientName, pn.get(d.partnerId) ?? "—", fmtMoney(d.valueCents, d.currency, locale), <span key="e"><LocalTime ms={d.expiresAt} locale={locale} withTime={false} />{d.expired && <> <Pill tone="danger">{t("deal.expired")}</Pill></>}</span>, <StatusPill key="s" status={d.stage} label={t(K(`dst.${d.stage}`))} />, ...(can("manage_deals") ? [<div key="a" className="flex flex-wrap gap-2">{d.stage === "registered" && !d.expired && <ActionButton path={`/deals/${d.id}/qualify`} label="deal.qualify" />}{(d.stage === "registered" || d.stage === "qualified") && !d.expired && <ActionButton path={`/deals/${d.id}/win`} label="deal.win" tone="primary" />}{(d.stage === "registered" || d.stage === "qualified") && <ActionButton path={`/deals/${d.id}/lose`} label="deal.lose" confirm />}</div>] : [])] }))} />
      )}
      <Pager t={t} base={`${B}/deals`} params={params} next={r.nextCursor} />
      {can("manage_deals") && <Card title={t("deal.new")} className="mt-5"><EntityForm path="/deals" fields={[{ name: "partnerId", label: "common.partner", kind: "select", required: true, options: ps.items.filter((x) => x.status === "active").map((x) => ({ value: x.id, label: x.name })) }, { name: "clientName", label: "deal.client", required: true, max: 120 }, { name: "valueCents", label: "deal.value", kind: "money" }, { name: "notes", label: "common.notes", max: 500 }]} /><p className="mt-2 text-xs text-muted">{t("deal.hint")}</p></Card>}
    </>
  );
}
