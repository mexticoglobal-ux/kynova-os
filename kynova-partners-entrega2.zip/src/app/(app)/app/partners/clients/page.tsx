import ActionButton from "@/components/partners/ActionButton";
import EntityForm from "@/components/partners/EntityForm";
import LocalTime from "@/components/partners/LocalTime";
import { partnersContext } from "@/components/partners/context";
import { K } from "@/components/partners/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/partners/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/partners/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/partners";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
import { CLIENT_STATUS } from "@/modules/partners";
export default async function Page({ searchParams }: SP) {
  const { actor, svc, t, locale, can } = await partnersContext(), q = await cur(searchParams, ["q", "status", "partnerId"]), p = await searchParams;
  const [r, ps, st] = await Promise.all([svc.clients.list(actor, q), svc.partners.list(actor, { limit: 100 }), svc.settings.get(actor)]);
  const pn = new Map(ps.items.map((x) => [x.id, x.name])), params = { q: sp1(p.q), status: sp1(p.status), partnerId: sp1(p.partnerId) };
  return (
    <>
      <PageHeader title={t("nav.clients")} />
      <FilterForm t={t} params={params} selects={[{ name: "status", label: t("common.status"), options: CLIENT_STATUS.map((x) => ({ value: x, label: t(K(`cst.${x}`)) })) }, { name: "partnerId", label: t("common.partner"), options: ps.items.map((x) => ({ value: x.id, label: x.name })) }]} />
      {r.items.length === 0 ? <Empty>{t("common.noResults")}</Empty> : (
        <Table right={[3]} head={[t("common.name"), t("common.partner"), t("cli.plan"), t("cli.mrr"), t("common.status"), ...(can("manage_clients") ? [t("common.actions")] : [])]} rows={r.items.map((c) => ({ key: c.id, cells: [c.name, pn.get(c.partnerId) ?? "—", c.plan || "—", fmtMoney(c.mrrCents, c.currency, locale), <StatusPill key="s" status={c.status} label={t(K(`cst.${c.status}`))} />, ...(can("manage_clients") ? [<div key="a" className="flex flex-wrap gap-2">{c.status === "lead" && <ActionButton path={`/clients/${c.id}`} method="PATCH" body={{ status: "trial" }} label="cli.toTrial" />}{(c.status === "lead" || c.status === "trial") && <ActionButton path={`/clients/${c.id}`} method="PATCH" body={{ status: "active" }} label="cli.toActive" />}{c.status !== "churned" && <ActionButton path={`/clients/${c.id}`} method="PATCH" body={{ status: "churned" }} label="cli.churn" confirm />}</div>] : [])] }))} />
      )}
      <Pager t={t} base={`${B}/clients`} params={params} next={r.nextCursor} />
      {can("manage_clients") && <Card title={t("cli.new")} className="mt-5"><EntityForm path="/clients" fields={[{ name: "partnerId", label: "common.partner", kind: "select", required: true, options: ps.items.filter((x) => x.status === "active").map((x) => ({ value: x.id, label: x.name })) }, { name: "name", label: "common.name", required: true, max: 120 }, { name: "plan", label: "cli.plan", max: 60 }, { name: "status", label: "common.status", kind: "select", def: "lead", options: CLIENT_STATUS.map((x) => ({ value: x, label: t(K(`cst.${x}`)) })) }, { name: "mrrCents", label: "cli.mrr", kind: "money" }]} /><p className="mt-2 text-xs text-muted">{t("cli.hint", { c: st.currency })}</p></Card>}
    </>
  );
}
