import ActionButton from "@/components/partners/ActionButton";
import EntityForm from "@/components/partners/EntityForm";
import LocalTime from "@/components/partners/LocalTime";
import { partnersContext } from "@/components/partners/context";
import { K } from "@/components/partners/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/partners/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/partners/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/partners";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
export default async function Page() {
  const { actor, svc, t, locale, can } = await partnersContext();
  const [tr, ev, st] = await Promise.all([svc.tiers.list(actor), svc.tiers.evaluate(actor), svc.settings.get(actor)]);
  const money = (c: number) => fmtMoney(c, st.currency, locale);
  return (
    <>
      <PageHeader title={t("nav.tiers")} />
      <Table right={[1, 2, 3]} head={[t("common.tier"), t("tier.minClients"), t("tier.minMrr"), t("agr.commission"), t("tier.perks")]} rows={tr.items.map((x) => ({ key: x.id, cells: [t(K(`tier.${x.code}`)), x.minActiveClients, money(x.minMrrCents), `${x.commissionBps / 100} %`, x.perks || "—"] }))} />
      <Card title={t("tier.review")} className="mt-5" action={can("manage_tiers") && ev.items.some((x) => x.direction !== "same") ? <ActionButton path="/tiers/apply" label="tier.apply" confirm /> : undefined}>
        <p className="mb-3 text-xs text-muted">{t("tier.reviewHint")}</p>
        {ev.items.length === 0 ? <Empty>{t("common.noResults")}</Empty> : <Table right={[3, 4]} head={[t("common.partner"), t("tier.current"), t("tier.suggested"), t("dash.clients"), t("dash.mrr")]} rows={ev.items.map((x) => ({ key: x.partnerId, cells: [x.name, t(K(`tier.${x.current}`)), <span key="s" className="inline-flex items-center gap-1.5">{t(K(`tier.${x.suggested}`))}{x.direction !== "same" && <StatusPill status={x.direction} label={t(K(`dir.${x.direction}`))} />}</span>, x.activeClients, money(x.mrrCents)] }))} />}
      </Card>
      {can("manage_tiers") && tr.items.map((x) => <Card key={x.id} title={t("tier.edit", { n: t(K(`tier.${x.code}`)) })} className="mt-4"><EntityForm path={`/tiers/${x.id}`} method="PATCH" submit="common.save" fields={[{ name: "minActiveClients", label: "tier.minClients", kind: "number", def: String(x.minActiveClients) }, { name: "minMrrCents", label: "tier.minMrr", kind: "money", def: String(x.minMrrCents / 100) }, { name: "commissionBps", label: "agr.commission", kind: "percent", def: String(x.commissionBps / 100) }, { name: "perks", label: "tier.perks", def: x.perks, max: 500 }]} /></Card>)}
    </>
  );
}
