import ActionButton from "@/components/partners/ActionButton";
import EntityForm from "@/components/partners/EntityForm";
import LocalTime from "@/components/partners/LocalTime";
import { partnersContext } from "@/components/partners/context";
import { K } from "@/components/partners/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/partners/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/partners/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/partners";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
export default async function Page({ searchParams }: SP) {
  const { actor, svc, t } = await partnersContext(), q = await cur(searchParams, ["unread"]), p = await searchParams;
  const r = await svc.notifications.list(actor, q);
  return (
    <>
      <PageHeader title={t("nav.notifications")} actions={<ActionButton path="/notifications/read-all" label="not.readAll" />} />
      <FilterForm t={t} q={false} params={{ unread: sp1(p.unread) }} selects={[{ name: "unread", label: t("not.filter"), options: [{ value: "1", label: t("not.unreadOnly") }] }]} />
      {r.items.length === 0 ? <Empty>{t("common.noResults")}</Empty> : (
        <Table head={[t("common.title"), t("common.kind"), t("common.severity"), t("common.actions")]} rows={r.items.map((n) => ({ key: n.id, cells: [<div key="t"><p className={n.readAt ? "" : "font-semibold"}>{n.title}</p><p className="text-xs text-muted">{n.body}</p></div>, t(K(`nk.${n.kind}`)), <Pill key="s" tone={n.severity === "critical" ? "danger" : n.severity === "warning" ? "warning" : "info"}>{t(K(`sv.${n.severity}`))}</Pill>, n.readAt ? null : <ActionButton key="a" path={`/notifications/${n.id}/read`} label="not.markRead" />] }))} />
      )}
      <Pager t={t} base={`${B}/notifications`} params={{ unread: sp1(p.unread) }} next={r.nextCursor} />
    </>
  );
}
