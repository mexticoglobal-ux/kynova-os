import ActionButton from "@/components/partners/ActionButton";
import EntityForm from "@/components/partners/EntityForm";
import LocalTime from "@/components/partners/LocalTime";
import { partnersContext } from "@/components/partners/context";
import { K } from "@/components/partners/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/partners/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/partners/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/partners";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
import Link from "next/link";
import { AdvisorPanel } from "@/components/partners/Forms";
import { AI_TOPICS, ARCHITECTURE_STATUS } from "@/modules/partners";
export default async function Page() {
  const { actor, svc, t, locale, can } = await partnersContext();
  const [s, st, ps] = await Promise.all([svc.summary(actor), svc.settings.get(actor), svc.partners.list(actor, { limit: 100, status: "active" })]);
  const money = (c: number) => fmtMoney(c, st.currency, locale);
  return (
    <>
      <PageHeader title={t("title")} />
      <p role="note" className="mb-4 rounded-xl border border-line px-3 py-2 text-xs text-muted">{t("arch.notice")}</p>
      <dl className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label={t("dash.active")} value={s.active} sub={t("dash.of", { n: s.partners })} /><Stat label={t("dash.pipeline")} value={s.pipeline} /><Stat label={t("dash.clients")} value={s.activeClients} /><Stat label={t("dash.mrr")} value={money(s.mrrCents)} />
        <Stat label={t("dash.deals")} value={s.openDeals} sub={t("dash.expiring", { n: s.dealsExpiring })} /><Stat label={t("dash.invitations")} value={s.pendingInvitations} /><Stat label={t("dash.suspended")} value={s.suspended} /><Stat label={t("dash.unread")} value={s.unread} />
        {s.accruedCents !== null && <><Stat label={t("dash.accrued")} value={money(s.accruedCents)} /><Stat label={t("dash.approved")} value={money(s.approvedCents ?? 0)} /><Stat label={t("dash.draftPayouts")} value={s.draftPayouts} /></>}
      </dl>
      <Card title={t("dash.top")}>{s.top.length === 0 ? <Empty>{t("common.noResults")}</Empty> : <Table right={[1, 2]} head={[t("common.partner"), t("dash.clients"), t("dash.mrr")]} rows={s.top.map((x) => ({ key: x.id, cells: [<Link key="n" className="hover:underline" href={`${B}/partners/${x.id}`}>{x.name}</Link>, x.activeClients, money(x.mrrCents)] }))} />}</Card>
      <h2 className="mb-2 mt-6 text-sm font-semibold">{t("arch.title")}</h2>
      <Table head={[t("arch.part"), t("common.status")]} rows={Object.entries(ARCHITECTURE_STATUS).map(([k, v]) => ({ key: k, cells: [t(K(`arch.${k}`)), <Pill key="v" tone={v === "never_executed" ? "success" : "warning"}>{t(K(`arch.state.${v}`))}</Pill>] }))} />
      <div className="mt-5">{can("use_ai") && st.aiEnabled ? <AdvisorPanel topics={AI_TOPICS} partners={ps.items.map((p) => ({ value: p.id, label: p.name }))} /> : <Empty>{t("adv.off")}</Empty>}</div>
    </>
  );
}
