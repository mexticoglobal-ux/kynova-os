import ActionButton from "@/components/partners/ActionButton";
import EntityForm from "@/components/partners/EntityForm";
import LocalTime from "@/components/partners/LocalTime";
import { partnersContext } from "@/components/partners/context";
import { K } from "@/components/partners/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/partners/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/partners/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/partners";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
import { PAYOUT_STATUS } from "@/modules/partners";
export default async function Page({ searchParams }: SP) {
  const { actor, svc, t, locale, can } = await partnersContext(), q = await cur(searchParams, ["status", "partnerId"]), p = await searchParams;
  const [r, ps] = await Promise.all([svc.payouts.list(actor, q), svc.partners.list(actor, { limit: 100 })]);
  const pn = new Map(ps.items.map((x) => [x.id, x.name])), params = { status: sp1(p.status), partnerId: sp1(p.partnerId) }, mp = can("manage_payouts");
  return (
    <>
      <PageHeader title={t("nav.payouts")} />
      <p role="note" className="mb-3 rounded-xl border border-line px-3 py-2 text-xs text-muted">{t("pay.notice")}</p>
      <FilterForm t={t} q={false} params={params} selects={[{ name: "status", label: t("common.status"), options: PAYOUT_STATUS.map((x) => ({ value: x, label: t(K(`pyst.${x}`)) })) }, { name: "partnerId", label: t("common.partner"), options: ps.items.map((x) => ({ value: x.id, label: x.name })) }]} />
      {r.items.length === 0 ? <Empty>{t("common.noResults")}</Empty> : (
        <Table right={[2, 3]} head={[t("pay.number"), t("common.partner"), t("com.amount"), t("pay.items"), t("common.status"), t("pay.mode"), ...(mp ? [t("common.actions")] : [])]} rows={r.items.map((x) => ({ key: x.id, cells: [x.number, pn.get(x.partnerId) ?? "—", fmtMoney(x.totalCents, x.currency, locale), x.itemCount, <StatusPill key="s" status={x.status} label={t(K(`pyst.${x.status}`))} />, <StatusPill key="m" status={x.mode} label={t(K(`pmode.${x.mode}`))} />, ...(mp ? [<div key="a" className="flex flex-wrap gap-2">{x.status === "draft" && <ActionButton path={`/payouts/${x.id}/pay`} label="pay.markPaid" tone="primary" confirm />}{x.status === "draft" && <ActionButton path={`/payouts/${x.id}/cancel`} label="pay.cancel" confirm />}</div>] : [])] }))} />
      )}
      <Pager t={t} base={`${B}/payouts`} params={params} next={r.nextCursor} />
      {mp && <Card title={t("pay.new")} className="mt-5"><EntityForm path="/payouts" fields={[{ name: "partnerId", label: "common.partner", kind: "select", required: true, options: ps.items.filter((x) => x.status !== "prospect" && x.status !== "invited").map((x) => ({ value: x.id, label: x.name })) }]} /><p className="mt-2 text-xs text-muted">{t("pay.newHint")}</p></Card>}
    </>
  );
}
