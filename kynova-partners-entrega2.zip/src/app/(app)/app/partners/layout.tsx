import Link from "next/link";
import { PartnersI18n } from "@/components/partners/I18n";
import { partnersContext } from "@/components/partners/context";
import ActionButton from "@/components/partners/ActionButton";
import { Card } from "@/components/partners/ui";
import { PARTNERS_DICTIONARIES } from "@/modules/partners";

const TABS = [["", "nav.dashboard"], ["partners", "nav.partners"], ["invitations", "nav.invitations"], ["agreements", "nav.agreements"], ["tiers", "nav.tiers"], ["clients", "nav.clients"], ["deals", "nav.deals"], ["commissions", "nav.commissions"], ["payouts", "nav.payouts"], ["notifications", "nav.notifications"], ["settings", "nav.settings"]] as const;

export default async function PartnersLayout({ children }: { children: React.ReactNode }) {
  const { t, locale, can, svc, actor } = await partnersContext();
  const ready = (await svc.setup.status(actor).catch(() => ({ initialized: false }))).initialized;
  return (
    <PartnersI18n dict={PARTNERS_DICTIONARIES[locale]} locale={locale}>
      <div className="mx-auto w-full max-w-[96rem] p-4 sm:p-6 lg:p-8">
        <nav aria-label={t("title")} className="-mx-1 mb-5 flex gap-1 overflow-x-auto border-b border-line px-1 pb-2">
          {TABS.map(([x, k]) => <Link key={x} href={`/app/partners${x ? `/${x}` : ""}`} className="shrink-0 rounded-lg px-3 py-1.5 text-sm hover:bg-ac/10 focus-visible:outline-2 focus-visible:outline-ac2">{t(k)}</Link>)}
        </nav>
        {ready ? children : (
          <Card title={t("setup.title")}>
            {can("manage_settings") ? <div className="grid max-w-xl gap-3"><p className="text-sm text-muted">{t("setup.intro")}</p><div><ActionButton path="/setup" label="setup.start" tone="primary" /></div></div> : <p className="text-sm text-muted">{t("setup.notReady")}</p>}
          </Card>
        )}
      </div>
    </PartnersI18n>
  );
}
