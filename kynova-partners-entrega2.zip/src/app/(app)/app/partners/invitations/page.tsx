import ActionButton from "@/components/partners/ActionButton";
import EntityForm from "@/components/partners/EntityForm";
import LocalTime from "@/components/partners/LocalTime";
import { partnersContext } from "@/components/partners/context";
import { K } from "@/components/partners/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/partners/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/partners/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/partners";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
import { AcceptForm, InviteForm } from "@/components/partners/Forms";
import { INVITATION_STATUS, inviteState } from "@/modules/partners";
export default async function Page({ searchParams }: SP) {
  const { actor, svc, t, locale, can } = await partnersContext(), q = await cur(searchParams, ["status"]), p = await searchParams, now = Date.now();
  const [r, ps] = await Promise.all([svc.invitations.list(actor, q), svc.partners.list(actor, { limit: 100 })]);
  const pn = new Map(ps.items.map((x) => [x.id, x.name]));
  return (
    <>
      <PageHeader title={t("nav.invitations")} />
      <FilterForm t={t} q={false} params={{ status: sp1(p.status) }} selects={[{ name: "status", label: t("common.status"), options: INVITATION_STATUS.map((x) => ({ value: x, label: t(K(`ist.${x}`)) })) }]} />
      {r.items.length === 0 ? <Empty>{t("common.noResults")}</Empty> : (
        <Table head={[t("common.partner"), t("common.email"), t("inv.hint"), t("inv.expires"), t("common.status"), ...(can("manage_partners") ? [t("common.actions")] : [])]} rows={r.items.map((i) => { const s = inviteState(i, now); return { key: i.id, cells: [pn.get(i.partnerId) ?? "—", i.email, `…${i.codeHint}`, <LocalTime key="e" ms={i.expiresAt} locale={locale} withTime={false} />, <StatusPill key="s" status={s} label={t(K(`ist.${s}`))} />, ...(can("manage_partners") ? [s === "pending" ? <ActionButton key="a" path={`/invitations/${i.id}/revoke`} label="inv.revoke" confirm /> : null] : [])] }; })} />
      )}
      <Pager t={t} base={`${B}/invitations`} params={{ status: sp1(p.status) }} next={r.nextCursor} />
      {can("manage_partners") && <><Card title={t("inv.new")} className="mt-5"><InviteForm partners={ps.items.filter((x) => x.status === "prospect" || x.status === "invited").map((x) => ({ value: x.id, label: x.name }))} /></Card><Card title={t("inv.acceptTitle")} className="mt-4"><AcceptForm /><p className="mt-2 text-xs text-muted">{t("inv.acceptHint")}</p></Card></>}
    </>
  );
}
