import ActionButton from "@/components/partners/ActionButton";
import EntityForm from "@/components/partners/EntityForm";
import LocalTime from "@/components/partners/LocalTime";
import { partnersContext } from "@/components/partners/context";
import { K } from "@/components/partners/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/partners/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/partners/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/partners";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
import Link from "next/link";
import { getActivityService } from "@/platform/activity";
import { PARTNER_KINDS, TIER_CODES } from "@/modules/partners";
import { SignForm } from "@/components/partners/Forms";
type Ctx = { params: Promise<{ id: string }> };
export default async function Page({ params }: Ctx) {
  const { id } = await params, { actor, svc, t, locale, can } = await partnersContext();
  const d = await orNotFound(svc.partners.get(actor, id)), p = d.partner, st = await svc.settings.get(actor), money = (c: number) => fmtMoney(c, st.currency, locale);
  const [ags, activity] = await Promise.all([svc.agreements.list(actor, { partnerId: id, limit: 20 }), getActivityService().then((a) => a.timeline(actor, "partner", id, { limit: 8 })).catch(() => null)]);
  const mp = can("manage_partners");
  return (
    <>
      <PageHeader title={p.name} back={{ href: `${B}/partners`, label: t("nav.partners") }} actions={<StatusPill status={p.status} label={t(K(`pst.${p.status}`))} />} />
      <dl className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label={t("common.tier")} value={t(K(`tier.${p.tier}`))} /><Stat label={t("par.rate")} value={`${d.rate.bps / 100} %`} sub={t(K(`src.${d.rate.source}`))} /><Stat label={t("dash.clients")} value={d.activeClients} /><Stat label={t("dash.mrr")} value={money(d.mrrCents)} />
        {d.commissions && <><Stat label={t("dash.accrued")} value={money(d.commissions.accruedCents)} /><Stat label={t("dash.approved")} value={money(d.commissions.approvedCents)} /><Stat label={t("par.paid")} value={money(d.commissions.paidCents)} /></>}
      </dl>
      {mp && (
        <div className="mb-5 flex flex-wrap gap-2">
          {(p.status === "prospect" || p.status === "invited") && <ActionButton path={`/partners/${id}/activate`} label="par.activate" tone="primary" />}
          {p.status === "active" && <ActionButton path={`/partners/${id}/suspend`} label="par.suspend" confirm />}
          {p.status === "suspended" && <ActionButton path={`/partners/${id}/reactivate`} label="par.reactivate" tone="primary" />}
          {p.status !== "terminated" && <ActionButton path={`/partners/${id}/terminate`} label="par.terminate" tone="danger" confirm />}
        </div>
      )}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title={t("par.details")}>
          <dl className="grid gap-1 text-sm"><div className="flex gap-2"><dt className="text-muted">{t("common.kind")}</dt><dd>{t(K(`pk.${p.kind}`))}</dd></div><div className="flex gap-2"><dt className="text-muted">{t("common.country")}</dt><dd>{p.country ?? "—"}</dd></div><div className="flex gap-2"><dt className="text-muted">{t("par.website")}</dt><dd>{p.website ?? "—"}</dd></div><div className="flex gap-2"><dt className="text-muted">{t("par.contactName")}</dt><dd>{p.contactName ?? "—"}</dd></div><div className="flex gap-2"><dt className="text-muted">{t("common.email")}</dt><dd>{p.contactEmail ?? "—"}</dd></div></dl>
          {p.notes && <p className="mt-2 whitespace-pre-wrap text-sm">{p.notes}</p>}
          {mp && p.status !== "terminated" && <div className="mt-4"><EntityForm path={`/partners/${id}`} method="PATCH" submit="common.save" fields={[{ name: "name", label: "common.name", def: p.name, max: 100 }, { name: "kind", label: "common.kind", kind: "select", def: p.kind, options: PARTNER_KINDS.map((x) => ({ value: x, label: t(K(`pk.${x}`)) })) }, { name: "contactName", label: "par.contactName", def: p.contactName ?? "", max: 100 }, { name: "contactEmail", label: "common.email", def: p.contactEmail ?? "", max: 120 }, { name: "notes", label: "common.notes", kind: "textarea", def: p.notes, max: 1000 }]} /></div>}
          {can("manage_tiers") && p.status !== "terminated" && <div className="mt-4"><EntityForm path={`/partners/${id}/tier`} submit="par.setTier" fields={[{ name: "tier", label: "common.tier", kind: "select", def: p.tier, required: true, options: TIER_CODES.map((x) => ({ value: x, label: t(K(`tier.${x}`)) })) }]} /></div>}
        </Card>
        <Card title={t("nav.agreements")}>
          {ags.items.length === 0 ? <Empty>{t("common.noResults")}</Empty> : <Table right={[1]} head={[t("agr.label"), t("agr.commission"), t("common.status"), t("common.actions")]} rows={ags.items.map((a) => ({ key: a.id, cells: [a.label, `${a.commissionBps / 100} %`, <StatusPill key="s" status={a.status} label={t(K(`ast.${a.status}`))} />, <div key="a" className="flex flex-wrap gap-2">{can("manage_agreements") && a.status === "draft" && p.status === "active" && <SignForm agreementId={a.id} />}{can("manage_agreements") && a.status === "active" && <ActionButton path={`/agreements/${a.id}/end`} label="agr.end" confirm />}</div>] }))} />}
          {can("manage_agreements") && p.status !== "terminated" && <div className="mt-4"><EntityForm path="/agreements" fixed={{ partnerId: id }} fields={[{ name: "label", label: "agr.label", required: true, max: 80 }, { name: "commissionBps", label: "agr.commission", kind: "percent", required: true }, { name: "recurringMonths", label: "agr.months", kind: "number", def: "12" }]} /></div>}
        </Card>
      </div>
      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card title={t("nav.clients")}>{d.clients.length === 0 ? <Empty>{t("common.noResults")}</Empty> : <Table right={[2]} head={[t("common.name"), t("common.status"), t("cli.mrr")]} rows={d.clients.map((c) => ({ key: c.id, cells: [c.name, <StatusPill key="s" status={c.status} label={t(K(`cst.${c.status}`))} />, money(c.mrrCents)] }))} />}</Card>
        <Card title={t("nav.deals")}>{d.deals.length === 0 ? <Empty>{t("common.noResults")}</Empty> : <Table right={[1]} head={[t("deal.client"), t("deal.value"), t("common.status")]} rows={d.deals.map((x) => ({ key: x.id, cells: [x.clientName, money(x.valueCents), <StatusPill key="s" status={x.stage} label={t(K(`dst.${x.stage}`))} />] }))} />}</Card>
      </div>
      <Card title={t("par.activity")} className="mt-4">
        {!activity || activity.items.length === 0 ? <Empty>{t("par.noActivity")}</Empty> : <ul className="grid gap-1.5 text-sm">{activity.items.map((e) => <li key={e.id} className="flex flex-wrap items-baseline gap-2"><span className="text-xs text-muted"><LocalTime ms={e.occurredAt} locale={locale} /></span><span>{e.summary}</span>{e.mode !== "production" && <Pill tone="warning">{t(K(`mode.${e.mode}`))}</Pill>}</li>)}</ul>}
        <p className="mt-2 text-xs text-muted">{t("par.activityNote")}</p>
      </Card>
      <p className="mt-4 text-xs text-muted"><Link className="hover:underline" href={`${B}/partners`}>{t("nav.partners")}</Link></p>
    </>
  );
}
