import ActionButton from "@/components/partners/ActionButton";
import EntityForm from "@/components/partners/EntityForm";
import LocalTime from "@/components/partners/LocalTime";
import { partnersContext } from "@/components/partners/context";
import { K } from "@/components/partners/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/partners/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/partners/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/partners";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
import Link from "next/link";
import { PARTNER_KINDS, PARTNER_STATUS, TIER_CODES } from "@/modules/partners";
export default async function Page({ searchParams }: SP) {
  const { actor, svc, t, can } = await partnersContext(), q = await cur(searchParams, ["q", "status", "kind", "tier"]), p = await searchParams;
  const r = await svc.partners.list(actor, q), params = { q: sp1(p.q), status: sp1(p.status), kind: sp1(p.kind), tier: sp1(p.tier) };
  return (
    <>
      <PageHeader title={t("nav.partners")} />
      <FilterForm t={t} params={params} selects={[
        { name: "status", label: t("common.status"), options: PARTNER_STATUS.map((x) => ({ value: x, label: t(K(`pst.${x}`)) })) },
        { name: "kind", label: t("common.kind"), options: PARTNER_KINDS.map((x) => ({ value: x, label: t(K(`pk.${x}`)) })) },
        { name: "tier", label: t("common.tier"), options: TIER_CODES.map((x) => ({ value: x, label: t(K(`tier.${x}`)) })) },
      ]} />
      {r.items.length === 0 ? <Empty>{t("par.none")}</Empty> : (
        <Table head={[t("common.name"), t("common.kind"), t("common.tier"), t("common.country"), t("common.status")]} rows={r.items.map((x) => ({ key: x.id, cells: [<Link key="n" className="hover:underline" href={`${B}/partners/${x.id}`}>{x.name}</Link>, t(K(`pk.${x.kind}`)), t(K(`tier.${x.tier}`)), x.country ?? "—", <StatusPill key="s" status={x.status} label={t(K(`pst.${x.status}`))} />] }))} />
      )}
      <Pager t={t} base={`${B}/partners`} params={params} next={r.nextCursor} />
      {can("manage_partners") && (
        <Card title={t("par.new")} className="mt-5">
          <EntityForm path="/partners" goto={`${B}/partners/`} fields={[
            { name: "slug", label: "common.slug", required: true, max: 60 }, { name: "name", label: "common.name", required: true, max: 100 },
            { name: "kind", label: "common.kind", kind: "select", def: "agency", options: PARTNER_KINDS.map((x) => ({ value: x, label: t(K(`pk.${x}`)) })) },
            { name: "country", label: "common.country", max: 2 }, { name: "website", label: "par.website", max: 200 },
            { name: "contactName", label: "par.contactName", max: 100 }, { name: "contactEmail", label: "common.email", max: 120 },
            { name: "notes", label: "common.notes", kind: "textarea", max: 1000 },
          ]} />
        </Card>
      )}
    </>
  );
}
