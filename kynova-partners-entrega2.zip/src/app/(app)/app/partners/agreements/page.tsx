import ActionButton from "@/components/partners/ActionButton";
import EntityForm from "@/components/partners/EntityForm";
import LocalTime from "@/components/partners/LocalTime";
import { partnersContext } from "@/components/partners/context";
import { K } from "@/components/partners/helpers";
import { Card, Empty, FilterForm, PageHeader, Pager, Pill, Stat, sp1 } from "@/components/partners/ui";
import { StatusPill, Table, fmtMoney, orNotFound } from "@/components/partners/view";
type SP = { searchParams: Promise<Record<string, string | string[] | undefined>> };
const cur = async (sp: SP["searchParams"], keys: string[] = []) => { const p = await sp, o: Record<string, string> = { limit: "50" }; for (const k of ["cursor", ...keys]) { const v = sp1(p[k]); if (v) o[k] = v; } return o; };
const B = "/app/partners";
void ActionButton; void EntityForm; void LocalTime; void K; void Card; void Empty; void FilterForm; void Pager; void Pill; void Stat; void StatusPill; void Table; void fmtMoney; void orNotFound; void cur; void B;
import { SignForm } from "@/components/partners/Forms";
import { AGREEMENT_STATUS } from "@/modules/partners";
export default async function Page({ searchParams }: SP) {
  const { actor, svc, t, locale, can } = await partnersContext(), q = await cur(searchParams, ["status", "partnerId"]), p = await searchParams;
  const [r, ps] = await Promise.all([svc.agreements.list(actor, q), svc.partners.list(actor, { limit: 100 })]);
  const pn = new Map(ps.items.map((x) => [x.id, x]));
  return (
    <>
      <PageHeader title={t("nav.agreements")} />
      <FilterForm t={t} q={false} params={{ status: sp1(p.status), partnerId: sp1(p.partnerId) }} selects={[{ name: "status", label: t("common.status"), options: AGREEMENT_STATUS.map((x) => ({ value: x, label: t(K(`ast.${x}`)) })) }, { name: "partnerId", label: t("common.partner"), options: ps.items.map((x) => ({ value: x.id, label: x.name })) }]} />
      {r.items.length === 0 ? <Empty>{t("common.noResults")}</Empty> : (
        <Table right={[2, 3]} head={[t("common.partner"), t("agr.label"), t("agr.commission"), t("agr.months"), t("agr.signedBy"), t("common.status"), ...(can("manage_agreements") ? [t("common.actions")] : [])]} rows={r.items.map((a) => ({ key: a.id, cells: [pn.get(a.partnerId)?.name ?? "—", a.label, `${a.commissionBps / 100} %`, a.recurringMonths, a.signedBy ? <span key="b">{a.signedBy}{a.signedAt ? <> · <LocalTime ms={a.signedAt} locale={locale} withTime={false} /></> : null}</span> : "—", <StatusPill key="s" status={a.status} label={t(K(`ast.${a.status}`))} />, ...(can("manage_agreements") ? [<div key="a" className="flex flex-wrap gap-2">{a.status === "draft" && pn.get(a.partnerId)?.status === "active" && <SignForm agreementId={a.id} />}{a.status === "active" && <ActionButton path={`/agreements/${a.id}/end`} label="agr.end" confirm />}</div>] : [])] }))} />
      )}
      <Pager t={t} base={`${B}/agreements`} params={{ status: sp1(p.status), partnerId: sp1(p.partnerId) }} next={r.nextCursor} />
      {can("manage_agreements") && <Card title={t("agr.new")} className="mt-5"><EntityForm path="/agreements" fields={[{ name: "partnerId", label: "common.partner", kind: "select", required: true, options: ps.items.filter((x) => x.status !== "terminated").map((x) => ({ value: x.id, label: x.name })) }, { name: "label", label: "agr.label", required: true, max: 80 }, { name: "commissionBps", label: "agr.commission", kind: "percent", required: true }, { name: "recurringMonths", label: "agr.months", kind: "number", def: "12" }]} /><p className="mt-2 text-xs text-muted">{t("agr.hint")}</p></Card>}
    </>
  );
}
