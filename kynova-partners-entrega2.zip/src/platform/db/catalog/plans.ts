import { MODULES } from "@/config/modules";

/** Platform modules every company always has, whatever its plan. */
export const CORE_MODULE_SLUGS: readonly string[] = ["settings", "profile", "notifications", "admin", "onboarding"];
export const DEFAULT_TRIAL_DAYS = 14;

export interface PlanDef { code: "starter" | "professional" | "business" | "enterprise"; name: string; version: number; modules: readonly string[]; config: Record<string, unknown> }

const STARTER = ["dashboard", "crm", "ai-studio", "social-media", "projects"] as const;
const PROFESSIONAL = [...STARTER, "seo", "google-business", "growth", "automation", "academy"] as const;
const BUSINESS = [...PROFESSIONAL, "finance", "marketplace", "partners", "communications", "billing", "security", "analytics", "mission-control", "analytics-bi", "integrations"] as const;

/**
 * Default module entitlements per plan (docs/02 section 4.2 proposal). Prices and limits are NOT final and are
 * not stored here. Planned modules (whatsapp, email-marketing, ...) join when they are registered in modules.ts.
 */
export const PLAN_DEFS: readonly PlanDef[] = [
  { code: "starter", name: "Starter", version: 1, modules: STARTER, config: {} },
  { code: "professional", name: "Professional", version: 1, modules: PROFESSIONAL, config: {} },
  { code: "business", name: "Business", version: 1, modules: BUSINESS, config: {} },
  { code: "enterprise", name: "Enterprise", version: 1, modules: BUSINESS, config: {} },
];
export const planId = (p: Pick<PlanDef, "code" | "version">) => `plan_${p.code}_v${p.version}`;

export const businessModuleSlugs = (): string[] => MODULES.map((m) => m.slug).filter((s) => !CORE_MODULE_SLUGS.includes(s));
