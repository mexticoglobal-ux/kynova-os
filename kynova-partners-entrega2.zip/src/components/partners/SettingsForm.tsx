"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useT } from "./I18n";
import { Err, primary, useRun } from "./Actions";
import { Check, Labeled, input } from "./Form";
import { partnersCall } from "./api";

interface S { defaultCommissionBps: number; dealProtectionDays: number; currency: string; notifyOnEvents: boolean; aiEnabled: boolean }
export default function SettingsForm({ initial, currencies }: { initial: S; currencies: readonly string[] }) {
  const { t } = useT(), router = useRouter(), { busy, err, run } = useRun(), [v, setV] = useState(initial), [pct, setPct] = useState(String(initial.defaultCommissionBps / 100)), [saved, setSaved] = useState(false);
  return (
    <form className="grid gap-3 sm:grid-cols-2" onSubmit={(e) => { e.preventDefault(); setSaved(false); const n = Number(pct.replace(",", ".")); if (!Number.isFinite(n) || n < 0 || n > 50) return; void run(() => partnersCall("PATCH", "/settings", { ...v, defaultCommissionBps: Math.round(n * 100) }), () => { setSaved(true); router.refresh(); }); }}>
      <Labeled label={t("set.commission")} hint={t("set.commissionHint")}>{(id) => <input id={id} inputMode="decimal" className={input} value={pct} onChange={(e) => setPct(e.target.value)} />}</Labeled>
      <Labeled label={t("set.protection")} hint={t("set.protectionHint")}>{(id) => <input id={id} type="number" min={7} max={365} className={input} value={v.dealProtectionDays} onChange={(e) => setV({ ...v, dealProtectionDays: Number(e.target.value) })} />}</Labeled>
      <Labeled label={t("set.currency")} hint={t("set.currencyHint")}>{(id) => <select id={id} className={input} value={v.currency} onChange={(e) => setV({ ...v, currency: e.target.value })}>{currencies.map((c) => <option key={c} value={c}>{c}</option>)}</select>}</Labeled>
      <div className="grid content-end"><Check label={t("set.notify")} checked={v.notifyOnEvents} onChange={(c) => setV({ ...v, notifyOnEvents: c })} /></div>
      <div className="grid content-end"><Check label={t("set.aiEnabled")} checked={v.aiEnabled} onChange={(c) => setV({ ...v, aiEnabled: c })} /></div>
      <div className="flex items-center gap-3 sm:col-span-2"><button className={primary} disabled={busy}>{busy ? t("common.saving") : t("common.save")}</button>{saved && <span role="status" className="text-xs text-muted">{t("common.saved")}</span>}<Err err={err} /></div>
    </form>
  );
}
