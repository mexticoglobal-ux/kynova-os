"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useT } from "./I18n";
import { Err, primary, useRun } from "./Actions";
import { Labeled, input } from "./Form";
import { Card } from "./ui";
import { partnersCall } from "./api";
import { K } from "./helpers";

interface AdvisorReply { ok: boolean; text?: string; message?: string }
/** Asks the Partner Manager AI. It only recommends, detects, explains and forecasts: nothing is executed and nothing is saved. */
export function AdvisorPanel({ topics, partners }: { topics: readonly string[]; partners: { value: string; label: string }[] }) {
  const { t, locale } = useT(), { busy, err, run } = useRun(), [topic, setTopic] = useState(topics[0] ?? ""), [pid, setPid] = useState(""), [out, setOut] = useState<AdvisorReply | null>(null);
  return (
    <Card title={t("adv.ask")}>
      <form className="grid gap-3 sm:grid-cols-2" onSubmit={(e) => { e.preventDefault(); setOut(null); void run(async () => { const r = await partnersCall<AdvisorReply>("POST", `/ai/${topic}`, { lang: locale, ...(topic === "explain_partner" ? { partnerId: pid } : {}) }); if (r.ok && r.data) setOut(r.data); return r; }, () => undefined); }}>
        <Labeled label={t("adv.topic")}>{(id) => <select id={id} className={input} value={topic} onChange={(e) => setTopic(e.target.value)}>{topics.map((x) => <option key={x} value={x}>{t(K(`topic.${x}`))}</option>)}</select>}</Labeled>
        {topic === "explain_partner" && <Labeled label={t("common.partner")}>{(id) => <select id={id} required className={input} value={pid} onChange={(e) => setPid(e.target.value)}><option value="">—</option>{partners.map((k) => <option key={k.value} value={k.value}>{k.label}</option>)}</select>}</Labeled>}
        <div className="flex items-end gap-3 sm:col-span-2"><button className={primary} disabled={busy}>{busy ? t("adv.thinking") : t("adv.run")}</button><Err err={err} /></div>
      </form>
      <p className="mt-3 text-xs text-muted">{t("adv.readOnly")}</p>
      {out?.text && <p className="mt-3 whitespace-pre-wrap rounded-xl border border-line p-3 text-sm">{out.text}</p>}
      {out && !out.ok && <p role="alert" className="mt-3 text-sm text-danger">{out.message ?? t("common.aiUnavailable")}</p>}
    </Card>
  );
}

/** Shows an invitation code exactly once (only its hash is stored). Nothing is emailed: the person shares the code. */
export function CodeOnce({ code }: { code: string }) {
  const { t } = useT();
  return <div role="status" className="mt-3 rounded-xl border border-line p-3 text-sm"><p className="mb-1 text-xs text-muted">{t("inv.codeOnce")}</p><code className="break-all">{code}</code></div>;
}
export function InviteForm({ partners }: { partners: { value: string; label: string }[] }) {
  const { t } = useT(), router = useRouter(), { busy, err, run } = useRun(), [pid, setPid] = useState(""), [email, setEmail] = useState(""), [code, setCode] = useState<string | null>(null);
  return (
    <div>
      <form className="grid gap-3 sm:grid-cols-3" onSubmit={(e) => { e.preventDefault(); setCode(null); void run(async () => { const r = await partnersCall<{ code: string }>("POST", "/invitations", { partnerId: pid, email }); if (r.ok && r.data) setCode(r.data.code); return r; }, () => { setEmail(""); router.refresh(); }); }}>
        <Labeled label={t("common.partner")}>{(id) => <select id={id} required className={input} value={pid} onChange={(e) => setPid(e.target.value)}><option value="">—</option>{partners.map((k) => <option key={k.value} value={k.value}>{k.label}</option>)}</select>}</Labeled>
        <Labeled label={t("common.email")}>{(id) => <input id={id} type="email" required maxLength={120} className={input} value={email} onChange={(e) => setEmail(e.target.value)} />}</Labeled>
        <div className="flex items-end gap-3"><button className={primary} disabled={busy}>{busy ? t("common.saving") : t("inv.create")}</button><Err err={err} /></div>
      </form>
      <p className="mt-2 text-xs text-muted">{t("inv.noEmail")}</p>
      {code && <CodeOnce code={code} />}
    </div>
  );
}
/** Records that the partner returned the code (the partner portal is not built yet, so a person registers the acceptance). */
export function AcceptForm() {
  const { t } = useT(), router = useRouter(), { busy, err, run } = useRun(), [code, setCode] = useState("");
  return (
    <form className="flex flex-wrap items-end gap-3" onSubmit={(e) => { e.preventDefault(); void run(() => partnersCall("POST", "/invitations/accept", { code }), () => { setCode(""); router.refresh(); }); }}>
      <Labeled label={t("inv.code")}>{(id) => <input id={id} required maxLength={20} placeholder="PRT-XXXXX-XXXXX" className={input} value={code} onChange={(e) => setCode(e.target.value)} />}</Labeled>
      <button className={primary} disabled={busy}>{busy ? t("common.saving") : t("inv.accept")}</button><Err err={err} />
    </form>
  );
}
/** Accrues one commission per active client for a month. Safe to run twice: nothing is duplicated. */
export function AccrueForm({ defaultPeriod }: { defaultPeriod: string }) {
  const { t } = useT(), router = useRouter(), { busy, err, run } = useRun(), [period, setPeriod] = useState(defaultPeriod), [res, setRes] = useState<{ created: number; skipped: number } | null>(null);
  return (
    <div>
      <form className="flex flex-wrap items-end gap-3" onSubmit={(e) => { e.preventDefault(); setRes(null); void run(async () => { const r = await partnersCall<{ created: number; skipped: number }>("POST", "/commissions/accrue", { period }); if (r.ok && r.data) setRes(r.data); return r; }, () => router.refresh()); }}>
        <Labeled label={t("com.period")} hint={t("com.periodHint")}>{(id) => <input id={id} required pattern="\d{4}-(0[1-9]|1[0-2])" placeholder="2026-10" className={input} value={period} onChange={(e) => setPeriod(e.target.value)} />}</Labeled>
        <button className={primary} disabled={busy}>{busy ? t("common.saving") : t("com.accrue")}</button><Err err={err} />
      </form>
      {res && <p role="status" className="mt-2 text-xs text-muted">{t("com.accrued", { n: res.created, s: res.skipped })}</p>}
    </div>
  );
}
/** Activating an agreement records who signed it (no e-signature provider is connected). */
export function SignForm({ agreementId }: { agreementId: string }) {
  const { t } = useT(), router = useRouter(), { busy, err, run } = useRun(), [by, setBy] = useState("");
  return (
    <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); void run(() => partnersCall("POST", `/agreements/${agreementId}/activate`, { signedBy: by }), () => router.refresh()); }}>
      <input aria-label={t("agr.signedBy")} required minLength={2} maxLength={100} placeholder={t("agr.signedBy")} className={`${input} !w-44`} value={by} onChange={(e) => setBy(e.target.value)} />
      <button className={primary} disabled={busy}>{busy ? t("common.saving") : t("agr.activate")}</button><Err err={err} />
    </form>
  );
}
