import Link from "next/link";
import { canAccess } from "@/config/modules";
import { registerWidget } from "@/components/dashboard/widgets";
import { Empty, Panel, Pill } from "@/components/dashboard/ui";
import { getPartnersService, partnersLocale, tr, type PartnersKey } from "@/modules/partners";

interface PartnersWidgetData { initialized: boolean; active: number; pipeline: number; activeClients: number; mrrCents: number; openDeals: number; approvedCents: number | null; unread: number; currency: string }
const flag = globalThis as unknown as { __kynovaPartnersWidget?: boolean };

/** The single "partners-overview" panel of the main dashboard, registered at startup through the dashboard's public `registerWidget`. Real figures only; payouts are simulated and the panel says so. */
export function registerPartnersWidget(): void {
  if (flag.__kynovaPartnersWidget) return;
  flag.__kynovaPartnersWidget = true;
  registerWidget<PartnersWidgetData>({
    id: "partners-overview", zone: "main", order: 59, span: "third", skeleton: "panel",
    title: (c) => tr(partnersLocale(c.locale), "widget.title"),
    access: (c) => canAccess(c.role, "partners"),
    async load(svc) {
      const c = svc.ctx, s = await (await getPartnersService()).summary({ tenantId: c.tenantId, userId: c.userId, role: c.role });
      return { initialized: s.initialized, active: s.active, pipeline: s.pipeline, activeClients: s.activeClients, mrrCents: s.mrrCents, openDeals: s.openDeals, approvedCents: s.approvedCents, unread: s.unread, currency: (await (await getPartnersService()).settings.get({ tenantId: c.tenantId, userId: c.userId, role: c.role })).currency };
    },
    Component({ data, ctx }) {
      const L = partnersLocale(ctx.locale), x = (k: PartnersKey, v?: Record<string, string | number>) => tr(L, k, v);
      const cell = (label: string, value: string | number) => <div className="rounded-xl border border-line px-3 py-2.5"><dt className="text-xs text-muted">{label}</dt><dd className="mt-0.5 truncate text-lg font-bold tabular-nums">{value}</dd></div>;
      return (
        <Panel id="partners" title={x("widget.title")} action={<Link href="/app/partners" className="text-xs text-ac2 hover:underline">{x("widget.open")}</Link>}>
          {!data.initialized ? <Empty>{x("widget.empty")}</Empty> : (
            <dl className="grid grid-cols-2 gap-3">
              {cell(x("widget.active"), data.active)}{cell(x("widget.pipeline"), data.pipeline)}
              {cell(x("widget.clients"), data.activeClients)}{cell(x("widget.deals"), data.openDeals)}
              <div className="col-span-2">{cell(x("widget.mrr"), new Intl.NumberFormat(L, { style: "currency", currency: data.currency }).format(data.mrrCents / 100))}</div>
              {data.approvedCents !== null && data.approvedCents > 0 && <div className="col-span-2"><Pill tone="warning">{x("widget.owed", { n: new Intl.NumberFormat(L, { style: "currency", currency: data.currency }).format(data.approvedCents / 100) })}</Pill></div>}
              {data.unread > 0 && <div className="col-span-2"><Pill tone="info">{x("widget.unread", { n: data.unread })}</Pill></div>}
              <p className="col-span-2 text-xs text-muted">{x("widget.notice")}</p>
            </dl>
          )}
        </Panel>
      );
    },
  });
}
