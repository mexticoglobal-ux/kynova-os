import type { PartnersKey } from "@/modules/partners/i18n";
import type { T } from "./ui";

/** Name of a catalog item in the user's language; custom items show the name they were saved with. */
export const nm = (t: T, prefix: string, code: string, fallback: string): string => {
  const k = `${prefix}.${code}` as PartnersKey, v = t(k);
  return v === k ? fallback : v;
};
export const K = (s: string) => s as PartnersKey;
export function fmtVal(v: number | null | undefined, unit: string | undefined, locale: string): string {
  if (v === null || v === undefined) return "—";
  const n = new Intl.NumberFormat(locale, { maximumFractionDigits: 2 }).format(v);
  return unit === "percent" ? `${n} %` : n;
}
export function dayInput(ms: number): string { return new Date(ms).toISOString().slice(0, 10); }
