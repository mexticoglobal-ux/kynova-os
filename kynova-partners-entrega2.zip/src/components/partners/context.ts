import { redirect } from "next/navigation";
import { requireModuleAccess } from "@/platform/auth/session";
import { getPartnersService, partnersLocale, tr, type Actor, type Capability, type PartnersKey } from "@/modules/partners";

/** Server-side context of every Partners page: verified session, actor, service, translator and the capabilities of the role. The tenant always comes from the session. */
export async function partnersContext() {
  const s = await requireModuleAccess("partners");
  if (!s.tenantId) redirect("/app/profile");
  const actor: Actor = { tenantId: s.tenantId, userId: s.user.id, role: s.role };
  const locale = partnersLocale(s.user.locale), svc = await getPartnersService(), mine = await svc.permissions.mine(actor).catch(() => ({ role: s.role, capabilities: [] as Capability[] }));
  const caps = new Set<string>(mine.capabilities);
  return {
    actor, locale, svc, role: s.role,
    t: (k: PartnersKey, v?: Record<string, string | number>) => tr(locale, k, v),
    can: (p: Capability) => caps.has(p),
  };
}
export type PartnersContext = Awaited<ReturnType<typeof partnersContext>>;
