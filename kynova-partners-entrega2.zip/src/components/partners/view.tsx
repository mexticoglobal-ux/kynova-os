import type { ReactNode } from "react";
import { notFound } from "next/navigation";
import { Pill } from "./ui";
import { isPartnersError } from "@/modules/partners/errors";

const TONE: Record<string, "info" | "success" | "warning" | "danger"> = { active: "success", passed: "success", resolved: "success", trusted: "success", unused: "info", used: "info", open: "warning", acknowledged: "info", detected: "warning", investigating: "warning", contained: "info", warning: "warning", failed: "danger", critical: "danger", high: "warning", medium: "info", low: "success", revoked: "danger", expired: "warning", blocked: "danger", dismissed: "info", closed: "info", draft: "info", ready: "success", disabled: "warning", allow: "success", deny: "danger", success: "success", failure: "danger", denied: "danger", unknown: "info", reviewing: "info", mitigated: "success", false_positive: "info", new: "warning", archived: "info", inactive: "warning" };
const MORE: Record<string, "info" | "success" | "warning" | "danger"> = { connected: "success", healthy: "success", succeeded: "success", processed: "success", enabled: "success", pending: "warning", degraded: "warning", skipped: "warning", received: "info", prepared: "info", unknown: "info", ignored: "info", paused: "warning", disabled: "warning", disconnected: "info", expired: "danger", error: "danger", down: "danger", failed: "danger", revoked: "danger", critical: "danger", warning: "warning", info: "info", warn: "warning" };
const MKT: Record<string, "info" | "success" | "warning" | "danger"> = { active: "success", prospect: "info", invited: "warning", suspended: "danger", terminated: "danger", pending: "warning", accepted: "success", revoked: "danger", expired: "danger", accrued: "info", approved: "success", paid: "success", reversed: "warning", draft: "info", ended: "info", lead: "info", trial: "warning", churned: "danger", registered: "info", qualified: "warning", won: "success", lost: "danger", cancelled: "info", simulated: "warning", not_connected: "info", up: "success", down: "warning", same: "info" };
Object.assign(TONE, MORE, MKT);
export const StatusPill = ({ status, label }: { status: string; label: string }) => <Pill tone={TONE[status] ?? "info"}>{label}</Pill>;
/** Plain accessible table; scrolls sideways on narrow screens instead of breaking the layout. */
export function Table({ head, rows, right = [] }: { head: string[]; rows: { key: string; cells: ReactNode[] }[]; right?: number[] }) {
  return (
    <div className="overflow-x-auto rounded-2xl border border-line bg-surface">
      <table className="w-full min-w-[28rem] text-sm">
        <thead><tr className="border-b border-line text-xs text-muted">{head.map((h, i) => <th key={h + i} scope="col" className={`px-4 py-2 font-medium ${right.includes(i) ? "text-right" : "text-left"}`}>{h}</th>)}</tr></thead>
        <tbody>{rows.map((r) => <tr key={r.key} className="border-b border-line last:border-0">{r.cells.map((c, i) => <td key={i} className={`px-4 py-2.5 align-top ${right.includes(i) ? "text-right tabular-nums" : ""}`}>{c}</td>)}</tr>)}</tbody>
      </table>
    </div>
  );
}
export const opt = <T extends { id: string }>(xs: T[], label: (x: T) => string) => xs.map((x) => ({ value: x.id, label: label(x) }));
/** Detail pages: a missing or foreign id is a 404, any other error keeps propagating. */
export async function orNotFound<T>(p: Promise<T>): Promise<T> { try { return await p; } catch (e) { if (isPartnersError(e) && e.code === "not_found") notFound(); throw e; } }
export const fmtMoney = (minor: number, currency: string, locale: string): string => new Intl.NumberFormat(locale, { style: "currency", currency }).format(minor / 100);
