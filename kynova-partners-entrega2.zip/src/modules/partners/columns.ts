import type { Kind } from "./store";

export const TABLE: Record<Kind, string> = {
  partner: "pt_partners", invitation: "pt_invitations", agreement: "pt_agreements", tier: "pt_tiers", client: "pt_clients", deal: "pt_deals", commission: "pt_commissions", payout: "pt_payouts", notification: "pt_notifications", setting: "pt_settings",
};
export const KIND_LIST = Object.keys(TABLE) as Kind[];
/** Nothing in Partners is soft-deleted or hard-deleted: partners are terminated, clients churn, commissions are reversed. */
export const SOFT_DELETE: ReadonlySet<Kind> = new Set<Kind>();
export const REMOVABLE: ReadonlySet<Kind> = new Set<Kind>();
export const IMMUTABLE_KINDS: ReadonlySet<Kind> = new Set<Kind>();
/** Columns that never change after insert (money and identity of a commission). The migration enforces the same with a trigger. */
export const FROZEN_COLS: Partial<Record<Kind, readonly string[]>> = { commission: ["partnerId", "clientId", "period", "baseCents", "rateBps", "amountCents", "currency", "rateSource"] };
export const BOOLEAN_COLS: ReadonlySet<string> = new Set(["notifyOnEvents", "aiEnabled"]);
export const JSON_COLS: ReadonlySet<string> = new Set();
const AUDIT = ["createdBy", "createdAt", "updatedAt"] as const;
/** The only columns the D1 store will ever write or filter on (property names; snake_case in SQL). Verified against the migration by a test. */
export const COLUMNS: Record<Kind, readonly string[]> = {
  partner: ["id", "tenantId", "slug", "name", "kind", "tier", "status", "country", "website", "contactName", "contactEmail", "notes", ...AUDIT],
  invitation: ["id", "tenantId", "partnerId", "codeHash", "codeHint", "email", "status", "expiresAt", "acceptedAt", ...AUDIT],
  agreement: ["id", "tenantId", "partnerId", "label", "commissionBps", "recurringMonths", "startsAt", "endsAt", "status", "signedBy", "signedAt", ...AUDIT],
  tier: ["id", "tenantId", "code", "name", "minActiveClients", "minMrrCents", "commissionBps", "perks", "updatedBy", "createdAt", "updatedAt"],
  client: ["id", "tenantId", "partnerId", "name", "clientKey", "plan", "status", "mrrCents", "currency", "startedAt", "endedAt", ...AUDIT],
  deal: ["id", "tenantId", "partnerId", "clientName", "clientKey", "valueCents", "currency", "stage", "expiresAt", "notes", "clientId", "closedAt", ...AUDIT],
  commission: ["id", "tenantId", "partnerId", "clientId", "period", "baseCents", "rateBps", "amountCents", "currency", "rateSource", "status", "payoutId", "approvedAt", "paidAt", "reversedAt", ...AUDIT],
  payout: ["id", "tenantId", "partnerId", "number", "status", "currency", "totalCents", "itemCount", "mode", "paidAt", "cancelledAt", ...AUDIT],
  notification: ["id", "tenantId", "kind", "severity", "refId", "title", "body", "readAt", "createdAt"],
  setting: ["id", "tenantId", "defaultCommissionBps", "dealProtectionDays", "currency", "notifyOnEvents", "aiEnabled", "updatedBy", "createdAt", "updatedAt"],
};
/** Unique constraints (property names), mirrored by the memory store. Partial ones are noted in the migration. */
export const UNIQUE: Partial<Record<Kind, readonly (readonly string[])[]>> = {
  partner: [["slug"]], tier: [["code"]], client: [["clientKey"]], commission: [["clientId", "period"]], payout: [["number"]], setting: [["tenantId"]],
};
/** Partial unique: deals protect a client only while the deal is open. */
export const UNIQUE_WHEN: Partial<Record<Kind, readonly { cols: readonly string[]; col: string; in: readonly string[] }[]>> = {
  deal: [{ cols: ["clientKey"], col: "stage", in: ["registered", "qualified"] }],
  agreement: [{ cols: ["partnerId"], col: "status", in: ["active"] }],
};
export const snake = (k: string) => k.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
export const camel = (k: string) => k.replace(/_([a-z0-9])/g, (_m, c: string) => c.toUpperCase());
