import type { Role } from "@/config/roles";
import { DEFAULT_CAPABILITIES, type Capability } from "./domain";

/**
 * Capabilities INSIDE Partners. Whether a role may open /app/partners at all is decided only by src/config/modules.ts; this table
 * never grants module access, it describes what a role that already has access can do.
 */
export const allows = (role: Role, c: Capability): boolean => DEFAULT_CAPABILITIES[role].includes(c);
