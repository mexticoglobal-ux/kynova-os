import { getAiKernel, isAiError } from "@/platform/ai-kernel";
import type { AiFailure, AiOutcome, PartnersAi } from "./service";

/**
 * Every model call of Partners goes through the AI Kernel (docs/07): the Partners Advisor uses `generate` with module
 * "communications", so they get the same routing, limits, fallbacks and usage accounting as everything else. No provider is named here.
 * Failures that are the provider's or the plan's (limits, no route, blocked) come back as data, because the person must SEE errors.
 */
export const kernelPartnersAi: PartnersAi = {
  async generate(a, req): Promise<AiOutcome | AiFailure> {
    try {
      const r = await getAiKernel().generate({
        ctx: { tenantId: a.tenantId, module: "partners", userId: a.userId, requestId: a.requestId },
        task: req.task, input: { adhoc: { system: req.system, user: req.user } }, maxOutputTokens: req.maxOutputTokens, ...(req.temperature === undefined ? {} : { temperature: req.temperature }),
      });
      return { ok: true, text: r.text, provider: r.provider, model: r.model, usage: r.usage, latencyMs: r.latencyMs, degraded: r.degraded };
    } catch (e) {
      if (isAiError(e)) return { ok: false, code: e.code, message: e.message };
      if ((e as { __kynovaConfigError?: boolean })?.__kynovaConfigError || (e as { name?: string })?.name === "AiConfigError") return { ok: false, code: "ai_unavailable", message: "AI services are temporarily unavailable." };
      throw e;
    }
  },
};
