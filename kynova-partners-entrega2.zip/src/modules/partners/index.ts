/** Public interface of the Partners module. Other modules import only from here. */
export { createPartnersService, eq, type Actor, type Page, type PartnersAi, type PartnersDeps, type PartnersService, type AiOutcome, type AiFailure, type AdvisorResult } from "./service";
export { PartnersError, isPartnersError, type PartnersErrorCode } from "./errors";
export { allows } from "./access";
export * from "./domain";
export { ARCHITECTURE_STATUS } from "./contracts";
export { dayStart, periodOf, commissionAmount, clientKey, resolveRate, evaluateTier, newInviteCode, payoutNumber, inviteState, change } from "./compute";
export { createMemoryPartnersStore } from "./store-memory";
export { createD1PartnersStore } from "./store-d1";
export { getPartnersStore, setPartnersStore } from "./runtime";
export { getPartnersService } from "./server";
export { kernelPartnersAi } from "./ai";
export type { PartnersStore } from "./store";
export { tr, partnersLocale, PARTNERS_DICTIONARIES, type PartnersKey, type PartnersLocale } from "./i18n";
export { registerPartnersEmployee, PARTNERS_BLUEPRINT, PARTNERS_BLUEPRINT_KEY, PARTNERS_CAPABILITIES } from "./employee";
export { registerPartnersReverters } from "./reverters";
