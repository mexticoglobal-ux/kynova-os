import { z } from "zod";
import { ROLES } from "@/config/roles";

/* ------------------------------------------------------------------ vocabulary */
export const PARTNER_KINDS = ["agency", "reseller", "integrator", "technology"] as const;
export const PARTNER_STATUS = ["prospect", "invited", "active", "suspended", "terminated"] as const;
/** Ordered from lowest to highest. */
export const TIER_CODES = ["registered", "silver", "gold", "platinum"] as const;
export const INVITATION_STATUS = ["pending", "accepted", "expired", "revoked"] as const;
export const AGREEMENT_STATUS = ["draft", "active", "ended"] as const;
export const CLIENT_STATUS = ["lead", "trial", "active", "churned"] as const;
export const DEAL_STAGES = ["registered", "qualified", "won", "lost"] as const;
/** Stages that protect the client from being registered by another partner. */
export const OPEN_STAGES = ["registered", "qualified"] as const;
export const COMMISSION_STATUS = ["accrued", "approved", "paid", "reversed"] as const;
export const PAYOUT_STATUS = ["draft", "paid", "cancelled"] as const;
export const PAYOUT_MODES = ["not_connected", "simulated"] as const;
export const CURRENCIES = ["USD", "EUR", "GBP", "CRC", "MXN", "COP", "BRL", "CAD"] as const;
export const NOTIFICATION_KINDS = ["invitation_accepted", "deal_registered", "deal_won", "partner_suspended", "tier_changed", "commission_approved", "payout_paid"] as const;
export const SEVERITIES = ["info", "warning", "critical"] as const;
export const AI_TOPICS = ["recommend_tier_changes", "find_at_risk_partners", "explain_partner", "summarize_program", "detect_opportunities", "forecast_commissions"] as const;
export const CAPABILITIES = ["view", "manage_partners", "manage_agreements", "manage_deals", "manage_clients", "view_commissions", "approve_commissions", "manage_payouts", "manage_tiers", "use_ai", "manage_settings"] as const;
export type Capability = (typeof CAPABILITIES)[number];
export const DAY_MS = 86_400_000;
export const INVITATION_DAYS = 14;

/** The first thing a new workspace gets: four tiers. Names are translated by the UI. */
export const DEFAULT_TIERS = [
  { code: "registered", minActiveClients: 0, minMrrCents: 0, commissionBps: 1000 },
  { code: "silver", minActiveClients: 3, minMrrCents: 30_000, commissionBps: 1500 },
  { code: "gold", minActiveClients: 10, minMrrCents: 150_000, commissionBps: 2000 },
  { code: "platinum", minActiveClients: 25, minMrrCents: 500_000, commissionBps: 2500 },
] as const;

const ALL = [...CAPABILITIES] as Capability[];
const SALES: Capability[] = ["view", "manage_deals", "manage_clients", "use_ai"];
export const DEFAULT_CAPABILITIES: Record<(typeof ROLES)[number], readonly Capability[]> = {
  super_admin: ALL, owner: ALL, administrator: ALL, ceo: ALL.filter((c) => c !== "manage_settings"),
  manager: ["view", "manage_partners", "manage_deals", "manage_clients", "manage_agreements", "view_commissions", "use_ai"],
  marketing: ["view", "manage_partners", "use_ai"], sales: SALES, finance: ["view", "view_commissions", "approve_commissions", "manage_payouts", "use_ai"],
  support: [], hr: [], employee: [], guest: [],
};

/* ------------------------------------------------------------------ helpers */
const text = (max: number) => z.string().trim().max(max);
const id = z.string().trim().min(1).max(64);
const slug = z.string().trim().toLowerCase().regex(/^[a-z0-9][a-z0-9-]*$/, "Use lowercase letters, numbers or -.").min(2).max(60);
const int = (min: number, max: number) => z.number().int().min(min).max(max);
const email = z.string().trim().email().max(120);
export const PERIOD_RE = /^\d{4}-(0[1-9]|1[0-2])$/;
export const sha256 = async (s: string): Promise<string> => [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)))].map((b) => b.toString(16).padStart(2, "0")).join("");

/* ------------------------------------------------------------------ inputs */
export const partnerInput = z.object({
  slug, name: text(100).min(2), kind: z.enum(PARTNER_KINDS).default("agency"), country: z.string().trim().toUpperCase().regex(/^[A-Z]{2}$/).optional(), website: text(200).url().optional(),
  contactName: text(100).optional(), contactEmail: email.optional(), notes: text(1000).default(""),
}).strict();
export const partnerPatch = z.object({
  name: text(100).min(2).optional(), kind: z.enum(PARTNER_KINDS).optional(), country: z.string().trim().toUpperCase().regex(/^[A-Z]{2}$/).nullable().optional(), website: text(200).url().nullable().optional(),
  contactName: text(100).nullable().optional(), contactEmail: email.nullable().optional(), notes: text(1000).optional(),
}).strict();
export const tierChangeInput = z.object({ tier: z.enum(TIER_CODES) }).strict();
export const invitationInput = z.object({ partnerId: id, email }).strict();
export const acceptInput = z.object({ code: z.string().trim().toUpperCase().regex(/^PRT-[A-Z0-9]{5}-[A-Z0-9]{5}$/, "Use the code as it was shown, for example PRT-AB2CD-3EF4G.") }).strict();
export const agreementInput = z.object({ partnerId: id, label: text(80).min(2), commissionBps: int(0, 5000), recurringMonths: int(0, 60).default(12), startsAt: z.number().int().min(0).optional(), endsAt: z.number().int().min(0).optional() }).strict();
export const signInput = z.object({ signedBy: text(100).min(2) }).strict();
export const tierPatch = z.object({ name: text(60).min(2).optional(), minActiveClients: int(0, 100_000).optional(), minMrrCents: int(0, 1_000_000_000).optional(), commissionBps: int(0, 5000).optional(), perks: text(500).optional() }).strict();
export const clientInput = z.object({ partnerId: id, name: text(120).min(2), plan: text(60).default(""), status: z.enum(CLIENT_STATUS).default("lead"), mrrCents: int(0, 100_000_000).default(0), startedAt: z.number().int().min(0).optional() }).strict();
export const clientPatch = z.object({ name: text(120).min(2).optional(), plan: text(60).optional(), status: z.enum(CLIENT_STATUS).optional(), mrrCents: int(0, 100_000_000).optional() }).strict();
export const dealInput = z.object({ partnerId: id, clientName: text(120).min(2), valueCents: int(0, 1_000_000_000).default(0), notes: text(500).default("") }).strict();
export const dealPatch = z.object({ valueCents: int(0, 1_000_000_000).optional(), notes: text(500).optional() }).strict();
export const accrueInput = z.object({ period: z.string().regex(PERIOD_RE, "Use YYYY-MM."), partnerId: id.optional() }).strict();
export const payoutInput = z.object({ partnerId: id }).strict();
export const settingsPatch = z.object({ defaultCommissionBps: int(0, 5000).optional(), dealProtectionDays: int(7, 365).optional(), currency: z.enum(CURRENCIES).optional(), notifyOnEvents: z.boolean().optional(), aiEnabled: z.boolean().optional() }).strict();
export const aiInput = z.object({ lang: z.enum(["es", "en"]).optional(), question: text(500).optional(), partnerId: id.optional() }).strict();
export const listQuery = z.object({
  q: text(100).optional(), status: text(20).optional(), kind: text(30).optional(), tier: text(20).optional(), partnerId: id.optional(), clientId: id.optional(), stage: text(20).optional(), period: text(7).optional(),
  payoutId: id.optional(), unread: z.enum(["1", "0"]).optional(), cursor: text(300).optional(), limit: z.coerce.number().int().min(1).max(100).default(25),
}).strict();
export type ListQuery = z.output<typeof listQuery>;

/* ------------------------------------------------------------------ records */
type V<T extends readonly string[]> = T[number];
export interface PartnerRecord { id: string; tenantId: string; slug: string; name: string; kind: V<typeof PARTNER_KINDS>; tier: V<typeof TIER_CODES>; status: V<typeof PARTNER_STATUS>; country: string | null; website: string | null; contactName: string | null; contactEmail: string | null; notes: string; createdBy: string; createdAt: number; updatedAt: number }
export interface InvitationRecord { id: string; tenantId: string; partnerId: string; codeHash: string; codeHint: string; email: string; status: V<typeof INVITATION_STATUS>; expiresAt: number; acceptedAt: number | null; createdBy: string; createdAt: number; updatedAt: number }
export interface AgreementRecord { id: string; tenantId: string; partnerId: string; label: string; commissionBps: number; recurringMonths: number; startsAt: number; endsAt: number | null; status: V<typeof AGREEMENT_STATUS>; signedBy: string | null; signedAt: number | null; createdBy: string; createdAt: number; updatedAt: number }
export interface TierRecord { id: string; tenantId: string; code: V<typeof TIER_CODES>; name: string; minActiveClients: number; minMrrCents: number; commissionBps: number; perks: string; updatedBy: string; createdAt: number; updatedAt: number }
export interface ClientRecord { id: string; tenantId: string; partnerId: string; name: string; clientKey: string; plan: string; status: V<typeof CLIENT_STATUS>; mrrCents: number; currency: V<typeof CURRENCIES>; startedAt: number | null; endedAt: number | null; createdBy: string; createdAt: number; updatedAt: number }
export interface DealRecord { id: string; tenantId: string; partnerId: string; clientName: string; clientKey: string; valueCents: number; currency: V<typeof CURRENCIES>; stage: V<typeof DEAL_STAGES>; expiresAt: number; notes: string; clientId: string | null; closedAt: number | null; createdBy: string; createdAt: number; updatedAt: number }
export interface CommissionRecord { id: string; tenantId: string; partnerId: string; clientId: string; period: string; baseCents: number; rateBps: number; amountCents: number; currency: V<typeof CURRENCIES>; rateSource: "agreement" | "tier" | "default"; status: V<typeof COMMISSION_STATUS>; payoutId: string | null; approvedAt: number | null; paidAt: number | null; reversedAt: number | null; createdBy: string; createdAt: number; updatedAt: number }
/** No payout provider is connected: `paid` is simulated (mode "simulated") and no money moves. */
export interface PayoutRecord { id: string; tenantId: string; partnerId: string; number: string; status: V<typeof PAYOUT_STATUS>; currency: V<typeof CURRENCIES>; totalCents: number; itemCount: number; mode: V<typeof PAYOUT_MODES>; paidAt: number | null; cancelledAt: number | null; createdBy: string; createdAt: number; updatedAt: number }
export interface NotificationRecord { id: string; tenantId: string; kind: V<typeof NOTIFICATION_KINDS>; severity: V<typeof SEVERITIES>; refId: string | null; title: string; body: string; readAt: number | null; createdAt: number }
export interface SettingRecord { id: string; tenantId: string; defaultCommissionBps: number; dealProtectionDays: number; currency: V<typeof CURRENCIES>; notifyOnEvents: boolean; aiEnabled: boolean; updatedBy: string; createdAt: number; updatedAt: number }
