import { registerReverter } from "@/platform/activity";
import type { PartnersService } from "./service";

const flag = globalThis as unknown as { __kynovaPartnersReverters?: boolean };
/**
 * How Partners undoes its own reversible activity (the Activity Engine only coordinates). Every handler is idempotent: if the work is already
 * undone it succeeds without changing anything. Registered once at startup (src/instrumentation.ts).
 */
export function registerPartnersReverters(getService: () => Promise<PartnersService>): void {
  if (flag.__kynovaPartnersReverters) return;
  flag.__kynovaPartnersReverters = true;
  registerReverter("partners", async (event, actor) => {
    const svc = await getService(), h = (event.revertHint ?? {}) as { partnerId?: string; previousTier?: never; commissionId?: string };
    switch (event.action) {
      case "partners.partner.suspended": {
        const d = await svc.partners.get(actor, String(h.partnerId));
        if (d.partner.status === "suspended") await svc.partners.reactivate(actor, d.partner.id);
        return { summary: `Partner reactivated: ${d.partner.name}` };
      }
      case "partners.partner.tier_changed": {
        await svc.partners.setTier(actor, String(h.partnerId), { tier: h.previousTier }, { undo: true });
        return { summary: "Tier restored" };
      }
      case "partners.commission.approved": {
        const c = await svc.commissions.get(actor, String(h.commissionId));
        if (c.status === "approved") await svc.commissions.unapprove(actor, c.id);
        return { summary: "Commission back to accrued" };
      }
      default: throw new Error("This activity cannot be undone.");
    }
  });
}
