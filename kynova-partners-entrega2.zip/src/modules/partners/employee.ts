import { z } from "zod";
import type { Role } from "@/config/roles";
import { defineEmployeeBlueprint, defineEmployeeCapability, type CapabilityContext, type EmployeeBlueprint } from "@/platform/ai-employees";
import { aiInput, AI_TOPICS } from "./domain";
import type { Actor, PartnersService } from "./service";

/** Partner Manager AI is an ordinary AI Employee of the platform framework: blueprint + capabilities registered through its public API. Read only: it explains, detects and recommends; it never executes anything. */
export const PARTNERS_BLUEPRINT_KEY = "partner_manager";
export const PARTNERS_ROLES: readonly Role[] = ["super_admin", "owner", "ceo", "administrator", "manager", "sales", "finance"];
const CAPS = ["partners.read_summary", ...AI_TOPICS.map((t) => `partners.${t}`)] as const;
export const PARTNERS_CAPABILITIES: readonly string[] = CAPS;
export const PARTNERS_BLUEPRINT: EmployeeBlueprint = {
  key: PARTNERS_BLUEPRINT_KEY, name: "Partner Manager AI",
  description: "Recommends tier changes, finds partners at risk, explains partners, forecasts commissions and summarizes the partner program.",
  defaultGoal: "Help the team grow and keep healthy partners: right tiers, timely follow-up, clear commissions.",
  defaultInstructions: [
    "You work only with the data recorded in Partners. Never invent data and say plainly when data is missing. Payouts are simulated: no payout provider is connected and no money moves.",
    "You are read only: you explain and suggest, people decide. Never invite, activate, suspend or terminate partners, change tiers or agreements, register or close deals, approve commissions, create or pay payouts, or change settings.",
  ].join(" "),
  taskClass: "reason", capabilities: PARTNERS_CAPABILITIES, defaultAutonomy: 1, maxAutonomy: 1, allowedRoles: PARTNERS_ROLES,
};
type Svc = () => Promise<PartnersService>;
const asActor = (c: CapabilityContext): Actor => ({ tenantId: c.tenantId, userId: c.onBehalfOf.userId, role: c.onBehalfOf.role, agentId: c.employeeId });
const flag = globalThis as unknown as { __kynovaPartnersEmployee?: boolean };
/** Registered once at startup (src/instrumentation.ts). Every capability is `read` or `draft`. */
export function registerPartnersEmployee(getService: Svc): void {
  if (flag.__kynovaPartnersEmployee) return;
  flag.__kynovaPartnersEmployee = true;
  defineEmployeeBlueprint(PARTNERS_BLUEPRINT);
  defineEmployeeCapability<Record<string, never>>({ key: "partners.read_summary", description: "Read the partner program overview: partners, clients, recurring revenue, deals and commissions owed.", risk: "read", roles: PARTNERS_ROLES, input: z.object({}).strict() as never, handler: async (c) => (await getService()).summary(asActor(c)) });
  for (const topic of AI_TOPICS) defineEmployeeCapability({ key: `partners.${topic}`, description: `Partner Manager: ${topic.replace(/_/g, " ")}.`, risk: "draft", roles: PARTNERS_ROLES, input: aiInput, handler: async (c, i) => (await getService()).ai.run(asActor(c), topic, i) });
}
