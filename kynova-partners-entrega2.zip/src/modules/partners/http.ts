import { NextResponse, type NextRequest } from "next/server";
import { canAccess } from "@/config/modules";
import { isConfigError } from "@/platform/auth/errors";
import { assertSameOrigin, getAuthConfig, ok, problem, route } from "@/platform/auth/http";
import { requireApiSession } from "@/platform/auth/session";
import { isAiError } from "@/platform/ai-kernel";
import { isEmployeeError } from "@/platform/ai-employees";
import { listQuery } from "./domain";
import { PartnersError, isPartnersError } from "./errors";
import { getPartnersService } from "./server";
import type { Actor, PartnersService } from "./service";
import { fromWire, queryObject, toWire } from "./wire";

/** Partners has its own module slug in src/config/modules.ts. */
export const PARTNERS_SLUG = "partners";
export interface PartnersRouteContext { actor: Actor; rid: string; svc: PartnersService }

/** Verified session, module access for the role, an active company, CSRF checks on mutations, and Partners/AI errors as problem+json. */
export function partnersRoute<C = unknown>(fn: (req: NextRequest, ctx: C, a: PartnersRouteContext) => Promise<NextResponse>, opts: { mutating?: boolean } = {}) {
  return route<C>(async (req, ctx, rid) => {
    try {
      if (opts.mutating) assertSameOrigin(req, getAuthConfig());
      const s = await requireApiSession();
      if (!s.tenantId) throw new PartnersError("forbidden", "Select or create a company first.");
      if (!canAccess(s.role, PARTNERS_SLUG)) throw new PartnersError("forbidden", "Your role cannot use Partners.");
      const actor: Actor = { tenantId: s.tenantId, userId: s.user.id, role: s.role, requestId: rid };
      return await fn(req, ctx, { actor, rid, svc: await getPartnersService() });
    } catch (e) {
      if (isPartnersError(e)) return problem(e.code, e.status, e.message, rid, { ...(e.details?.fields ? { errors: e.details.fields } : {}), ...(e.details && !e.details.fields ? { details: e.details } : {}) });
      if (isEmployeeError(e)) return problem(e.code, e.status, e.message, rid, e.details ? { details: e.details } : {});
      if (isAiError(e)) return problem(e.code, e.status, e.message, rid, e.details ? { details: e.details } : {});
      if (isConfigError(e) && !(e as { name?: string }).name?.startsWith("Missing")) return problem("ai_unavailable", 503, "This service is temporarily unavailable.", rid);
      throw e;
    }
  });
}
export async function readBody(req: NextRequest): Promise<unknown> {
  if (!req.headers.get("content-type")?.toLowerCase().startsWith("application/json")) throw new PartnersError("validation_failed", "Content-Type must be application/json.");
  const text = await req.text();
  if (!text.trim()) return {};
  try { const b = JSON.parse(text) as unknown; if (b === null || typeof b !== "object" || Array.isArray(b)) throw 0; return fromWire(b); }
  catch { throw new PartnersError("validation_failed", "The body must be a JSON object."); }
}
export const parseListQuery = (req: NextRequest) => {
  const r = listQuery.safeParse(queryObject(req.nextUrl.searchParams));
  if (!r.success) throw new PartnersError("validation_failed", "Invalid query.", { fields: r.error.issues.map((i) => ({ field: i.path.join("."), message: i.message })) });
  return r.data;
};
export const respond = (data: unknown, rid: string, status = 200) => ok(toWire(data), rid, status);
export const noContent = (rid: string) => new NextResponse(null, { status: 204, headers: { "X-Request-Id": rid, "Cache-Control": "no-store" } });
