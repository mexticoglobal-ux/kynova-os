import { DAY_MS, TIER_CODES, type AgreementRecord, type TierRecord } from "./domain";

export const dayStart = (t: number): number => Math.floor(t / DAY_MS) * DAY_MS;
/** UTC billing period of a moment, "YYYY-MM". */
export const periodOf = (t: number): string => new Date(t).toISOString().slice(0, 7);
/** Commission in cents, rounded half up. The same formula is a CHECK in the migration. */
export const commissionAmount = (baseCents: number, rateBps: number): number => Math.floor((baseCents * rateBps + 5000) / 10_000);
/** Normalized identity of a client name, used to stop two partners from registering the same client. */
export function clientKey(name: string): string {
  return name.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80);
}
/** Agreement beats tier beats the workspace default. Returns the basis points and where they came from. */
export function resolveRate(p: { agreement: Pick<AgreementRecord, "commissionBps" | "status"> | null; tier: Pick<TierRecord, "commissionBps"> | null; defaultBps: number }): { bps: number; source: "agreement" | "tier" | "default" } {
  if (p.agreement && p.agreement.status === "active") return { bps: p.agreement.commissionBps, source: "agreement" };
  if (p.tier) return { bps: p.tier.commissionBps, source: "tier" };
  return { bps: p.defaultBps, source: "default" };
}
/** The highest tier whose two minimums are both met. */
export function evaluateTier(tiers: readonly Pick<TierRecord, "code" | "minActiveClients" | "minMrrCents">[], activeClients: number, mrrCents: number): (typeof TIER_CODES)[number] {
  let best: (typeof TIER_CODES)[number] = "registered";
  for (const code of TIER_CODES) { const t = tiers.find((x) => x.code === code); if (t && activeClients >= t.minActiveClients && mrrCents >= t.minMrrCents) best = code; }
  return best;
}
const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
/** `PRT-XXXXX-XXXXX`, shown once; only its SHA-256 is stored. */
export function newInviteCode(): string {
  const b = crypto.getRandomValues(new Uint8Array(10)), s = [...b].map((x) => ALPHABET[x % ALPHABET.length]).join("");
  return `PRT-${s.slice(0, 5)}-${s.slice(5)}`;
}
export const payoutNumber = (t: number, seq: number): string => `PO-${new Date(t).getUTCFullYear()}-${String(seq).padStart(4, "0")}`;
export const inviteState = (i: { status: string; expiresAt: number }, t: number): "pending" | "accepted" | "expired" | "revoked" => (i.status === "pending" && i.expiresAt <= t ? "expired" : (i.status as "pending" | "accepted" | "expired" | "revoked"));
/** Percentage change between two periods; null when there is nothing to compare with. */
export const change = (cur: number, prev: number): number | null => (prev === 0 ? null : Math.round(((cur - prev) / prev) * 1000) / 10);
