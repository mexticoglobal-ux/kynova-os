import type { z } from "zod";
import { canAccess } from "@/config/modules";
import type { Role } from "@/config/roles";
import type { ActivitySink, SinkEvent } from "@/platform/activity";
import { allows } from "./access";
import { clientKey, commissionAmount, evaluateTier, inviteState, newInviteCode, payoutNumber, periodOf, resolveRate } from "./compute";
import {
  AI_TOPICS, DAY_MS, DEFAULT_TIERS, INVITATION_DAYS, OPEN_STAGES, TIER_CODES, accrueInput, acceptInput, agreementInput, aiInput, clientInput, clientPatch, dealInput, dealPatch, invitationInput, listQuery, partnerInput, partnerPatch, payoutInput, settingsPatch, sha256, signInput, tierChangeInput, tierPatch,
  type AgreementRecord, type Capability, type ClientRecord, type CommissionRecord, type DealRecord, type InvitationRecord, type ListQuery, type NotificationRecord, type PartnerRecord, type PayoutRecord, type SettingRecord, type TierRecord,
} from "./domain";
import { PartnersError } from "./errors";
import type { Cond, Kind, KindMap, PartnersStore } from "./store";

export interface Actor { tenantId: string; userId: string; role: Role; requestId?: string; /** Set when an AI employee acts for the person. */ agentId?: string }
export interface Page<T> { items: T[]; nextCursor: string | null }
export interface AiOutcome { ok: true; text: string; provider: string; model: string; usage: { inputTokens: number; outputTokens: number; costMicros: number }; latencyMs: number; degraded: boolean }
export interface AiFailure { ok: false; code: string; message: string }
/** The only way this module talks to a model: a port implemented over the AI Kernel (ai.ts). */
export interface PartnersAi { generate(a: Actor, req: { task: "reason" | "summarize" | "chat"; system: string; user: string; maxOutputTokens: number; temperature?: number }): Promise<AiOutcome | AiFailure> }
export interface PartnersDeps { store: PartnersStore; newId: () => string; now?: () => number; ai?: PartnersAi; /** Evidence for the Activity Engine; optional so the module also runs without it. */ activity?: ActivitySink }
export type AdvisorResult = ({ ok: true; text: string; provider: string; model: string } | AiFailure) & { facts: Record<string, unknown> };

const enc = (v: string | number, id: string): string => btoa(JSON.stringify({ v, id })).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
function dec(c: string | undefined): { value: string | number; id: string } | undefined {
  if (!c) return undefined;
  try { const o = JSON.parse(atob(c.replace(/-/g, "+").replace(/_/g, "/"))) as { v?: unknown; id?: unknown }; if ((typeof o.v === "string" || typeof o.v === "number") && typeof o.id === "string") return { value: o.v, id: o.id }; } catch { /* fallthrough */ }
  throw new PartnersError("validation_failed", "Invalid cursor.");
}
const SEARCH = { partner: ["name", "slug", "contactEmail"], client: ["name", "plan"], deal: ["clientName"], payout: ["number"] } as const;
export const eq = <K extends Kind>(col: keyof KindMap[K] & string, value: string | number | boolean): Cond<K> => ({ col, op: "eq", value });
const SCAN_MAX = 5000, LIMITS = { partner: 1000, agreement: 5000, client: 5000, deal: 5000 } as const;
const DEFAULTS = { defaultCommissionBps: 1000, dealProtectionDays: 90, currency: "USD", notifyOnEvents: true, aiEnabled: true } as const;
const SYSTEM = "You are the Partner Manager of a software company's partner program (agencies, resellers, integrators). Every partner, client, deal, commission and number comes ONLY from the FACTS block: never invent data and say plainly when data is missing. Payouts are simulated: no payout provider is connected and no money moves.";
const INSTRUCTION: Record<(typeof AI_TOPICS)[number], string> = {
  recommend_tier_changes: "From FACTS, list the partners whose tier should go up or down, with the numbers behind each (active clients, monthly revenue vs the tier minimums). Say when nobody needs a change.",
  find_at_risk_partners: "From FACTS, list the active partners at risk (no new clients or deals lately, churned clients, expired registrations, suspended) ordered by urgency, each with the fact that shows it and one suggested follow-up for a person to do.",
  explain_partner: "Explain the partner in FACTS in plain language: who they are, their tier and commission rate and where it comes from, clients and revenue, open deals, commissions and what needs attention.",
  summarize_program: "Summarize the partner program in FACTS in a short paragraph and a few bullets: partners, clients and recurring revenue, deals, commissions owed and what needs attention.",
  detect_opportunities: "List the opportunities in FACTS: prospects not invited, invitations waiting, active partners without agreement or clients, deals about to expire, approved commissions not yet paid, partners ready for a higher tier.",
  forecast_commissions: "From FACTS, explain what commissions are expected next period (per partner and in total) and the amount already approved and unpaid. State the assumptions: active clients keep paying, window of recurring months.",
};

export function createPartnersService(deps: PartnersDeps) {
  const { store } = deps;
  const now = deps.now ?? Date.now;
  const parse = <S extends z.ZodType>(schema: S, input: unknown): z.output<S> => {
    const r = schema.safeParse(input);
    if (!r.success) throw new PartnersError("validation_failed", "One or more fields are invalid.", { fields: r.error.issues.map((i) => ({ field: i.path.join(".") || "_", message: i.message })) });
    return r.data;
  };
  const invalid = (field: string, message: string): never => { throw new PartnersError("validation_failed", message, { fields: [{ field, message }] }); };
  const notFound = (what: string): never => { throw new PartnersError("not_found", `${what} not found.`); };
  const state = (message: string, details?: Record<string, unknown>): never => { throw new PartnersError("invalid_state", message, details); };
  const one = async <K extends Kind>(kind: K, a: Actor, id: string, what: string): Promise<KindMap[K]> => (await store.get(kind, a.tenantId, id)) ?? notFound(what);

  const can = (a: Actor, c: Capability): boolean => canAccess(a.role, "partners") && allows(a.role, c) && (!a.agentId || c === "view" || c === "use_ai");
  function need(a: Actor, c: Capability): void {
    if (can(a, c)) return;
    throw new PartnersError("forbidden", a.agentId && c !== "view" && c !== "use_ai" ? "AI employees cannot change the partner program." : `Your role cannot do this in Partners (${c}).`);
  }
  /** Leaves evidence in the Activity Engine. Never fails the operation. */
  async function rec(a: Actor, e: SinkEvent): Promise<void> {
    if (!deps.activity) return;
    await deps.activity.record({ tenantId: a.tenantId, requestId: a.requestId }, { actorKind: a.agentId ? "employee" : "user", actorId: a.userId, ...(a.agentId ? { employeeKey: "partner_manager" } : {}), ...e });
  }
  async function listPage<K extends Kind>(kind: K, a: Actor, q: ListQuery, where: Cond<K>[], order?: { col: keyof KindMap[K] & string; dir: "asc" | "desc" }): Promise<Page<KindMap[K]>> {
    const col = order?.col ?? "createdAt", cols = (SEARCH as Record<string, readonly string[]>)[kind];
    const rows = await store.query(kind, a.tenantId, { where, search: q.q && cols ? { cols: cols as never, text: q.q } : undefined, orderBy: order, limit: q.limit + 1, after: dec(q.cursor) });
    const page = rows.slice(0, q.limit), last = page.at(-1) as Record<string, unknown> | undefined;
    return { items: page, nextCursor: rows.length > q.limit && last ? enc(last[col] as string | number, last.id as string) : null };
  }
  async function scan<K extends Kind>(kind: K, a: Actor, where: Cond<K>[], max = SCAN_MAX): Promise<KindMap[K][]> {
    const out: KindMap[K][] = [];
    let after: { value: string; id: string } | undefined;
    for (;;) {
      const rows = await store.query(kind, a.tenantId, { where, orderBy: { col: "id" as never, dir: "asc" }, limit: 500, after });
      out.push(...rows);
      if (out.length > max) throw new PartnersError("invalid_state", "There are too many records. Narrow the filters.");
      if (rows.length < 500) return out;
      const last = rows.at(-1) as { id: string }; after = { value: last.id, id: last.id };
    }
  }
  const w = <K extends Kind>(...c: (Cond<K> | false | undefined | "" | null)[]): Cond<K>[] => c.filter(Boolean) as Cond<K>[];
  const guardLimit = async (kind: Kind, a: Actor, max: number, what: string) => { if ((await store.count(kind, a.tenantId)) >= max) throw new PartnersError("limit_exceeded", `You reached the limit of ${max} ${what}.`); };
  const cfg = async (a: Actor): Promise<SettingRecord> => (await store.query("setting", a.tenantId, { limit: 1 }))[0] ?? { id: "", tenantId: a.tenantId, ...DEFAULTS, updatedBy: "", createdAt: 0, updatedAt: 0 };
  const dupAs = async (field: string, msg: string, fn: () => Promise<void>): Promise<void> => { try { await fn(); } catch (e) { if ((e as { code?: string } | null)?.code === "duplicate") invalid(field, msg); throw e; } };
  async function notify(a: Actor, kind: NotificationRecord["kind"], severity: NotificationRecord["severity"], refId: string | null, title: string, body: string): Promise<void> {
    if (!(await cfg(a)).notifyOnEvents) return;
    await store.insert("notification", { id: deps.newId(), tenantId: a.tenantId, kind, severity, refId, title: title.slice(0, 120), body: body.slice(0, 300), readAt: null, createdAt: now() });
  }
  const partnerOf = (a: Actor, id: string) => one("partner", a, id, "Partner");
  const activeAgreement = async (a: Actor, partnerId: string): Promise<AgreementRecord | null> => (await store.query("agreement", a.tenantId, { where: [eq<"agreement">("partnerId", partnerId), eq<"agreement">("status", "active")], limit: 1 }))[0] ?? null;
  const tierOf = async (a: Actor, code: string): Promise<TierRecord | null> => (await store.query("tier", a.tenantId, { where: [eq<"tier">("code", code)], limit: 1 }))[0] ?? null;
  async function rateFor(a: Actor, p: PartnerRecord) { return resolveRate({ agreement: await activeAgreement(a, p.id), tier: await tierOf(a, p.tier), defaultBps: (await cfg(a)).defaultCommissionBps }); }
  const mustBeActive = (p: PartnerRecord, what: string): void => { if (p.status !== "active") state(`The partner must be active to ${what}.`, { reason: "partner_not_active", status: p.status }); };

  /* ---------------- setup ---------------- */
  const setup = {
    async status(a: Actor) { need(a, "view"); return { initialized: (await store.count("setting", a.tenantId)) > 0 }; },
    async initialize(a: Actor) {
      need(a, "manage_settings");
      if ((await store.count("setting", a.tenantId)) > 0) throw new PartnersError("invalid_state", "Partners is already set up.");
      const t = now(), ops: Parameters<PartnersStore["batch"]>[0][number][] = DEFAULT_TIERS.map((x) => ({ op: "insert" as const, kind: "tier" as const, row: { id: deps.newId(), tenantId: a.tenantId, code: x.code, name: x.code, minActiveClients: x.minActiveClients, minMrrCents: x.minMrrCents, commissionBps: x.commissionBps, perks: "", updatedBy: a.userId, createdAt: t, updatedAt: t } }));
      ops.push({ op: "insert", kind: "setting", row: { id: deps.newId(), tenantId: a.tenantId, ...DEFAULTS, updatedBy: a.userId, createdAt: t, updatedAt: t } });
      await store.batch(ops);
      await rec(a, { action: "partners.program.initialized", summary: "Partner program set up", quantity: DEFAULT_TIERS.length });
      return { initialized: true };
    },
  };

  /* ---------------- partners ---------------- */
  async function setStatus(a: Actor, id: string, to: PartnerRecord["status"], from: readonly PartnerRecord["status"][], cap: Capability, label: string): Promise<PartnerRecord> {
    need(a, cap); const p = await partnerOf(a, id);
    if (!from.includes(p.status)) state(`A ${p.status} partner cannot be ${label}.`, { reason: "invalid_transition", status: p.status });
    return (await store.update("partner", a.tenantId, id, { status: to, updatedAt: now() })) as PartnerRecord;
  }
  const partners = {
    async list(a: Actor, q: unknown = {}) { need(a, "view"); const p = parse(listQuery, q); return listPage("partner", a, p, w<"partner">(p.status && eq<"partner">("status", p.status), p.kind && eq<"partner">("kind", p.kind), p.tier && eq<"partner">("tier", p.tier)), { col: "name", dir: "asc" }); },
    async get(a: Actor, id: string) {
      need(a, "view"); const p = await partnerOf(a, id), t = now();
      const [agreement, tier, clients, deals, invitations, coms] = await Promise.all([activeAgreement(a, id), tierOf(a, p.tier), scan("client", a, [eq<"client">("partnerId", id)], 2000), scan("deal", a, [eq<"deal">("partnerId", id)], 2000), scan("invitation", a, [eq<"invitation">("partnerId", id)], 100), can(a, "view_commissions") ? scan("commission", a, [eq<"commission">("partnerId", id)], 5000) : Promise.resolve([] as CommissionRecord[])]);
      const live = clients.filter((c) => c.status === "active"), sum = (st: string) => coms.filter((c) => c.status === st).reduce((s, c) => s + c.amountCents, 0);
      return {
        partner: p, agreement, tier, rate: await rateFor(a, p), clients, deals: deals.map((d) => ({ ...d, expired: (OPEN_STAGES as readonly string[]).includes(d.stage) && d.expiresAt <= t })),
        invitations: invitations.map((i) => ({ ...i, state: inviteState(i, t) })), activeClients: live.length, mrrCents: live.reduce((s, c) => s + c.mrrCents, 0),
        commissions: can(a, "view_commissions") ? { accruedCents: sum("accrued"), approvedCents: sum("approved"), paidCents: sum("paid") } : null,
      };
    },
    async create(a: Actor, input: unknown) {
      need(a, "manage_partners"); const i = parse(partnerInput, input); await guardLimit("partner", a, LIMITS.partner, "partners"); const t = now();
      const row: PartnerRecord = { id: deps.newId(), tenantId: a.tenantId, slug: i.slug, name: i.name, kind: i.kind, tier: "registered", status: "prospect", country: i.country ?? null, website: i.website ?? null, contactName: i.contactName ?? null, contactEmail: i.contactEmail ?? null, notes: i.notes, createdBy: a.userId, createdAt: t, updatedAt: t };
      await dupAs("slug", "That slug is already used.", () => store.insert("partner", row));
      await rec(a, { action: "partners.partner.created", summary: `Partner added: ${row.name}`, subjectKind: "partner", subjectId: row.id });
      return row;
    },
    async update(a: Actor, id: string, input: unknown) { need(a, "manage_partners"); const i = parse(partnerPatch, input); await partnerOf(a, id); return (await store.update("partner", a.tenantId, id, { ...i, updatedAt: now() })) as PartnerRecord; },
    async activate(a: Actor, id: string) {
      const p = await setStatus(a, id, "active", ["prospect", "invited"], "manage_partners", "activated");
      await rec(a, { action: "partners.partner.activated", summary: `Partner active: ${p.name}`, subjectKind: "partner", subjectId: id }); return p;
    },
    async suspend(a: Actor, id: string) {
      const p = await setStatus(a, id, "suspended", ["active"], "manage_partners", "suspended");
      await notify(a, "partner_suspended", "warning", id, p.name, "Partner suspended."); await rec(a, { action: "partners.partner.suspended", summary: `Partner suspended: ${p.name}`, subjectKind: "partner", subjectId: id, reversible: true, revertHint: { partnerId: id } }); return p;
    },
    async reactivate(a: Actor, id: string) {
      const p = await setStatus(a, id, "active", ["suspended"], "manage_partners", "reactivated");
      await rec(a, { action: "partners.partner.reactivated", summary: `Partner reactivated: ${p.name}`, subjectKind: "partner", subjectId: id }); return p;
    },
    async terminate(a: Actor, id: string) {
      need(a, "manage_partners"); const p = await partnerOf(a, id);
      if (p.status === "terminated") state("The partner is already terminated.", { reason: "invalid_transition" });
      const t = now(), ag = await activeAgreement(a, id), ops: Parameters<PartnersStore["batch"]>[0][number][] = [];
      if (ag) ops.push({ op: "update", kind: "agreement", tenantId: a.tenantId, id: ag.id, patch: { status: "ended", endsAt: t, updatedAt: t } });
      ops.push({ op: "update", kind: "partner", tenantId: a.tenantId, id, patch: { status: "terminated", updatedAt: t } });
      await store.batch(ops); await rec(a, { action: "partners.partner.terminated", summary: `Partner terminated: ${p.name}`, subjectKind: "partner", subjectId: id });
      return (await partnerOf(a, id));
    },
    /** `undo` marks a change made by the Activity Engine's undo, which is not itself reversible. */
    async setTier(a: Actor, id: string, input: unknown, opts: { undo?: boolean } = {}) {
      need(a, "manage_tiers"); const i = parse(tierChangeInput, input), p = await partnerOf(a, id);
      if (p.status === "terminated") state("A terminated partner has no tier.", { reason: "invalid_transition" });
      if (p.tier === i.tier) return p;
      const row = (await store.update("partner", a.tenantId, id, { tier: i.tier, updatedAt: now() })) as PartnerRecord;
      await notify(a, "tier_changed", "info", id, p.name, `${p.tier} → ${i.tier}`);
      await rec(a, { action: "partners.partner.tier_changed", summary: `${p.name}: ${p.tier} → ${i.tier}`, subjectKind: "partner", subjectId: id, ...(opts.undo ? {} : { reversible: true, revertHint: { partnerId: id, previousTier: p.tier } }) });
      return row;
    },
  };

  /* ---------------- invitations ---------------- */
  const invitations = {
    async list(a: Actor, q: unknown = {}) { need(a, "view"); const p = parse(listQuery, q); return listPage("invitation", a, p, w<"invitation">(p.status && eq<"invitation">("status", p.status), p.partnerId && eq<"invitation">("partnerId", p.partnerId))); },
    /** The code is returned ONCE; only its hash is stored. No email is sent (delivery is not connected): the person shares the code. */
    async create(a: Actor, input: unknown) {
      need(a, "manage_partners"); const i = parse(invitationInput, input), p = await partnerOf(a, i.partnerId);
      if (p.status !== "prospect" && p.status !== "invited") state("Only a prospect or an invited partner can be invited.", { reason: "invalid_transition", status: p.status });
      const t = now(), code = newInviteCode(), ops: Parameters<PartnersStore["batch"]>[0][number][] = [];
      for (const old of await scan("invitation", a, [eq<"invitation">("partnerId", p.id), eq<"invitation">("status", "pending")], 50)) ops.push({ op: "update", kind: "invitation", tenantId: a.tenantId, id: old.id, patch: { status: "revoked", updatedAt: t } });
      const row: InvitationRecord = { id: deps.newId(), tenantId: a.tenantId, partnerId: p.id, codeHash: await sha256(code), codeHint: code.slice(-4), email: i.email, status: "pending", expiresAt: t + INVITATION_DAYS * DAY_MS, acceptedAt: null, createdBy: a.userId, createdAt: t, updatedAt: t };
      ops.push({ op: "insert", kind: "invitation", row }); if (p.status === "prospect") ops.push({ op: "update", kind: "partner", tenantId: a.tenantId, id: p.id, patch: { status: "invited", updatedAt: t } });
      await store.batch(ops); await rec(a, { action: "partners.invitation.created", summary: `Invitation created for ${p.name}`, subjectKind: "partner", subjectId: p.id });
      return { invitation: row, code };
    },
    /** Marks an invitation accepted (the partner portal is not built yet, so a person records the acceptance with the code the partner returned). */
    async accept(a: Actor, input: unknown) {
      need(a, "manage_partners"); const i = parse(acceptInput, input), t = now();
      const inv = (await store.query("invitation", a.tenantId, { where: [eq<"invitation">("codeHash", await sha256(i.code))], limit: 1 }))[0];
      if (!inv) throw new PartnersError("not_found", "That code does not match any invitation.");
      const st = inviteState(inv, t); if (st !== "pending") state(`The invitation is ${st}.`, { reason: `invitation_${st}` });
      const p = await partnerOf(a, inv.partnerId); if (p.status === "terminated" || p.status === "suspended") state("The partner cannot be activated.", { reason: "invalid_transition", status: p.status });
      await store.batch([{ op: "update", kind: "invitation", tenantId: a.tenantId, id: inv.id, patch: { status: "accepted", acceptedAt: t, updatedAt: t } }, { op: "update", kind: "partner", tenantId: a.tenantId, id: p.id, patch: { status: "active", updatedAt: t } }]);
      await notify(a, "invitation_accepted", "info", p.id, p.name, "Invitation accepted."); await rec(a, { action: "partners.invitation.accepted", summary: `Invitation accepted: ${p.name}`, subjectKind: "partner", subjectId: p.id });
      return { invitation: await one("invitation", a, inv.id, "Invitation"), partner: await partnerOf(a, p.id) };
    },
    async revoke(a: Actor, id: string) {
      need(a, "manage_partners"); const inv = await one("invitation", a, id, "Invitation");
      if (inviteState(inv, now()) !== "pending") state("Only a pending invitation can be revoked.", { reason: "invalid_transition" });
      const row = (await store.update("invitation", a.tenantId, id, { status: "revoked", updatedAt: now() })) as InvitationRecord;
      await rec(a, { action: "partners.invitation.revoked", summary: "Invitation revoked", subjectKind: "partner", subjectId: inv.partnerId }); return row;
    },
  };

  /* ---------------- agreements ---------------- */
  const agreements = {
    async list(a: Actor, q: unknown = {}) { need(a, "view"); const p = parse(listQuery, q); return listPage("agreement", a, p, w<"agreement">(p.status && eq<"agreement">("status", p.status), p.partnerId && eq<"agreement">("partnerId", p.partnerId))); },
    async create(a: Actor, input: unknown) {
      need(a, "manage_agreements"); const i = parse(agreementInput, input); await partnerOf(a, i.partnerId); await guardLimit("agreement", a, LIMITS.agreement, "agreements"); const t = now();
      if (i.endsAt !== undefined && i.endsAt <= (i.startsAt ?? t)) invalid("endsAt", "The end must be after the start.");
      const row: AgreementRecord = { id: deps.newId(), tenantId: a.tenantId, partnerId: i.partnerId, label: i.label, commissionBps: i.commissionBps, recurringMonths: i.recurringMonths, startsAt: i.startsAt ?? t, endsAt: i.endsAt ?? null, status: "draft", signedBy: null, signedAt: null, createdBy: a.userId, createdAt: t, updatedAt: t };
      await store.insert("agreement", row); return row;
    },
    /** There is no e-signature provider: a person records who signed. Activating replaces the partner's current agreement. */
    async activate(a: Actor, id: string, input: unknown) {
      need(a, "manage_agreements"); const i = parse(signInput, input), ag = await one("agreement", a, id, "Agreement"), p = await partnerOf(a, ag.partnerId);
      if (ag.status !== "draft") state("Only a draft agreement can be activated.", { reason: "invalid_transition" }); mustBeActive(p, "sign an agreement");
      const t = now(), ops: Parameters<PartnersStore["batch"]>[0][number][] = [], cur = await activeAgreement(a, p.id);
      if (cur) ops.push({ op: "update", kind: "agreement", tenantId: a.tenantId, id: cur.id, patch: { status: "ended", endsAt: t, updatedAt: t } });
      ops.push({ op: "update", kind: "agreement", tenantId: a.tenantId, id, patch: { status: "active", signedBy: i.signedBy, signedAt: t, updatedAt: t } });
      await store.batch(ops); await rec(a, { action: "partners.agreement.activated", summary: `Agreement active for ${p.name}: ${ag.commissionBps / 100}%`, subjectKind: "partner", subjectId: p.id });
      return one("agreement", a, id, "Agreement");
    },
    async end(a: Actor, id: string) {
      need(a, "manage_agreements"); const ag = await one("agreement", a, id, "Agreement");
      if (ag.status !== "active") state("Only an active agreement can be ended.", { reason: "invalid_transition" });
      const t = now(), row = (await store.update("agreement", a.tenantId, id, { status: "ended", endsAt: t, updatedAt: t })) as AgreementRecord;
      await rec(a, { action: "partners.agreement.ended", summary: "Agreement ended", subjectKind: "partner", subjectId: ag.partnerId }); return row;
    },
  };

  /* ---------------- tiers ---------------- */
  const rank = (c: string) => TIER_CODES.indexOf(c as (typeof TIER_CODES)[number]);
  async function suggestions(a: Actor) {
    const tiers = await scan("tier", a, [], 10), ps = await scan("partner", a, [eq<"partner">("status", "active")], LIMITS.partner), cs = await scan("client", a, [eq<"client">("status", "active")], LIMITS.client);
    return ps.map((p) => {
      const mine = cs.filter((c) => c.partnerId === p.id), activeClients = mine.length, mrrCents = mine.reduce((s, c) => s + c.mrrCents, 0), suggested = evaluateTier(tiers, activeClients, mrrCents);
      return { partnerId: p.id, name: p.name, current: p.tier, suggested, activeClients, mrrCents, direction: rank(suggested) > rank(p.tier) ? ("up" as const) : rank(suggested) < rank(p.tier) ? ("down" as const) : ("same" as const) };
    }).sort((x, y) => x.name.localeCompare(y.name));
  }
  const tiers = {
    async list(a: Actor) { need(a, "view"); return { items: (await scan("tier", a, [], 10)).sort((x, y) => rank(x.code) - rank(y.code)) }; },
    async update(a: Actor, id: string, input: unknown) { need(a, "manage_tiers"); const i = parse(tierPatch, input); await one("tier", a, id, "Tier"); return (await store.update("tier", a.tenantId, id, { ...i, updatedBy: a.userId, updatedAt: now() })) as TierRecord; },
    /** Read only: who would change tier under the current rules. */
    async evaluate(a: Actor) { need(a, "view"); return { items: await suggestions(a) }; },
    /** Applies the evaluation to every active partner (a person decides to run it). */
    async apply(a: Actor) {
      need(a, "manage_tiers"); const changes = (await suggestions(a)).filter((s) => s.direction !== "same"), t = now();
      if (changes.length) await store.batch(changes.map((s) => ({ op: "update" as const, kind: "partner" as const, tenantId: a.tenantId, id: s.partnerId, patch: { tier: s.suggested, updatedAt: t } })));
      for (const s of changes) await notify(a, "tier_changed", "info", s.partnerId, s.name, `${s.current} → ${s.suggested}`);
      if (changes.length) await rec(a, { action: "partners.tier.reviewed", summary: `Tiers reviewed: ${changes.length} changed`, quantity: changes.length });
      return { changed: changes.length, items: changes };
    },
  };

  /* ---------------- clients ---------------- */
  const clients = {
    async list(a: Actor, q: unknown = {}) { need(a, "view"); const p = parse(listQuery, q); return listPage("client", a, p, w<"client">(p.status && eq<"client">("status", p.status), p.partnerId && eq<"client">("partnerId", p.partnerId))); },
    async get(a: Actor, id: string) { need(a, "view"); const c = await one("client", a, id, "Client"); return { client: c, partner: await store.get("partner", a.tenantId, c.partnerId), commissions: can(a, "view_commissions") ? await scan("commission", a, [eq<"commission">("clientId", id)], 500) : [] }; },
    async create(a: Actor, input: unknown) {
      need(a, "manage_clients"); const i = parse(clientInput, input), p = await partnerOf(a, i.partnerId); mustBeActive(p, "register a client"); await guardLimit("client", a, LIMITS.client, "clients");
      const key = clientKey(i.name); if (key.length < 2) invalid("name", "Use a name with letters or numbers.");
      const rival = (await store.query("deal", a.tenantId, { where: [eq<"deal">("clientKey", key), { col: "stage", op: "in", value: OPEN_STAGES }], limit: 5 })).find((d) => d.partnerId !== p.id && d.expiresAt > now());
      if (rival) state("Another partner has this client registered.", { reason: "client_protected", partnerId: rival.partnerId });
      const t = now(), st = i.status, row: ClientRecord = { id: deps.newId(), tenantId: a.tenantId, partnerId: p.id, name: i.name, clientKey: key, plan: i.plan, status: st, mrrCents: i.mrrCents, currency: (await cfg(a)).currency, startedAt: i.startedAt ?? (st === "active" || st === "trial" ? t : null), endedAt: st === "churned" ? t : null, createdBy: a.userId, createdAt: t, updatedAt: t };
      await dupAs("name", "This client already exists in the program.", () => store.insert("client", row));
      await rec(a, { action: "partners.client.created", summary: `Client added: ${row.name} (${p.name})`, subjectKind: "client", subjectId: row.id }); return row;
    },
    async update(a: Actor, id: string, input: unknown) {
      need(a, "manage_clients"); const i = parse(clientPatch, input), c = await one("client", a, id, "Client"), t = now(), patch: Partial<ClientRecord> = { ...i, updatedAt: t };
      if (i.status && i.status !== c.status) { if ((i.status === "active" || i.status === "trial") && c.startedAt === null) patch.startedAt = t; patch.endedAt = i.status === "churned" ? t : null; }
      const row = (await store.update("client", a.tenantId, id, patch)) as ClientRecord;
      if (i.status && i.status !== c.status) await rec(a, { action: "partners.client.status_changed", summary: `${c.name}: ${c.status} → ${i.status}`, subjectKind: "client", subjectId: id });
      return row;
    },
  };

  /* ---------------- deals (registration protects a client while it is open) ---------------- */
  const isOpen = (d: DealRecord) => (OPEN_STAGES as readonly string[]).includes(d.stage);
  const dealView = (d: DealRecord, t: number) => ({ ...d, expired: isOpen(d) && d.expiresAt <= t });
  const deals = {
    async list(a: Actor, q: unknown = {}) { need(a, "view"); const p = parse(listQuery, q), t = now(), pg = await listPage("deal", a, p, w<"deal">(p.stage && eq<"deal">("stage", p.stage), p.partnerId && eq<"deal">("partnerId", p.partnerId))); return { ...pg, items: pg.items.map((d) => dealView(d, t)) }; },
    async register(a: Actor, input: unknown) {
      need(a, "manage_deals"); const i = parse(dealInput, input), p = await partnerOf(a, i.partnerId); mustBeActive(p, "register a deal"); await guardLimit("deal", a, LIMITS.deal, "deals");
      const key = clientKey(i.clientName); if (key.length < 2) invalid("clientName", "Use a name with letters or numbers.");
      if ((await store.query("client", a.tenantId, { where: [eq<"client">("clientKey", key)], limit: 1 })).length) state("That client already exists in the program.", { reason: "client_exists" });
      const t = now(), open = (await store.query("deal", a.tenantId, { where: [eq<"deal">("clientKey", key), { col: "stage", op: "in", value: OPEN_STAGES }], limit: 1 }))[0];
      const ops: Parameters<PartnersStore["batch"]>[0][number][] = [];
      if (open) { if (open.expiresAt > t) state("This client is already registered by a partner.", { reason: "client_protected", partnerId: open.partnerId }); ops.push({ op: "update", kind: "deal", tenantId: a.tenantId, id: open.id, patch: { stage: "lost", closedAt: t, updatedAt: t } }); }
      const s = await cfg(a), row: DealRecord = { id: deps.newId(), tenantId: a.tenantId, partnerId: p.id, clientName: i.clientName, clientKey: key, valueCents: i.valueCents, currency: s.currency, stage: "registered", expiresAt: t + s.dealProtectionDays * DAY_MS, notes: i.notes, clientId: null, closedAt: null, createdBy: a.userId, createdAt: t, updatedAt: t };
      ops.push({ op: "insert", kind: "deal", row }); await dupAs("clientName", "This client is already registered by a partner.", () => store.batch(ops));
      await notify(a, "deal_registered", "info", row.id, row.clientName, p.name); await rec(a, { action: "partners.deal.registered", summary: `Deal registered: ${row.clientName} (${p.name})`, subjectKind: "deal", subjectId: row.id }); return dealView(row, t);
    },
    async update(a: Actor, id: string, input: unknown) { need(a, "manage_deals"); const i = parse(dealPatch, input), d = await one("deal", a, id, "Deal"); if (!isOpen(d)) state("Only an open deal can be edited.", { reason: "invalid_transition" }); return dealView((await store.update("deal", a.tenantId, id, { ...i, updatedAt: now() })) as DealRecord, now()); },
    async qualify(a: Actor, id: string) {
      need(a, "manage_deals"); const d = await one("deal", a, id, "Deal"); if (d.stage !== "registered") state("Only a registered deal can be qualified.", { reason: "invalid_transition" }); if (d.expiresAt <= now()) state("The registration expired.", { reason: "deal_expired" });
      return dealView((await store.update("deal", a.tenantId, id, { stage: "qualified", updatedAt: now() })) as DealRecord, now());
    },
    /** Winning a deal creates the client (as a lead) under the same partner. */
    async win(a: Actor, id: string) {
      need(a, "manage_deals"); const d = await one("deal", a, id, "Deal"), t = now(), p = await partnerOf(a, d.partnerId);
      if (!isOpen(d)) state("Only an open deal can be won.", { reason: "invalid_transition" }); if (d.expiresAt <= t) state("The registration expired.", { reason: "deal_expired" }); mustBeActive(p, "win a deal");
      const client: ClientRecord = { id: deps.newId(), tenantId: a.tenantId, partnerId: p.id, name: d.clientName, clientKey: d.clientKey, plan: "", status: "lead", mrrCents: 0, currency: d.currency, startedAt: null, endedAt: null, createdBy: a.userId, createdAt: t, updatedAt: t };
      await dupAs("clientName", "This client already exists in the program.", () => store.batch([{ op: "update", kind: "deal", tenantId: a.tenantId, id, patch: { stage: "won", clientId: client.id, closedAt: t, updatedAt: t } }, { op: "insert", kind: "client", row: client }].reverse() as never));
      await notify(a, "deal_won", "info", id, d.clientName, p.name); await rec(a, { action: "partners.deal.won", summary: `Deal won: ${d.clientName} (${p.name})`, subjectKind: "deal", subjectId: id });
      return { deal: dealView(await one("deal", a, id, "Deal"), t), client };
    },
    async lose(a: Actor, id: string) {
      need(a, "manage_deals"); const d = await one("deal", a, id, "Deal"); if (!isOpen(d)) state("Only an open deal can be lost.", { reason: "invalid_transition" });
      const t = now(), row = (await store.update("deal", a.tenantId, id, { stage: "lost", closedAt: t, updatedAt: t })) as DealRecord;
      await rec(a, { action: "partners.deal.lost", summary: `Deal lost: ${d.clientName}`, subjectKind: "deal", subjectId: id }); return dealView(row, t);
    },
  };

  /* ---------------- commissions (a ledger of what is owed; nothing is paid for real) ---------------- */
  const monthIndex = (t: number) => { const d = new Date(t); return d.getUTCFullYear() * 12 + d.getUTCMonth(); };
  const commissions = {
    async get(a: Actor, id: string) { need(a, "view_commissions"); return one("commission", a, id, "Commission"); },
    async list(a: Actor, q: unknown = {}) { need(a, "view_commissions"); const p = parse(listQuery, q); return listPage("commission", a, p, w<"commission">(p.status && eq<"commission">("status", p.status), p.partnerId && eq<"commission">("partnerId", p.partnerId), p.clientId && eq<"commission">("clientId", p.clientId), p.period && eq<"commission">("period", p.period), p.payoutId && eq<"commission">("payoutId", p.payoutId))); },
    /** Accrues one commission per active client of each active partner for a month. Running it twice for the same month creates nothing new. */
    async accrue(a: Actor, input: unknown) {
      need(a, "approve_commissions"); const i = parse(accrueInput, input), t = now();
      if (i.period > periodOf(t)) invalid("period", "The period cannot be in the future.");
      const [y, m] = i.period.split("-").map(Number) as [number, number], periodStart = Date.UTC(y, m - 1, 1), periodEnd = Date.UTC(y, m, 1) - 1, s = await cfg(a);
      const ps = i.partnerId ? [await partnerOf(a, i.partnerId)] : await scan("partner", a, [eq<"partner">("status", "active")], LIMITS.partner);
      let created = 0, skipped = 0, total = 0;
      for (const p of ps.filter((x) => x.status === "active")) {
        const ag = await activeAgreement(a, p.id), rate = resolveRate({ agreement: ag, tier: await tierOf(a, p.tier), defaultBps: s.defaultCommissionBps }), window = ag?.recurringMonths ?? 12;
        const ops: Parameters<PartnersStore["batch"]>[0][number][] = [];
        for (const c of await scan("client", a, [eq<"client">("partnerId", p.id), eq<"client">("status", "active")], 2000)) {
          const started = c.startedAt ?? c.createdAt;
          if (c.mrrCents <= 0 || started > periodEnd || monthIndex(periodStart) - monthIndex(started) >= window) { skipped++; continue; }
          if ((await store.count("commission", a.tenantId, [eq<"commission">("clientId", c.id), eq<"commission">("period", i.period)])) > 0) { skipped++; continue; }
          const amount = commissionAmount(c.mrrCents, rate.bps);
          ops.push({ op: "insert", kind: "commission", row: { id: deps.newId(), tenantId: a.tenantId, partnerId: p.id, clientId: c.id, period: i.period, baseCents: c.mrrCents, rateBps: rate.bps, amountCents: amount, currency: c.currency, rateSource: rate.source, status: "accrued", payoutId: null, approvedAt: null, paidAt: null, reversedAt: null, createdBy: a.userId, createdAt: t, updatedAt: t } });
          created++; total += amount;
        }
        if (ops.length) await store.batch(ops);
      }
      if (created) await rec(a, { action: "partners.commission.accrued", summary: `Commissions accrued for ${i.period}: ${created}`, quantity: created });
      return { period: i.period, created, skipped, totalCents: total };
    },
    async approve(a: Actor, id: string) {
      need(a, "approve_commissions"); const c = await one("commission", a, id, "Commission"); if (c.status !== "accrued") state("Only an accrued commission can be approved.", { reason: "invalid_transition", status: c.status });
      const t = now(), row = (await store.update("commission", a.tenantId, id, { status: "approved", approvedAt: t, updatedAt: t })) as CommissionRecord;
      await notify(a, "commission_approved", "info", id, "", `${c.amountCents}`); await rec(a, { action: "partners.commission.approved", summary: `Commission approved (${(c.amountCents / 100).toFixed(2)} ${c.currency})`, subjectKind: "commission", subjectId: id, reversible: true, revertHint: { commissionId: id } }); return row;
    },
    /** Approves every accrued commission that matches (a person decides to run it). */
    async approveAll(a: Actor, input: unknown = {}) {
      need(a, "approve_commissions"); const i = parse(accrueInput.partial(), input), rows = await scan("commission", a, w<"commission">(eq<"commission">("status", "accrued"), i.partnerId && eq<"commission">("partnerId", i.partnerId), i.period && eq<"commission">("period", i.period)), 500), t = now();
      if (rows.length) { await store.batch(rows.map((c) => ({ op: "update" as const, kind: "commission" as const, tenantId: a.tenantId, id: c.id, patch: { status: "approved" as const, approvedAt: t, updatedAt: t } }))); await rec(a, { action: "partners.commission.approved_batch", summary: `Commissions approved: ${rows.length}`, quantity: rows.length }); }
      return { approved: rows.length, totalCents: rows.reduce((s, c) => s + c.amountCents, 0) };
    },
    /** Back to accrued, while it is not in a payout. */
    async unapprove(a: Actor, id: string) {
      need(a, "approve_commissions"); const c = await one("commission", a, id, "Commission"); if (c.status !== "approved" || c.payoutId) state("Only an approved commission outside a payout can be unapproved.", { reason: "invalid_transition", status: c.status });
      return (await store.update("commission", a.tenantId, id, { status: "accrued", approvedAt: null, updatedAt: now() })) as CommissionRecord;
    },
    async reverse(a: Actor, id: string) {
      need(a, "approve_commissions"); const c = await one("commission", a, id, "Commission"); if ((c.status !== "accrued" && c.status !== "approved") || c.payoutId) state("Only an accrued or approved commission outside a payout can be reversed.", { reason: "invalid_transition", status: c.status });
      const t = now(), row = (await store.update("commission", a.tenantId, id, { status: "reversed", reversedAt: t, updatedAt: t })) as CommissionRecord;
      await rec(a, { action: "partners.commission.reversed", summary: "Commission reversed", subjectKind: "commission", subjectId: id }); return row;
    },
  };

  /* ---------------- payouts (simulated: no payout provider is connected) ---------------- */
  const payouts = {
    async list(a: Actor, q: unknown = {}) { need(a, "view_commissions"); const p = parse(listQuery, q); return listPage("payout", a, p, w<"payout">(p.status && eq<"payout">("status", p.status), p.partnerId && eq<"payout">("partnerId", p.partnerId))); },
    async get(a: Actor, id: string) { need(a, "view_commissions"); const payout = await one("payout", a, id, "Payout"); return { payout, partner: await store.get("partner", a.tenantId, payout.partnerId), commissions: await scan("commission", a, [eq<"commission">("payoutId", id)], 500) }; },
    async create(a: Actor, input: unknown) {
      need(a, "manage_payouts"); const i = parse(payoutInput, input), p = await partnerOf(a, i.partnerId), due = await scan("commission", a, [eq<"commission">("partnerId", p.id), eq<"commission">("status", "approved"), { col: "payoutId", op: "null" }], 200);
      if (!due.length) state("There are no approved commissions to pay.", { reason: "nothing_to_pay" });
      if (new Set(due.map((c) => c.currency)).size > 1) state("The commissions use different currencies.", { reason: "mixed_currency" });
      const t = now(), total = due.reduce((s, c) => s + c.amountCents, 0);
      let seq = (await store.count("payout", a.tenantId)) + 1;
      for (let tries = 0; ; tries++) {
        const row: PayoutRecord = { id: deps.newId(), tenantId: a.tenantId, partnerId: p.id, number: payoutNumber(t, seq), status: "draft", currency: due[0]!.currency, totalCents: total, itemCount: due.length, mode: "not_connected", paidAt: null, cancelledAt: null, createdBy: a.userId, createdAt: t, updatedAt: t };
        try { await store.batch([{ op: "insert", kind: "payout", row }, ...due.map((c) => ({ op: "update" as const, kind: "commission" as const, tenantId: a.tenantId, id: c.id, patch: { payoutId: row.id, updatedAt: t } }))]); await rec(a, { action: "partners.payout.created", summary: `Payout ${row.number} created for ${p.name}`, subjectKind: "payout", subjectId: row.id, quantity: due.length }); return row; }
        catch (e) { if ((e as { code?: string }).code !== "duplicate" || tries >= 5) throw e; seq++; }
      }
    },
    /** Marks the payout paid. Simulated: no provider is contacted and no money moves. */
    async pay(a: Actor, id: string) {
      need(a, "manage_payouts"); const po = await one("payout", a, id, "Payout"); if (po.status !== "draft") state("Only a draft payout can be paid.", { reason: "invalid_transition", status: po.status });
      const t = now(), items = await scan("commission", a, [eq<"commission">("payoutId", id)], 500);
      await store.batch([{ op: "update", kind: "payout", tenantId: a.tenantId, id, patch: { status: "paid", mode: "simulated", paidAt: t, updatedAt: t } }, ...items.map((c) => ({ op: "update" as const, kind: "commission" as const, tenantId: a.tenantId, id: c.id, patch: { status: "paid" as const, paidAt: t, updatedAt: t } }))]);
      await notify(a, "payout_paid", "info", id, po.number, "Simulated"); await rec(a, { action: "partners.payout.paid", summary: `Payout ${po.number} marked paid (simulated)`, subjectKind: "payout", subjectId: id, quantity: items.length, mode: "simulation" });
      return one("payout", a, id, "Payout");
    },
    async cancel(a: Actor, id: string) {
      need(a, "manage_payouts"); const po = await one("payout", a, id, "Payout"); if (po.status !== "draft") state("Only a draft payout can be cancelled.", { reason: "invalid_transition", status: po.status });
      const t = now(), items = await scan("commission", a, [eq<"commission">("payoutId", id)], 500);
      await store.batch([{ op: "update", kind: "payout", tenantId: a.tenantId, id, patch: { status: "cancelled", cancelledAt: t, updatedAt: t } }, ...items.map((c) => ({ op: "update" as const, kind: "commission" as const, tenantId: a.tenantId, id: c.id, patch: { payoutId: null, updatedAt: t } }))]);
      await rec(a, { action: "partners.payout.cancelled", summary: `Payout ${po.number} cancelled`, subjectKind: "payout", subjectId: id }); return one("payout", a, id, "Payout");
    },
  };

  /* ---------------- notifications, settings ---------------- */
  const notifications = {
    async list(a: Actor, q: unknown = {}) { need(a, "view"); const p = parse(listQuery, q); return listPage("notification", a, p, w<"notification">(p.kind && eq<"notification">("kind", p.kind), p.unread === "1" && { col: "readAt", op: "null" })); },
    async unread(a: Actor) { need(a, "view"); return { count: await store.count("notification", a.tenantId, [{ col: "readAt", op: "null" }]) }; },
    async markRead(a: Actor, id: string) { need(a, "view"); const n = await one("notification", a, id, "Notification"); return n.readAt ? n : ((await store.update("notification", a.tenantId, id, { readAt: now() })) as NotificationRecord); },
    async markAllRead(a: Actor) { need(a, "view"); const t = now(), un = await scan("notification", a, [{ col: "readAt", op: "null" }], 2000); for (const n of un) await store.update("notification", a.tenantId, n.id, { readAt: t }); return { updated: un.length }; },
  };
  const settingsApi = {
    async get(a: Actor) { need(a, "view"); return cfg(a); },
    async update(a: Actor, input: unknown) {
      need(a, "manage_settings"); const i = parse(settingsPatch, input), cur = await cfg(a);
      if (!cur.id) throw new PartnersError("invalid_state", "Set up Partners first.");
      return (await store.update("setting", a.tenantId, cur.id, { ...i, updatedBy: a.userId, updatedAt: now() })) as SettingRecord;
    },
  };

  /* ---------------- summary ---------------- */
  async function summary(a: Actor) {
    need(a, "view"); const initialized = (await store.count("setting", a.tenantId)) > 0, t = now();
    if (!initialized) return { initialized, partners: 0, active: 0, pipeline: 0, suspended: 0, activeClients: 0, mrrCents: 0, openDeals: 0, dealsExpiring: 0, pendingInvitations: 0, accruedCents: null as number | null, approvedCents: null as number | null, draftPayouts: 0, unread: 0, top: [] as { id: string; name: string; mrrCents: number; activeClients: number }[] };
    const pc = (st: string) => store.count("partner", a.tenantId, [eq<"partner">("status", st)]);
    const [total, active, prospect, invited, suspended, unread, draftPayouts, cs, openDeals, invs] = await Promise.all([
      store.count("partner", a.tenantId), pc("active"), pc("prospect"), pc("invited"), pc("suspended"), store.count("notification", a.tenantId, [{ col: "readAt", op: "null" }]), can(a, "view_commissions") ? store.count("payout", a.tenantId, [eq<"payout">("status", "draft")]) : Promise.resolve(0),
      scan("client", a, [eq<"client">("status", "active")], LIMITS.client), scan("deal", a, [{ col: "stage", op: "in", value: OPEN_STAGES }], LIMITS.deal), scan("invitation", a, [eq<"invitation">("status", "pending")], 1000),
    ]);
    const live = openDeals.filter((d) => d.expiresAt > t), names = new Map((await scan("partner", a, [eq<"partner">("status", "active")], LIMITS.partner)).map((p) => [p.id, p.name]));
    const by = new Map<string, { id: string; name: string; mrrCents: number; activeClients: number }>(); for (const c of cs) { const g = by.get(c.partnerId) ?? { id: c.partnerId, name: names.get(c.partnerId) ?? "—", mrrCents: 0, activeClients: 0 }; g.mrrCents += c.mrrCents; g.activeClients++; by.set(c.partnerId, g); }
    const money = can(a, "view_commissions"), owed = async (st: string) => (await scan("commission", a, [eq<"commission">("status", st)], 5000)).reduce((s, c) => s + c.amountCents, 0);
    return {
      initialized, partners: total, active, pipeline: prospect + invited, suspended, activeClients: cs.length, mrrCents: cs.reduce((s, c) => s + c.mrrCents, 0), openDeals: live.length, dealsExpiring: live.filter((d) => d.expiresAt - t <= 7 * DAY_MS).length,
      pendingInvitations: invs.filter((i) => inviteState(i, t) === "pending").length, accruedCents: money ? await owed("accrued") : null, approvedCents: money ? await owed("approved") : null, draftPayouts, unread, top: [...by.values()].sort((x, y) => y.mrrCents - x.mrrCents).slice(0, 5),
    };
  }

  /* ---------------- AI Partner Manager (read only; goes through the AI Kernel port) ---------------- */
  async function factsFor(a: Actor, topic: (typeof AI_TOPICS)[number], i: { partnerId?: string }): Promise<Record<string, unknown>> {
    const t = now(), base = { topic, notice: "Payouts are simulated: no payout provider is connected and no money moves." };
    const [ps, cs, ds] = await Promise.all([scan("partner", a, [], LIMITS.partner), scan("client", a, [], LIMITS.client), scan("deal", a, [], LIMITS.deal)]);
    const name = new Map(ps.map((p) => [p.id, p.name])), live = cs.filter((c) => c.status === "active"), pview = (p: PartnerRecord) => ({ id: p.id, name: p.name, kind: p.kind, tier: p.tier, status: p.status, country: p.country });
    if (topic === "recommend_tier_changes") return { ...base, tiers: (await tiers.list(a)).items.map((x) => ({ code: x.code, minActiveClients: x.minActiveClients, minMrrCents: x.minMrrCents, commissionBps: x.commissionBps })), partners: (await suggestions(a)) };
    if (topic === "find_at_risk_partners") {
      const cutoff = t - 90 * DAY_MS;
      return { ...base, partners: ps.filter((p) => p.status === "active" || p.status === "suspended").map((p) => {
        const mine = cs.filter((c) => c.partnerId === p.id), md = ds.filter((d) => d.partnerId === p.id);
        return { ...pview(p), activeClients: mine.filter((c) => c.status === "active").length, churnedClients: mine.filter((c) => c.status === "churned").length, newClients90d: mine.filter((c) => c.createdAt >= cutoff).length, newDeals90d: md.filter((d) => d.createdAt >= cutoff).length, expiredRegistrations: md.filter((d) => isOpen(d) && d.expiresAt <= t).length };
      }) };
    }
    if (topic === "explain_partner") {
      if (!i.partnerId) invalid("partnerId", "Choose a partner to explain."); const d = await partners.get(a, i.partnerId as string);
      return { ...base, partner: pview(d.partner), rate: d.rate, agreement: d.agreement && { label: d.agreement.label, commissionBps: d.agreement.commissionBps, recurringMonths: d.agreement.recurringMonths }, activeClients: d.activeClients, mrrCents: d.mrrCents, clients: d.clients.slice(0, 15).map((c) => ({ name: c.name, status: c.status, mrrCents: c.mrrCents })), deals: d.deals.slice(0, 10).map((x) => ({ client: x.clientName, stage: x.stage, valueCents: x.valueCents, expired: x.expired })), commissions: d.commissions };
    }
    if (topic === "detect_opportunities") {
      const sg = await suggestions(a), ags = await scan("agreement", a, [eq<"agreement">("status", "active")], 5000), invs = await scan("invitation", a, [eq<"invitation">("status", "pending")], 1000), approved = await scan("commission", a, [eq<"commission">("status", "approved"), { col: "payoutId", op: "null" }], 5000);
      return { ...base, prospectsNotInvited: ps.filter((p) => p.status === "prospect").map((p) => p.name), invitationsWaiting: invs.map((x) => ({ partner: name.get(x.partnerId) ?? x.partnerId, daysWaiting: Math.floor((t - x.createdAt) / DAY_MS), expired: inviteState(x, t) === "expired" })), activeWithoutAgreement: ps.filter((p) => p.status === "active" && !ags.some((x) => x.partnerId === p.id)).map((p) => p.name), activeWithoutClients: ps.filter((p) => p.status === "active" && !live.some((c) => c.partnerId === p.id)).map((p) => p.name), dealsExpiringSoon: ds.filter((d) => isOpen(d) && d.expiresAt > t && d.expiresAt - t <= 7 * DAY_MS).map((d) => ({ client: d.clientName, partner: name.get(d.partnerId) ?? d.partnerId, daysLeft: Math.ceil((d.expiresAt - t) / DAY_MS) })), approvedNotPaidCents: approved.reduce((s, c) => s + c.amountCents, 0), readyForHigherTier: sg.filter((s) => s.direction === "up") };
    }
    if (topic === "forecast_commissions") {
      const s = await cfg(a), rows: { partner: string; expectedCents: number; clients: number; rateBps: number }[] = [];
      for (const p of ps.filter((x) => x.status === "active")) { const r = await rateFor(a, p), ag = await activeAgreement(a, p.id), win = ag?.recurringMonths ?? 12, nextStart = Date.UTC(new Date(t).getUTCFullYear(), new Date(t).getUTCMonth() + 1, 1), mine = live.filter((c) => c.partnerId === p.id && c.mrrCents > 0 && monthIndex(nextStart) - monthIndex(c.startedAt ?? c.createdAt) < win); rows.push({ partner: p.name, expectedCents: mine.reduce((x, c) => x + commissionAmount(c.mrrCents, r.bps), 0), clients: mine.length, rateBps: r.bps }); }
      const approved = await scan("commission", a, [eq<"commission">("status", "approved")], 5000), accrued = await scan("commission", a, [eq<"commission">("status", "accrued")], 5000);
      return { ...base, nextPeriod: periodOf(Date.UTC(new Date(t).getUTCFullYear(), new Date(t).getUTCMonth() + 1, 1)), currency: s.currency, expected: rows, expectedTotalCents: rows.reduce((x, r) => x + r.expectedCents, 0), approvedUnpaidCents: approved.reduce((x, c) => x + c.amountCents, 0), accruedNotApprovedCents: accrued.reduce((x, c) => x + c.amountCents, 0) };
    }
    const sm = await summary(a), cur = t - 30 * DAY_MS;
    return { ...base, summary: sm, last30Days: { newPartners: ps.filter((p) => p.createdAt >= cur).length, newClients: cs.filter((c) => c.createdAt >= cur).length, dealsWon: ds.filter((d) => d.stage === "won" && (d.closedAt ?? 0) >= cur).length, dealsLost: ds.filter((d) => d.stage === "lost" && (d.closedAt ?? 0) >= cur).length } };
  }
  const ai = {
    async run(a: Actor, topic: (typeof AI_TOPICS)[number], input: unknown = {}): Promise<AdvisorResult> {
      need(a, "use_ai"); if (!AI_TOPICS.includes(topic)) invalid("topic", "Unknown topic."); const i = parse(aiInput, input);
      if ((await cfg(a)).aiEnabled === false) throw new PartnersError("invalid_state", "The Partner Manager AI is turned off in settings.");
      if (!deps.ai) throw new PartnersError("unavailable", "AI services are not configured.");
      const facts = await factsFor(a, topic, i), lang = i.lang === "es" ? "Answer in Spanish." : "Answer in English.";
      const r = await deps.ai.generate(a, { task: "reason", system: SYSTEM, user: `${INSTRUCTION[topic]}\n${lang}${i.question ? `\nThe person also asks: ${i.question}` : ""}\n\nFACTS (JSON):\n${JSON.stringify(facts)}`, maxOutputTokens: 700, temperature: 0.2 });
      return r.ok ? { ok: true, text: r.text, provider: r.provider, model: r.model, facts } : { ...r, facts };
    },
  };

  const permissions = { async mine(a: Actor) { return { role: a.role, capabilities: (["view", "manage_partners", "manage_agreements", "manage_deals", "manage_clients", "view_commissions", "approve_commissions", "manage_payouts", "manage_tiers", "use_ai", "manage_settings"] as Capability[]).filter((c) => can(a, c)) }; } };
  return { setup, summary, permissions, partners, invitations, agreements, tiers, clients, deals, commissions, payouts, notifications, settings: settingsApi, ai };
}
export type PartnersService = ReturnType<typeof createPartnersService>;
