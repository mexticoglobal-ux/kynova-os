import { getActivitySink } from "@/platform/activity";
import { kernelPartnersAi } from "./ai";
import { getPartnersStore } from "./runtime";
import { createPartnersService, type PartnersService } from "./service";

/** Composition root: the store is resolved per request (the D1 binding only exists inside a request), everything else is stateless. Evidence goes to the Activity Engine through its sink. */
export async function getPartnersService(): Promise<PartnersService> {
  return createPartnersService({ store: await getPartnersStore(), newId: () => crypto.randomUUID().replace(/-/g, ""), ai: kernelPartnersAi, activity: await getActivitySink("partners") });
}
