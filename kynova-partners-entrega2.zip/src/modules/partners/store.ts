import type { AgreementRecord, ClientRecord, CommissionRecord, DealRecord, InvitationRecord, NotificationRecord, PartnerRecord, PayoutRecord, SettingRecord, TierRecord } from "./domain";

/** Record kinds the store persists (one table each). */
export interface KindMap { partner: PartnerRecord; invitation: InvitationRecord; agreement: AgreementRecord; tier: TierRecord; client: ClientRecord; deal: DealRecord; commission: CommissionRecord; payout: PayoutRecord; notification: NotificationRecord; setting: SettingRecord }
export type Kind = keyof KindMap;
export type Col<K extends Kind> = keyof KindMap[K] & string;
export type Cond<K extends Kind> =
  | { col: Col<K>; op: "eq" | "ne"; value: string | number | boolean }
  | { col: Col<K>; op: "in"; value: readonly string[] }
  | { col: Col<K>; op: "gte" | "lte"; value: number }
  | { col: Col<K>; op: "null" | "notnull" };
export interface QuerySpec<K extends Kind> {
  where?: readonly Cond<K>[];
  /** Case-insensitive substring match on any of the columns. */
  search?: { cols: readonly Col<K>[]; text: string };
  /** Defaults to createdAt desc. The id is always the tiebreaker, in the same direction. */
  orderBy?: { col: Col<K>; dir: "asc" | "desc" };
  limit: number;
  /** Keyset cursor: continue after this (sort value, id). */
  after?: { value: string | number; id: string };
}
export type WriteOp = { op: "insert"; kind: Kind; row: KindMap[Kind] } | { op: "update"; kind: Kind; tenantId: string; id: string; patch: Partial<KindMap[Kind]> };

/** Persistence port. EVERY method takes the tenant id and the implementation must scope every statement by it. Two implementations: D1 (production) and in-memory (local development and unit tests). */
export interface PartnersStore {
  insert<K extends Kind>(kind: K, row: KindMap[K]): Promise<void>;
  get<K extends Kind>(kind: K, tenantId: string, id: string): Promise<KindMap[K] | null>;
  update<K extends Kind>(kind: K, tenantId: string, id: string, patch: Partial<KindMap[K]>): Promise<KindMap[K] | null>;
  query<K extends Kind>(kind: K, tenantId: string, spec: QuerySpec<K>): Promise<KindMap[K][]>;
  count<K extends Kind>(kind: K, tenantId: string, where?: readonly Cond<K>[]): Promise<number>;
  /** Hard delete, allowed only for the kinds in REMOVABLE (none today). */
  remove(kind: Kind, tenantId: string, id: string): Promise<boolean>;
  batch(ops: readonly WriteOp[]): Promise<void>;
}
