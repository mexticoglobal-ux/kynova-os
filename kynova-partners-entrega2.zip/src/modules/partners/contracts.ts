/** Honest status of every part that is not fully working yet; the UI and the docs read it. */
export const ARCHITECTURE_STATUS = {
  payouts: "simulated_only", payout_provider: "not_connected", partner_portal: "not_built", e_signature: "not_connected", invitation_delivery: "not_connected", cross_company_linking: "not_implemented", renewal_scheduler: "not_implemented", ai_actions: "never_executed",
} as const;
