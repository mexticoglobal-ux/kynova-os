import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES, canAccess } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { ARCHITECTURE_STATUS } from "../../../src/modules/team/contracts";
import { TEAM_DICTIONARIES } from "../../../src/modules/team/i18n";
import { allows } from "../../../src/modules/team/access";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => { try { return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; }); } catch { return []; } };
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "team");
const bad = (dirs: string[], re: RegExp, skip: string[] = []) => dirs.flatMap((d) => files(d)).filter((f) => !skip.some((s) => f.endsWith(s))).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "team"), join(SRC, "app", "(app)", "app", "team")];
const OTHERS = "crm|marketing|seo|ai-studio|finance|communications|billing|security|analytics|analytics-bi|mission-control|integrations|marketplace|partners|referrals|portal|activation";

describe("Team module boundaries", () => {
  it("owns no storage: no SQL, no migration, no tables; only server.ts reads the plan through the database public index", () => {
    expect(bad([MOD], /drizzle-orm|ai-kernel/)).toEqual([]);
    expect(bad([MOD], /platform\/db/, ["server.ts"])).toEqual([]);
    expect(bad([MOD], /platform\/db\/(?!$)/)).toEqual([]);
    expect(files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8")))).toEqual([]);
    expect(existsSync(join(process.cwd(), "drizzle/migrations"))).toBe(true);
    expect(readdirSync(join(process.cwd(), "drizzle/migrations")).filter((f) => /team/i.test(f))).toEqual([]);
  });
  it("never imports another product module; platform services only through their public index", () => {
    expect(bad([MOD, ...UI], new RegExp(`modules/(${OTHERS})|components/(${OTHERS})`))).toEqual([]);
    expect(bad([MOD, ...UI], /platform\/(activity|ai-employees)\/(?!$)/)).toEqual([]);
  });
  it("only a few files meet the platform services", () => {
    const users = files(MOD).filter((f) => /@\/platform\/(activity|ai-employees)/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f)).sort();
    expect(users.filter((u) => !["bridge.ts", "compute.ts", "domain.ts", "http.ts", "register.ts", "server.ts", "service.ts"].includes(u))).toEqual([]);
  });
  it("makes no network call and calls no AI provider", () => {
    expect(files(MOD).filter((f) => /(?<![.\w])fetch\(|XMLHttpRequest|new WebSocket|node:https?|node:net|getAiKernel/.test(readFileSync(f, "utf8")))).toEqual([]);
  });
  it("frozen code does not know the team module", () => {
    const frozen = ["platform/db", "platform/auth", "platform/ai-kernel", "platform/ai-employees", "platform/activity", ...OTHERS.split("|").map((m) => `modules/${m}`)].map((d) => join(SRC, d));
    expect(bad(frozen, /modules\/team|components\/team/)).toEqual([]);
  });
  it("keeps client components free of server-only imports", () => {
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThanOrEqual(3);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/team\/(service|server|http|bridge|register|compute)|platform\//.test(i)))).toEqual([]);
  });
  it("is one module slug open to every signed-in member except guests", () => {
    expect(MODULES.filter((m) => m.slug === "team")).toHaveLength(1);
    for (const r of ROLES) expect(canAccess(r, "team") === allows(r, "view"), r).toBe(true);
    expect(canAccess("guest", "team")).toBe(false); expect(canAccess("employee", "team")).toBe(true);
  });
  it("states plainly what it does not do", () => {
    expect(ARCHITECTURE_STATUS).toMatchObject({ evidence: "activity_engine_only", continuous_scheduler: "not_built", cross_company_learning: "not_built", academy: "structure_only", blog: "structure_only" });
  });
});

describe("API surface: /api/v1/team/*", () => {
  const API = join(SRC, "app", "api", "v1", "team"), routes = files(API).filter((f) => f.endsWith("route.ts"));
  it("every handler goes through teamRoute; the only write is activation, with CSRF checks", () => {
    expect(routes.map((f) => relative(API, f)).sort()).toEqual(["members/[key]/activate/route.ts", "members/[key]/route.ts", "overview/route.ts", "permissions/mine/route.ts"]);
    for (const f of routes) { const src = readFileSync(f, "utf8"); const verbs = [...src.matchAll(/export const (\w+) = (\w+)/g)].map((m) => `${m[1]}:${m[2]}`); expect(verbs).toEqual([f.includes("activate") ? "POST:teamRoute" : "GET:teamRoute"]); if (f.includes("activate")) expect(src).toContain("mutating: true"); }
  });
});

describe("pages and texts", () => {
  it("has the roster page, the member page and the Mission Control home that keeps the old panels one click away", () => {
    const base = join(SRC, "app", "(app)", "app");
    expect(files(join(base, "team")).filter((f) => f.endsWith("page.tsx")).map((f) => relative(join(base, "team"), f)).sort()).toEqual(["[key]/page.tsx", "page.tsx"]);
    expect(readFileSync(join(base, "dashboard", "page.tsx"), "utf8")).toContain("MissionHome");
    expect(readFileSync(join(base, "dashboard", "panels", "page.tsx"), "utf8")).toContain("WidgetGrid");
  });
  it("English and Spanish have the same keys and no empty text", () => {
    const en = TEAM_DICTIONARIES.en as Record<string, string>, es = TEAM_DICTIONARIES.es as Record<string, string>;
    expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort());
    for (const [k, v] of Object.entries(es)) expect(v.trim(), k).not.toBe("");
  });
});
