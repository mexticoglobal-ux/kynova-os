import { teamRoute, respond } from "@/modules/team/http";

type Ctx = { params: Promise<{ key: string }> };

export const POST = teamRoute<Ctx>(async (req, c, { actor, svc, rid }) => { void req; const p = await c.params; return respond(await svc.activate(actor, p.key), rid, 201); }, { mutating: true });
