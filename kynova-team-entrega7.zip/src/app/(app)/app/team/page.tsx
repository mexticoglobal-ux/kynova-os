import Link from "next/link";
import { teamContext } from "@/components/team/context";
import { ActivateButton } from "@/components/team/Activate";
import { Card, Notice, Pill, ago, badge } from "@/components/team/ui";
import { ARCHITECTURE_STATUS, DEPARTMENTS } from "@/modules/team";

export const metadata = { title: "Mi equipo" };
export const dynamic = "force-dynamic";

export default async function TeamPage() {
  const ctx = await teamContext(), { t, locale } = ctx, o = await ctx.svc.overview(ctx.actor), now = o.until;
  return (
    <div className="grid gap-5">
      <header><h1 className="text-xl font-bold tracking-tight sm:text-2xl">{t("team.title")}</h1><p className="mt-1 max-w-3xl text-sm text-muted">{t("team.sub")}</p><p className="mt-1 max-w-3xl text-xs text-muted">{o.can.activate ? t("team.activateNote") : t("team.noActivateRights")}</p></header>
      {!o.sources.employees && <Notice>{t("src.unavailable", { what: t("src.employees") })}</Notice>}
      {DEPARTMENTS.map((d) => {
        const members = o.team.filter((m) => m.department === d);
        return (
          <div key={d} id={d}><Card title={t(`dept.${d}`)}>
            <ul className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
              {members.map((m) => (
                <li key={m.key} className="grid gap-2 rounded-xl border border-line p-3">
                  <div className="flex items-start justify-between gap-2">
                    <Link href={`/app/team/${m.key}`} className="min-w-0 truncate text-sm font-medium hover:underline">{m.name}</Link>
                    <Pill tone={badge(m).tone}>{t(badge(m).key)}</Pill>
                  </div>
                  <p className="text-xs text-muted">{m.withTools ? t("tools.with") : t("tools.without")}</p>
                  <p className="text-xs text-muted">{m.lastAt ? `${t("mem.last")}: ${ago(m.lastAt, now, locale)}` : t("mem.never")}</p>
                  {m.activatable && o.can.activate && <ActivateButton memberKey={m.key} />}
                </li>
              ))}
            </ul>
          </Card></div>
        );
      })}
      <Card title={t("arch.title")}>
        <dl className="grid gap-2 text-sm sm:grid-cols-2">
          {(Object.entries(ARCHITECTURE_STATUS) as [keyof typeof ARCHITECTURE_STATUS, string][]).map(([k, v]) => (
            <div key={k} className="flex justify-between gap-3 rounded-lg border border-line px-3 py-2"><dt className="text-muted">{t(`arch.${k}`)}</dt><dd className="text-right">{t(v === "not_built" ? "av.not_built" : (`av.${v}` as never))}</dd></div>
          ))}
        </dl>
      </Card>
    </div>
  );
}
