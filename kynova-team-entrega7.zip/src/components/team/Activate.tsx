"use client";
import { useRouter } from "next/navigation";
import { useT } from "./I18n";
import { Err, primary, useRun } from "./Actions";
import { teamCall } from "./api";

/** Activation goes through the team API, which checks the plan on the server. Nothing is invented; the member starts with no recorded work. */
export function ActivateButton({ memberKey }: { memberKey: string }) {
  const { t } = useT(), router = useRouter(), { busy, err, run } = useRun();
  return (
    <div className="grid gap-1">
      <button type="button" className={primary} disabled={busy} onClick={() => void run(() => teamCall("POST", `/team/members/${memberKey}/activate`, {}), () => router.refresh())}>{busy ? t("act.activating") : t("act.activate")}</button>
      <Err err={err} />
    </div>
  );
}
export function DecisionButtons({ taskId }: { taskId: string }) {
  const { t } = useT(), router = useRouter(), { busy, err, run } = useRun();
  const go = (decision: "approve" | "reject") => void run(() => teamCall("POST", `/ai-employees/tasks/${taskId}/decision`, { decision }), () => router.refresh());
  return (
    <div className="grid gap-1">
      <div className="flex gap-2">
        <button type="button" className={primary} disabled={busy} onClick={() => go("approve")}>{t("act.approve")}</button>
        <button type="button" className="rounded-lg border border-line px-3 py-1.5 text-sm hover:bg-ac/10 disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-ac2" disabled={busy} onClick={() => go("reject")}>{t("act.reject")}</button>
      </div>
      <Err err={err} />
    </div>
  );
}
