import Link from "next/link";
import type { Overview } from "@/modules/team";
import { TEAM_DICTIONARIES } from "@/modules/team/i18n";
import type { TeamContext } from "./context";
import { DecisionButtons } from "./Activate";
import { TeamI18n } from "./I18n";
import { describeEvent, describeGroup } from "./helpers";
import { Card, Empty, LinkBtn, MODE_TONE, Notice, OUTCOME_TONE, Pill, Stat, ago, badge, dateTime } from "./ui";

const HOME_MEMBERS = 8, PLAN_NAMES: Record<string, string> = { starter: "Starter", professional: "Professional", business: "Business", enterprise: "Enterprise" };

export function StateBadge({ state, t }: { state: Overview["state"]; t: TeamContext["t"] }) {
  const tone = state === "production" ? "success" : state === "empty" ? "muted" : state === "simulation" ? "warning" : "info";
  return <span className="inline-flex items-center gap-2"><Pill tone={tone}>{t(`state.${state}`)}</Pill><span className="text-xs text-muted">{t(`state.${state}.d`)}</span></span>;
}

/** The first screen: an operating company, not a dashboard. Everything on it comes from the Activity Engine, the AI Employees framework or the roster; empty is shown as empty. */
export async function MissionHome({ ctx }: { ctx: TeamContext }) {
  const { t, locale } = ctx, o = await ctx.svc.overview(ctx.actor), now = o.until;
  const activated = o.team.filter((m) => m.status !== "inactive"), relevant = o.team.filter((m) => m.relevant).slice(0, HOME_MEMBERS);
  return (
    <TeamI18n dict={TEAM_DICTIONARIES[locale]} locale={locale}>
      <div className="grid gap-5">
        <header className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <h1 className="truncate text-2xl font-bold tracking-tight sm:text-3xl">{t("home.hello", { name: ctx.name.split(" ")[0] ?? "" })}</h1>
            <p className="mt-1 max-w-2xl text-sm text-muted">{t("home.sub")}</p>
            <div className="mt-2"><StateBadge state={o.state} t={t} /></div>
          </div>
          <LinkBtn href="/app/dashboard/panels">{t("home.details")}</LinkBtn>
        </header>

        {!o.sources.employees && <Notice>{t("src.unavailable", { what: t("src.employees") })}</Notice>}
        {!o.sources.activity && <Notice>{t("src.unavailable", { what: t("src.activity") })}</Notice>}
        {activated.length === 0 && o.sources.employees && <Notice>{t("home.firstSteps")}</Notice>}

        <dl className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          <Stat label={t("stat.active")} value={o.counts.active} /><Stat label={t("stat.working")} value={o.counts.working} /><Stat label={t("stat.approvals")} value={o.counts.approvals} />
          <Stat label={t("stat.issues")} value={o.counts.issues} /><Stat label={t("stat.available")} value={o.counts.available} />
        </dl>

        <div className="grid gap-5 lg:grid-cols-5">
          <div className="grid content-start gap-5 lg:col-span-3">
            <Card title={t("home.away")} action={<span className="text-xs text-muted">{t("home.awaySince", { since: dateTime(o.since, locale) })}</span>}>
              {o.away.groups.length === 0 ? <Empty>{t("home.awayNone")}</Empty> : (
                <ul className="grid gap-1.5">
                  {o.away.groups.slice(0, 8).map((g) => <li key={`${g.module}|${g.action}`} className="rounded-lg border border-line px-3 py-2 text-sm">{describeGroup(g, t)}</li>)}
                </ul>
              )}
              {o.away.truncated && <p className="mt-2 text-xs text-muted">{t("home.awayMore")}</p>}
            </Card>
            <Card title={t("home.timeline")}>
              {o.timeline.length === 0 ? <Empty>{t("home.timelineNone")}</Empty> : (
                <ol className="grid gap-2">
                  {o.timeline.slice(0, 12).map((e) => (
                    <li key={e.id} className="flex flex-wrap items-center gap-x-2 gap-y-1 rounded-lg border border-line px-3 py-2 text-sm">
                      <span className="min-w-0 flex-1">{describeEvent(e, t, locale)}</span>
                      <Pill tone={MODE_TONE[e.mode]}>{t(`mode.${e.mode}`)}</Pill><Pill tone={OUTCOME_TONE[e.outcome]}>{t(`out.${e.outcome}`)}</Pill>
                      <time className="text-xs text-muted" dateTime={new Date(e.at).toISOString()}>{ago(e.at, now, locale)}</time>
                    </li>
                  ))}
                </ol>
              )}
            </Card>
          </div>

          <div className="grid content-start gap-5 lg:col-span-2">
            <Card title={t("home.approvals")}>
              {o.approvals.length === 0 ? <Empty>{t("home.approvalsNone")}</Empty> : (
                <ul className="grid gap-3">
                  {o.approvals.map((a) => (
                    <li key={a.taskId} className="grid gap-2 rounded-xl border border-line p-3">
                      <div><p className="text-sm font-medium">{a.employeeName}</p><p className="text-sm text-muted">{a.title}</p></div>
                      {a.actions.length > 0 && <ul className="grid gap-1 text-xs text-muted">{a.actions.map((x, i) => <li key={i}><code>{x.capability}</code>{x.rationale ? ` — ${x.rationale}` : ""}</li>)}</ul>}
                      {o.can.decide ? <DecisionButtons taskId={a.taskId} /> : <Pill tone="warning">{t("ms.awaiting_approval")}</Pill>}
                    </li>
                  ))}
                </ul>
              )}
            </Card>
            <Card title={t("home.relevant")} action={<Link href="/app/team" className="text-xs text-ac2 hover:underline">{t("home.teamAll")}</Link>}>
              {relevant.length === 0 ? <Empty>{t("home.relevantNone")}</Empty> : (
                <ul className="grid gap-1.5">
                  {relevant.map((m) => { const b = badge(m); return (
                    <li key={m.key}>
                      <Link href={`/app/team/${m.key}`} className="flex items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 text-sm hover:bg-ac/5 focus-visible:outline-2 focus-visible:outline-ac2">
                        <span className="min-w-0 truncate">{m.name}</span><Pill tone={b.tone}>{t(b.key)}</Pill>
                      </Link>
                    </li>
                  ); })}
                </ul>
              )}
            </Card>
            <Card title={t("home.otherTeams")} action={<span className="text-xs text-muted">{o.plan.known ? `${t("home.plan", { plan: PLAN_NAMES[o.plan.code ?? ""] ?? o.plan.code ?? "" })} · ${o.plan.team === "all" ? t("home.planAll") : t("home.planTeam", { n: o.plan.team })}` : t("home.planUnknown")}</span>}>
              <ul className="grid grid-cols-2 gap-1.5">
                {o.teams.map((tm) => (
                  <li key={tm.department}>
                    <Link href={`/app/team#${tm.department}`} className="grid rounded-lg border border-line px-3 py-2 text-sm hover:bg-ac/5 focus-visible:outline-2 focus-visible:outline-ac2">
                      <span className="truncate font-medium">{t(`dept.${tm.department}`)}</span><span className="truncate text-xs text-muted">{t("home.teamCount", { active: tm.active, entitled: tm.entitled })}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </Card>
            {o.usage.tokens > 0 && <Card title={t("home.usage")}><p className="text-sm tabular-nums">{new Intl.NumberFormat(locale).format(o.usage.tokens)} tokens</p></Card>}
          </div>
        </div>
      </div>
    </TeamI18n>
  );
}
