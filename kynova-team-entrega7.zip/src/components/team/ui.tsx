import Link from "next/link";
import type { ReactNode } from "react";
import type { TeamKey } from "@/modules/team/i18n";

export type T = (k: TeamKey, v?: Record<string, string | number>) => string;
export const Card = ({ title, action, children, className = "" }: { title?: string; action?: ReactNode; children: ReactNode; className?: string }) => (
  <section className={`min-w-0 rounded-2xl border border-line bg-surface p-4 sm:p-5 ${className}`}>
    {(title || action) && <header className="mb-3 flex items-center justify-between gap-3">{title && <h2 className="text-sm font-semibold tracking-tight">{title}</h2>}{action}</header>}
    {children}
  </section>
);
export const Stat = ({ label, value }: { label: string; value: string | number }) => (
  <div className="min-w-0 rounded-xl border border-line px-3.5 py-3"><dt className="truncate text-xs text-muted">{label}</dt><dd className="mt-0.5 truncate text-xl font-bold tabular-nums">{value}</dd></div>
);
export const TONES = { info: "bg-ac2/10 text-ac2", success: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300", warning: "bg-amber-500/10 text-amber-700 dark:text-amber-300", danger: "bg-rose-500/10 text-rose-700 dark:text-rose-300", muted: "bg-line/40 text-muted" } as const;
export const Pill = ({ tone = "info", children }: { tone?: keyof typeof TONES; children: ReactNode }) => <span className={`inline-flex items-center whitespace-nowrap rounded-full px-2 py-0.5 text-xs font-medium ${TONES[tone]}`}>{children}</span>;
export const Empty = ({ children }: { children: ReactNode }) => <p className="rounded-xl border border-dashed border-line px-4 py-6 text-center text-sm text-muted">{children}</p>;
export const Notice = ({ children }: { children: ReactNode }) => <p role="status" className="rounded-xl border border-amber-500/40 bg-amber-500/5 px-4 py-3 text-sm">{children}</p>;
export const LinkBtn = ({ href, children }: { href: string; children: ReactNode }) => <Link href={href} className="rounded-lg border border-line px-3 py-1.5 text-sm hover:bg-ac/10 focus-visible:outline-2 focus-visible:outline-ac2">{children}</Link>;

export const STATUS_TONE = { inactive: "muted", empty: "info", idle: "success", working: "success", awaiting_approval: "warning", issue: "danger", paused: "muted" } as const;
type Badgeable = { status: keyof typeof STATUS_TONE; stage: "ready" | "preparing" | "soon"; entitled: boolean };
/**
 * The one honest label of a member. Plan and readiness come first: nobody is shown as working unless it really has tools and real tasks.
 * An activated member that is only in preparation says so, whatever its tasks say.
 */
export function badge(m: Badgeable): { tone: keyof typeof TONES; key: "ms.plan" | "ms.soon" | "ms.preparing" | `ms.${keyof typeof STATUS_TONE}` } {
  if (!m.entitled) return { tone: "muted", key: "ms.plan" };
  if (m.stage === "soon") return { tone: "muted", key: "ms.soon" };
  if (m.stage === "preparing") return m.status === "awaiting_approval" || m.status === "issue" || m.status === "paused" ? { tone: STATUS_TONE[m.status], key: `ms.${m.status}` } : { tone: "info", key: "ms.preparing" };
  return { tone: STATUS_TONE[m.status], key: `ms.${m.status}` };
}
export const MODE_TONE = { production: "success", simulation: "warning", demo: "info" } as const;
export const OUTCOME_TONE = { success: "success", failed: "danger", skipped: "warning" } as const;

/** Relative time that is rendered on the server with a fixed "now", so the page never flickers on hydration. */
export function ago(ms: number, now: number, locale: string): string {
  const diff = ms - now, abs = Math.abs(diff), f = new Intl.RelativeTimeFormat(locale, { numeric: "auto" });
  if (abs < 60_000) return f.format(0, "second");
  if (abs < 3_600_000) return f.format(Math.round(diff / 60_000), "minute");
  if (abs < 86_400_000) return f.format(Math.round(diff / 3_600_000), "hour");
  return f.format(Math.round(diff / 86_400_000), "day");
}
export const dateTime = (ms: number, locale: string) => new Intl.DateTimeFormat(locale, { dateStyle: "medium", timeStyle: "short", timeZone: "UTC" }).format(ms);
