import { defineEmployeeBlueprint, employeeRegistry } from "@/platform/ai-employees";
import { DEPARTMENTS, DEPARTMENT_GOALS as GOALS, ROSTER } from "./roster";

const flag = globalThis as unknown as { __kynovaTeamRoster?: boolean };
/** Official team members that have no tools yet become activatable "reasoning only" blueprints: they can think, explain and propose, and say so. Members that already have a real blueprint are left to the module that owns it. */
export function registerTeamRoster(): void {
  if (flag.__kynovaTeamRoster) return;
  flag.__kynovaTeamRoster = true;
  for (const r of ROSTER) {
    if (r.blueprint || employeeRegistry().blueprint(r.key)) continue;
    defineEmployeeBlueprint({
      key: r.key, name: r.name, description: `${r.name} (${DEPARTMENTS.find((d) => d === r.department)}): reasons and recommends from what is recorded; no tools are connected to it yet.`,
      defaultGoal: GOALS[r.department],
      defaultInstructions: `You are ${r.name}. Work only from the information you are given. Never invent results, numbers or actions; say plainly when information is missing. You have no tools connected yet: explain, recommend and prepare proposals; people decide.`,
      taskClass: "reason", capabilities: [], defaultAutonomy: 1, maxAutonomy: 1, allowedRoles: ["super_admin", "owner", "ceo", "administrator", "manager"],
    });
  }
}
