/** What Mission Control / the team view does and does not do today; the UI shows this table so nobody is promised more. */
export const ARCHITECTURE_STATUS = {
  evidence: "activity_engine_only",
  employee_work_recording: "bridged_from_framework",
  member_status: "derived_from_tasks_and_evidence",
  employee_tools: "partial_read_only",
  continuous_scheduler: "not_built",
  cross_company_learning: "not_built",
  hq: "not_built",
  academy: "structure_only",
  blog: "structure_only",
} as const;
