import { getActivitySink } from "@/platform/activity";
import { onEmployeeEvent, type EmployeeEvent } from "@/platform/ai-employees";
import { employeeKeyOf } from "./roster";

/** Local and test runs never reach a real provider or database, so what they produce is labelled simulation; only a deployed environment records production. */
export function runsAsSimulation(env: { APP_ENV?: string; NODE_ENV?: string } = process.env): boolean {
  const e = env.APP_ENV;
  if (e === "local" || e === "test") return true;
  if (e === "preview" || e === "staging" || e === "production") return false;
  return env.NODE_ENV !== "production";
}
type Mapped = { action: string; summary: string; outcome: "success" | "failed" | "skipped"; key: string; subject?: [string, string] };
/** Pure mapping from a framework event to the evidence it leaves; null = not evidence of work (queued, started, retry...). */
export function toEvidence(e: EmployeeEvent): Mapped | null {
  const id = e.employeeId; if (!id) return null;
  const task = e.taskId, cap = typeof e.detail?.capability === "string" ? e.detail.capability : "";
  switch (e.type) {
    case "employee.created": return { action: "employee.activated", summary: "An AI employee joined the team.", outcome: "success", key: `created:${id}`, subject: ["ai_employee", id] };
    case "employee.task.succeeded": return task ? { action: "employee.task.completed", summary: "The employee completed a task.", outcome: "success", key: `done:${task}`, subject: ["ai_task", task] } : null;
    case "employee.task.failed": return task ? { action: "employee.task.failed", summary: `A task failed${typeof e.detail?.code === "string" ? ` (${e.detail.code})` : ""}.`, outcome: "failed", key: `failed:${task}`, subject: ["ai_task", task] } : null;
    case "employee.task.awaiting_approval": return task ? { action: "employee.task.awaiting_approval", summary: "A task is waiting for a person to approve it.", outcome: "skipped", key: `await:${task}`, subject: ["ai_task", task] } : null;
    case "employee.task.rejected": return task ? { action: "employee.task.rejected", summary: "A person rejected the proposed work.", outcome: "skipped", key: `rejected:${task}`, subject: ["ai_task", task] } : null;
    case "employee.task.cancelled": return task ? { action: "employee.task.cancelled", summary: "A task was cancelled.", outcome: "skipped", key: `cancelled:${task}`, subject: ["ai_task", task] } : null;
    case "employee.action.executed": return task && cap ? { action: "employee.action.executed", summary: `The employee carried out ${cap}.`, outcome: "success", key: `act:${task}:${cap}`.slice(0, 120), subject: ["ai_task", task] } : null;
    default: return null;
  }
}
const flag = globalThis as unknown as { __kynovaTeamBridge?: boolean };
/** Registered once at startup. Every piece of employee work leaves evidence in the Activity Engine (Blueprint: Mission Control only shows what is recorded there). Failing to record never breaks the work. */
export function registerTeamBridge(): void {
  if (flag.__kynovaTeamBridge) return;
  flag.__kynovaTeamBridge = true;
  onEmployeeEvent((e) => {
    const m = toEvidence(e); if (!m || !e.employeeId) return;
    const id = e.employeeId, employee = e.type === "employee.created" ? false : true;
    void (async () => {
      const sink = await getActivitySink("employees");
      await sink.record({ tenantId: e.tenantId }, {
        action: m.action, summary: m.summary, outcome: m.outcome, mode: runsAsSimulation() ? "simulation" : "production",
        actorKind: employee ? "employee" : "user", actorId: employee ? id : null, employeeKey: employeeKeyOf(id),
        ...(m.subject ? { subjectKind: m.subject[0], subjectId: m.subject[1] } : {}), idempotencyKey: m.key,
      });
    })().catch(() => undefined);
  });
}
