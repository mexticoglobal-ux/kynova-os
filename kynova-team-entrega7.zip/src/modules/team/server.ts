import { canEmployee, employeeRegistry, getEmployeeFramework } from "@/platform/ai-employees";
import { getActivityService } from "@/platform/activity";
import { getDb, plansRepo, tenantDb } from "@/platform/db";
import { createTeamService, type Actor, type TeamPorts, type TeamService } from "./service";

/** Composition root: the only file that meets the AI Employees framework and the Activity Engine. It reads; it never writes (the bridge does the writing). */
export const teamPorts: TeamPorts = {
  async employees(a) { return (await getEmployeeFramework().employees.list(a)).map((e) => ({ id: e.id, blueprint: e.blueprint, name: e.name, goal: e.goal, status: e.status, capabilities: e.capabilities })); },
  async tasks(a) { return (await getEmployeeFramework().tasks.list(a, { limit: 100 })).map((t) => ({ id: t.id, employeeId: t.employeeId, title: t.title, status: t.status, createdAt: t.createdAt, finishedAt: t.finishedAt, inputTokens: t.inputTokens, outputTokens: t.outputTokens, costMicros: t.costMicros, result: t.result })); },
  registered: () => new Set(employeeRegistry().blueprints().map((b) => b.key)),
  async state(a: Actor) { return (await (await getActivityService()).summary(a, { days: 1 })).state; },
  async digest(a, since) { const d = await (await getActivityService()).digest(a, { since }); return { groups: d.groups, truncated: d.truncated }; },
  async events(a, q) { return (await (await getActivityService()).list(a, { limit: Math.min(q.limit, 100), ...(q.since ? { since: q.since } : {}), ...(q.employeeKey ? { employeeKey: q.employeeKey } : {}) })).items; },
  async plan(a) {
    const db = await getDb(), sub = await tenantDb(db, { tenantId: a.tenantId }).subscriptions.current();
    return sub ? ((await plansRepo(db).findById(sub.planId))?.code ?? null) : null;
  },
  async activate(a, i) { const e = await getEmployeeFramework().employees.hire(a, { blueprint: i.blueprint, name: i.name, goal: i.goal }); return { id: e.id }; },
  can: (a) => ({ activate: canEmployee(a.role, "employee:manage"), decide: canEmployee(a.role, "employee:approve") }),
};
export async function getTeamService(): Promise<TeamService> { return createTeamService({ ports: teamPorts }); }
