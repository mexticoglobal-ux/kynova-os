import { ROSTER } from "./roster";

/**
 * Which AI Employees each plan includes (owner's decision, Oct 2026). The plan decides the team; the company only activates, configures and extends it.
 * `professional` was not specified by the owner: it is Starter plus the marketing, SEO and sales specialists, and is meant to be edited here.
 */
export const STARTER_TEAM = ["ceo_ai", "marketing_manager", "sales_manager", "customer_success_manager", "finance_manager", "integration_manager"] as const;
export const PROFESSIONAL_TEAM = [...STARTER_TEAM, "content_creator", "social_media_manager", "technical_seo", "local_seo", "content_seo", "seo_auditor", "crm_manager", "lead_manager"] as const;
export type PlanTeam = readonly string[] | "all";
export const PLAN_TEAMS: Record<string, PlanTeam> = { starter: STARTER_TEAM, professional: PROFESSIONAL_TEAM, business: "all", enterprise: "all" };
/** What the owner listed beyond the team itself; shown as promised, not as built. */
export const ENTERPRISE_EXTRAS = ["custom_teams", "advanced_workflows", "dedicated_ai", "white_label", "multi_company", "processing_priority", "advanced_security", "advanced_api"] as const;
/** A company whose plan cannot be read gets the smallest team, never the largest. */
export const FALLBACK_PLAN = "starter";
export const teamOf = (planCode: string | null | undefined): PlanTeam => PLAN_TEAMS[planCode ?? ""] ?? PLAN_TEAMS[FALLBACK_PLAN]!;
export const isEntitled = (team: PlanTeam, key: string): boolean => team === "all" || team.includes(key);
export const ENTITLED_COUNT = (team: PlanTeam): number => (team === "all" ? ROSTER.length : ROSTER.filter((r) => team.includes(r.key)).length);
