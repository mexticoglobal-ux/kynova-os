export type TeamErrorCode = "forbidden" | "not_found" | "validation_failed" | "conflict" | "duplicate" | "invalid_state" | "limit_exceeded" | "unavailable" | "ai_unavailable" | "plan_required";
const STATUS: Record<TeamErrorCode, number> = { forbidden: 403, not_found: 404, validation_failed: 422, conflict: 409, duplicate: 409, invalid_state: 409, limit_exceeded: 403, unavailable: 503, ai_unavailable: 503, plan_required: 403 };
export class TeamError extends Error {
  readonly status: number;
  constructor(readonly code: TeamErrorCode, message: string, readonly details?: Record<string, unknown>) { super(message); this.name = "TeamError"; this.status = STATUS[code]; }
}
export const isTeamError = (e: unknown): e is TeamError => e instanceof TeamError || (typeof e === "object" && e !== null && (e as { name?: string }).name === "TeamError");
