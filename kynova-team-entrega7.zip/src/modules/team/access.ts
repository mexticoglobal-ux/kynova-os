import type { Role } from "@/config/roles";
import type { Capability } from "./domain";
/** The team view is for every signed-in member of a company. What each person may DO (hire, approve) is decided by the AI Employees framework, never here. */
export const allows = (role: Role, _cap: Capability): boolean => role !== "guest";
