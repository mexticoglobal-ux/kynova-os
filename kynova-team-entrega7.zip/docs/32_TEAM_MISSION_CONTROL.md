# 32 · Mi equipo y Mission Control (primera pantalla)

Módulo `team` (slug `team`, `/app/team`, API `/api/v1/team`). La home `/app/dashboard` ahora es Mission Control; los paneles anteriores siguen intactos en `/app/dashboard/panels`.

## Idea (Blueprint docs 01, 03 y 05)
El cliente ve empleados trabajando, no módulos: qué hicieron mientras no estaba, qué necesita su decisión, la línea de tiempo y el estado de cada especialista. Los módulos (CRM, Partners, Referidos...) son infraestructura que los empleados usan.

## De dónde sale cada dato (nada se inventa)
- Empleados activados y sus tareas: marco de AI Employees.
- "Mientras estabas fuera", línea de tiempo y estado de la empresa (Vacío/Demo/Simulación/Producción): solo el Activity Engine.
- Estado de cada especialista: se calcula con tareas y evidencia. Sin contratar = "Sin contratar"; activado sin evidencia = "Contratado, aún sin trabajo".
- Si una fuente no se puede leer, la pantalla lo dice; nunca muestra "no pasó nada".

## Puente al Activity Engine
Antes, el trabajo de los empleados no dejaba evidencia en el Activity Engine. `bridge.ts` escucha los eventos del marco y registra: contratación, tarea completada, fallida, en espera de aprobación, rechazada, cancelada y acción ejecutada. Local y test se marcan como Simulación; solo un entorno desplegado registra Producción.

## Plantel
47 especialistas del doc 03 agrupados en 11 áreas. Los que ya tienen un empleado real (Partner Manager, Marketplace, Finanzas, Billing, Integraciones, Analytics, CEO AI→Executive Advisor) usan su plantilla. El resto se registra como plantilla "solo razona y recomienda, sin herramientas", activable por roles de dirección.

## Límites declarados
Sin planificador 24/7 (las tareas se encolan y las ejecuta un worker), sin aprendizaje entre empresas, sin HQ. Las herramientas de los empleados son de solo lectura. El periodo de "mientras estabas fuera" son las últimas 24 h (máx. 14 días) porque aún no se guarda la última visita.

## Escala
Sin tablas ni migración: lee contadores y listas acotadas por empresa (100 tareas, 100 eventos). Cada consulta lleva `tenant_id` por los servicios que usa.

## Entrega 7: planes por equipo, activar y estados honestos
- **El plan decide el equipo** (`entitlements.ts`). Starter: CEO AI, Marketing Manager, Sales Manager, Customer Success Manager, Finance Manager e Integration Manager. Business y Enterprise: todo el plantel. Professional no estaba definido por el dueño: es Starter más marketing, SEO y ventas, y se edita en ese archivo. Un plan ilegible recibe el equipo más pequeño, nunca el más grande.
- **"Activar", no "Contratar".** `POST /api/v1/team/members/{key}/activate` valida en el servidor el plan, la madurez del especialista y que no esté ya activo; el marco de empleados valida el rol. Ocultar un botón nunca es seguridad.
- **Madurez** (`roster.ts`): *ready* (con herramientas conectadas), *preparing* (razona, sin herramientas: "En preparación") y *soon* ("Disponible próximamente"). Solo un especialista *ready* puede figurar como "Trabajando" o contar como relevante; uno en preparación solo aparece si necesita una decisión o tiene un problema.
- **Mission Control muestra solo lo relevante** y resume el resto por equipo (activos / incluidos en el plan).
- **Academy y Blog** hoy son solo la estructura (páginas vacías): se declaran "En preparación".

## Pendiente conocido
La API general de empleados (`POST /api/v1/ai-employees`) sigue permitiendo crear un empleado de cualquier plantilla registrada a quien tenga permiso de gestión, sin mirar el plan. El Framework de la siguiente entrega mueve la activación a un único punto que sí valida el plan.
