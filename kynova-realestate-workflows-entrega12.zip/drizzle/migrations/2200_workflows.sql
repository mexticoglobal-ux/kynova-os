-- Workflow engine (Entrega 12). Generic: every AI Business System stores its proposed work here, keyed by `system`. Owned by src/platform/workflows.
-- Tenant-owned; every index leads with tenant_id. Nothing is deleted: a finding is approved, dismissed or resolved.
CREATE TABLE `wf_items` (
	`id` text PRIMARY KEY NOT NULL, `tenant_id` text NOT NULL, `system` text NOT NULL, `workflow` text NOT NULL, `kind` text NOT NULL, `employee` text NOT NULL, `code` text NOT NULL,
	`subject_kind` text NOT NULL, `subject_id` text NOT NULL, `priority` text DEFAULT 'medium' NOT NULL, `params` text DEFAULT '{}' NOT NULL, `evidence` text DEFAULT '[]' NOT NULL,
	`dedup_key` text NOT NULL, `status` text DEFAULT 'open' NOT NULL, `decided_by` text, `decided_at` integer, `created_at` integer NOT NULL, `updated_at` integer NOT NULL,
	FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`) ON UPDATE no action ON DELETE cascade,
	CHECK (`kind` IN ('recommendation', 'task', 'review', 'opportunity', 'marker')), CHECK (`priority` IN ('high', 'medium', 'low')), CHECK (`status` IN ('open', 'approved', 'dismissed', 'resolved')),
	CHECK ((`status` IN ('approved', 'dismissed')) = (`decided_at` IS NOT NULL))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `wf_items_dedup_uq` ON `wf_items` (`tenant_id`,`system`,`dedup_key`);--> statement-breakpoint
CREATE INDEX `wf_items_status_idx` ON `wf_items` (`tenant_id`,`system`,`status`,`created_at`);--> statement-breakpoint
CREATE INDEX `wf_items_subject_idx` ON `wf_items` (`tenant_id`,`system`,`subject_kind`,`subject_id`);--> statement-breakpoint
CREATE TRIGGER wf_items_frozen BEFORE UPDATE OF tenant_id, system, workflow, kind, dedup_key, subject_kind, subject_id ON wf_items BEGIN SELECT RAISE(ABORT, 'workflow item identity cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER wf_items_decided_once BEFORE UPDATE OF status ON wf_items WHEN OLD.status IN ('approved', 'dismissed') AND NEW.status <> OLD.status BEGIN SELECT RAISE(ABORT, 'a decided workflow item cannot change'); END;
--> statement-breakpoint
CREATE TRIGGER wf_items_no_delete BEFORE DELETE ON wf_items BEGIN SELECT RAISE(ABORT, 'wf_items rows cannot be deleted'); END;
