import type { BuyerRecord, OwnerRecord, PropertyRecord } from "./domain";
import type { Match } from "./engine";

/**
 * Rule-based scores (Entrega 12). No AI: every point comes from a recorded fact and every score carries its explanation.
 * A factor the data cannot answer is "not evaluated" and leaves the score instead of being guessed (a property has no photo field yet).
 */
export const DAY = 86_400_000;
export interface Factor { code: string; points: number; max: number; evaluated: boolean; params?: Record<string, number> }
export interface Health { score: number; factors: Factor[]; notEvaluated: string[] }
export type Level = "high" | "medium" | "low";
export interface Opportunity { level: Level; points: number; reasons: { code: string; points: number }[] }
export interface PropertySignals { now: number; doneVisits: number; recentVisits: number; liveBuyers: number; buyersInBudget: number; matchingBuyers: number }

export function healthScore(p: PropertyRecord, s: PropertySignals): Health {
  const F: Factor[] = [], add = (code: string, points: number, max: number, evaluated = true, params?: Record<string, number>) => F.push({ code, points: evaluated ? points : 0, max, evaluated, ...(params ? { params } : {}) });
  const d = p.description.trim().length; add("description", d >= 80 ? 20 : d >= 40 ? 10 : 0, 20, true, { chars: d });
  const needBeds = p.kind !== "land" && p.kind !== "commercial", filled = [p.zone.trim() !== "", p.address.trim() !== "", !needBeds || p.bedrooms > 0, !needBeds || p.bathrooms > 0, p.areaM2 > 0];
  add("fields", filled.filter(Boolean).length * 4, 20, true, { filled: filled.filter(Boolean).length, of: filled.length });
  add("price", p.priceMinor > 0 ? 10 : 0, 10);
  add("demand", s.buyersInBudget > 0 ? 10 : 0, 10, s.liveBuyers > 0, { buyers: s.buyersInBudget });
  const days = Math.max(0, Math.floor((s.now - p.listedAt) / DAY)); add("listed", days <= 15 ? 20 : days <= 30 ? 15 : days <= 60 ? 8 : 0, 20, p.status === "active" || p.status === "reserved", { days });
  add("activity", s.recentVisits >= 2 ? 20 : s.recentVisits === 1 ? 12 : 0, 20, (p.status === "active" || p.status === "reserved") && days >= 7, { visits: s.recentVisits });
  const ev = F.filter((f) => f.evaluated), max = ev.reduce((n, f) => n + f.max, 0);
  return { score: max ? Math.round((ev.reduce((n, f) => n + f.points, 0) / max) * 100) : 0, factors: F, notEvaluated: ["media", ...F.filter((f) => !f.evaluated).map((f) => f.code)] };
}
const level = (pts: number, hi: number, mid: number): Level => (pts >= hi ? "high" : pts >= mid ? "medium" : "low");
const pack = (rs: [string, number][], hi: number, mid: number): Opportunity => { const reasons = rs.filter(([, n]) => n !== 0).map(([code, points]) => ({ code, points })), points = reasons.reduce((n, r) => n + r.points, 0); return { level: level(points, hi, mid), points, reasons }; };

export function buyerOpportunity(b: BuyerRecord, matches: readonly Match[], daysIdle: number): Opportunity {
  if (b.stage === "won" || b.stage === "lost") return { level: "low", points: 0, reasons: [{ code: "closed", points: 0 }] };
  const stage = { negotiating: 50, visiting: 35, searching: 15, contacted: 10, new: 5 }[b.stage] ?? 0, best = matches[0]?.score ?? 0;
  return pack([[`stage_${b.stage}`, stage], ["matches", matches.length >= 3 ? 25 : matches.length > 0 ? 15 : 0], ["strong_match", best >= 80 ? 10 : 0], ["budget_set", b.budgetMaxMinor > 0 ? 5 : 0], ["recent_contact", daysIdle <= 7 ? 10 : 0], ["idle", daysIdle >= 14 ? -20 : 0]], 60, 30);
}
export function ownerOpportunity(o: OwnerRecord, properties: number, daysIdle: number, now: number): Opportunity {
  if (o.stage === "lost") return { level: "low", points: 0, reasons: [{ code: "closed", points: 0 }] };
  const stage = { meeting: 45, contacted: 25, new: 15, mandate: 10 }[o.stage] ?? 0;
  return pack([[`stage_${o.stage}`, stage], ["has_properties", properties > 0 ? 10 : 0], ["action_due", o.nextActionAt !== null && o.nextActionAt <= now ? 15 : 0], ["recent_contact", daysIdle <= 7 ? 10 : 0], ["idle", daysIdle >= 14 ? -20 : 0]], 50, 25);
}
export function propertyOpportunity(p: PropertyRecord, matchingBuyers: number, doneVisits: number, health: number): Opportunity {
  if (p.status === "sold" || p.status === "rented" || p.status === "archived") return { level: "low", points: 0, reasons: [{ code: "closed", points: 0 }] };
  return pack([["reserved", p.status === "reserved" ? 30 : 0], ["buyers", matchingBuyers >= 3 ? 40 : matchingBuyers > 0 ? 25 : 0], ["visits", Math.min(20, doneVisits * 10)], ["healthy", health >= 70 ? 15 : 0]], 60, 30);
}
