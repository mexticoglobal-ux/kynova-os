import type { Proposal, WorkflowDef } from "@/platform/workflows";
import type { ActivityRecord, BuyerRecord, OwnerRecord, PropertyRecord, PublicationRecord } from "./domain";
import { matchesForBuyer, matchesForProperty, type Match, type Matcher } from "./engine";
import { DAY, buyerOpportunity, healthScore, ownerOpportunity, propertyOpportunity, type PropertySignals } from "./scores";

/**
 * Real Estate workflows (Entrega 12). Each one is a PURE rule over the facts of the company: no I/O, no AI, no clock of its own, and no external effect.
 * They only PROPOSE; the generic engine in src/platform/workflows stores the proposals and a person approves or dismisses them.
 */
export const SYSTEM = "realestate";
export const THRESHOLDS = { followupDays: 7, followupHighDays: 14, reviewDays: 30, readyDescription: 40, recentDays: 30, trendDays: 7 } as const;
/** The ONLY growth levers a Bootstrap company is ever pointed to. There is no paid-advertising lever, by construction. */
export const BOOTSTRAP_LEVERS = ["seo", "google_business", "content", "social", "captation", "referrals"] as const;
export const WORKFLOW_IDS = ["buyer_matching", "followup", "listing_review", "opportunity", "performance_watch", "bootstrap_growth"] as const;
export type WorkflowId = (typeof WORKFLOW_IDS)[number];

export interface Facts {
  now: number; props: readonly PropertyRecord[]; owners: readonly OwnerRecord[]; buyers: readonly BuyerRecord[]; acts: readonly ActivityRecord[]; pubs: readonly PublicationRecord[]; bootstrap: boolean; matcher: Matcher;
  /** Event-scoped runs only look at these subjects; a sweep leaves it undefined and looks at everything. */
  focus?: { buyers?: ReadonlySet<string>; owners?: ReadonlySet<string>; properties?: ReadonlySet<string> };
}
const live = (b: BuyerRecord) => b.stage !== "won" && b.stage !== "lost";
const want = (f: Facts, k: "buyers" | "owners" | "properties", id: string): boolean => !f.focus || Boolean(f.focus[k]?.has(id));
const ref = (kind: string, id: string, label: string) => ({ kind, id, label });

/** Derived indexes, computed once per evaluation (O(records)). */
export function index(f: Facts) {
  const lastDone = new Map<string, number>(), planned = new Set<string>(), visits = new Map<string, number[]>();
  for (const a of f.acts) for (const [k, id] of [["buyer", a.buyerId], ["owner", a.ownerId], ["property", a.propertyId]] as const) {
    if (!id) continue; const key = `${k}:${id}`;
    if (a.status === "done" && a.whenAt <= f.now) lastDone.set(key, Math.max(lastDone.get(key) ?? 0, a.whenAt));
    if (a.status === "planned" && a.whenAt >= f.now) planned.add(key);
    if (k === "property" && a.kind === "visit" && a.status === "done" && a.whenAt <= f.now) visits.set(id, [...(visits.get(id) ?? []), a.whenAt]);
  }
  const liveBuyers = f.buyers.filter(live), activeProps = f.props.filter((p) => p.status === "active");
  const bMatches = new Map<string, Match[]>(), pBuyers = new Map<string, Match[]>();
  const matchesOfBuyer = (b: BuyerRecord) => bMatches.get(b.id) ?? (bMatches.set(b.id, matchesForBuyer(b, activeProps, f.matcher)), bMatches.get(b.id) as Match[]);
  const matchesOfProperty = (p: PropertyRecord) => pBuyers.get(p.id) ?? (pBuyers.set(p.id, matchesForProperty(p, liveBuyers, f.matcher)), pBuyers.get(p.id) as Match[]);
  const touch = (kind: string, id: string, updatedAt: number) => Math.max(updatedAt, lastDone.get(`${kind}:${id}`) ?? 0);
  const idle = (kind: string, id: string, updatedAt: number) => Math.max(0, Math.floor((f.now - touch(kind, id, updatedAt)) / DAY));
  const signals = (p: PropertyRecord): PropertySignals => {
    const vs = visits.get(p.id) ?? [], inBudget = liveBuyers.filter((b) => b.intent === p.operation && b.currency === p.currency && p.priceMinor >= b.budgetMinMinor && (b.budgetMaxMinor === 0 || p.priceMinor <= b.budgetMaxMinor)).length;
    return { now: f.now, doneVisits: vs.length, recentVisits: vs.filter((t) => f.now - t <= THRESHOLDS.recentDays * DAY).length, liveBuyers: liveBuyers.filter((b) => b.intent === p.operation && b.currency === p.currency).length, buyersInBudget: inBudget, matchingBuyers: matchesOfProperty(p).length };
  };
  return { lastDone, planned, visits, liveBuyers, activeProps, matchesOfBuyer, matchesOfProperty, idle, signals };
}
type Ix = ReturnType<typeof index>;
const idx = new WeakMap<Facts, Ix>();
export const ix = (f: Facts): Ix => idx.get(f) ?? (idx.set(f, index(f)), idx.get(f) as Ix);

const buyerMatching: WorkflowDef<Facts> = {
  id: "buyer_matching", employee: "buyer_specialist",
  run(f) {
    const x = ix(f), out: Proposal[] = [], propById = new Map(f.props.map((p) => [p.id, p]));
    for (const b of x.liveBuyers) {
      if (!want(f, "buyers", b.id)) continue;
      const m = x.matchesOfBuyer(b); if (!m.length) continue;
      const top = m.slice(0, 5), titles = top.slice(0, 3).map((t) => propById.get(t.propertyId)?.title ?? "").filter(Boolean).join(" · ");
      out.push({ workflow: "buyer_matching", kind: "recommendation", employee: "buyer_specialist", code: "buyer_matches", subjectKind: "buyer", subjectId: b.id, priority: top[0]!.score >= 80 ? "high" : "medium",
        params: { buyer: b.name, count: m.length, best: top[0]!.score, top: titles }, evidence: top.map((t) => ref("property", t.propertyId, propById.get(t.propertyId)?.title ?? t.propertyId)),
        summary: `Buyer Specialist found ${m.length} matching ${m.length === 1 ? "property" : "properties"} for ${b.name}`, dedupKey: `match:${b.id}:${top.map((t) => t.propertyId).sort().join(",")}` });
    }
    return out;
  },
};
const followup: WorkflowDef<Facts> = {
  id: "followup", employee: "follow_up_manager",
  run(f) {
    const x = ix(f), out: Proposal[] = [];
    const one = (kind: "buyer" | "owner", id: string, name: string, stage: string, updatedAt: number, nextAt: number | null) => {
      const key = `${kind}:${id}`, days = x.idle(kind, id, updatedAt);
      if (days < THRESHOLDS.followupDays || x.planned.has(key) || (nextAt !== null && nextAt > f.now)) return; // already scheduled → nothing to chase
      out.push({ workflow: "followup", kind: "task", employee: "follow_up_manager", code: `followup_${kind}`, subjectKind: kind, subjectId: id, priority: days >= THRESHOLDS.followupHighDays ? "high" : "medium", params: { name, days, stage },
        evidence: [ref(kind, id, name)], summary: `Follow-up Manager: ${name} has had no activity for ${days} days`, dedupKey: `fu:${key}:${Math.max(updatedAt, x.lastDone.get(key) ?? 0)}` });
    };
    for (const b of x.liveBuyers) if (want(f, "buyers", b.id)) one("buyer", b.id, b.name, b.stage, b.updatedAt, b.nextActionAt);
    for (const o of f.owners) if (o.stage !== "lost" && o.stage !== "mandate" && want(f, "owners", o.id)) one("owner", o.id, o.name, o.stage, o.updatedAt, o.nextActionAt);
    return out;
  },
};
const listingReview: WorkflowDef<Facts> = {
  id: "listing_review", employee: "listing_manager",
  run(f) {
    const x = ix(f), out: Proposal[] = [];
    for (const p of x.activeProps) {
      if (!want(f, "properties", p.id)) continue;
      const days = Math.floor((f.now - p.listedAt) / DAY); if (days < THRESHOLDS.reviewDays) continue;
      const s = x.signals(p), bucket = Math.floor(days / THRESHOLDS.reviewDays), shortText = p.description.trim().length < 80;
      // Suggestions are recommendations only. Photos/video/virtual tour cannot be checked (no media field yet), so they are offered as a verification, never as a finding.
      out.push({ workflow: "listing_review", kind: "review", employee: "listing_manager", code: "listing_review", subjectKind: "property", subjectId: p.id, priority: days >= 2 * THRESHOLDS.reviewDays ? "high" : "medium",
        params: { title: p.title, days, visits: s.doneVisits, buyers: s.matchingBuyers, s_description: shortText, s_price: s.doneVisits === 0 || s.matchingBuyers === 0, s_media: true }, evidence: [ref("property", p.id, p.title)],
        summary: `Listing Manager: ${p.title} has been listed for ${days} days, review suggested`, dedupKey: `lr:${p.id}:${bucket}` });
    }
    return out;
  },
};
const opportunity: WorkflowDef<Facts> = {
  id: "opportunity", employee: "real_estate_director",
  run(f) {
    const x = ix(f), out: Proposal[] = [];
    const push = (kind: string, id: string, name: string, level: string, points: number) => { if (level === "high") out.push({ workflow: "opportunity", kind: "opportunity", employee: "real_estate_director", code: `opportunity_${kind}`, subjectKind: kind, subjectId: id, priority: "high", params: { name, points }, evidence: [ref(kind, id, name)], summary: `Real Estate Director detected an important opportunity: ${name}`, dedupKey: `opp:${kind}:${id}` }); };
    for (const b of x.liveBuyers) if (want(f, "buyers", b.id)) { const o = buyerOpportunity(b, x.matchesOfBuyer(b), x.idle("buyer", b.id, b.updatedAt)); push("buyer", b.id, b.name, o.level, o.points); }
    for (const o of f.owners) if (want(f, "owners", o.id)) { const r = ownerOpportunity(o, f.props.filter((p) => p.ownerId === o.id).length, x.idle("owner", o.id, o.updatedAt), f.now); push("owner", o.id, o.name, r.level, r.points); }
    for (const p of f.props.filter((q) => q.status === "active" || q.status === "reserved")) if (want(f, "properties", p.id)) { const s = x.signals(p), r = propertyOpportunity(p, s.matchingBuyers, s.doneVisits, healthScore(p, s).score); push("property", p.id, p.title, r.level, r.points); }
    return out;
  },
};
const performanceWatch: WorkflowDef<Facts> = {
  id: "performance_watch", employee: "analytics_manager",
  run(f) {
    if (f.focus) return [];
    const W = THRESHOLDS.trendDays * DAY, wk = Math.floor(f.now / W), out: Proposal[] = [], win = (t: number, a: number, b: number) => t > f.now - b * W && t <= f.now - a * W;
    const closed = (a: number, b: number) => f.props.filter((p) => p.closedAt !== null && win(p.closedAt, a, b)).length, done = (a: number, b: number) => f.acts.filter((x) => x.status === "done" && win(x.whenAt, a, b)).length;
    const cur = closed(0, 1), prev = closed(1, 2); // closings are dated facts; a weekly "conversion" cannot be rebuilt because buyer stage changes are not dated
    if (prev > 0 && cur < prev) out.push({ workflow: "performance_watch", kind: "recommendation", employee: "analytics_manager", code: "closings_down", subjectKind: "system", subjectId: SYSTEM, priority: "medium", params: { cur, prev }, evidence: [], summary: `Analytics Manager: closings fell from ${prev} to ${cur} week over week`, dedupKey: `perf:closings:${wk}` });
    const a1 = done(0, 1), a0 = done(1, 2);
    if (a0 > 0 && a1 < a0) out.push({ workflow: "performance_watch", kind: "recommendation", employee: "analytics_manager", code: "activity_down", subjectKind: "system", subjectId: SYSTEM, priority: "medium", params: { cur: a1, prev: a0 }, evidence: [], summary: `Analytics Manager detected lower activity: ${a1} vs ${a0} completed last week`, dedupKey: `perf:activity:${wk}` });
    return out;
  },
};
const bootstrapGrowth: WorkflowDef<Facts> = {
  id: "bootstrap_growth", employee: "marketing_manager",
  run(f) {
    if (!f.bootstrap || f.focus) return [];
    const x = ix(f), out: Proposal[] = [], approvedFor = new Set(f.pubs.filter((p) => p.status === "approved").map((p) => p.propertyId));
    const rec = (code: string, levers: (typeof BOOTSTRAP_LEVERS)[number][], params: Record<string, number>, key: string, priority: "high" | "medium", summary: string, evidence: Proposal["evidence"] = []) =>
      out.push({ workflow: "bootstrap_growth", kind: "recommendation", employee: "marketing_manager", code, subjectKind: "system", subjectId: SYSTEM, priority, params: { ...params, levers: levers.join(",") }, evidence, summary, dedupKey: `bs:${key}` });
    const newOwners = f.owners.filter((o) => f.now - o.createdAt <= 30 * DAY).length;
    if (newOwners === 0) rec("growth_captation", ["captation", "referrals"], { owners: f.owners.length }, `capt:${Math.floor(f.now / (30 * DAY))}`, f.owners.length === 0 ? "high" : "medium", "Marketing Manager: no owners captured in the last 30 days (free levers only)");
    const unpublished = x.activeProps.filter((p) => !approvedFor.has(p.id));
    if (unpublished.length) rec("growth_content", ["content", "social"], { n: unpublished.length }, `content:${unpublished.map((p) => p.id).sort().join(",")}`.slice(0, 110), "medium", `Marketing Manager: ${unpublished.length} active listings have no approved content`, unpublished.slice(0, 5).map((p) => ref("property", p.id, p.title)));
    if (x.activeProps.length) rec("growth_local", ["seo", "google_business"], { n: x.activeProps.length, zones: new Set(x.activeProps.map((p) => p.zone.trim().toLowerCase()).filter(Boolean)).size }, `local:${x.activeProps.length}`, "medium", `Marketing Manager: ${x.activeProps.length} active listings can feed local SEO and Google Business`);
    const closed = f.props.filter((p) => p.closedAt !== null && f.now - (p.closedAt as number) <= 90 * DAY).length;
    if (closed > 0) rec("growth_referrals", ["referrals"], { closed }, `ref:${closed}`, "medium", `Marketing Manager: ${closed} closings in 90 days are a source of referrals`);
    return out;
  },
};
/** Publication drafts are an effect, not a finding: the service prepares the briefs (always proposed, never published) for properties that are ready and have none. */
export const isReady = (p: PropertyRecord, pubs: readonly PublicationRecord[]): boolean => p.status === "active" && p.description.trim().length >= THRESHOLDS.readyDescription && p.zone.trim() !== "" && p.priceMinor > 0 && !pubs.some((x) => x.propertyId === p.id);

export const REAL_ESTATE_WORKFLOWS: readonly WorkflowDef<Facts>[] = [buyerMatching, followup, listingReview, opportunity, performanceWatch, bootstrapGrowth];
