import type { Params, Priority, Proposal, Scope, WorkflowDef, WorkflowItem } from "./types";

export interface Plan { create: Proposal[]; update: { id: string; priority: Priority; params: Params }[]; reopen: { id: string; priority: Priority; params: Params }[]; resolve: string[] }
const same = (a: Params, b: Params): boolean => { const k = Object.keys(a); return k.length === Object.keys(b).length && k.every((x) => a[x] === b[x]); };
const inScope = (i: { workflow: string; subjectKind: string; subjectId: string }, s: Scope): boolean =>
  s.workflows.includes(i.workflow) && (!s.subjects || s.subjects.some((x) => x.kind === i.subjectKind && x.id === i.subjectId));

/**
 * Pure and idempotent. `existing` holds the items of every status (so a finding the person already decided is not proposed again).
 * - a proposal with a new key is created;
 * - an open item whose finding changed (priority, numbers) is refreshed;
 * - an open item in scope that is no longer proposed is resolved (the condition cleared by itself).
 */
export function plan(existing: readonly WorkflowItem[], proposals: readonly Proposal[], scope: Scope): Plan {
  const byKey = new Map(existing.map((i) => [i.dedupKey, i])), seen = new Set<string>(), out: Plan = { create: [], update: [], reopen: [], resolve: [] };
  for (const p of proposals) {
    if (seen.has(p.dedupKey) || !inScope({ workflow: p.workflow, subjectKind: p.subjectKind, subjectId: p.subjectId }, scope)) continue;
    seen.add(p.dedupKey);
    const cur = byKey.get(p.dedupKey);
    if (!cur) out.create.push(p);
    else if (cur.status === "resolved") out.reopen.push({ id: cur.id, priority: p.priority, params: p.params }); // the condition came back
    else if (cur.status === "open" && (cur.priority !== p.priority || !same(cur.params, p.params))) out.update.push({ id: cur.id, priority: p.priority, params: p.params });
  }
  for (const i of existing) if (i.status === "open" && i.kind !== "marker" && !seen.has(i.dedupKey) && inScope(i, scope)) out.resolve.push(i.id);
  return out;
}
export const rank = (p: Priority): number => (p === "high" ? 0 : p === "medium" ? 1 : 2);

/** Runs the definitions that belong to `ids` (all of them when omitted) over the same facts. */
export function runDefs<F>(defs: readonly WorkflowDef<F>[], facts: F, ids?: readonly string[]): Proposal[] { return defs.filter((d) => !ids || ids.includes(d.id)).flatMap((d) => d.run(facts)); }
