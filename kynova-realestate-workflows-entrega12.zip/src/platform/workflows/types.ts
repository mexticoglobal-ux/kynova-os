/**
 * Workflow engine (generic, Entrega 12). A workflow is a PURE rule: (facts, now) → proposals. The engine turns proposals into stored work items
 * that wait for a human decision. Nothing here knows about any one business: YouTube, Ecommerce, Finance, CRM... plug in their own `WorkflowDef`s.
 * It never sends, publishes or changes business data; a proposal is only ever a suggestion the person approves or dismisses.
 */
export const ITEM_KINDS = ["recommendation", "task", "review", "opportunity", "marker"] as const;
export const PRIORITIES = ["high", "medium", "low"] as const;
export const ITEM_STATUS = ["open", "approved", "dismissed", "resolved"] as const;
export type ItemKind = (typeof ITEM_KINDS)[number];
export type Priority = (typeof PRIORITIES)[number];
export type ItemStatus = (typeof ITEM_STATUS)[number];
export type Params = Record<string, string | number | boolean>;
export interface EvidenceRef { kind: string; id: string; label: string }

/** What a workflow proposes. `code` + `params` are localized by the UI; `summary` is the English line written to the Activity Engine. */
export interface Proposal {
  workflow: string; kind: Exclude<ItemKind, "marker">; employee: string; code: string; subjectKind: string; subjectId: string; priority: Priority;
  params: Params; evidence: EvidenceRef[]; summary: string;
  /** Identity of the finding. Same key = same finding, so re-running never duplicates and a decided finding never comes back. Include the state the finding depends on. */
  dedupKey: string;
}
export interface WorkflowItem {
  id: string; tenantId: string; system: string; workflow: string; kind: ItemKind; employee: string; code: string; subjectKind: string; subjectId: string; priority: Priority;
  params: Params; evidence: EvidenceRef[]; dedupKey: string; status: ItemStatus; decidedBy: string | null; decidedAt: number | null; createdAt: number; updatedAt: number;
}
export interface ItemQuery { system: string; workflows?: readonly string[]; statuses?: readonly ItemStatus[]; kinds?: readonly ItemKind[]; subject?: { kind: string; id: string }; since?: number; limit: number }

/** Persistence port. EVERY method takes the tenant id. Two implementations: D1 and memory. */
export interface WorkflowStore {
  insert(row: WorkflowItem): Promise<boolean>; // false when (tenant, system, dedupKey) already exists
  update(tenantId: string, id: string, patch: Partial<WorkflowItem>): Promise<WorkflowItem | null>;
  get(tenantId: string, id: string): Promise<WorkflowItem | null>;
  query(tenantId: string, q: ItemQuery): Promise<WorkflowItem[]>;
}
/** Scope of one evaluation: which workflows ran and (optionally) for which subjects. Open items inside the scope that are no longer proposed are resolved. */
export interface Scope { workflows: readonly string[]; subjects?: readonly { kind: string; id: string }[] }

/** A workflow definition: a pure function over the facts of one AI Business System. `F` is that system's own fact bundle. */
export interface WorkflowDef<F> { id: string; employee: string; run(facts: F): Proposal[] }
