import type { D1Database } from "@cloudflare/workers-types";
import type { ItemQuery, WorkflowItem, WorkflowStore } from "./types";

type Row = Record<string, unknown>;
const J = (v: unknown): unknown => { try { return JSON.parse(String(v)); } catch { return null; } };
const dec = (r: Row): WorkflowItem => ({
  id: r.id as string, tenantId: r.tenant_id as string, system: r.system as string, workflow: r.workflow as string, kind: r.kind as WorkflowItem["kind"], employee: r.employee as string, code: r.code as string,
  subjectKind: r.subject_kind as string, subjectId: r.subject_id as string, priority: r.priority as WorkflowItem["priority"], params: (J(r.params) ?? {}) as WorkflowItem["params"], evidence: (J(r.evidence) ?? []) as WorkflowItem["evidence"],
  dedupKey: r.dedup_key as string, status: r.status as WorkflowItem["status"], decidedBy: (r.decided_by as string | null) ?? null, decidedAt: (r.decided_at as number | null) ?? null, createdAt: r.created_at as number, updatedAt: r.updated_at as number,
});
const COL: Record<string, string> = { priority: "priority", params: "params", evidence: "evidence", status: "status", decidedBy: "decided_by", decidedAt: "decided_at", updatedAt: "updated_at" };
/** Plain parameterized SQL. Every statement is scoped by tenant_id; identifiers come from a fixed whitelist; values are always bound. */
export function createD1WorkflowStore(d1: D1Database): WorkflowStore {
  async function get(t: string, id: string) { const r = await d1.prepare("SELECT * FROM wf_items WHERE tenant_id = ? AND id = ?").bind(t, id).first<Row>(); return r ? dec(r) : null; }
  return {
    async insert(r) {
      const res = await d1.prepare("INSERT OR IGNORE INTO wf_items (id, tenant_id, system, workflow, kind, employee, code, subject_kind, subject_id, priority, params, evidence, dedup_key, status, decided_by, decided_at, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
        .bind(r.id, r.tenantId, r.system, r.workflow, r.kind, r.employee, r.code, r.subjectKind, r.subjectId, r.priority, JSON.stringify(r.params), JSON.stringify(r.evidence), r.dedupKey, r.status, r.decidedBy, r.decidedAt, r.createdAt, r.updatedAt).run();
      return (res.meta?.changes ?? 0) > 0;
    },
    get,
    async update(t, id, patch) {
      const keys = Object.keys(patch).filter((k) => k in COL && (patch as Row)[k] !== undefined);
      if (keys.length) await d1.prepare(`UPDATE wf_items SET ${keys.map((k) => `${COL[k]} = ?`).join(", ")} WHERE tenant_id = ? AND id = ?`).bind(...keys.map((k) => { const v = (patch as Row)[k]; return k === "params" || k === "evidence" ? JSON.stringify(v) : (v as string | number | null); }), t, id).run();
      return get(t, id);
    },
    async query(t, q: ItemQuery) {
      const w = ["tenant_id = ?", "system = ?"], b: (string | number)[] = [t, q.system], inl = (col: string, v?: readonly string[]) => { if (v) { w.push(v.length ? `${col} IN (${v.map(() => "?").join(",")})` : "0 = 1"); b.push(...v); } };
      inl("workflow", q.workflows); inl("status", q.statuses); inl("kind", q.kinds);
      if (q.subject) { w.push("subject_kind = ? AND subject_id = ?"); b.push(q.subject.kind, q.subject.id); }
      if (q.since !== undefined) { w.push("created_at >= ?"); b.push(q.since); }
      const r = await d1.prepare(`SELECT * FROM wf_items WHERE ${w.join(" AND ")} ORDER BY created_at DESC, id DESC LIMIT ?`).bind(...b, Math.min(1000, Math.max(1, q.limit))).all<Row>();
      return r.results.map(dec);
    },
  };
}
