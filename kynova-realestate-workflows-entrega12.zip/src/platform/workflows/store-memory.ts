import type { ItemQuery, WorkflowItem, WorkflowStore } from "./types";

export function createMemoryWorkflowStore(): WorkflowStore {
  const rows = new Map<string, WorkflowItem>();
  return {
    async insert(row) { for (const r of rows.values()) if (r.tenantId === row.tenantId && r.system === row.system && r.dedupKey === row.dedupKey) return false; rows.set(row.id, structuredClone(row)); return true; },
    async get(t, id) { const r = rows.get(id); return r && r.tenantId === t ? structuredClone(r) : null; },
    async update(t, id, patch) { const r = rows.get(id); if (!r || r.tenantId !== t) return null; const n = { ...r, ...patch, id: r.id, tenantId: r.tenantId }; rows.set(id, n); return structuredClone(n); },
    async query(t, q: ItemQuery) {
      return [...rows.values()].filter((r) => r.tenantId === t && r.system === q.system && (!q.workflows || q.workflows.includes(r.workflow)) && (!q.statuses || q.statuses.includes(r.status)) && (!q.kinds || q.kinds.includes(r.kind))
        && (!q.subject || (r.subjectKind === q.subject.kind && r.subjectId === q.subject.id)) && (q.since === undefined || r.createdAt >= q.since))
        .sort((a, b) => b.createdAt - a.createdAt || (a.id < b.id ? 1 : -1)).slice(0, q.limit).map((r) => structuredClone(r));
    },
  };
}
