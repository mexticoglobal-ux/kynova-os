import type { ActivitySink } from "@/platform/activity";
import { plan } from "./engine";
import type { ItemStatus, Proposal, Scope, WorkflowItem, WorkflowStore } from "./types";

export interface WorkflowCtx { tenantId: string; userId: string; requestId?: string; /** blueprint key → Activity Engine key of the real AI Employee, so the evidence names who did the work */ employees?: Readonly<Record<string, string>> }
export interface WorkflowDeps {
  store: WorkflowStore; newId: () => string; now?: () => number; activity?: ActivitySink;
}
export type WorkflowService = ReturnType<typeof createWorkflowService>;
const CAP = 1000, SAFE = /[^a-z0-9_]/g;

export function createWorkflowService(deps: WorkflowDeps) {
  const { store } = deps, now = deps.now ?? Date.now;
  /** Applies the proposals of one evaluation. Records one Activity Engine event per NEW finding, attributed to the AI Employee that found it. */
  async function apply(ctx: WorkflowCtx, system: string, scope: Scope, proposals: readonly Proposal[]) {
    const existing = await store.query(ctx.tenantId, { system, workflows: scope.workflows, limit: CAP }), p = plan(existing, proposals, scope), t = now();
    let created = 0;
    for (const x of p.create) {
      const row: WorkflowItem = { id: deps.newId(), tenantId: ctx.tenantId, system, workflow: x.workflow, kind: x.kind, employee: x.employee, code: x.code, subjectKind: x.subjectKind, subjectId: x.subjectId, priority: x.priority, params: x.params, evidence: x.evidence, dedupKey: x.dedupKey, status: "open", decidedBy: null, decidedAt: null, createdAt: t, updatedAt: t };
      if (!(await store.insert(row))) continue;
      created++;
      if (deps.activity) {
        const ek = ctx.employees?.[x.employee] ?? x.employee;
        await deps.activity.record({ tenantId: ctx.tenantId, ...(ctx.requestId ? { requestId: ctx.requestId } : {}) }, {
          module: system, source: system, action: `${system}.workflow.${x.workflow.replace(SAFE, "_")}`, summary: x.summary.slice(0, 240), actorKind: "employee", actorId: ek, employeeKey: ek,
          mode: "production", subjectKind: x.subjectKind, subjectId: x.subjectId, idempotencyKey: `wf:${row.id}`,
        });
      }
    }
    for (const u of p.update) await store.update(ctx.tenantId, u.id, { priority: u.priority, params: u.params, updatedAt: t });
    for (const r of p.reopen) await store.update(ctx.tenantId, r.id, { status: "open", priority: r.priority, params: r.params, updatedAt: t });
    for (const id of p.resolve) await store.update(ctx.tenantId, id, { status: "resolved", updatedAt: t });
    return { created, updated: p.update.length + p.reopen.length, resolved: p.resolve.length };
  }
  const list = (tenantId: string, q: { system: string; workflows?: readonly string[]; statuses?: readonly ItemStatus[]; kinds?: readonly WorkflowItem["kind"][]; subject?: { kind: string; id: string }; since?: number; limit?: number }) =>
    store.query(tenantId, { ...q, kinds: q.kinds ?? ["recommendation", "task", "review", "opportunity"], limit: q.limit ?? 200 });
  /** The human decision. Only an open item can be decided, once. Deciding changes the item only: it never touches business data. */
  async function decide(ctx: WorkflowCtx, system: string, id: string, approve: boolean): Promise<WorkflowItem | "not_found" | "invalid_state"> {
    const cur = await store.get(ctx.tenantId, id);
    if (!cur || cur.system !== system || cur.kind === "marker") return "not_found";
    if (cur.status !== "open") return "invalid_state";
    const t = now(), row = (await store.update(ctx.tenantId, id, { status: approve ? "approved" : "dismissed", decidedBy: ctx.userId, decidedAt: t, updatedAt: t })) as WorkflowItem;
    await deps.activity?.record({ tenantId: ctx.tenantId, ...(ctx.requestId ? { requestId: ctx.requestId } : {}) }, {
      module: system, source: system, action: `${system}.workflow.${approve ? "approved" : "dismissed"}`, summary: `${approve ? "Approved" : "Dismissed"}: ${cur.code}`.slice(0, 240), actorKind: "user", actorId: ctx.userId, mode: "production", subjectKind: cur.subjectKind, subjectId: cur.subjectId, idempotencyKey: `wf:${id}:decided`,
    });
    return row;
  }
  /** Throttle for the periodic sweep: remembers when it last ran (a marker row, one per system). */
  async function lastSweep(tenantId: string, system: string): Promise<number | null> { return (await store.query(tenantId, { system, kinds: ["marker"], limit: 1 }))[0]?.updatedAt ?? null; }
  async function markSweep(ctx: WorkflowCtx, system: string): Promise<void> {
    const t = now(), cur = (await store.query(ctx.tenantId, { system, kinds: ["marker"], limit: 1 }))[0];
    if (cur) await store.update(ctx.tenantId, cur.id, { updatedAt: t });
    else await store.insert({ id: deps.newId(), tenantId: ctx.tenantId, system, workflow: "sweep", kind: "marker", employee: "system", code: "sweep", subjectKind: "system", subjectId: system, priority: "low", params: {}, evidence: [], dedupKey: "sweep:marker", status: "resolved", decidedBy: null, decidedAt: null, createdAt: t, updatedAt: t });
  }
  return { apply, list, decide, lastSweep, markSweep };
}
export { plan };
