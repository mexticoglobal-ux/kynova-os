import { createMemoryWorkflowStore } from "./store-memory";
import type { WorkflowStore } from "./types";

let override: WorkflowStore | null = null;
export const setWorkflowStore = (s: WorkflowStore | null): void => { override = s; };
const g = globalThis as unknown as { __kynovaWorkflowDevStore?: WorkflowStore };
const isDevLike = (): boolean => process.env.APP_ENV === "local" || process.env.NODE_ENV === "test" || process.env.NODE_ENV === "development";
/** D1 in the Worker (the binding is per request); in-memory on a laptop; fails closed anywhere else. */
export async function getWorkflowStore(): Promise<WorkflowStore> {
  if (override) return override;
  try {
    const { getCloudflareContext } = await import("@opennextjs/cloudflare");
    const d1 = getCloudflareContext().env.DB;
    if (d1) { const { createD1WorkflowStore } = await import("./store-d1"); return createD1WorkflowStore(d1); }
  } catch { /* no Cloudflare context */ }
  if (!isDevLike()) throw new Error("The workflow database is not available. Check the D1 binding.");
  return (g.__kynovaWorkflowDevStore ??= createMemoryWorkflowStore());
}
