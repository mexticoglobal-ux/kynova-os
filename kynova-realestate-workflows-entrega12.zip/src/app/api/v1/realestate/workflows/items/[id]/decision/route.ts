import { realestateRoute, readBody, respond } from "@/modules/realestate/http";
type Ctx = { params: Promise<{ id: string }> };
/** Approve or dismiss a piece of work the team prepared. It only records the decision: nothing is sent or published. */
export const POST = realestateRoute<Ctx>(async (req, c, { actor, svc, rid }) => respond(await svc.decideWorkflowItem(actor, (await c.params).id, await readBody(req)), rid), { mutating: true });
