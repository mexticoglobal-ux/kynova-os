import { realestateRoute, respond } from "@/modules/realestate/http";
export const GET = realestateRoute(async (req, c, { actor, svc, rid }) => {
  void c; const p = req.nextUrl.searchParams;
  return respond(await svc.listWorkflowItems(actor, { ...(p.get("status") ? { status: p.get("status") as string } : {}), ...(p.get("kind") ? { kind: p.get("kind") as string } : {}), ...(p.get("workflow") ? { workflow: p.get("workflow") as string } : {}) }), rid);
});
