import { realestateRoute, respond } from "@/modules/realestate/http";
export const GET = realestateRoute(async (req, c, { actor, svc, rid }) => { void c; const p = req.nextUrl.searchParams; return respond(await svc.timeline(actor, { ...(p.get("since") ? { since: Number(p.get("since")) } : {}), ...(p.get("limit") ? { limit: Number(p.get("limit")) } : {}) }), rid); });
