import { realestateRoute, respond } from "@/modules/realestate/http";
/** Runs every workflow for the company (idempotent). `?stale_minutes=N` skips the run when one finished less than N minutes ago. Cron-ready: no payload needed. */
export const POST = realestateRoute(async (req, c, { actor, svc, rid }) => {
  void c; const m = Number(req.nextUrl.searchParams.get("stale_minutes") ?? "");
  return respond(Number.isFinite(m) && m > 0 ? await svc.sweepIfStale(actor, m * 60_000) : { ran: true, ...(await svc.sweep(actor)) }, rid);
}, { mutating: true });
