import { realestateRoute, respond } from "@/modules/realestate/http";
export const GET = realestateRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(await svc.scores(actor), rid); });
