import type { WorkflowItem } from "@/platform/workflows";
import { Card, Empty, Pill } from "@/components/workforce/ui";
import { REALESTATE_DICTIONARIES, type RealEstateKey, type RealEstateLocale } from "@/modules/realestate";
import { DecisionButtons, LocalTime } from "./WorkActions";
import { RealEstateI18n } from "./I18n";

type T = (k: RealEstateKey, v?: Record<string, number | string>) => string;
export interface TimelineEvent { occurredAt: number; employee: string; action: string }
const TONE = { high: "danger", medium: "info", low: "muted" } as const;
const vars = (p: WorkflowItem["params"]) => Object.fromEntries(Object.entries(p).filter(([, v]) => typeof v !== "boolean")) as Record<string, number | string>;
/** What the team prepared and is waiting on you for, written as sentences. The person approves or dismisses; nothing is sent. */
export function PendingWork({ items, names, t, can }: { items: WorkflowItem[]; names: Record<string, string>; t: T; can: boolean }) {
  return (
    <Card title={t("wi.title")}>
      <p className="mb-2 text-xs text-muted">{t("wi.note")}</p>
      {items.length === 0 ? <Empty>{t("wi.none")}</Empty> : (
        <div className="grid gap-2">{items.slice(0, 6).map((i) => (
          <article key={i.id} className="grid gap-1 rounded-xl border border-line px-3 py-2 text-sm">
            <div className="flex flex-wrap items-center gap-2"><strong>{names[i.employee] ?? i.employee}</strong><Pill tone={TONE[i.priority]}>{t(`wi.p.${i.priority}` as RealEstateKey)}</Pill></div>
            <p>{t(`wi.${i.code}` as RealEstateKey, vars(i.params))}</p>
            {i.code === "listing_review" && <p className="text-xs text-muted">{(["s_description", "s_price", "s_media"] as const).filter((k) => i.params[k] === true).map((k) => t(`wi.${k}` as RealEstateKey)).join(" ")}</p>}
            {can && <div><DecisionButtons id={i.id} /></div>}
          </article>))}</div>)}
    </Card>
  );
}
/** The team's real day, straight from the Activity Engine. */
export function TeamTimeline({ events, names, t }: { events: TimelineEvent[]; names: Record<string, string>; t: T }) {
  const phrase = (action: string) => { const k = `tl.${action.split(".").slice(1).join(".")}` as RealEstateKey; return REALESTATE_DICTIONARIES.en[k] ? k : "tl.other"; };
  return (
    <Card title={t("tl.title")}>
      {events.length === 0 ? <Empty>{t("tl.none")}</Empty> : (
        <ol className="grid gap-0 border-l border-line pl-3">{[...events].reverse().map((e, n) => (
          <li key={n} className="flex items-baseline gap-2 py-1 text-sm"><LocalTime ms={e.occurredAt} /><span><strong>{names[e.employee] ?? e.employee}</strong> {t(phrase(e.action))}</span></li>))}</ol>)}
    </Card>
  );
}
/** Client i18n provider for the buttons and clocks inside the cards above. */
export function TeamWorkProvider({ locale, children }: { locale: RealEstateLocale; children: React.ReactNode }) { return <RealEstateI18n dict={REALESTATE_DICTIONARIES[locale]} locale={locale}>{children}</RealEstateI18n>; }
