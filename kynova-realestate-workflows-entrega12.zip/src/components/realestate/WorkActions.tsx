"use client";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { wfCall } from "@/components/workforce/api";
import { useT } from "./I18n";

const btn = "rounded-lg border border-line px-2.5 py-1 text-xs hover:bg-ac/10 disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-ac2";
/** Approve or dismiss a piece of work the team prepared. It only records the decision: nothing is sent or published. */
export function DecisionButtons({ id }: { id: string }) {
  const router = useRouter(), { t } = useT(), [busy, setBusy] = useState(false), [err, setErr] = useState<string | null>(null);
  async function go(approve: boolean) { setBusy(true); setErr(null); const r = await wfCall("POST", `/realestate/workflows/items/${id}/decision`, { approve }); setBusy(false); if (!r.ok) { setErr(r.message ?? t("common.error")); return; } router.refresh(); }
  return <span className="inline-flex flex-wrap items-center gap-1"><button type="button" className={btn} disabled={busy} onClick={() => void go(true)}>{t("approve")}</button><button type="button" className={btn} disabled={busy} onClick={() => void go(false)}>{t("wi.dismiss")}</button>{err && <span role="status" className="text-xs text-rose-700 dark:text-rose-300">{err}</span>}</span>;
}
/** Local clock time of an event (the server does not know the person's time zone). */
export function LocalTime({ ms }: { ms: number }) {
  const { locale } = useT(), [s, setS] = useState("");
  useEffect(() => setS(new Date(ms).toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" })), [ms, locale]);
  return <time dateTime={new Date(ms).toISOString()} className="w-12 shrink-0 text-xs tabular-nums text-muted">{s}</time>;
}
/** Runs the workflows once when the page opens (idempotent, skipped if one ran in the last hour). Cron can call the same endpoint. */
export function SweepOnOpen() {
  const router = useRouter();
  useEffect(() => { let off = false; void wfCall("POST", "/realestate/workflows/run?stale_minutes=60", {}).then((r) => { if (!off && r.ok && (r.data as { ran?: boolean } | undefined)?.ran) router.refresh(); }); return () => { off = true; }; }, [router]);
  return null;
}
