# ADR 029 – Motor de Workflows genérico (Entrega 12)

**Estado:** aceptado.

**Contexto.** Cada AI Business System necesita "trabajo que ocurre solo y espera aprobación". Escribirlo dentro de Real Estate obligaría a rehacerlo en YouTube, Ecommerce, Finanzas y CRM.

**Decisión.**
1. Un motor genérico en `src/platform/workflows` (no es un módulo): reglas puras → propuestas → almacén por tenant → decisión humana. Un solo almacén (`wf_items`) con columna `system`.
2. Real Estate aporta solo reglas puras (`workflows.ts`, `scores.ts`) y las expone por sus propias rutas. No hay entidades nuevas del negocio: las tareas, revisiones y recomendaciones son *hallazgos* del motor; las publicaciones siguen siendo `re_publications`.
3. Disparo: por eventos (acotado a los sujetos afectados), por barrido idempotente y limitado, y por endpoint listo para cron. Un fallo del workflow nunca rompe la operación de negocio.
4. Evidencia: un evento del Activity Engine por hallazgo nuevo, atribuido al AI Employee; la línea de tiempo se lee de ahí.
5. Bootstrap: el flag se lee de Blueprints solo en la composition root (`server.ts`), por un puerto.

**Alternativas descartadas.** Tablas por sistema (duplica); cola/cron global (estado compartido, infra nueva); IA para priorizar (fuera de alcance).

**¿Escala a 10.000 empresas sin rediseño?** Sí: todo aislado por tenant con índices tenant-first, sin estado global ni tareas globales; el costo de un barrido es acotado por tenant y se puede mover a un Cron/Queue sin cambiar las reglas.

**Consecuencias.** Sin cron real los barridos ocurren al operar o abrir Mission Control; un Cron Trigger es la siguiente pieza (Entrega 13+).
