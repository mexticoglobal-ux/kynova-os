# 37 – Real Estate Workflows V1 (Entrega 12)

El usuario siente que tiene un equipo trabajando aunque no esté conectado. Todo se apoya en el Activity Engine, es por tenant, y **nada se envía ni se publica**: el equipo solo **propone**; la persona aprueba o descarta.

## Motor genérico (reutilizable): `src/platform/workflows`
- `WorkflowDef<F>`: función **pura** `(hechos) → Proposal[]`. Sin I/O, reloj, red ni IA.
- `plan()`: crea hallazgos nuevos, refresca los que cambiaron, **resuelve** los que dejaron de ser ciertos y **reabre** los que vuelven. Idempotente por `dedupKey` (la clave incluye el estado del que depende el hallazgo: un hallazgo ya decidido no vuelve para la misma situación).
- `createWorkflowService`: `apply` (guarda + una evidencia en el Activity Engine por hallazgo nuevo, atribuida al AI Employee), `list`, `decide` (aprobar/descartar, una sola vez), `lastSweep/markSweep`.
- Tabla `wf_items` (migración `2200_workflows.sql`), columna `system`: YouTube, Ecommerce, Finanzas, CRM, Restaurantes… solo escriben sus `WorkflowDef` y su módulo expone las rutas. Un test garantiza que la plataforma no importa ningún módulo ni menciona Real Estate.

## Los 10 workflows
| # | Workflow | Empleado | Cómo |
|---|---|---|---|
| 1 | Buyer Matching | Buyer Specialist | Motor de reglas actual. Se dispara al crear/editar propiedad o comprador (presupuesto, zonas, etc.). Recomendación priorizada + evidencia. No contacta. |
| 2 | Follow-up | Follow-up Manager | Comprador/propietario sin actividad ≥ 7 días (alta ≥ 14) → tarea con el porqué. No si ya hay algo agendado. |
| 3 | Listing Review | Listing Manager | Propiedad activa ≥ 30 días → revisión (descripción, precio, medios). No modifica la propiedad. |
| 4 | Publication Draft | Marketing Manager | Propiedad lista (activa, descripción ≥ 40, zona, precio) sin publicaciones → 5 briefs `proposed`. Nada publicado. |
| 5 | Daily Digest | — | "Mientras estabas fuera…" en Mission Control: solo conteos reales. |
| 6 | Property Health | — | 0–100, reglas, con explicación por factor. |
| 7 | Opportunity | Real Estate Director | Alta/Media/Baja para cada comprador, propietario y propiedad, con razones. Las "Alta" generan un hallazgo. |
| 8 | Timeline | — | Eventos de empleados leídos del Activity Engine. |
| 9 | Bootstrap | Marketing Manager | Solo palancas gratuitas (SEO, Google Business, contenido, redes, captación, referidos). No existe palanca de publicidad pagada. |
| 10 | Recomendaciones | varios | Textos simples con los números reales. |

## Honestidad (qué no se hace)
- **Fotos/video/recorrido virtual**: la propiedad no los registra; el health score los declara "no evaluados" y la revisión los ofrece como "verifica", nunca como hallazgo.
- **Tasa de conversión semanal**: no se puede reconstruir (los cambios de etapa no tienen fecha). Se reporta la caída de **cierres** (semana vs semana anterior) y de **actividades completadas**.
- "Sin actividad" = la última edición del registro o la última actividad completada.
- **Sin cron todavía**: corre (a) al crear/editar propiedad, comprador, propietario o actividad, (b) al abrir Mission Control (máx. 1 vez/hora) y (c) con `POST /api/v1/realestate/workflows/run` (listo para un cron). Con la app cerrada no se ejecuta nada hasta que haya un Cron Trigger.

## API (`/api/v1/realestate/workflows`)
`GET items` · `POST items/{id}/decision {approve}` · `POST run[?stale_minutes=N]` · `GET scores` · `GET timeline`.

## Rendimiento / escala
Todo con `tenant_id` primero, sin estado global. Barrido: O(compradores × propiedades) con tope de 2000 registros por tipo; los eventos recalculan solo los sujetos afectados (O(n)). El `Matcher` es sustituible por un índice sin tocar los workflows.
