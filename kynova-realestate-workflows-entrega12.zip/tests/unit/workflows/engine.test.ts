import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { createMemoryWorkflowStore, createWorkflowService, plan, runDefs, type Proposal, type Scope, type WorkflowDef, type WorkflowItem } from "@/platform/workflows";

/** A made-up system ("youtube") proves the engine knows nothing about Real Estate. */
interface Facts { videos: { id: string; views: number }[] }
const lowViews: WorkflowDef<Facts> = { id: "low_views", employee: "analyst", run: (f) => f.videos.filter((v) => v.views < 100).map((v): Proposal => ({ workflow: "low_views", kind: "recommendation", employee: "analyst", code: "low_views", subjectKind: "video", subjectId: v.id, priority: "medium", params: { views: v.views }, evidence: [{ kind: "video", id: v.id, label: v.id }], summary: `Video ${v.id} has ${v.views} views`, dedupKey: `lv:${v.id}` })) };
const setup = () => {
  let n = 0, t = 1_000; const events: { action: string; employeeKey?: string | null }[] = [];
  const svc = createWorkflowService({ store: createMemoryWorkflowStore(), newId: () => `w${++n}`, now: () => t, activity: { async record(_c, e) { events.push(e); return { ok: false, error: { code: "x", message: "captured" } }; }, async recordStrict() { throw new Error("x"); } } });
  return { svc, events, tick: (ms: number) => { t += ms; } };
};
const ctx = { tenantId: "t1", userId: "u1", employees: { analyst: "emp_9" } }, scope = { workflows: ["low_views"] };

describe("generic workflow engine", () => {
  it("creates, dedups, refreshes, resolves and reopens, per scope", async () => {
    const { svc, events } = setup(), run = (videos: Facts["videos"], sc: Scope = scope) => svc.apply(ctx, "youtube", sc, runDefs([lowViews], { videos }));
    expect(await run([{ id: "a", views: 10 }, { id: "b", views: 20 }])).toMatchObject({ created: 2 });
    expect(await run([{ id: "a", views: 10 }, { id: "b", views: 20 }])).toEqual({ created: 0, updated: 0, resolved: 0 });
    expect(events).toHaveLength(2); expect(events[0]).toMatchObject({ action: "youtube.workflow.low_views", employeeKey: "emp_9" });
    expect(await run([{ id: "a", views: 11 }])).toMatchObject({ updated: 1, resolved: 1 }); // a refreshed, b cleared by itself
    expect(await run([{ id: "a", views: 11 }, { id: "b", views: 5 }])).toMatchObject({ updated: 1 }); // b came back → reopened
    expect((await svc.list("t1", { system: "youtube" })).filter((i) => i.status === "open")).toHaveLength(2);
    expect(await run([], { workflows: ["low_views"], subjects: [{ kind: "video", id: "a" }] })).toMatchObject({ resolved: 1 }); // only a was in scope
    expect((await svc.list("t1", { system: "youtube", statuses: ["open"] })).map((i) => i.subjectId)).toEqual(["b"]);
  });
  it("a decided item is final and is never proposed again; other tenants and systems never see it", async () => {
    const { svc } = setup(); await svc.apply(ctx, "youtube", scope, runDefs([lowViews], { videos: [{ id: "a", views: 1 }] }));
    const [i] = await svc.list("t1", { system: "youtube" }) as [WorkflowItem];
    expect(await svc.decide({ ...ctx, tenantId: "t2" }, "youtube", i.id, true)).toBe("not_found"); expect(await svc.decide(ctx, "other", i.id, true)).toBe("not_found");
    expect(await svc.decide(ctx, "youtube", i.id, false)).toMatchObject({ status: "dismissed", decidedBy: "u1" }); expect(await svc.decide(ctx, "youtube", i.id, true)).toBe("invalid_state");
    expect(await svc.apply(ctx, "youtube", scope, runDefs([lowViews], { videos: [{ id: "a", views: 1 }] }))).toEqual({ created: 0, updated: 0, resolved: 0 });
    expect(await svc.list("t2", { system: "youtube" })).toEqual([]); expect(await svc.list("t1", { system: "ecommerce" })).toEqual([]);
  });
  it("tracks the last sweep per system without showing it as work", async () => {
    const { svc, tick } = setup(); expect(await svc.lastSweep("t1", "youtube")).toBeNull(); await svc.markSweep(ctx, "youtube"); tick(500); await svc.markSweep(ctx, "youtube");
    expect(await svc.lastSweep("t1", "youtube")).toBe(1_500); expect(await svc.list("t1", { system: "youtube" })).toEqual([]);
  });
  it("plan() is pure", () => { expect(plan([], [], scope)).toEqual({ create: [], update: [], reopen: [], resolve: [] }); });
});
describe("the platform engine is generic", () => {
  const DIR = join(process.cwd(), "src", "platform", "workflows"), src = readdirSync(DIR).filter((f) => f.endsWith(".ts")).map((f) => readFileSync(join(DIR, f), "utf8")).join("\n");
  it("imports no business module and knows nothing about Real Estate", () => { expect(src).not.toMatch(/@\/modules\//); expect(src.toLowerCase()).not.toMatch(/real.?estate|propert|buyer/); });
  it("has no network, no AI and no way to send anything", () => { expect(src).not.toMatch(/\bfetch\(|XMLHttpRequest|ai-kernel|@anthropic|openai|twilio|sendgrid/i); });
});
