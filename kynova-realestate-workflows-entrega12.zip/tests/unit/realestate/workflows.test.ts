import { describe, expect, it } from "vitest";
import { BOOTSTRAP_LEVERS, WORKFLOW_IDS } from "../../../src/modules/realestate/workflows";
import { DAY, OTHER, OWNER, SALES, SUPPORT, code, harness, house, type H } from "./helpers";

const LONG = "Casa amplia y luminosa con jardín, cerca de comercios y colegios, lista para estrenar.";
const buyer = (o: Record<string, unknown> = {}) => ({ name: "Ana", intent: "sale", budgetMaxMinor: 30_000_000, zones: ["Escazú"], ...o });
const open = (h: H, a = OWNER, q: { workflow?: string } = {}) => h.svc.listWorkflowItems(a, q);

describe("Workflow 1 · Buyer Matching", () => {
  it("a new property finds the compatible buyers, with evidence and an attributed event, and contacts nobody", async () => {
    const h = harness(); await h.svc.createBuyer(OWNER, buyer()); await h.svc.createBuyer(OWNER, buyer({ name: "Beto", zones: ["Limón"] }));
    const p = await h.svc.createProperty(OWNER, house({ title: "Casa Escazú" }));
    const items = await open(h, OWNER, { workflow: "buyer_matching" });
    expect(items).toHaveLength(1); expect(items[0]).toMatchObject({ code: "buyer_matches", employee: "buyer_specialist", status: "open", subjectKind: "buyer" });
    expect(items[0]!.evidence).toEqual([{ kind: "property", id: p.id, label: "Casa Escazú" }]); expect(items[0]!.params.count).toBe(1);
    const ev = h.events.find((e) => e.action === "realestate.workflow.buyer_matching")!; expect(ev).toMatchObject({ actorKind: "employee", employeeKey: "emp_buyer_specialist", mode: "production" });
    expect(h.drafts).toEqual([]); // nothing was published or sent
  });
  it("a new buyer finds existing properties, and a change that removes the match resolves the item", async () => {
    const h = harness(); const p = await h.svc.createProperty(OWNER, house()); await h.svc.createBuyer(OWNER, buyer());
    expect(await open(h)).toHaveLength(1);
    await h.svc.updateProperty(OWNER, p.id, { priceMinor: 90_000_000 }); // now above the budget
    expect((await open(h, OWNER, { workflow: "buyer_matching" }))).toHaveLength(0);
  });
  it("changing the budget or the zones re-evaluates the buyer", async () => {
    const h = harness(); await h.svc.createProperty(OWNER, house()); const b = await h.svc.createBuyer(OWNER, buyer({ zones: ["Limón"] }));
    expect(await open(h)).toHaveLength(0);
    await h.svc.updateBuyer(OWNER, b.id, { zones: ["Escazú"] }); expect(await open(h, OWNER, { workflow: "buyer_matching" })).toHaveLength(1);
    await h.svc.updateBuyer(OWNER, b.id, { budgetMaxMinor: 1_000_000 }); expect(await open(h, OWNER, { workflow: "buyer_matching" })).toHaveLength(0);
  });
});

describe("Workflow 2 · Follow-up", () => {
  it("an idle buyer or owner becomes a task for the Follow-up Manager, with the reason and a priority, waiting for approval", async () => {
    const h = harness(); const b = await h.svc.createBuyer(OWNER, buyer({ zones: [] })), o = await h.svc.createOwner(OWNER, { name: "Luis" });
    h.clock.t += 8 * DAY; await h.svc.sweep(OWNER);
    const t = await open(h, OWNER, { workflow: "followup" }); expect(t.map((x) => x.code).sort()).toEqual(["followup_buyer", "followup_owner"]);
    expect(t.every((x) => x.employee === "follow_up_manager" && x.status === "open" && x.priority === "medium" && x.params.days === 8)).toBe(true);
    h.clock.t += 7 * DAY; await h.svc.sweep(OWNER); expect((await open(h, OWNER, { workflow: "followup" })).every((x) => x.priority === "high")).toBe(true);
    expect(b.id && o.id).toBeTruthy(); expect(h.drafts).toEqual([]);
  });
  it("a planned visit, or a completed contact, removes the need", async () => {
    const h = harness(); const b = await h.svc.createBuyer(OWNER, buyer({ zones: [] })); h.clock.t += 9 * DAY; await h.svc.sweep(OWNER);
    expect(await open(h, OWNER, { workflow: "followup" })).toHaveLength(1);
    const act = await h.svc.createActivity(OWNER, { kind: "call", title: "Llamar a Ana", whenAt: h.clock.t - 1000, buyerId: b.id }); await h.svc.updateActivity(OWNER, act.id, { status: "done" });
    expect(await open(h, OWNER, { workflow: "followup" })).toHaveLength(0);
  });
  it("a decided task is never proposed again for the same inactivity", async () => {
    const h = harness(); await h.svc.createBuyer(OWNER, buyer({ zones: [] })); h.clock.t += 9 * DAY; await h.svc.sweep(OWNER);
    const [t] = await open(h, OWNER, { workflow: "followup" }); await h.svc.decideWorkflowItem(OWNER, t!.id, { approve: false }); await h.svc.sweep(OWNER);
    expect(await open(h, OWNER, { workflow: "followup" })).toHaveLength(0);
  });
});

describe("Workflow 3 · Listing Review", () => {
  it("a long-listed property gets a review of suggestions and is never modified", async () => {
    const h = harness(); const p = await h.svc.createProperty(OWNER, house({ description: "corta" })); h.clock.t += 31 * DAY; await h.svc.sweep(OWNER);
    const [r] = await open(h, OWNER, { workflow: "listing_review" }); expect(r).toMatchObject({ kind: "review", employee: "listing_manager", subjectId: p.id });
    expect(r!.params).toMatchObject({ days: 31, visits: 0, s_description: true, s_price: true, s_media: true });
    expect((await h.svc.getProperty(OWNER, p.id)).updatedAt).toBe(p.updatedAt);
    await h.svc.sweep(OWNER); expect(await open(h, OWNER, { workflow: "listing_review" })).toHaveLength(1); // idempotent
  });
  it("a recent property gets no review", async () => { const h = harness(); await h.svc.createProperty(OWNER, house()); h.clock.t += 5 * DAY; await h.svc.sweep(OWNER); expect(await open(h, OWNER, { workflow: "listing_review" })).toEqual([]); });
});

describe("Workflow 4 · Publication Draft", () => {
  it("a ready property gets a brief for each channel, all proposed, nothing published", async () => {
    const h = harness(); const p = await h.svc.createProperty(OWNER, house({ description: LONG }));
    const pubs = await h.svc.listPublications(OWNER); expect(pubs.map((x) => x.channel).sort()).toEqual(["email", "facebook", "instagram", "linkedin", "whatsapp"]);
    expect(pubs.every((x) => x.status === "proposed" && x.outcome === "" && x.propertyId === p.id)).toBe(true); expect(h.drafts).toEqual([]);
    await h.svc.sweep(OWNER); expect(await h.svc.listPublications(OWNER)).toHaveLength(5);
  });
  it("a property that is not ready gets none", async () => { const h = harness(); await h.svc.createProperty(OWNER, house({ description: "corta" })); expect(await h.svc.listPublications(OWNER)).toEqual([]); });
});

describe("Workflow 5 · Daily digest", () => {
  it("shows only real work, per employee", async () => {
    const h = harness(); expect((await h.svc.digest(OWNER)).items).toEqual([]);
    await h.svc.createBuyer(OWNER, buyer()); await h.svc.createProperty(OWNER, house({ description: LONG }));
    const d = await h.svc.digest(OWNER), k = Object.fromEntries(d.items.map((i) => [i.key, i.count]));
    expect(k.w_matches).toBe(1); expect(k.w_drafts).toBe(5); expect(k.w_opportunities).toBeUndefined(); expect(k.w_reviews).toBeUndefined();
  });
});

describe("Workflows 6 and 7 · Scores (rules, no AI)", () => {
  it("health is 0-100, explained factor by factor, and photos are reported as not evaluated", async () => {
    const h = harness(); await h.svc.createProperty(OWNER, house({ description: LONG, address: "Calle 1", bathrooms: 2, areaM2: 180 })); await h.svc.createProperty(OWNER, house({ title: "Vacía", zone: "" }));
    const s = await h.svc.scores(OWNER), full = s.properties.find((p) => p.title !== "Vacía")!, bare = s.properties.find((p) => p.title === "Vacía")!;
    expect(s.engine).toBe("rules"); expect(s.ai).toBe(false);
    for (const p of s.properties) { expect(p.health.score).toBeGreaterThanOrEqual(0); expect(p.health.score).toBeLessThanOrEqual(100); expect(p.health.notEvaluated).toContain("media"); expect(p.health.factors.length).toBeGreaterThan(3); }
    expect(full.health.score).toBeGreaterThan(bare.health.score); expect(full.health.factors.find((f) => f.code === "description")).toMatchObject({ points: 20, max: 20 });
  });
  it("every buyer, owner and property has a High, Medium or Low level with reasons", async () => {
    const h = harness(); await h.svc.createOwner(OWNER, { name: "Luis" }); await h.svc.createProperty(OWNER, house());
    const hot = await h.svc.createBuyer(OWNER, buyer({ name: "Hot" })); await h.svc.updateBuyer(OWNER, hot.id, { stage: "negotiating" }); await h.svc.createBuyer(OWNER, buyer({ name: "Cold", zones: ["Limón"] }));
    const s = await h.svc.scores(OWNER);
    for (const x of [...s.buyers, ...s.owners, ...s.properties]) expect(["high", "medium", "low"]).toContain(x.opportunity.level);
    expect(s.buyers.find((b) => b.id === hot.id)!.opportunity.level).toBe("high"); expect(s.buyers.find((b) => b.name === "Cold")!.opportunity.level).toBe("low");
    expect(s.buyers.find((b) => b.id === hot.id)!.opportunity.reasons.length).toBeGreaterThan(0);
    expect((await open(h, OWNER, { workflow: "opportunity" })).some((i) => i.subjectId === hot.id)).toBe(true);
  });
});

describe("Workflow 8 · Timeline", () => {
  it("comes from the Activity Engine and names the employee who did the work", async () => {
    const h = harness(); await h.svc.createBuyer(OWNER, buyer()); await h.svc.createProperty(OWNER, house({ description: LONG }));
    const tl = await h.svc.timeline(OWNER, { since: 0 }); const acts = tl.events.map((e) => e.action);
    expect(acts).toContain("realestate.workflow.buyer_matching"); expect(acts).toContain("realestate.publication.prepared");
    expect(tl.events.find((e) => e.action === "realestate.workflow.buyer_matching")!.employee).toBe("buyer_specialist");
    expect(tl.events.every((e) => !e.action.includes("property.created"))).toBe(true); // user actions are not the team's work
  });
});

describe("Workflow 9 · Bootstrap never recommends paid advertising", () => {
  it("in Bootstrap, only the free levers appear and every one is grounded in the company's data", async () => {
    const h = harness({ bootstrap: true }); await h.svc.createProperty(OWNER, house({ description: LONG })); await h.svc.sweep(OWNER);
    const g = await open(h, OWNER, { workflow: "bootstrap_growth" }); expect(g.map((x) => x.code).sort()).toEqual(["growth_captation", "growth_content", "growth_local"]);
    for (const i of g) for (const l of String(i.params.levers).split(",")) expect(BOOTSTRAP_LEVERS as readonly string[]).toContain(l);
    expect(JSON.stringify(g).toLowerCase()).not.toMatch(/paid|ads\b|advert|publicidad|campaign/);
  });
  it("outside Bootstrap there are no growth recommendations, and with no data there are none either", async () => {
    const a = harness(); await a.svc.createProperty(OWNER, house()); await a.svc.sweep(OWNER); expect(await open(a, OWNER, { workflow: "bootstrap_growth" })).toEqual([]);
    const b = harness({ bootstrap: true }); await b.svc.sweep(OWNER); expect((await open(b, OWNER, { workflow: "bootstrap_growth" })).map((x) => x.code)).toEqual(["growth_captation"]);
  });
});

describe("Workflow 10 · Recommendations", () => {
  it("closings falling week over week is reported with the real numbers; nothing is said without data", async () => {
    const h = harness(); await h.svc.sweep(OWNER); expect(await open(h, OWNER, { workflow: "performance_watch" })).toEqual([]);
    const p = await h.svc.createProperty(OWNER, house()); h.clock.t += 2 * DAY; await h.svc.updateProperty(OWNER, p.id, { status: "sold", closedPriceMinor: 24_000_000 });
    h.clock.t += 8 * DAY; await h.svc.sweep(OWNER);
    expect((await open(h, OWNER, { workflow: "performance_watch" })).find((i) => i.code === "closings_down")!.params).toEqual({ cur: 0, prev: 1 });
  });
});

describe("Engine rules shared by every workflow", () => {
  it("the decision changes only the item; a decided item cannot be decided again; viewers cannot decide", async () => {
    const h = harness(); await h.svc.createBuyer(OWNER, buyer()); await h.svc.createProperty(OWNER, house());
    const [i] = await open(h); expect(await code(h.svc.decideWorkflowItem(SALES, i!.id, { approve: true }))).toBe("forbidden");
    const d = await h.svc.decideWorkflowItem(OWNER, i!.id, { approve: true }); expect(d).toMatchObject({ status: "approved", decidedBy: OWNER.userId });
    expect(await code(h.svc.decideWorkflowItem(OWNER, i!.id, { approve: false }))).toBe("invalid_state"); expect(await code(h.svc.decideWorkflowItem(OWNER, "nope", { approve: true }))).toBe("not_found");
    expect(h.events.some((e) => e.action === "realestate.workflow.approved")).toBe(true); expect(h.drafts).toEqual([]);
  });
  it("is isolated by company and respects roles", async () => {
    const h = harness(); await h.svc.createBuyer(OWNER, buyer()); await h.svc.createProperty(OWNER, house());
    expect(await open(h, OTHER)).toEqual([]); expect(await code(open(h, SUPPORT))).toBe("forbidden"); expect(await code(h.svc.sweep(SUPPORT))).toBe("forbidden");
    expect((await h.svc.scores(OTHER)).properties).toEqual([]);
  });
  it("a sweep is idempotent and throttled", async () => {
    const h = harness(); await h.svc.createBuyer(OWNER, buyer()); await h.svc.createProperty(OWNER, house({ description: LONG }));
    const n = (await open(h)).length, ev = h.events.length; await h.svc.sweep(OWNER); await h.svc.sweep(OWNER); expect((await open(h)).length).toBe(n); expect(h.events.length).toBe(ev);
    expect((await h.svc.sweepIfStale(OWNER)).ran).toBe(false); h.clock.t += 2 * 3_600_000; expect((await h.svc.sweepIfStale(OWNER)).ran).toBe(true);
    expect(WORKFLOW_IDS.length).toBeGreaterThan(5);
  });
});

describe("Real Estate rules are pure", () => {
  it("the rule file has no I/O, no clock, no network", async () => {
    const { readFileSync } = await import("node:fs"), src = readFileSync("src/modules/realestate/workflows.ts", "utf8") + readFileSync("src/modules/realestate/scores.ts", "utf8");
    expect(src.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "")).not.toMatch(/Date\.now|new Date\(|fetch\(|store|process\.env|Math\.random/);
  });
  it("a failing workflow store never breaks the business operation", async () => {
    const { createRealEstateService } = await import("../../../src/modules/realestate/service"), { createMemoryRealEstateStore } = await import("../../../src/modules/realestate/store-memory");
    const bad = { insert: async () => { throw new Error("down"); }, update: async () => { throw new Error("down"); }, get: async () => { throw new Error("down"); }, query: async () => { throw new Error("down"); } };
    const svc = createRealEstateService({ store: createMemoryRealEstateStore(), ports: { member: async () => null, createDraft: async () => ({ id: "x" }) }, newId: (() => { let n = 0; return () => `i${++n}`; })(), workflows: bad });
    expect((await svc.createProperty(OWNER, house())).id).toBeTruthy(); expect((await svc.createBuyer(OWNER, buyer())).id).toBeTruthy();
  });
});
