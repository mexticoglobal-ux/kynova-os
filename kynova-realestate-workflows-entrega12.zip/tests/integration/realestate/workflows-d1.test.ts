import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { createD1WorkflowStore } from "../../../src/platform/workflows/store-d1";
import { createWorkflowService } from "../../../src/platform/workflows/service";
import { createRealEstateService, type Actor } from "../../../src/modules/realestate/service";
import { createD1RealEstateStore } from "../../../src/modules/realestate/store-d1";
import { createTestDb, newCompany, newUser } from "../db/helpers";

let t: Awaited<ReturnType<typeof createTestDb>>;
beforeAll(async () => { t = await createTestDb(); }, 60_000);
afterAll(async () => { await t.dispose(); });
const fresh = async (): Promise<Actor> => { const u = await newUser(t.db), c = await newCompany(t.db, u.id); return { tenantId: c.companyId, userId: u.id, role: "owner" }; };
const refused = async (p: Promise<unknown>) => { try { await p; return "no error"; } catch { return "refused"; } };

describe("wf_items on D1", () => {
  it("runs Real Estate workflows end to end on the real schema, isolated by company", async () => {
    const A = await fresh(), B = await fresh(), drafts: unknown[] = [];
    const svc = createRealEstateService({ store: createD1RealEstateStore(t.d1), workflows: createD1WorkflowStore(t.d1), newId: () => crypto.randomUUID().replace(/-/g, ""), ports: { member: async (_a, key) => ({ key, name: key, entitled: true, active: true, activityKey: key }), async createDraft(_a, d) { drafts.push(d); return { id: "p" }; } } });
    await svc.createBuyer(A, { name: "Ana", intent: "sale", budgetMaxMinor: 30_000_000, zones: ["Escazú"] });
    await svc.createProperty(A, { title: "Casa", operation: "sale", kind: "house", priceMinor: 25_000_000, zone: "Escazú", bedrooms: 3, description: "Casa amplia y luminosa con jardín, cerca de todo, lista para estrenar." });
    const items = await svc.listWorkflowItems(A); expect(items.map((i) => i.code)).toContain("buyer_matches"); expect(items[0]!.params).toBeTypeOf("object"); expect(items.find((i) => i.code === "buyer_matches")!.evidence[0]).toMatchObject({ kind: "property" });
    expect(await svc.listPublications(A)).toHaveLength(5); expect(drafts).toEqual([]);
    expect(await svc.listWorkflowItems(B)).toEqual([]);
    const again = await svc.sweep(A); expect(again.created).toBe(0);
    const d = await svc.decideWorkflowItem(A, items[0]!.id, { approve: true }); expect(d.status).toBe("approved");
    expect((await svc.sweepIfStale(A)).ran).toBe(false);
  });
  it("the database itself refuses duplicates, bad values, identity changes, re-deciding and deletes", async () => {
    const A = await fresh(), store = createD1WorkflowStore(t.d1), w = createWorkflowService({ store, newId: () => crypto.randomUUID().replace(/-/g, "") });
    await w.apply({ tenantId: A.tenantId, userId: A.userId }, "youtube", { workflows: ["x"] }, [{ workflow: "x", kind: "task", employee: "e", code: "c", subjectKind: "video", subjectId: "v1", priority: "high", params: { n: 1 }, evidence: [], summary: "s", dedupKey: "k1" }]);
    const [i] = await store.query(A.tenantId, { system: "youtube", limit: 5 });
    expect(await store.insert({ ...i!, id: "other-id" })).toBe(false); // same (tenant, system, dedup_key)
    expect(await refused(t.d1.prepare("UPDATE wf_items SET priority = 'urgent' WHERE id = ?").bind(i!.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("UPDATE wf_items SET dedup_key = 'zzz' WHERE id = ?").bind(i!.id).run())).toBe("refused");
    expect(await refused(t.d1.prepare("DELETE FROM wf_items WHERE id = ?").bind(i!.id).run())).toBe("refused");
    expect(await w.decide({ tenantId: A.tenantId, userId: A.userId }, "youtube", i!.id, true)).toMatchObject({ status: "approved" });
    expect(await refused(t.d1.prepare("UPDATE wf_items SET status = 'open', decided_at = NULL WHERE id = ?").bind(i!.id).run())).toBe("refused");
  });
});
