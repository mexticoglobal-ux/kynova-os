import { TeamError } from "./errors";

/**
 * API wire format (docs/21): snake_case JSON and ISO 8601 timestamps. The domain stays camelCase with epoch milliseconds;
 * this file is the single translation point. Internal columns never leave the module.
 */

const HIDDEN = new Set(["tenantId"]);
const snake = (k: string) => k.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
const camel = (k: string) => k.replace(/_([a-z0-9])/g, (_m, c: string) => c.toUpperCase());

export function toWire(v: unknown): unknown {
  if (Array.isArray(v)) return v.map(toWire);
  if (v && typeof v === "object") {
    const o: Record<string, unknown> = {};
    for (const [k, val] of Object.entries(v)) {
      if (HIDDEN.has(k)) continue;
      o[snake(k)] = /At$/.test(k) && typeof val === "number" ? new Date(val).toISOString() : toWire(val);
    }
    return o;
  }
  return v;
}
export function fromWire(v: unknown): unknown {
  if (Array.isArray(v)) return v.map(fromWire);
  if (v && typeof v === "object") {
    const o: Record<string, unknown> = {};
    for (const [k, val] of Object.entries(v)) o[camel(k)] = /_at$/.test(k) && typeof val === "string" ? (Number.isNaN(Date.parse(val)) ? val : Date.parse(val)) : fromWire(val);
    return o;
  }
  return v;
}
export function queryObject(params: URLSearchParams): Record<string, string> {
  const o: Record<string, string> = {};
  for (const [k, v] of params) { if (camel(k) in o) throw new TeamError("validation_failed", `Repeated parameter ${k}.`); o[camel(k)] = v; }
  return o;
}
