import type { Department } from "./roster";
import type { Mode, WorkspaceState } from "@/platform/activity";

export const CAPABILITIES = ["view"] as const;
export type Capability = (typeof CAPABILITIES)[number];
export const AWAY_DEFAULT_MS = 86_400_000, AWAY_MAX_MS = 14 * 86_400_000, TIMELINE_SHOWN = 25, APPROVALS_SHOWN = 20;

/** What a team member is doing, derived only from tasks and recorded evidence. `empty` = hired but nothing recorded yet. */
export const MEMBER_STATUS = ["not_hired", "empty", "idle", "working", "awaiting_approval", "issue", "paused"] as const;
export type MemberStatus = (typeof MEMBER_STATUS)[number];

export interface MemberView {
  key: string; name: string; department: Department;
  status: MemberStatus; employeeId: string | null; /** A blueprint is registered, so it can be hired. */ hireable: boolean;
  /** Has tools wired to the platform (a real capability), not only reasoning. */ withTools: boolean;
  open: number; doneInWindow: number; failedInWindow: number; lastAt: number | null; mode: Mode | null;
  goal: string | null;
}
export interface ApprovalView { taskId: string; employeeId: string; employeeName: string; employeeKey: string; title: string; createdAt: number; actions: { capability: string; rationale: string | null }[] }
export interface TimelineItem { id: string; at: number; module: string; action: string; summary: string; employeeId: string | null; employeeName: string | null; mode: Mode; outcome: "success" | "failed" | "skipped"; quantity: number; reversible: boolean }
export interface AwayGroup { module: string; action: string; events: number; quantity: number }
export interface Overview {
  state: WorkspaceState; since: number; until: number;
  away: { groups: AwayGroup[]; events: number; truncated: boolean };
  counts: { hired: number; working: number; approvals: number; issues: number; available: number; roster: number };
  team: MemberView[]; approvals: ApprovalView[]; timeline: TimelineItem[];
  /** Spend of the window, from task records. */
  usage: { tokens: number; costMicros: number };
  /** Which sources could be read. A source that is not available is never shown as "nothing happened". */
  sources: { employees: boolean; activity: boolean };
  can: { hire: boolean; decide: boolean };
}
