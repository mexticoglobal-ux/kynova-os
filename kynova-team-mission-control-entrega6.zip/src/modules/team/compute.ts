import type { ActivityEvent } from "@/platform/activity";
import type { WorkspaceState } from "@/platform/activity";
import { APPROVALS_SHOWN, TIMELINE_SHOWN, type ApprovalView, type MemberView, type Overview, type TimelineItem } from "./domain";
import { ROSTER, blueprintOf, employeeKeyOf, type RosterEntry } from "./roster";

export interface EmployeeRow { id: string; blueprint: string; name: string; goal: string; status: string; capabilities: string[] }
export interface TaskRow { id: string; employeeId: string; title: string; status: string; createdAt: number; finishedAt: number | null; inputTokens: number; outputTokens: number; costMicros: number; result: { actions?: { capability: string; rationale?: string; status: string }[] } | null }
export interface Inputs {
  now: number; since: number; state: WorkspaceState;
  employees: readonly EmployeeRow[]; tasks: readonly TaskRow[]; events: readonly ActivityEvent[];
  digest: { groups: { module: string; action: string; events: number; quantity: number }[]; truncated: boolean };
  registered: ReadonlySet<string>; roster?: readonly RosterEntry[];
}
const OPEN = new Set(["queued", "running", "awaiting_approval"]);

/**
 * The whole "company is operating" picture from three sources only: hired employees, their tasks and the Activity Engine. Nothing is invented:
 * a member with no evidence is `empty`, one nobody hired is `not_hired`, and the mode of the last evidence (production / simulation / demo) travels with it.
 */
export function buildOverview(i: Inputs): Omit<Overview, "sources" | "can"> {
  const byBlueprint = new Map<string, EmployeeRow>();
  for (const e of i.employees) if (e.status !== "retired" && !byBlueprint.has(e.blueprint)) byBlueprint.set(e.blueprint, e);
  const names = new Map(i.employees.map((e) => [e.id, e.name]));
  const tasksOf = new Map<string, TaskRow[]>();
  for (const t of i.tasks) tasksOf.set(t.employeeId, [...(tasksOf.get(t.employeeId) ?? []), t]);
  const evOf = new Map<string, ActivityEvent[]>();
  for (const e of i.events) if (e.employeeKey) evOf.set(e.employeeKey, [...(evOf.get(e.employeeKey) ?? []), e]);

  const team: MemberView[] = (i.roster ?? ROSTER).map((r) => {
    const emp = byBlueprint.get(blueprintOf(r)), hireable = i.registered.has(blueprintOf(r));
    if (!emp) return { key: r.key, name: r.name, department: r.department, status: "not_hired", employeeId: null, hireable, withTools: !!r.blueprint, open: 0, doneInWindow: 0, failedInWindow: 0, lastAt: null, mode: null, goal: null };
    /* Being hired is not work: it never turns "no work yet" into "available". */
    const ts = tasksOf.get(emp.id) ?? [], evs = (evOf.get(employeeKeyOf(emp.id)) ?? []).filter((e) => e.action !== "employee.hired"), inWin = (t: TaskRow) => (t.finishedAt ?? t.createdAt) >= i.since;
    const open = ts.filter((t) => OPEN.has(t.status)), done = ts.filter((t) => t.status === "succeeded" && inWin(t)), failed = ts.filter((t) => t.status === "failed" && inWin(t));
    const last = [...evs.map((e) => e.occurredAt), ...ts.map((t) => t.finishedAt ?? t.createdAt)].sort((a, b) => b - a)[0] ?? null;
    const lastFailed = ts.filter((t) => t.status === "failed").map((t) => t.finishedAt ?? 0).sort((a, b) => b - a)[0] ?? 0, lastOk = ts.filter((t) => t.status === "succeeded").map((t) => t.finishedAt ?? 0).sort((a, b) => b - a)[0] ?? 0;
    const status = emp.status === "paused" ? "paused" : open.some((t) => t.status === "awaiting_approval") ? "awaiting_approval" : open.some((t) => t.status === "running") ? "working"
      : failed.length > 0 && lastFailed > lastOk ? "issue" : last === null ? "empty" : "idle";
    const latest = [...evs].sort((a, b) => b.occurredAt - a.occurredAt)[0];
    return { key: r.key, name: r.name, department: r.department, status, employeeId: emp.id, hireable, withTools: !!r.blueprint, open: open.length, doneInWindow: done.length, failedInWindow: failed.length, lastAt: last, mode: latest?.mode ?? null, goal: emp.goal };
  });

  const approvals: ApprovalView[] = i.tasks.filter((t) => t.status === "awaiting_approval").sort((a, b) => a.createdAt - b.createdAt).slice(0, APPROVALS_SHOWN).map((t) => {
    return { taskId: t.id, employeeId: t.employeeId, employeeName: names.get(t.employeeId) ?? "—", employeeKey: employeeKeyOf(t.employeeId), title: t.title, createdAt: t.createdAt, actions: (t.result?.actions ?? []).filter((a) => a.status === "pending").map((a) => ({ capability: a.capability, rationale: a.rationale ?? null })) };
  });

  const byKey = new Map(i.employees.map((e) => [employeeKeyOf(e.id), e]));
  const timeline: TimelineItem[] = [...i.events].sort((a, b) => b.occurredAt - a.occurredAt || b.id.localeCompare(a.id)).slice(0, TIMELINE_SHOWN).map((e) => {
    const emp = e.employeeKey ? byKey.get(e.employeeKey) : undefined;
    return { id: e.id, at: e.occurredAt, module: e.module, action: e.action, summary: e.summary, employeeId: emp?.id ?? null, employeeName: emp?.name ?? null, mode: e.mode, outcome: e.outcome, quantity: e.quantity, reversible: e.reversible };
  });

  const win = i.tasks.filter((t) => (t.finishedAt ?? t.createdAt) >= i.since);
  const hired = team.filter((m) => m.status !== "not_hired");
  return {
    state: i.state, since: i.since, until: i.now,
    away: { groups: i.digest.groups, events: i.digest.groups.reduce((n, g) => n + g.events, 0), truncated: i.digest.truncated },
    counts: { hired: hired.length, working: hired.filter((m) => m.status === "working").length, approvals: i.tasks.filter((t) => t.status === "awaiting_approval").length, issues: hired.filter((m) => m.status === "issue").length, available: team.filter((m) => m.status === "not_hired" && m.hireable).length, roster: team.length },
    team, approvals, timeline, usage: { tokens: win.reduce((n, t) => n + t.inputTokens + t.outputTokens, 0), costMicros: win.reduce((n, t) => n + t.costMicros, 0) },
  };
}
