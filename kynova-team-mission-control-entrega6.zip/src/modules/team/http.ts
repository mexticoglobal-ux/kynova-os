import { NextResponse, type NextRequest } from "next/server";
import { canAccess } from "@/config/modules";
import { assertSameOrigin, getAuthConfig, ok, problem, route } from "@/platform/auth/http";
import { requireApiSession } from "@/platform/auth/session";
import { TeamError, isTeamError } from "./errors";
import { getTeamService } from "./server";
import type { Actor, TeamService } from "./service";
import { toWire } from "./wire";

export const TEAM_SLUG = "team";
export interface TeamRouteContext { actor: Actor; rid: string; svc: TeamService }
/** Verified session, module access for the role, an active company, CSRF checks on mutations, and Team errors as problem+json. */
export function teamRoute<C = unknown>(fn: (req: NextRequest, ctx: C, a: TeamRouteContext) => Promise<NextResponse>, opts: { mutating?: boolean } = {}) {
  return route<C>(async (req, ctx, rid) => {
    try {
      if (opts.mutating) assertSameOrigin(req, getAuthConfig());
      const s = await requireApiSession();
      if (!s.tenantId) throw new TeamError("forbidden", "Select or create a company first.");
      if (!canAccess(s.role, TEAM_SLUG)) throw new TeamError("forbidden", "Your role cannot see the team.");
      return await fn(req, ctx, { actor: { tenantId: s.tenantId, userId: s.user.id, role: s.role, requestId: rid }, rid, svc: await getTeamService() });
    } catch (e) {
      if (isTeamError(e)) return problem(e.code, e.status, e.message, rid, e.details ? { details: e.details } : {});
      throw e;
    }
  });
}
export const respond = (data: unknown, rid: string, status = 200) => ok(toWire(data), rid, status);
