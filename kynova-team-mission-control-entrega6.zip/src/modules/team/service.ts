import type { Role } from "@/config/roles";
import type { ActivityEvent } from "@/platform/activity";
import { allows } from "./access";
import { buildOverview, type EmployeeRow, type TaskRow } from "./compute";
import { AWAY_DEFAULT_MS, AWAY_MAX_MS, type MemberView, type Overview } from "./domain";
import { TeamError } from "./errors";
import { ROSTER_BY_KEY } from "./roster";
import { employeeKeyOf } from "./roster";
import type { WorkspaceState } from "@/platform/activity";

export interface Actor { tenantId: string; userId: string; role: Role; requestId?: string }
export interface TeamPorts {
  employees(a: Actor): Promise<EmployeeRow[]>;
  tasks(a: Actor): Promise<TaskRow[]>;
  registered(): ReadonlySet<string>;
  state(a: Actor): Promise<WorkspaceState>;
  digest(a: Actor, since: number): Promise<{ groups: { module: string; action: string; events: number; quantity: number }[]; truncated: boolean }>;
  events(a: Actor, q: { since?: number; employeeKey?: string; limit: number }): Promise<ActivityEvent[]>;
  can(a: Actor): { hire: boolean; decide: boolean };
}
export interface TeamDeps { ports: TeamPorts; now?: () => number }
export type TeamService = ReturnType<typeof createTeamService>;

/** Every source is read independently: if one is down (or the role cannot read it) the answer says so instead of pretending nothing happened. */
async function attempt<T>(f: () => Promise<T>, empty: T): Promise<[T, boolean]> { try { return [await f(), true]; } catch { return [empty, false]; } }

export function createTeamService(deps: TeamDeps) {
  const now = deps.now ?? Date.now, p = deps.ports;
  const need = (a: Actor) => { if (!allows(a.role, "view")) throw new TeamError("forbidden", "Your role cannot see the team."); };
  const windowStart = (t: number, since?: number) => Math.min(t, Math.max(t - AWAY_MAX_MS, since ?? t - AWAY_DEFAULT_MS));

  async function overview(a: Actor, q: { since?: number } = {}): Promise<Overview> {
    need(a);
    const t = now(), since = windowStart(t, q.since);
    const [[employees, okE], [tasks], [state, okA], [digest], [events]] = await Promise.all([
      attempt(() => p.employees(a), [] as EmployeeRow[]), attempt(() => p.tasks(a), [] as TaskRow[]), attempt(() => p.state(a), "empty" as WorkspaceState),
      attempt(() => p.digest(a, since), { groups: [], truncated: false }), attempt(() => p.events(a, { since, limit: 100 }), [] as ActivityEvent[]),
    ]);
    return { ...buildOverview({ now: t, since, state, employees, tasks, events, digest, registered: p.registered() }), sources: { employees: okE, activity: okA }, can: p.can(a) };
  }
  async function member(a: Actor, key: string): Promise<{ member: MemberView; tasks: TaskRow[]; events: ActivityEvent[]; sources: Overview["sources"]; can: Overview["can"] }> {
    need(a);
    if (!ROSTER_BY_KEY.has(key)) throw new TeamError("not_found", "Team member not found.");
    const o = await overview(a), m = o.team.find((x) => x.key === key);
    if (!m) throw new TeamError("not_found", "Team member not found.");
    if (!m.employeeId) return { member: m, tasks: [], events: [], sources: o.sources, can: o.can };
    const id = m.employeeId, [tasks] = await attempt(async () => (await p.tasks(a)).filter((x) => x.employeeId === id).slice(0, 15), [] as TaskRow[]);
    const [events] = await attempt(() => p.events(a, { employeeKey: employeeKeyOf(id), limit: 25 }), [] as ActivityEvent[]);
    return { member: m, tasks, events, sources: o.sources, can: o.can };
  }
  return { overview, member, permissions: (a: Actor) => ({ role: a.role, capabilities: allows(a.role, "view") ? ["view" as const] : [] }) };
}
