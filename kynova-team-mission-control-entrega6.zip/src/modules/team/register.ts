import { defineEmployeeBlueprint, employeeRegistry } from "@/platform/ai-employees";
import { DEPARTMENTS, ROSTER, type Department } from "./roster";

const GOALS: Record<Department, string> = {
  direction: "Keep the whole company moving toward its goals and tell the owner what matters.", marketing: "Plan and improve the company's marketing from the evidence available.", seo: "Find and prioritise what will improve the company's search visibility.",
  sales: "Help the company win and follow up customers.", finance: "Keep the company's money clear and flag what needs attention.", customers: "Keep customers supported, onboarded and successful.",
  marketplace: "Keep the marketplace healthy and recommend what fits the company.", partners: "Grow and look after partners, referrals and commissions.", operations: "Keep people, contracts and documents in order.",
  technology: "Keep the platform secure, tested and connected.", intelligence: "Turn the company's own data into forecasts and clear recommendations.",
};
const flag = globalThis as unknown as { __kynovaTeamRoster?: boolean };
/** Official team members that have no tools yet become hireable "reasoning only" blueprints: they can think, explain and propose, and say so. Members that already have a real blueprint are left to the module that owns it. */
export function registerTeamRoster(): void {
  if (flag.__kynovaTeamRoster) return;
  flag.__kynovaTeamRoster = true;
  for (const r of ROSTER) {
    if (r.blueprint || employeeRegistry().blueprint(r.key)) continue;
    defineEmployeeBlueprint({
      key: r.key, name: r.name, description: `${r.name} (${DEPARTMENTS.find((d) => d === r.department)}): reasons and recommends from what is recorded; no tools are connected to it yet.`,
      defaultGoal: GOALS[r.department],
      defaultInstructions: `You are ${r.name}. Work only from the information you are given. Never invent results, numbers or actions; say plainly when information is missing. You have no tools connected yet: explain, recommend and prepare proposals; people decide.`,
      taskClass: "reason", capabilities: [], defaultAutonomy: 1, maxAutonomy: 1, allowedRoles: ["super_admin", "owner", "ceo", "administrator", "manager"],
    });
  }
}
