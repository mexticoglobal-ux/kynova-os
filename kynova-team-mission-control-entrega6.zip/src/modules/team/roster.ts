/** The official AI Employees of Blueprint doc 03 section 21, by department. Names are the Blueprint's own role names. A registered blueprint with the same key makes the entry hireable; `real` marks the ones that already have tools wired to a platform capability. */
export const DEPARTMENTS = ["direction", "marketing", "seo", "sales", "finance", "customers", "marketplace", "partners", "operations", "technology", "intelligence"] as const;
export type Department = (typeof DEPARTMENTS)[number];
export interface RosterEntry { key: string; name: string; department: Department; /** Key of an already-registered blueprint that does this job today. */ blueprint?: string }
const d = (department: Department, names: readonly string[], map: Record<string, string> = {}): RosterEntry[] =>
  names.map((name) => { const key = name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, ""); return { key, name, department, ...(map[key] ? { blueprint: map[key] } : {}) }; });
export const ROSTER: readonly RosterEntry[] = [
  ...d("direction", ["CEO AI", "Chief of Staff AI", "Mission Control AI"], { ceo_ai: "executive_advisor", mission_control_ai: "mission_control_advisor" }),
  ...d("marketing", ["Marketing Manager", "Content Creator", "Social Media Manager", "Ads Manager", "Email Marketing Manager", "Brand Manager"]),
  ...d("seo", ["Technical SEO", "Local SEO", "Content SEO", "Link Building Advisor", "SEO Auditor"]),
  ...d("sales", ["Sales Manager", "CRM Manager", "Lead Manager", "Proposal Manager", "Follow-up Manager"]),
  ...d("finance", ["Finance Manager", "Accounting Manager", "Billing Manager", "Collections Manager", "Tax Assistant"], { finance_manager: "finance_analyst", billing_manager: "billing_advisor" }),
  ...d("customers", ["Customer Success Manager", "Support Manager", "Onboarding Specialist", "Training Manager"]),
  ...d("marketplace", ["Marketplace Manager", "Product Reviewer", "License Manager"], { marketplace_manager: "marketplace_advisor" }),
  ...d("partners", ["Partner Manager", "Referral Manager", "Commission Manager"], { partner_manager: "partner_manager" }),
  ...d("operations", ["HR Manager", "Legal Assistant", "Contract Manager", "Document Manager"]),
  ...d("technology", ["Developer Assistant", "QA Manager", "Release Manager", "Security Officer", "Integration Manager"], { integration_manager: "integrations_advisor" }),
  ...d("intelligence", ["Analytics Advisor", "Forecast Manager", "Automation Manager", "AI Research Manager"], { analytics_advisor: "analytics_advisor" }),
];
export const ROSTER_BY_KEY = new Map(ROSTER.map((r) => [r.key, r]));
/** The blueprint a hire of this entry uses: the existing one when it has one, otherwise the generic one registered under the roster key. */
export const blueprintOf = (r: RosterEntry): string => r.blueprint ?? r.key;
/** Activity Engine key for a hired employee: stable, one per employee record, never a person's data. */
export const employeeKeyOf = (employeeId: string): string => `emp_${employeeId.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 40)}`;
