import { AiConfigError, getAiKernel } from "@/platform/ai-kernel";
import { createMemoryEmployeeStores } from "./memory-stores";
import type { EmployeeStores, TaskDispatcher } from "./ports";
import { createEmployeeRegistry, type EmployeeRegistry } from "./registry";
import { createEmployeeFramework, type EmployeeEvent, type EmployeeFramework } from "./service";

/** Same environment rule as the AI Kernel: in-memory stores exist only in local and test. */
function devLike(): boolean {
  const e = process.env.APP_ENV;
  if (e === "local" || e === "test") return true;
  if (e === "preview" || e === "staging" || e === "production") return false;
  return process.env.NODE_ENV !== "production";
}

const g = globalThis as unknown as { __kynovaEmpListeners?: Set<(e: EmployeeEvent) => void>; __kynovaEmpRegistry?: EmployeeRegistry; __kynovaEmpStores?: Partial<EmployeeStores>; __kynovaEmpMem?: EmployeeStores; __kynovaEmpDispatcher?: TaskDispatcher; __kynovaEmpFw?: { key: string; fw: EmployeeFramework } };
/** On globalThis like the registry: Next bundles startup code and each route separately, so a module-level Set would never reach the observers registered at startup. */
const listeners = (g.__kynovaEmpListeners ??= new Set<(e: EmployeeEvent) => void>());

/** The registry of blueprints and capabilities. Business modules call defineEmployeeBlueprint / defineEmployeeCapability at startup. */
export const employeeRegistry = (): EmployeeRegistry => (g.__kynovaEmpRegistry ??= createEmployeeRegistry());
export const defineEmployeeBlueprint: EmployeeRegistry["defineBlueprint"] = (b) => employeeRegistry().defineBlueprint(b);
export const defineEmployeeCapability: EmployeeRegistry["defineCapability"] = (c) => employeeRegistry().defineCapability(c);

/** In-memory stores for LOCAL and TEST only (the fallback when `next dev` has no D1 binding). Throws anywhere else, so production never runs on volatile state. */
export function createDevEmployeeStores(): EmployeeStores {
  if (!devLike()) throw new AiConfigError("In-memory AI employee stores are only available in local and test environments.");
  return createMemoryEmployeeStores();
}

/** Production stores (D1) register here. See docs/adr/005-ai-employees-framework.md. */
export function registerEmployeeStores(stores: Partial<EmployeeStores>): void { g.__kynovaEmpStores = { ...(g.__kynovaEmpStores ?? {}), ...stores }; }
/** Optional: a Cloudflare Queues producer that wakes a worker for each new task. */
export function registerTaskDispatcher(d: TaskDispatcher): void { g.__kynovaEmpDispatcher = d; }
/** Subscribe to framework events (task lifecycle, executed actions, budget warnings). Returns an unsubscribe function. */
export function onEmployeeEvent(l: (e: EmployeeEvent) => void): () => void { listeners.add(l); return () => { listeners.delete(l); }; }

/**
 * The framework bound to the registered stores and the AI Kernel. Fails closed: outside local and test a missing store
 * raises AiConfigError (503), exactly like the kernel.
 */
export function getEmployeeFramework(): EmployeeFramework {
  const dev = devLike();
  const reg = g.__kynovaEmpStores ?? {};
  const key = `${dev}|${Object.keys(reg).sort().join(",")}|${g.__kynovaEmpDispatcher ? "d" : ""}`;
  if (g.__kynovaEmpFw?.key === key) return g.__kynovaEmpFw.fw;
  const mem = dev ? (g.__kynovaEmpMem ??= createMemoryEmployeeStores()) : null;
  const pick = <K extends "employees" | "tasks" | "memory">(k: K): EmployeeStores[K] => {
    const v = reg[k] ?? mem?.[k];
    if (!v) throw new AiConfigError(`AI employee store "${k}" is not registered. Register a production adapter with registerEmployeeStores().`);
    return v as EmployeeStores[K];
  };
  const stores: EmployeeStores = { employees: pick("employees"), tasks: pick("tasks"), memory: pick("memory"), actors: reg.actors ?? mem?.actors, audit: reg.audit ?? mem?.audit, profiles: reg.profiles ?? mem?.profiles };
  const fw = createEmployeeFramework({
    stores, registry: employeeRegistry(), kernel: getAiKernel, devLike: dev, dispatcher: g.__kynovaEmpDispatcher,
    onEvent: (e) => { for (const l of listeners) { try { l(e); } catch { /* observers must never break a request */ } } },
  });
  g.__kynovaEmpFw = { key, fw };
  return fw;
}

export { createEmployeeFramework, type EmployeeFramework, type EmployeeEvent, type FrameworkDeps } from "./service";
export { createMemoryEmployeeStores } from "./memory-stores";
export { createEmployeeRegistry, CUSTOM_BLUEPRINT, type EmployeeBlueprint, type EmployeeCapabilityDef, type CapabilityContext, type EmployeeRegistry } from "./registry";
export { authorizeEmployee, canEmployee, type EmployeeCapability } from "./access";
export { EmployeeError, isEmployeeError } from "./errors";
export { effectiveCapabilities, autonomyFor, dispositionFor } from "./policy";
export { buildContext } from "./context";
export { EMPLOYEE_PROMPT_ID, registerEmployeePrompts, STANDARD_VAR_NAMES } from "./prompts";
export type { EmployeeStores, EmployeeStore, TaskStore, MemoryStore, ActorDirectory, AuditSink, AuditEntry, CompanyProfiles, TaskDispatcher, TaskTransition } from "./ports";
export * from "./types";
