import { teamRoute, respond } from "@/modules/team/http";

export const GET = teamRoute(async (req, c, { actor, svc, rid }) => {
  void c;
  const raw = req.nextUrl.searchParams.get("since"), since = raw && /^\d{10,14}$/.test(raw) ? Number(raw) : undefined;
  return respond(await svc.overview(actor, { since }), rid);
});
