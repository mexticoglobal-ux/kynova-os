import { teamRoute, respond } from "@/modules/team/http";

export const GET = teamRoute(async (req, c, { actor, svc, rid }) => { void req; void c; return respond(svc.permissions(actor), rid); });
