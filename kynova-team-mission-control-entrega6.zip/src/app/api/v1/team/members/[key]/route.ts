import { teamRoute, respond } from "@/modules/team/http";

type Ctx = { params: Promise<{ key: string }> };

export const GET = teamRoute<Ctx>(async (req, c, { actor, svc, rid }) => { void req; const p = await c.params; return respond(await svc.member(actor, p.key), rid); });
