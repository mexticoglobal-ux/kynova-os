import { teamContext } from "@/components/team/context";
import { MissionHome } from "@/components/team/MissionHome";

export const metadata = { title: "Mission Control" };
export const dynamic = "force-dynamic";

/** The first screen after login (CLAUDE.md 2): Mission Control, the company operating. The widget panels it used to show stay available, unchanged, at /app/mission-control. */
export default async function DashboardPage() {
  const ctx = await teamContext("dashboard");
  return (
    <main id="main" className="mx-auto w-full max-w-[96rem] p-4 sm:p-6 lg:p-8">
      <MissionHome ctx={ctx} />
    </main>
  );
}
