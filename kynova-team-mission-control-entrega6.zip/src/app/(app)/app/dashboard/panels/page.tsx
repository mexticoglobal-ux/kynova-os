import { redirect } from "next/navigation";
import { WidgetGrid } from "@/components/dashboard/WidgetGrid";
import { requireModuleAccess } from "@/platform/auth/session";
import { createDashboardDeps, createDashboardService, safeTimeZone } from "@/platform/dashboard";

export const metadata = { title: "Dashboard" };

/** The widget panels that used to be the dashboard, unchanged. The home (/app/dashboard) is now Mission Control; this keeps every panel one click away. */
export default async function DashboardPanelsPage() {
  const { user, role, tenantId } = await requireModuleAccess("dashboard");
  if (!tenantId) redirect("/app/profile");
  const svc = createDashboardService(createDashboardDeps(), {
    tenantId, userId: user.id, role, name: user.name ?? user.email ?? "", locale: user.locale ?? "es",
    timezone: safeTimeZone(undefined), now: Date.now(), requestId: crypto.randomUUID(),
  });
  return (
    <main id="main" className="mx-auto w-full max-w-[96rem] p-4 sm:p-6 lg:p-8">
      <h1 className="sr-only">Dashboard</h1>
      <WidgetGrid svc={svc} />
    </main>
  );
}
