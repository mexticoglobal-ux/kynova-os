import type { ReactNode } from "react";
import { TeamI18n } from "@/components/team/I18n";
import { teamContext } from "@/components/team/context";
import { TEAM_DICTIONARIES } from "@/modules/team/i18n";

export default async function TeamLayout({ children }: { children: ReactNode }) {
  const { locale } = await teamContext();
  return <TeamI18n dict={TEAM_DICTIONARIES[locale]} locale={locale}><main id="main" className="mx-auto w-full max-w-[96rem] p-4 sm:p-6 lg:p-8">{children}</main></TeamI18n>;
}
