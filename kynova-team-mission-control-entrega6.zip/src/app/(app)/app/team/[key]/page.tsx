import { notFound } from "next/navigation";
import { teamContext } from "@/components/team/context";
import { describeEvent } from "@/components/team/helpers";
import { HireButton } from "@/components/team/Hire";
import { Card, Empty, LinkBtn, MODE_TONE, OUTCOME_TONE, Pill, STATUS_TONE, Stat, ago } from "@/components/team/ui";
import { ROSTER_BY_KEY, blueprintOf, isTeamError } from "@/modules/team";

export const dynamic = "force-dynamic";
type Props = { params: Promise<{ key: string }> };

export default async function MemberPage({ params }: Props) {
  const { key } = await params, ctx = await teamContext(), { t, locale } = ctx, now = Date.now();
  const r = await ctx.svc.member(ctx.actor, key).catch((e) => { if (isTeamError(e) && e.code === "not_found") return null; throw e; });
  if (!r) notFound();
  const { member: m, tasks, events, can } = r, entry = ROSTER_BY_KEY.get(key)!, next = tasks.filter((x) => x.status === "queued" || x.status === "awaiting_approval");
  return (
    <div className="grid gap-5">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0"><a href="/app/team" className="text-xs text-muted hover:underline">← {t("title")}</a><h1 className="truncate text-xl font-bold tracking-tight sm:text-2xl">{m.name}</h1>
          <p className="mt-1 flex flex-wrap items-center gap-2 text-sm text-muted"><span>{t(`dept.${m.department}`)}</span><Pill tone={STATUS_TONE[m.status]}>{t(`ms.${m.status}`)}</Pill>{m.mode && <Pill tone={MODE_TONE[m.mode]}>{t(`mode.${m.mode}`)}</Pill>}<span>{m.withTools ? t("tools.with") : t("tools.without")}</span></p></div>
        {m.status === "not_hired" && m.hireable && can.hire && <HireButton blueprint={blueprintOf(entry)} name={m.name} dept={t(`dept.${m.department}`)} />}
      </header>
      {m.status === "not_hired" ? <Card><Empty>{t("mem.notHired")}</Empty></Card> : (
        <>
          {m.goal && <Card title={t("mem.goal")}><p className="text-sm">{m.goal}</p></Card>}
          <dl className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label={t("mem.kpiDone")} value={m.doneInWindow} /><Stat label={t("mem.kpiFailed")} value={m.failedInWindow} /><Stat label={t("mem.kpiOpen")} value={m.open} /><Stat label={t("mem.last")} value={m.lastAt ? ago(m.lastAt, now, locale) : t("mem.never")} />
          </dl>
          <div className="grid gap-5 lg:grid-cols-2">
            <Card title={t("mem.work")}>
              {tasks.filter((x) => x.status === "succeeded" || x.status === "failed" || x.status === "rejected").length === 0 ? <Empty>{t("mem.workNone")}</Empty> : (
                <ul className="grid gap-2">{tasks.filter((x) => x.status === "succeeded" || x.status === "failed" || x.status === "rejected").slice(0, 8).map((x) => <li key={x.id} className="flex items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span className="min-w-0 truncate">{x.title}</span><Pill tone={x.status === "succeeded" ? "success" : "danger"}>{t(x.status === "succeeded" ? "out.success" : "out.failed")}</Pill></li>)}</ul>
              )}
            </Card>
            <Card title={t("mem.next")}>
              {next.length === 0 ? <Empty>{t("mem.nextNone")}</Empty> : <ul className="grid gap-2">{next.map((x) => <li key={x.id} className="flex items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span className="min-w-0 truncate">{x.title}</span><Pill tone={x.status === "queued" ? "info" : "warning"}>{t(x.status === "queued" ? "ms.working" : "ms.awaiting_approval")}</Pill></li>)}</ul>}
            </Card>
          </div>
          <Card title={t("mem.activity")}>
            {events.length === 0 ? <Empty>{t("mem.workNone")}</Empty> : (
              <ol className="grid gap-2">{events.map((e) => <li key={e.id} className="flex flex-wrap items-center gap-2 rounded-lg border border-line px-3 py-2 text-sm"><span className="min-w-0 flex-1">{describeEvent({ action: e.action, summary: e.summary, employeeName: m.name }, t, locale)}</span><Pill tone={MODE_TONE[e.mode]}>{t(`mode.${e.mode}`)}</Pill><Pill tone={OUTCOME_TONE[e.outcome]}>{t(`out.${e.outcome}`)}</Pill><time className="text-xs text-muted" dateTime={new Date(e.occurredAt).toISOString()}>{ago(e.occurredAt, now, locale)}</time></li>)}</ol>
            )}
          </Card>
        </>
      )}
      <div><LinkBtn href="/app/dashboard/panels">{t("home.details")}</LinkBtn></div>
    </div>
  );
}
