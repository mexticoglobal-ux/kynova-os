import { redirect } from "next/navigation";
import { requireModuleAccess } from "@/platform/auth/session";
import { getTeamService, teamLocale, tr, type Actor, type TeamKey } from "@/modules/team";

/** Server-side context of the team pages: verified session, actor, service and translator. The home (`/app/dashboard`) uses it with the dashboard slug; the tenant always comes from the session. */
export async function teamContext(slug: "team" | "dashboard" = "team") {
  const s = await requireModuleAccess(slug);
  if (!s.tenantId) redirect("/app/profile");
  const actor: Actor = { tenantId: s.tenantId, userId: s.user.id, role: s.role };
  const locale = teamLocale(s.user.locale);
  return { actor, locale, svc: await getTeamService(), name: s.user.name ?? s.user.email ?? "", t: (k: TeamKey, v?: Record<string, string | number>) => tr(locale, k, v) };
}
export type TeamContext = Awaited<ReturnType<typeof teamContext>>;
