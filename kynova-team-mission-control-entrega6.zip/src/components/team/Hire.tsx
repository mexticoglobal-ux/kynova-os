"use client";
import { useRouter } from "next/navigation";
import { useT } from "./I18n";
import { Err, primary, useRun } from "./Actions";
import { teamCall } from "./api";

/** Hiring uses the AI Employees API as is: the roster only chooses the blueprint. Nothing is invented; the new member starts with no recorded work. */
export function HireButton({ blueprint, name, dept }: { blueprint: string; name: string; dept: string }) {
  const { t } = useT(), router = useRouter(), { busy, err, run } = useRun();
  return (
    <div className="grid gap-1">
      <button type="button" className={primary} disabled={busy} onClick={() => void run(() => teamCall("POST", "/ai-employees", { blueprint, name, goal: t("hire.goal", { dept }) }), () => router.refresh())}>{busy ? t("act.hiring") : t("act.hire")}</button>
      <Err err={err} />
    </div>
  );
}
export function DecisionButtons({ taskId }: { taskId: string }) {
  const { t } = useT(), router = useRouter(), { busy, err, run } = useRun();
  const go = (decision: "approve" | "reject") => void run(() => teamCall("POST", `/ai-employees/tasks/${taskId}/decision`, { decision }), () => router.refresh());
  return (
    <div className="grid gap-1">
      <div className="flex gap-2">
        <button type="button" className={primary} disabled={busy} onClick={() => go("approve")}>{t("act.approve")}</button>
        <button type="button" className="rounded-lg border border-line px-3 py-1.5 text-sm hover:bg-ac/10 disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-ac2" disabled={busy} onClick={() => go("reject")}>{t("act.reject")}</button>
      </div>
      <Err err={err} />
    </div>
  );
}
