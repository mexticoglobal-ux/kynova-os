import type { Overview, TimelineItem } from "@/modules/team";
import { TEAM_DICTIONARIES, type TeamKey, type TeamLocale } from "@/modules/team/i18n";
import type { T } from "./ui";

const humanize = (action: string) => action.split(".").slice(1).join(" ").replace(/_/g, " ") || action;
/** Employee events have written texts in the dictionary; every other event shows the sentence its module recorded. Nothing is rephrased into a claim the evidence does not make. */
export function describeEvent(e: Pick<TimelineItem, "action" | "summary" | "employeeName">, t: T, locale: TeamLocale): string {
  const key = `act.${e.action}` as TeamKey;
  return key in TEAM_DICTIONARIES[locale] ? t(key, { name: e.employeeName ?? "—" }) : e.summary;
}
export const describeGroup = (g: Overview["away"]["groups"][number], t: T) => t("act.generic", { n: g.quantity, what: `${g.module} · ${humanize(g.action)}` });
