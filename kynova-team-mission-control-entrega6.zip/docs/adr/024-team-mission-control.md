# ADR 024 · Mission Control como capa de experiencia sin almacenamiento propio

**Contexto.** El Blueprint pide que el cliente vea un equipo de empleados trabajando, con evidencia en el Activity Engine.
**Decisión.** Un módulo de solo lectura (`team`) compone empleados, tareas y Activity Engine; el estado de cada especialista es derivado. Un puente registra el trabajo de los empleados en el Activity Engine. La home pasa a ser Mission Control y los paneles viejos se conservan en `/app/dashboard/panels`.
**Descartado.** Guardar el "estado" de cada empleado (se desincroniza); mostrar el plantel como si trabajara (viola "nunca inventar resultados").
**Consecuencias.** Cero migraciones y lecturas acotadas por empresa: escala a 10,000 empresas sin rediseño. Con poca actividad la pantalla se ve casi vacía, y es lo correcto.
**Pendiente.** Planificador continuo, aprendizaje anónimo entre empresas (requiere diseño de privacidad: umbrales de anonimato y opt-in), HQ.
