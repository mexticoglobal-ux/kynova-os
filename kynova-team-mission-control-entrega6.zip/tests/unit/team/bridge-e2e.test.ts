import { describe, expect, it } from "vitest";
import { getActivityService } from "@/platform/activity";
import { getEmployeeFramework } from "@/platform/ai-employees";
import { registerTeamBridge, registerTeamRoster } from "../../../src/modules/team";
import { employeeKeyOf } from "../../../src/modules/team/roster";

describe("bridge: the real framework leaves evidence in the real Activity Engine", () => {
  it("hiring a roster employee records an event that names that employee, as simulation in test", async () => {
    registerTeamRoster(); registerTeamBridge(); registerTeamBridge();
    const tenantId = `t-bridge-${crypto.randomUUID().slice(0, 8)}`, a = { tenantId, userId: "u1", role: "owner" as const };
    const fw = getEmployeeFramework(), e = await fw.employees.hire(a, { blueprint: "marketing_manager", name: "Marketing Manager", goal: "Support marketing." });
    let items: Awaited<ReturnType<Awaited<ReturnType<typeof getActivityService>>["list"]>>["items"] = [];
    for (let i = 0; i < 30 && items.length === 0; i++) { items = (await (await getActivityService()).list(a, { employeeKey: employeeKeyOf(e.id) })).items; if (!items.length) await new Promise((r) => setTimeout(r, 20)); }
    expect(items).toHaveLength(1); expect(items[0]).toMatchObject({ action: "employee.hired", module: "employees", mode: "simulation", employeeKey: employeeKeyOf(e.id), subjectId: e.id });
    const other = await (await getActivityService()).list({ ...a, tenantId: "someone-else" }, {}); expect(other.items).toHaveLength(0);
  });
  it("the roster has one hireable blueprint per member without an existing one, and registering twice is harmless", () => {
    registerTeamRoster(); expect(getEmployeeFramework().registry.blueprint("seo_auditor")?.capabilities).toEqual([]);
    expect(getEmployeeFramework().registry.blueprint("partner_manager")).toBeNull();
  });
});
