import type { Role } from "@/config/roles";
import type { ActivityEvent } from "@/platform/activity";
import type { EmployeeRow, TaskRow } from "../../../src/modules/team/compute";
import { createTeamService, type Actor, type TeamPorts } from "../../../src/modules/team/service";

export const T1 = "tenant-one", NOW = Date.UTC(2026, 9, 20, 18), H = 3_600_000;
export const actor = (role: Role, tenantId = T1): Actor => ({ tenantId, userId: `${role}-1`, role });
export const OWNER = actor("owner"), SALES = actor("sales"), GUEST = actor("guest");
export const code = async (p: Promise<unknown>) => { try { await p; return "ok"; } catch (e) { return (e as { code?: string }).code ?? `other:${(e as Error).message}`; } };
export const emp = (o: Partial<EmployeeRow> & { id: string; blueprint: string }): EmployeeRow => ({ name: o.blueprint, goal: "goal", status: "active", capabilities: [], ...o });
export const task = (o: Partial<TaskRow> & { id: string; employeeId: string }): TaskRow => ({ title: "t", status: "succeeded", createdAt: NOW - 2 * H, finishedAt: NOW - H, inputTokens: 10, outputTokens: 5, costMicros: 100, result: null, ...o });
export const ev = (o: Partial<ActivityEvent> & { id: string }): ActivityEvent => ({ tenantId: T1, schemaVersion: 1, occurredAt: NOW - H, recordedAt: NOW - H, source: "kynova", module: "partners", action: "partners.partner.created", summary: "Partner created", actorKind: "user", actorId: "u", employeeKey: null, outcome: "success", mode: "production", quantity: 1, subjectKind: null, subjectId: null, reversible: false, revertHint: null, revertsId: null, idempotencyKey: null, externalRef: null, requestId: null, ...o });
export interface Fixture { employees: EmployeeRow[]; tasks: TaskRow[]; events: ActivityEvent[]; registered: string[]; state: "empty" | "demo" | "simulation" | "production"; broken: Set<string> }
export function fixture(o: Partial<Fixture> = {}) {
  const f: Fixture = { employees: [], tasks: [], events: [], registered: ["partner_manager", "marketing_manager"], state: "empty", broken: new Set(), ...o };
  const guard = <T,>(k: string, v: () => T): T => { if (f.broken.has(k)) throw new Error(`${k} down`); return v(); };
  const ports: TeamPorts = {
    employees: async () => guard("employees", () => f.employees), tasks: async () => guard("tasks", () => f.tasks), registered: () => new Set(f.registered), state: async () => guard("activity", () => f.state),
    digest: async (_a, since) => guard("activity", () => { const m = new Map<string, { module: string; action: string; events: number; quantity: number }>(); for (const e of f.events.filter((x) => x.occurredAt >= since && x.mode === "production" && x.outcome === "success")) { const k = `${e.module}|${e.action}`, g = m.get(k) ?? { module: e.module, action: e.action, events: 0, quantity: 0 }; g.events++; g.quantity += e.quantity; m.set(k, g); } return { groups: [...m.values()], truncated: false }; }),
    events: async (_a, q) => guard("activity", () => f.events.filter((e) => (!q.since || e.occurredAt >= q.since) && (!q.employeeKey || e.employeeKey === q.employeeKey)).slice(0, q.limit)),
    can: (a) => ({ hire: ["owner", "super_admin", "administrator", "ceo", "manager"].includes(a.role), decide: ["owner", "super_admin", "administrator", "ceo", "manager"].includes(a.role) }),
  };
  return { f, svc: createTeamService({ ports, now: () => NOW }) };
}
