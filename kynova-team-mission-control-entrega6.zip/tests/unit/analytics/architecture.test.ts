import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { describe, expect, it } from "vitest";
import { MODULES, canAccess } from "@/config/modules";
import { ROLES } from "@/config/roles";
import { COLUMNS, TABLE } from "../../../src/modules/analytics/columns";
import { ANALYTICS_DICTIONARIES } from "../../../src/modules/analytics/i18n";
import { ARCHITECTURE_STATUS, notConnectedDelivery, notConnectedRenderer } from "../../../src/modules/analytics/contracts";
import { AI_TOPICS, ALERT_KINDS, ALERT_STATUS, CATEGORIES, DASHBOARD_CODES, DEFAULT_PERMISSIONS, DIMENSIONS, FORECASTS, FORMATS, METRIC_CATALOG, PERMISSIONS, SEVERITY, UNITS, WIDGET_CATALOG } from "../../../src/modules/analytics/domain";
import { ANALYTICS_BLUEPRINT } from "../../../src/modules/analytics/employee";

const SRC = join(process.cwd(), "src");
const files = (dir: string): string[] => { try { return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.(ts|tsx)$/.test(f) ? [p] : []; }); } catch { return []; } };
const imports = (f: string) => [...readFileSync(f, "utf8").matchAll(/from\s+["']([^"']+)["']/g)].map((m) => m[1] as string);
const MOD = join(SRC, "modules", "analytics");
const bad = (dirs: string[], re: RegExp) => dirs.flatMap((d) => files(d)).flatMap((f) => imports(f).filter((i) => re.test(i)).map((i) => `${relative(SRC, f)} -> ${i}`));
const UI = [join(SRC, "components", "analytics"), join(SRC, "app", "(app)", "app", "analytics")];
const strip = (s: string) => s.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, "");

describe("Analytics module boundaries", () => {
  it("never touches Drizzle, database internals, kernel internals or other product modules", () => {
    expect(bad([MOD], /drizzle-orm|platform\/db|ai-kernel\/|ai-employees\/|platform\/dashboard|components\/dashboard|modules\/(marketing|seo|ai-studio|finance|communications|crm|billing|security)/)).toEqual([]);
  });
  it("only the store layer knows SQL; no provider host and no network call exist in the module", () => {
    expect(files(MOD).filter((f) => /\b(SELECT|INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/.test(readFileSync(f, "utf8"))).map((f) => relative(MOD, f))).toEqual(["store-d1.ts"]);
    expect(files(MOD).filter((f) => /api\.openai\.com|api\.anthropic\.com|smtp\.|sendgrid|mailgun|googleapis\.com|api\.stripe\.com/.test(readFileSync(f, "utf8")))).toEqual([]);
    expect(files(MOD).filter((f) => /(?<![.\w])fetch\(|XMLHttpRequest|new WebSocket|node:https?|node:net/.test(strip(readFileSync(f, "utf8")))).map((f) => relative(MOD, f))).toEqual([]);
  });
  it("PDF/Excel/PowerPoint rendering and email/share delivery are contracts that are not connected by default", async () => {
    expect((await notConnectedRenderer.render("pdf", {})).ok).toBe(false);
    expect(await notConnectedDelivery.deliver({ channel: "email", to: "a@b.co", exportId: "x" })).toMatchObject({ delivered: false });
    expect(ARCHITECTURE_STATUS.pdf_excel_powerpoint_exports).toBe("interface_only"); expect(ARCHITECTURE_STATUS.email_share_delivery).toBe("interface_only");
  });
  it("UI uses the module's public interface only", () => {
    expect(bad(UI, /platform\/db|drizzle|modules\/analytics\/(store|columns|runtime|ai|server)|modules\/(crm|marketing|seo|finance|ai-studio|communications|billing|security)|components\/(crm|marketing|seo|finance|ai-studio|communications|billing|security)/)).toEqual([]);
  });
  it("frozen code does not know Analytics; it joins through startup registration only", () => {
    const frozen = ["platform/db", "platform/auth", "platform/ai-kernel", "platform/ai-employees", "platform/dashboard", "modules/crm", "modules/marketing", "modules/seo", "modules/ai-studio", "modules/finance", "modules/communications", "modules/billing", "modules/security"].map((d) => join(SRC, d));
    expect(bad(frozen, /modules\/analytics|components\/analytics/)).toEqual([]);
    const ins = readFileSync(join(SRC, "instrumentation.ts"), "utf8"); expect(ins).toContain("registerAnalyticsWidget"); expect(ins).toContain("registerAnalyticsEmployee");
  });
  it("registers exactly one widget: analytics-overview", () => {
    const w = readFileSync(join(SRC, "components", "analytics", "DashboardWidget.tsx"), "utf8");
    expect([...w.matchAll(/registerWidget</g)]).toHaveLength(1); expect(w).toContain('id: "analytics-overview"');
  });
  it("client components do not import server-only parts", () => {
    const client = UI.flatMap(files).filter((f) => /^\s*["']use client["']/.test(readFileSync(f, "utf8")));
    expect(client.length).toBeGreaterThanOrEqual(5);
    expect(client.flatMap((f) => imports(f).filter((i) => /modules\/analytics$|modules\/analytics\/(service|server|http|store|runtime|ai)/.test(i)))).toEqual([]);
  });
  it("adds exactly one product module slug, open to executives and administrators", () => {
    expect(MODULES).toHaveLength(29); expect(MODULES.filter((m) => m.slug === "analytics")).toHaveLength(1);
    expect(readFileSync(join(MOD, "http.ts"), "utf8")).toContain('ANALYTICS_SLUG = "analytics"');
    expect(canAccess("owner", "analytics")).toBe(true); expect(canAccess("guest", "analytics")).toBe(false);
  });
  it("the Executive Advisor is read only: its blueprint offers no write capability", () => {
    expect((ANALYTICS_BLUEPRINT.capabilities as readonly string[]).every((c) => /^analytics\.(read_summary|analyze_|executive_summary|predict_|recommend_actions|detect_risks|weekly_report|monthly_report|quarterly_report)/.test(c))).toBe(true);
    expect(ANALYTICS_BLUEPRINT.maxAutonomy).toBe(1); expect(ANALYTICS_BLUEPRINT.defaultInstructions).toMatch(/read only/);
    expect(AI_TOPICS).toHaveLength(15);
  });
});

describe("API surface: only /api/v1/analytics/*", () => {
  const API = join(SRC, "app", "api", "v1", "analytics");
  const routes = files(API).filter((f) => f.endsWith("route.ts"));
  it("every handler goes through analyticsRoute; every mutating verb enables CSRF checks", () => {
    expect(routes.length).toBeGreaterThanOrEqual(45);
    for (const f of routes) {
      const src = readFileSync(f, "utf8");
      for (const m of src.matchAll(/export const (GET|POST|PATCH|PUT|DELETE) = (\w+)/g)) {
        expect(m[2], `${relative(SRC, f)} ${m[1]}`).toBe("analyticsRoute");
        const decl = src.slice(src.indexOf(m[0])), next = decl.indexOf("\nexport const", 10), block = decl.slice(0, next === -1 ? decl.length : next);
        if (m[1] !== "GET") expect(block, `${relative(SRC, f)} ${m[1]}`).toContain("mutating: true"); else expect(block).not.toContain("mutating");
      }
    }
  });
  it("there is no public inbound endpoint and no outbound call", () => {
    expect(routes.filter((f) => !readFileSync(f, "utf8").includes("analyticsRoute"))).toEqual([]);
    expect(routes.filter((f) => /fetch\(/.test(readFileSync(f, "utf8")))).toEqual([]);
  });
  it("covers every section, the actions, downloads and the 15 Advisor topics", () => {
    const rel = new Set(routes.map((f) => relative(API, f).replace(/\/?route\.ts$/, "")));
    for (const p of ["setup", "summary", "dashboards", "dashboards/[id]/view", "widgets", "metrics", "metrics/record", "metrics/series", "kpis", "goals", "goals/evaluate", "predictions", "reports", "reports/[id]/exports", "exports", "exports/[id]/download", "exports/[id]/deliver", "schedules", "schedules/run-due", "filters", "snapshots", "alerts", "alerts/evaluate", "alerts/[id]/acknowledge", "alerts/[id]/resolve", "alerts/[id]/dismiss", "notifications", "notifications/read-all", "notifications/[id]/read", "permissions", "permissions/mine", "audit", "audit/verify", "ai/summaries", "ai/[id]"]) expect(rel.has(p), p).toBe(true);
  });
});

describe("pages", () => {
  it("has the 13 views", () => {
    const base = join(SRC, "app", "(app)", "app", "analytics"), pages = new Set(files(base).filter((f) => f.endsWith("page.tsx")).map((f) => relative(base, f).replace(/\/?page\.tsx$/, "")));
    expect([...pages].sort()).toEqual(["", "advisor", "alerts", "exports", "forecast", "goals", "kpis", "metrics", "notifications", "reports", "schedules", "settings", "widgets"]);
  });
});

describe("migration 0900_analytics.sql", () => {
  const sql = readFileSync(join(process.cwd(), "drizzle/migrations/0900_analytics.sql"), "utf8");
  const tables = [...sql.matchAll(/CREATE TABLE `(analytics_\w+)` \(([\s\S]*?)\n\);/g)];
  it("creates exactly the 18 analytics_* tables and touches nothing else", () => {
    expect(tables).toHaveLength(18);
    expect(Object.values(TABLE).sort()).toEqual(tables.map((t) => t[1]).sort());
    for (const n of ["dashboards", "widgets", "widget_layouts", "metrics", "metric_values", "kpis", "goals", "predictions", "reports", "report_exports", "report_schedules", "filters", "snapshots", "alerts", "notifications", "ai_summaries", "permissions", "audit"]) expect(Object.values(TABLE)).toContain(`analytics_${n}`);
    expect(sql.replace(/^--.*$/gm, "")).not.toMatch(/ALTER TABLE|DROP TABLE|DROP INDEX|INSERT INTO|DELETE FROM/);
    for (const o of sql.matchAll(/CREATE (?:UNIQUE )?INDEX `(\w+)`/g)) expect(o[1]).toMatch(/^analytics_/);
    for (const o of sql.matchAll(/CREATE TRIGGER (\w+)/g)) expect(o[1]).toMatch(/^analytics_/);
  });
  it("every table is tenant-owned with cascade and tenant-first indexes", () => {
    for (const [, name, body] of tables) {
      expect(body, name).toContain("`tenant_id` text NOT NULL");
      expect(body, name).toContain("FOREIGN KEY (`tenant_id`) REFERENCES `companies`(`id`)");
      for (const ix of sql.matchAll(new RegExp(`CREATE (?:UNIQUE )?INDEX \`\\w+\` ON \`${name}\` \\(([^)]*)\\)`, "g"))) expect(ix[1], name).toMatch(/^`tenant_id`/);
    }
  });
  it("the database enforces tenant freezing and append-only ledgers", () => {
    for (const t of Object.values(TABLE)) expect(sql, t).toContain(`${t}_tenant_frozen`);
    for (const t of ["metric_values", "predictions", "report_exports", "snapshots", "ai_summaries", "audit"]) { expect(sql).toContain(`analytics_${t}_immutable`); expect(sql).toContain(`analytics_${t}_no_delete`); }
  });
  it("whitelists cover each kind and carry the tenant column", () => {
    for (const k of Object.keys(TABLE) as (keyof typeof TABLE)[]) { expect(COLUMNS[k]).toContain("id"); expect(COLUMNS[k]).toContain("tenantId"); }
  });
});

describe("catalog, permissions and texts", () => {
  it("the catalog covers every card, graph, KPI, widget and dashboard of the specification", () => {
    expect(DASHBOARD_CODES).toHaveLength(10); expect(WIDGET_CATALOG.length).toBeGreaterThanOrEqual(45);
    const m = new Set<string>(METRIC_CATALOG.map((x) => x.code));
    for (const c of ["revenue_today", "revenue_month", "mrr", "arr", "profit", "expenses", "cash_flow", "customers", "active_users", "new_customers", "lost_customers", "ai_credits", "ai_consumption", "health_score", "security_score", "marketing_score", "seo_score", "system_status", "cac", "ltv", "roi", "roas", "ctr", "cpc", "cpa", "conversion_rate", "average_ticket", "support_time", "csat", "nps", "churn", "core_web_vitals", "google_position", "organic_traffic", "credits_consumption", "tokens", "automation_runs", "margin"]) expect(m.has(c), c).toBe(true);
    expect(FORECASTS).toHaveLength(11); expect(ALERT_KINDS).toHaveLength(16); expect(DIMENSIONS).toHaveLength(11); expect(PERMISSIONS).toHaveLength(12); expect([...FORMATS].sort()).toEqual(["api", "csv", "excel", "json", "pdf", "powerpoint"]);
  });
  it("module access is the outer gate; default capabilities only narrow it", () => {
    for (const r of ROLES) { if (!canAccess(r, "analytics")) expect(DEFAULT_PERMISSIONS[r].length, r).toBe(0); else expect(DEFAULT_PERMISSIONS[r].includes("view_dashboard"), r).toBe(true); }
    expect(DEFAULT_PERMISSIONS.owner).toHaveLength(PERMISSIONS.length);
  });
  it("English and Spanish have the same keys, and every vocabulary used by the UI has texts", () => {
    const en = ANALYTICS_DICTIONARIES.en as Record<string, string>, es = ANALYTICS_DICTIONARIES.es as Record<string, string>;
    expect(Object.keys(es).sort()).toEqual(Object.keys(en).sort());
    for (const k of SEVERITY) expect(en[`sev.${k}`], k).toBeDefined();
    for (const k of ALERT_STATUS) expect(en[`st.${k}`], k).toBeDefined();
    for (const k of UNITS) expect(en[`unit.${k}`], k).toBeDefined();
    for (const k of CATEGORIES) expect(en[`cat.${k}`], k).toBeDefined();
    for (const k of DIMENSIONS) expect(en[`dim.${k}`], k).toBeDefined();
    for (const k of FORMATS) expect(en[`fmt.${k}`], k).toBeDefined();
    for (const k of FORECASTS) expect(en[`fc.${k}`], k).toBeDefined();
    for (const k of AI_TOPICS) expect(en[`topic.${k}`], k).toBeDefined();
    for (const k of ALERT_KINDS) expect(en[`alertkind.${k}`], k).toBeDefined();
    for (const k of PERMISSIONS) expect(en[`perm.${k}`], k).toBeDefined();
    for (const k of METRIC_CATALOG) expect(en[`metric.${k.code}`], k.code).toBeDefined();
    for (const k of DASHBOARD_CODES) expect(en[`dashname.${k}`], k).toBeDefined();
    for (const k of WIDGET_CATALOG) expect(en[`widgetname.${k.code}`], k.code).toBeDefined();
    for (const [k, v] of Object.entries(es)) expect(v.trim(), k).not.toBe("");
  });
});
